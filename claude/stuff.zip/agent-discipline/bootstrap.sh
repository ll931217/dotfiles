#!/bin/sh
# agent-discipline bootstrap — clone (or update) the repo, then run its installer.
#
#   glab api "projects/liangshih.lin%2Fagent-discipline/repository/files/bootstrap.sh/raw?ref=master" | sh
#
# Not plain curl: the web /-/raw/ route redirects to sign_in for an internal project even with
# a PRIVATE-TOKEN header — it wants a browser session. The API route accepts a token, and glab
# already holds one. Fall back to: git clone <ssh url> && ./install.sh
#
# Env:
#   AGENT_DISCIPLINE_DIR   where to clone       (default: $HOME/GitLab/agent-discipline)
#   AGENT_DISCIPLINE_REPO  git URL to clone     (default: the internal GitLab repo)
#   AGENT_DISCIPLINE_REF   branch/tag to check out (default: main)
#   INSTALL_ARGS           passed to install.sh (e.g. INSTALL_ARGS=--cron)
#
# POSIX sh on purpose: this runs under `sh`, not bash. No prompts either — piped into sh
# there is no TTY, so anything interactive would hang or silently read your script.
set -eu

DIR="${AGENT_DISCIPLINE_DIR:-$HOME/GitLab/agent-discipline}"
REPO="${AGENT_DISCIPLINE_REPO:-ssh://git@gitlab.data.vici.corp:8022/liangshih.lin/agent-discipline.git}"
REF="${AGENT_DISCIPLINE_REF:-master}"
ARGS="${INSTALL_ARGS:-}"

printf 'agent-discipline bootstrap\n  repo   %s\n  ref    %s\n  target %s\n\n' "$REPO" "$REF" "$DIR"

command -v git >/dev/null 2>&1 || {
  echo "git is required"
  exit 1
}
command -v python3 >/dev/null 2>&1 || {
  echo "python3 is required"
  exit 1
}

if [ -d "$DIR/.git" ]; then
  echo "already cloned — updating"
  # Never discard local work silently; a dirty checkout stops the bootstrap.
  if [ -n "$(git -C "$DIR" status --porcelain 2>/dev/null)" ]; then
    echo "  local changes present in $DIR — not touching it."
    echo "  commit or stash them, then re-run. Skipping to install with what is on disk."
  else
    git -C "$DIR" fetch --quiet origin "$REF"
    git -C "$DIR" checkout --quiet "$REF"
    git -C "$DIR" merge --ff-only --quiet "origin/$REF" || {
      echo "  could not fast-forward $DIR — resolve it by hand, then re-run"
      exit 1
    }
    echo "  updated to $(git -C "$DIR" rev-parse --short HEAD)"
  fi
else
  mkdir -p "$(dirname "$DIR")"
  git clone --quiet --branch "$REF" "$REPO" "$DIR" || {
    echo "clone failed. Two usual causes on this network:"
    echo "  * SSH is on port 8022, not 22 — a bare git@host:path URL will fail"
    echo "  * the proxy: .vici.corp must be in NO_PROXY for the internal GitLab"
    exit 1
  }
  echo "  cloned $(git -C "$DIR" rev-parse --short HEAD)"
fi

[ -x "$DIR/install.sh" ] || {
  echo "install.sh missing or not executable in $DIR"
  exit 1
}
echo
# shellcheck disable=SC2086
exec "$DIR/install.sh" $ARGS
