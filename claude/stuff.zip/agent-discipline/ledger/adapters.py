"""Source adapters: Memory Kit, Canon, Ledger.

Each answers `query()` with normalized `KnowledgeCandidate`s and `health()` with a `SourceHealth`
(R-066, R-120). Reading a source's FILES is deliberate — the spec says reuse existing contracts
rather than import internals (§2), and neither memory-kit nor canon exposes an API here.

A source that fails does not raise into a hook. It reports `degraded`, and the resolver carries
that into the manifest's `degradedSources` so a thin answer is never mistaken for a confident one.
"""
from __future__ import annotations

import dataclasses
import os
import re

from .compat import read_all
from .types import LedgerEntry, Lifecycle, RetrievalMetadata, Scope, decision_key

CANON_AUTHORITY = "approved_team_decision"
"""Canon is human-merged, team-wide discipline, which is exactly what this enum value means.
NOT `hard_policy`: that is the one authority a current task instruction may never override
(R-031), and reserving it for rules explicitly marked mandatory keeps that meaningful."""


@dataclasses.dataclass(frozen=True)
class SourceHealth:
    source: str
    available: bool
    detail: str = ""
    item_count: int = 0

    @property
    def degraded(self):
        return not self.available


@dataclasses.dataclass(frozen=True)
class KnowledgeCandidate:
    """One normalized answer from one source (R-066). `why` records which retrieval tier found
    it, so a receipt can say more than 'it matched'."""
    source_system: str
    source_id: str
    entry: LedgerEntry
    why: str = "unspecified"

    @property
    def authority(self):
        return self.entry.authority


class Adapter:
    name = "adapter"

    def health(self):
        raise NotImplementedError

    def query(self, req):
        raise NotImplementedError


class LedgerAdapter(Adapter):
    """The user's `pref-*.md` records, read through the Phase 1 compatibility projection.
    Queries the ACTIVE PROJECTION by exact decision key and structured scope BEFORE any
    lexical fallback (R-076)."""
    name = "ledger"

    def __init__(self, topics_dir, projection_factory=None):
        self.topics_dir = topics_dir
        self._factory = projection_factory
        self._proj = None
        self._skipped = []

    def _projection(self):
        if self._proj is None:
            from .projection import ActiveProjection
            entries, self._skipped = read_all(self.topics_dir)
            self._proj = (self._factory or ActiveProjection)(entries)
        return self._proj

    def health(self):
        if not os.path.isdir(self.topics_dir):
            return SourceHealth(self.name, False, f"no ledger directory: {self.topics_dir}")
        p = self._projection()
        detail = ""
        if self._skipped:
            detail = (f"{len(self._skipped)} pref-* file(s) unreadable and therefore invisible to "
                      f"retrieval: {', '.join(fn for fn, _ in self._skipped[:3])}")
        return SourceHealth(self.name, True, detail, len(p.active))

    def query(self, req):
        p = self._projection()
        out, seen = [], set()
        for e in p.rank(p.by_decision_key(req.decision_key) if req.decision_key else []):
            seen.add(e.id)
            out.append(KnowledgeCandidate(self.name, e.id, e, "exact_decision_key"))
        for e in p.rank(p.by_scope(req.scope_context())):
            if e.id not in seen:
                seen.add(e.id)
                out.append(KnowledgeCandidate(self.name, e.id, e, "scope_match"))
        # Lexical last, and only over what scope did not already return (R-063: semantic
        # fallback sits BELOW every structured tier).
        for e in p.rank(p.active):
            if e.id in seen:
                continue
            if _lexical_hit(req.terms(), e):
                seen.add(e.id)
                out.append(KnowledgeCandidate(self.name, e.id, e, "lexical_fallback"))
        return out


class CanonAdapter(Adapter):
    """Canon disciplines. Nothing in this repository has ever queried canon — it reaches the
    model only as always-load rule text — so this is the first code path that treats it as a
    source with authority rather than as prose."""
    name = "canon"

    RULE = re.compile(
        r"^## (?P<id>[A-Z][A-Z0-9]*\d+):\s*(?P<title>.+?)\s*$\n"
        r"(?:<!-- key: (?P<key>[0-9a-f]+) -->\s*$\n)?"
        r"(?:<!-- triggers: (?P<triggers>.*?) -->\s*$\n)?",
        re.M)

    def __init__(self, disciplines_dir):
        self.dir = disciplines_dir
        self._entries = None

    def _load(self):
        if self._entries is not None:
            return self._entries
        out = []
        try:
            names = sorted(os.listdir(self.dir))
        except OSError:
            self._entries = []
            return self._entries
        for fn in names:
            if not fn.endswith(".md") or fn.startswith("INDEX"):
                continue
            domain = fn[:-3]
            try:
                text = open(os.path.join(self.dir, fn), encoding="utf-8", errors="replace").read()
            except OSError:
                continue
            for m in self.RULE.finditer(text):
                rid, title = m.group("id"), m.group("title")
                triggers = tuple(t.strip() for t in (m.group("triggers") or "").split(",")
                                 if t.strip())
                out.append(LedgerEntry(
                    id=f"canon:{domain}:{rid}", version=1, kind="policy",
                    subject=f"{domain}: {rid}", statement=title,
                    scope=Scope(organization="canon"),
                    authority=CANON_AUTHORITY, status="active",
                    autonomy="mandatory", risk="medium",
                    created_by="canon", created_at="published",
                    source_references=(f"file:{os.path.join(self.dir, fn)}",
                                       f"canon_key:{m.group('key') or 'none'}"),
                    retrieval=RetrievalMetadata(trigger_terms=triggers,
                                                decision_keys=(decision_key(f"{domain}-{rid}"),)),
                    lifecycle=Lifecycle(created_at="published")))
        self._entries = out
        return out

    def health(self):
        if not os.path.isdir(self.dir):
            return SourceHealth(self.name, False,
                                f"canon not installed at {self.dir}; team rules are UNAVAILABLE, "
                                f"not absent")
        n = len(self._load())
        return SourceHealth(self.name, n > 0, "" if n else "canon present but no rules parsed", n)

    def query(self, req):
        terms = req.terms()
        return [KnowledgeCandidate(self.name, e.id, e, "canon_trigger")
                for e in self._load() if _lexical_hit(terms, e)]


class MemoryKitAdapter(Adapter):
    """Memory-kit topic files that are NOT ledger records. They carry project facts and gotchas,
    which the spec's model calls `fact` — observation-grade, and deliberately ranked below any
    approved rule (R-006)."""
    name = "memory_kit"

    def __init__(self, topics_dir):
        self.dir = topics_dir
        self._entries = None

    def _load(self):
        if self._entries is not None:
            return self._entries
        out = []
        try:
            names = sorted(os.listdir(self.dir))
        except OSError:
            self._entries = []
            return self._entries
        from .compat import parse_frontmatter
        for fn in names:
            if not fn.endswith(".md") or fn.startswith("pref-"):
                continue          # pref-* belongs to the ledger adapter, not here
            path = os.path.join(self.dir, fn)
            try:
                raw = open(path, encoding="utf-8", errors="replace").read()
            except OSError:
                continue
            fm, body = parse_frontmatter(raw)
            desc = (fm.get("description") or fn[:-3]).strip()
            out.append(LedgerEntry(
                id=f"memory:{fn[:-3]}", version=1, kind="fact",
                subject=desc.split(".")[0][:200] or fn[:-3],
                statement=desc[:400] or fn[:-3],
                scope=Scope(), authority="reviewed_human_observation", status="active",
                autonomy="advisory", risk="low",
                created_by="memory_kit", created_at=fm.get("modified") or "unknown",
                source_references=(f"file:{path}",),
                retrieval=RetrievalMetadata(
                    trigger_terms=tuple(t.strip() for t in (fm.get("triggers") or "").split(",")
                                        if t.strip())),
                lifecycle=Lifecycle(created_at=fm.get("modified") or "unknown")))
        self._entries = out
        return out

    def health(self):
        if not os.path.isdir(self.dir):
            return SourceHealth(self.name, False, f"no memory directory: {self.dir}")
        return SourceHealth(self.name, True, "", len(self._load()))

    def query(self, req):
        terms = req.terms()
        return [KnowledgeCandidate(self.name, e.id, e, "memory_trigger")
                for e in self._load() if _lexical_hit(terms, e)]


def _lexical_hit(terms, entry, minimum=2):
    """Deliberately the same shape as the existing hook's matcher: triggers weigh double. This
    is the LOWEST retrieval tier and it can never widen authority (R-003) — it only decides
    whether a candidate is seen at all."""
    if not terms:
        return False
    score = 0
    hay = f"{entry.subject} {entry.statement}".lower()
    for t in entry.retrieval.trigger_terms:
        tl = t.lower()
        if tl in terms or any(tl in x for x in terms if len(tl) > 3):
            score += 2
    for t in terms:
        if len(t) > 3 and t in hay:
            score += 1
    return score >= minimum
