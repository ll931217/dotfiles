"""The active projection: what is in force right now, and how it is found.

A hook must not replay full event history to answer a question (R-057), so this is a
materialized view built once and queried cheaply. It is rebuildable from entries at any time,
which is the cheaper half of R-059's "transactional with event writes, or safely rebuildable".
"""
from __future__ import annotations

from .types import AUTHORITIES, decision_key


class ActiveProjection:
    """Holds only entries that are active AND in date. Everything else is reachable through the
    entry list, but never through a query — an expired entry answering a lookup is the bug this
    class exists to prevent."""

    def __init__(self, entries, now=None):
        self.now = now
        self.all = list(entries)
        self.active = [e for e in self.all if e.is_active(now)]
        self._by_key = {}
        for e in self.active:
            for k in (e.retrieval.decision_keys or (decision_key(e.subject, e.scope),)):
                self._by_key.setdefault(k, []).append(e)

    # --- R-058: what the projection must expose ------------------------------------------

    def row(self, e):
        return {
            "id": e.id, "version": e.version, "status": e.status,
            "scope": e.scope.declared(), "authority": e.authority,
            "last_validated_at": e.lifecycle.last_validated_at,
            "last_validated_revision": e.lifecycle.last_validated_revision,
            "superseded_by": e.lifecycle.superseded_by,
            "supersedes": list(e.lifecycle.supersedes),
            "evidence": len(e.evidence_ids),
            "subject": e.subject, "statement": e.statement,
            "stale": e.is_stale(self.now),
        }

    def rows(self):
        return [self.row(e) for e in self.active]

    # --- retrieval ------------------------------------------------------------------------

    def by_decision_key(self, key):
        """Exact key first (R-063, R-076). Exact means exact — no normalization beyond what
        decision_key() already did, or 'exact' stops meaning anything."""
        return list(self._by_key.get(key, ()))

    def by_scope(self, ctx):
        """Every entry whose DECLARED dimensions all match the context (R-021).

        An entry declaring no dimension is excluded here. It is not "constrained to nothing and
        therefore relevant to everything" — an undeclared dimension does not constrain (R-020),
        which cuts both ways: it cannot be the reason the entry was retrieved either. Measured:
        with all 25 of today's records unscoped, treating them as scope matches returned the
        entire ledger for every prompt. Unscoped entries reach the manifest through the exact
        decision key or the lexical tier, where they have to earn it."""
        return [e for e in self.active if e.scope.declared() and e.scope.matches(ctx)]

    def rank(self, entries):
        """Authority first, then specificity within one authority class. Never the other way:
        a narrower scope must not weaken a higher authority (R-004), and a user-scoped preference
        must not outrank team or organization policy (R-005)."""
        return sorted(entries, key=lambda e: (e.authority_rank(), e.scope.specificity(), e.id))

    def resolve(self, ctx, key=None):
        """The ordered result for one lookup, with the reason each item is there — the raw
        material of a context receipt."""
        seen, out = set(), []
        for e in self.rank(self.by_decision_key(key) if key else []):
            seen.add(e.id)
            out.append((e, "exact_decision_key"))
        for e in self.rank(self.by_scope(ctx)):
            if e.id not in seen:
                seen.add(e.id)
                out.append((e, "scope_match"))
        return out

    def conflicts(self, entries):
        """Same subject, incompatible statements. Grouped so precedence is applied to a group
        rather than silently resolved by sort order."""
        groups = {}
        for e in entries:
            groups.setdefault(e.subject.strip().lower(), []).append(e)
        out = []
        for subject, group in sorted(groups.items()):
            if len(group) < 2:
                continue
            statements = {e.statement.strip() for e in group}
            if len(statements) > 1:
                ranked = self.rank(group)
                out.append({"subject": subject, "winner": ranked[0],
                            "losers": ranked[1:],
                            "decided_by": ("authority" if ranked[0].authority != ranked[1].authority
                                           else "scope_specificity")})
        return out

    def stale(self):
        return [e for e in self.active if e.is_stale(self.now)]


def authority_beats(a, b):
    return AUTHORITIES.index(a) < AUTHORITIES.index(b)
