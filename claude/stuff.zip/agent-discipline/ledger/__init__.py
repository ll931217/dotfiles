"""Typed ledger core for the Ledger Context Governor.

Deliberately free of any Claude Code hook payload type (spec §7.16 / R-013): hooks parse their
own payloads and call in here with plain values. That separation does not exist anywhere else in
this repository yet, and retrofitting it later is expensive, so it starts here.

Runs on Python 3.12 — hooks execute as `#!/usr/bin/env python3`, the system interpreter, not the
uv environment that pyproject.toml's `requires-python = ">=3.14"` describes.
"""
