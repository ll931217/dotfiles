"""Decision needs: normalization, stable keys, intent, risk, and answer classification.

Raw question text is not a durable key (P4-01). Two people asking the same thing in different
words must land on the same key, and two people asking different things must not — the second
half is the one that costs correctness, so where normalization is unsure it keeps the keys
SEPARATE rather than merging (P4-05).
"""
from __future__ import annotations

import dataclasses
import hashlib
import re

INTENTS = ("apply_established", "choose_new", "change_established", "verify_fact")
RISKS = ("trivial", "low", "medium", "high", "critical")

ANSWER_CLASSES = ("task_choice", "personal_preference", "team_convention",
                  "architectural_decision", "factual_correction", "temporary_workaround",
                  "exception", "rejection", "insufficient_to_classify")

ANSWER_SOURCES = ("human", "ledger", "canon", "memory_kit", "current_task_cache", "stop_recovery")

# P4-27. A question touching any of these is answered by a person, in every mode, forever. The
# list is matched against the question text; a miss costs a prediction, a false match costs
# nothing at all in shadow mode, so it is deliberately generous.
MANDATORY_HUMAN = {
    "public_api": r"\b(public api|wire format|protocol|backward.compat|back.compat|breaking change)\b",
    "schema": r"\b(schema|migration|alter table|drop column|drop table)\b",
    "data_semantics": r"\b(trading calendar|timestamp semantics|derivation|raw data|financial)\b",
    "security": r"\b(auth|authorization|authentication|access control|secret|credential|crypto|"
                r"permission boundar)\w*\b",
    "destructive": r"\b(delete|drop|truncate|purge|irreversible|destructive|wipe)\b",
    "compliance": r"\b(legal|complian|audit|retention polic|gdpr)\w*\b",
    "production": r"\b(production infra|deployment topolog|prod cluster|failover)\w*\b",
    "customer_visible": r"\b(customer.visible|user.facing behaviour|user.facing behavior)\b",
    "expensive": r"\b(vendor|licence|license cost|platform choice|hard to reverse)\b",
}

CHANGE_ESTABLISHED = r"\b(instead of|change|replace|move away from|stop using|switch from|" \
                     r"override|reverse|revisit)\b"
VERIFY = r"\b(is it true|does it|are we|confirm|verify|correct\?|right\?)\b"

STOP_WORDS = {"the", "a", "an", "and", "or", "for", "to", "of", "in", "on", "we", "i", "you",
              "should", "would", "could", "do", "does", "did", "is", "are", "be", "this", "that",
              "it", "with", "use", "using", "want", "like", "please", "which", "what", "how",
              "when", "shall", "may", "can", "there", "here", "my", "our", "your"}


def normalize_subject(text):
    """Canonical subject. Incidental wording, punctuation and case are removed (P4-04); the
    surviving content words, sorted, are what identity is built from."""
    words = re.findall(r"[a-z0-9]+(?:[-_][a-z0-9]+)*", (text or "").lower())
    kept = [w for w in words if w not in STOP_WORDS and len(w) > 1]
    return " ".join(sorted(set(kept)))


def normalize_option(text):
    """Options are IDENTITIES, not prose. The subject normalizer drops stopwords and one-letter
    tokens, which erased labels like `a` / `b` / `pg` entirely and made two questions offering
    different choices produce the same key. Lowercase and strip punctuation; keep everything else.
    """
    return " ".join(re.findall(r"[a-z0-9]+", (text or "").lower()))


def classify_intent(question, has_established=False):
    q = (question or "").lower()
    if re.search(CHANGE_ESTABLISHED, q) and has_established:
        return "change_established"
    if re.search(VERIFY, q):
        return "verify_fact"
    return "apply_established" if has_established else "choose_new"


def mandatory_human_reasons(text):
    """Every category the text touches. Empty means no mandatory category matched — which is
    not the same as 'safe', only 'not on this list'."""
    low = (text or "").lower()
    return sorted(k for k, pat in MANDATORY_HUMAN.items() if re.search(pat, low))


def classify_risk(text):
    reasons = mandatory_human_reasons(text)
    if not reasons:
        return "low"
    if {"destructive", "security", "compliance"} & set(reasons):
        return "critical"
    if {"schema", "production", "public_api"} & set(reasons):
        return "high"
    return "medium"


@dataclasses.dataclass(frozen=True)
class DecisionNeed:
    """One normalized question. `original_text` is kept for audit even though the key ignores
    it (P4-02) — a key you cannot trace back to what was actually asked is unauditable."""
    original_text: str
    subject: str
    intent: str
    risk: str
    scope: dict = dataclasses.field(default_factory=dict)
    constraints: tuple = ()
    options: tuple = ()
    operation: str = ""
    mandatory_human: tuple = ()
    normalization_confident: bool = True

    @property
    def key(self):
        """P4-03. Option ORDER is excluded deliberately; the option SET is not, because a
        question offering different choices is a different question.

        When normalization is not confident the key carries a per-question salt, so two
        uncertain needs stay separate rather than being merged by accident (P4-05)."""
        parts = [self.intent, self.subject, self.operation,
                 "|".join(f"{k}={v}" for k, v in sorted(self.scope.items())),
                 "|".join(sorted(self.constraints)),
                 "|".join(sorted(normalize_option(o) for o in self.options))]
        if not self.normalization_confident:
            parts.append("unmerged:" + hashlib.sha1(
                self.original_text.encode()).hexdigest()[:8])
        return "dk_" + hashlib.sha1("\x1f".join(parts).encode()).hexdigest()[:16]


def need_from_question(question, header="", options=(), scope=None, operation="",
                       has_established=False):
    text = f"{header} {question}".strip()
    subject = normalize_subject(text)
    # Too little survived normalization to trust the key. Better two keys than one wrong merge.
    confident = len(subject.split()) >= 2
    return DecisionNeed(
        original_text=question,
        subject=subject,
        intent=classify_intent(question, has_established),
        risk=classify_risk(f"{text} {' '.join(options)}"),
        scope=dict(scope or {}),
        operation=operation,
        options=tuple(options),
        mandatory_human=tuple(mandatory_human_reasons(f"{text} {' '.join(options)}")),
        normalization_confident=confident,
    )


def classify_answer(answer, question="", actor_is_human=True):
    """P4-11/12: wording, task context, and who answered. Deliberately conservative — anything
    that does not clearly read as a durable rule is a task choice, and anything unreadable is
    `insufficient_to_classify` rather than a guess."""
    a = (answer or "").strip().lower()
    if not a:
        return "insufficient_to_classify"
    if not actor_is_human:
        return "insufficient_to_classify"
    if re.search(r"\b(no|don't|do not|never|stop|reject|not that)\b", a) and len(a.split()) <= 6:
        return "rejection"
    if re.search(r"\b(always|from now on|as a rule|convention|we standardi[sz]e|team)\b", a):
        return "team_convention"
    if re.search(r"\b(architecture|architectural|design decision|adr)\b", a):
        return "architectural_decision"
    if re.search(r"\b(actually|correction|that's wrong|incorrect|the real)\b", a):
        return "factual_correction"
    if re.search(r"\b(for now|temporar|workaround|just this once|hack)\w*\b", a):
        return "temporary_workaround"
    if re.search(r"\b(except|unless|only when|special case)\b", a):
        return "exception"
    if re.search(r"\b(i prefer|i like|i want|my preference)\b", a):
        return "personal_preference"
    return "task_choice"


@dataclasses.dataclass
class ResolvedNeed:
    """A human answer, cached for THIS task only (P4-13). Task-scoped by construction: there is
    no field that could widen it to a repository or a team, because auto-creating durable scope
    from one answer is exactly what P4-14 forbids without approval."""
    key: str
    answer: str
    answer_class: str
    source: str
    session_id: str
    task: str
    created_at: str
    scope_snapshot: dict = dataclasses.field(default_factory=dict)
    constraints: tuple = ()
    uses: int = 0

    def compatible_with(self, need, scope_now=None):
        """A cached answer applies only while the scope and constraints it was given under still
        hold (P4-08). Anything else is a different question wearing the same words."""
        if self.key != need.key:
            return False
        if scope_now is not None and self.scope_snapshot != dict(scope_now):
            return False
        return tuple(self.constraints) == tuple(need.constraints)

    def to_dict(self):
        return dataclasses.asdict(self)


class ResolvedNeedCache:
    def __init__(self, rows=None):
        self._rows = [ResolvedNeed(**r) for r in rows or []]

    def add(self, rn):
        self._rows.append(rn)
        return rn

    def find(self, need, scope_now=None):
        for r in self._rows:
            if r.compatible_with(need, scope_now):
                r.uses += 1
                return r
        return None

    def all(self):
        return list(self._rows)

    def to_list(self):
        return [r.to_dict() for r in self._rows]
