"""Manifest diffing: what materially changed between two manifests.

A delta carries ONLY material change (P3-17) and is `no_op` when there is none. The external
manifest stays complete; the model-visible delta stays minimal (P3-18). Re-injecting an unchanged
entry is not merely wasteful — it teaches the model that repetition means importance.
"""
from __future__ import annotations

import dataclasses
import uuid

MATERIAL = ("added", "removed", "invalidated", "superseded", "conflicts_added",
            "conflicts_resolved", "coverage_added", "coverage_invalidated",
            "resolved_needs_added", "assumptions_invalidated")


@dataclasses.dataclass
class ManifestDelta:
    """R-088."""
    delta_id: str
    session_id: str
    from_revision: int
    to_revision: int
    trigger: str
    generated_at: str
    discovered_scopes: list = dataclasses.field(default_factory=list)
    added: list = dataclasses.field(default_factory=list)
    removed: list = dataclasses.field(default_factory=list)
    invalidated: list = dataclasses.field(default_factory=list)
    superseded: list = dataclasses.field(default_factory=list)
    conflicts_added: list = dataclasses.field(default_factory=list)
    conflicts_resolved: list = dataclasses.field(default_factory=list)
    coverage_added: list = dataclasses.field(default_factory=list)
    coverage_invalidated: list = dataclasses.field(default_factory=list)
    resolved_needs_added: list = dataclasses.field(default_factory=list)
    assumptions_invalidated: list = dataclasses.field(default_factory=list)
    autonomy_boundary_changed: str = ""
    receipt_id: str = ""
    no_op: bool = True

    def to_dict(self):
        return dataclasses.asdict(self)

    def render(self):
        """What the model sees. Nothing at all when nothing changed — the correct output for a
        no-op is silence, not a note saying nothing happened."""
        if self.no_op:
            return ""
        out = [f"LEDGER CONTEXT UPDATE  {self.from_revision} -> {self.to_revision}",
               f"Triggered by: {self.trigger}"]
        if self.discovered_scopes:
            out.append("Newly in scope: " + ", ".join(self.discovered_scopes[:8]))
        for attr, title in (("added", "Now applies"),
                            ("removed", "No longer applies"),
                            ("invalidated", "Invalidated"),
                            ("superseded", "Superseded")):
            items = getattr(self, attr)
            if items:
                out.append(f"{title}:")
                out += [f"  - {i.get('statement', i.get('id'))}"
                        f"  [{i.get('authority', '?')}]" for i in items]
        if self.conflicts_added:
            out.append("New conflicts:")
            out += [f"  - {c['subject']}: {c['winner']} beats {', '.join(c['losers'])}"
                    for c in self.conflicts_added]
        if self.autonomy_boundary_changed:
            out.append(f"Autonomy boundary is now: {self.autonomy_boundary_changed}")
        if self.coverage_added:
            out.append(f"Coverage recorded for {len(self.coverage_added)} target(s).")
        return "\n".join(out)


def _items(manifest):
    out = {}
    for attr, _ in manifest.SECTIONS:
        for it in getattr(manifest, attr):
            out[it["id"]] = it
    return out


def diff(old, new, session_id, trigger, discovered=None, now=None):
    """The material difference between two manifests.

    Identity is the entry id. An entry whose STATEMENT changed counts as changed, because the
    text is what the model acts on — an id-only comparison would silently keep a superseded
    wording in context."""
    a, b = _items(old) if old else {}, _items(new)
    added = [b[i] for i in b if i not in a or b[i]["statement"] != a[i]["statement"]]
    removed = [a[i] for i in a if i not in b]
    invalidated = [it for it in removed if it.get("invalidated")]

    old_conf = {c["subject"]: c for c in (old.conflicts if old else [])}
    new_conf = {c["subject"]: c for c in new.conflicts}
    conflicts_added = [c for s, c in new_conf.items() if s not in old_conf]
    conflicts_resolved = [c for s, c in old_conf.items() if s not in new_conf]

    boundary = ""
    if old and old.autonomy_boundary != new.autonomy_boundary:
        boundary = new.autonomy_boundary

    d = ManifestDelta(
        delta_id="dlt_" + uuid.uuid4().hex[:8],
        session_id=session_id,
        from_revision=(old.revision if old else -1),
        to_revision=new.revision,
        trigger=trigger,
        generated_at=now or new.generated_at,
        discovered_scopes=list(discovered or []),
        added=added, removed=removed, invalidated=invalidated,
        superseded=[it for it in removed if it.get("superseded")],
        conflicts_added=conflicts_added, conflicts_resolved=conflicts_resolved,
        autonomy_boundary_changed=boundary,
        receipt_id=new.receipt_id,
    )
    d.no_op = not any(getattr(d, f) for f in MATERIAL) and not boundary
    return d
