"""Entry kinds, authority, scope, lifecycle, autonomy, risk, and retrieval metadata.

Enum values are the spec's own strings, verbatim. They are identifiers, so a tidier synonym is a
defect — see docs/lcg-requirements-phase1-2.md rows R-001, R-029, R-030, R-043, R-049.
"""
from __future__ import annotations

import dataclasses
import re
from typing import Optional

# --- enums, in the spec's order where the order carries meaning ---------------------------

KINDS = ("fact", "invariant", "policy", "decision", "preference", "heuristic",
         "assumption", "exception", "negative_preference", "constraint")            # R-001

# Highest authority first. Ordering IS the precedence rule (R-030); index = rank.
AUTHORITIES = ("hard_policy", "current_task_instruction", "approved_architectural_decision",
               "approved_team_decision", "approved_repository_decision",
               "explicit_human_preference", "reviewed_human_observation",
               "code_or_schema_observation", "repeated_agent_observation",
               "agent_inference", "generated_summary")                              # R-029/030

STATUSES = ("observed", "candidate", "approved", "active", "deprecated", "superseded",
            "rejected", "expired", "invalidated", "quarantined")                    # R-043

# observed->candidate->approved->active, and anything unsafe -> quarantined (R-044)
TRANSITIONS = {
    "observed": {"candidate", "quarantined"},
    "candidate": {"approved", "rejected", "quarantined"},
    "approved": {"active", "rejected", "quarantined"},
    "active": {"superseded", "deprecated", "expired", "invalidated", "quarantined"},
    "approved_": set(),
}

AUTONOMY = ("mandatory", "default", "advisory", "ask_before_applying", "never_auto_apply")  # R-049
RISKS = ("trivial", "low", "medium", "high", "critical")

# Most specific first. Used only WITHIN one authority class (R-027).
SPECIFICITY = ("task", "symbol", "path", "module", "service", "repository", "team",
               "organization")

ACTIVE_STATUSES = ("active",)


class LedgerError(ValueError):
    """A governance field is missing or not a permitted value."""


def _check(name, value, allowed):
    if value not in allowed:
        raise LedgerError(f"{name}={value!r} is not one of {', '.join(allowed)}")


@dataclasses.dataclass(frozen=True)
class Scope:
    """Every dimension is optional. A MISSING dimension means 'not constrained by this
    dimension' — never 'applies globally with authority' (R-020). That distinction is the whole
    reason this is a dataclass and not a dict."""
    organization: Optional[str] = None
    team: Optional[str] = None
    repository: Optional[str] = None
    service: Optional[str] = None
    module: Optional[str] = None
    path: Optional[str] = None
    symbol: Optional[str] = None
    task: Optional[str] = None
    branches: tuple = ()
    environments: tuple = ()
    actor_ids: tuple = ()

    def declared(self):
        """The dimensions this entry actually constrains."""
        return {f.name: getattr(self, f.name) for f in dataclasses.fields(self)
                if getattr(self, f.name) not in (None, ())}

    def matches(self, ctx):
        """A candidate must match EVERY dimension it declares (R-021). A dimension the context
        does not mention cannot satisfy a declared constraint — that is how a branch-specific
        fact leaks into an unrelated branch (R-022) and an environment-scoped entry gets applied
        elsewhere (R-023)."""
        for name, want in self.declared().items():
            got = ctx.get(name)
            if name in ("branches", "environments", "actor_ids"):
                if got is None or got not in want:
                    return False
            elif got != want:
                return False
        return True

    def specificity(self):
        """Rank within one authority class; lower is more specific. Unscoped sorts last (R-027)."""
        for i, dim in enumerate(SPECIFICITY):
            if getattr(self, dim, None):
                return i
        return len(SPECIFICITY)


@dataclasses.dataclass(frozen=True)
class RetrievalMetadata:
    """How an entry is FOUND. Separate from what it says, so retrieval can never widen
    authority (R-003)."""
    repositories: tuple = ()
    services: tuple = ()
    modules: tuple = ()
    path_globs: tuple = ()
    symbols: tuple = ()
    endpoints: tuple = ()
    datasets: tuple = ()
    tables: tuple = ()
    message_topics: tuple = ()
    dependencies: tuple = ()
    concepts: tuple = ()
    operations: tuple = ()
    decision_keys: tuple = ()
    trigger_terms: tuple = ()
    applies_when: tuple = ()


@dataclasses.dataclass(frozen=True)
class Lifecycle:
    created_at: str = ""
    effective_from: Optional[str] = None
    expires_at: Optional[str] = None
    last_validated_at: Optional[str] = None
    last_validated_revision: Optional[str] = None
    supersedes: tuple = ()
    superseded_by: Optional[str] = None
    invalidation_conditions: tuple = ()
    review_after: Optional[str] = None
    approved_by: Optional[str] = None
    approved_at: Optional[str] = None


@dataclasses.dataclass(frozen=True)
class LedgerEntry:
    """Required fields are required. An entry missing scope, authority, status or provenance is
    rejected at construction rather than silently treated as inactive later (R-002, R-047)."""
    id: str
    version: int
    kind: str
    subject: str
    statement: str
    scope: Scope
    authority: str
    status: str
    autonomy: str
    risk: str
    created_by: str
    created_at: str
    source_references: tuple = ()
    evidence_ids: tuple = ()
    retrieval: RetrievalMetadata = dataclasses.field(default_factory=RetrievalMetadata)
    lifecycle: Lifecycle = dataclasses.field(default_factory=Lifecycle)

    def __post_init__(self):
        for name in ("id", "subject", "statement", "created_by", "created_at"):
            if not str(getattr(self, name) or "").strip():
                raise LedgerError(f"{name} is required and was empty")
        if not isinstance(self.version, int) or self.version < 1:
            raise LedgerError(f"version must be a positive int, got {self.version!r}")
        _check("kind", self.kind, KINDS)
        _check("authority", self.authority, AUTHORITIES)
        _check("status", self.status, STATUSES)
        _check("autonomy", self.autonomy, AUTONOMY)
        _check("risk", self.risk, RISKS)
        if not isinstance(self.scope, Scope):
            raise LedgerError("scope must be a Scope; a bare dict cannot express "
                              "'not constrained by this dimension'")
        if self.lifecycle.approved_by and not self.lifecycle.approved_at:
            raise LedgerError("approved_by without approved_at: who granted authority and when "
                              "are recorded together or not at all (R-008)")

    # --- lifecycle ------------------------------------------------------------------------

    def authority_rank(self):
        return AUTHORITIES.index(self.authority)

    def is_active(self, now=None):
        """Active means the status says so AND the clock agrees."""
        if self.status not in ACTIVE_STATUSES:
            return False
        if self.lifecycle.expires_at and now and self.lifecycle.expires_at <= now:
            return False
        if self.lifecycle.effective_from and now and self.lifecycle.effective_from > now:
            return False
        return True

    def is_stale(self, now=None):
        """Past its review date but not yet expired. Surfacing one of these without a warning is
        forbidden (R-007), so the projection needs to be able to ask."""
        rev = self.lifecycle.review_after
        return bool(rev and now and rev <= now) and self.is_active(now)

    def with_status(self, status, **lifecycle):
        """Return a new entry at `status`, refusing a transition the lifecycle does not allow."""
        _check("status", status, STATUSES)
        allowed = TRANSITIONS.get(self.status, set())
        if status != self.status and status not in allowed:
            raise LedgerError(
                f"{self.status} -> {status} is not a permitted transition "
                f"(allowed: {', '.join(sorted(allowed)) or 'none'})")
        lc = dataclasses.replace(self.lifecycle, **lifecycle) if lifecycle else self.lifecycle
        return dataclasses.replace(self, status=status, version=self.version + 1, lifecycle=lc)


def decision_key(subject, scope=None):
    """A stable, exact retrieval key. Deliberately NOT session- or time-dependent: the existing
    question hash mixes in session_id, which is why it can never match across sessions (gap
    analysis 4.2)."""
    base = re.sub(r"[^a-z0-9]+", "-", str(subject).strip().lower()).strip("-")
    if scope is not None:
        dims = scope.declared()
        if dims:
            suffix = ",".join(f"{k}={v}" for k, v in sorted(dims.items()) if isinstance(v, str))
            if suffix:
                return f"{base}@{suffix}"
    return base
