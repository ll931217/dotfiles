"""Phase 5: turning answers into candidates without letting one answer become policy.

The exit criterion that shapes this module is "one answer cannot silently become team policy".
Everything here is built so the *widening* of scope or authority is an explicit, recorded, human
act — never a side effect of someone answering a question.
"""
from __future__ import annotations

import dataclasses
import datetime
import difflib
import uuid

from .decision import normalize_subject
from .types import AUTHORITIES, LedgerEntry, Lifecycle, RetrievalMetadata, Scope

# Which authority an answer class may reach WITHOUT approval. Anything above needs a human, which
# is the whole point of the phase (P4-14).
SELF_SERVE = {
    "task_choice": "current_task_instruction",
    "personal_preference": "explicit_human_preference",
    "temporary_workaround": "current_task_instruction",
    "exception": "explicit_human_preference",
    "factual_correction": "reviewed_human_observation",
}
NEEDS_APPROVAL = {
    "team_convention": "approved_team_decision",
    "architectural_decision": "approved_architectural_decision",
}
# An agent observation stops at `candidate` and can never be promoted straight to policy (P4-15).
OBSERVATION_CEILING = "repeated_agent_observation"

PARAPHRASE_RATIO = 0.86


def _now():
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")


@dataclasses.dataclass
class Evidence:
    """§12.2. Attached to a candidate rather than creating a second one, which is how repeated
    observation increases confidence instead of inflating the ledger."""
    id: str
    kind: str                      # human_answer | agent_observation | correction | rejection
    quote: str                     # the ORIGINAL wording, preserved (P4-17)
    session_id: str
    recorded_at: str = dataclasses.field(default_factory=_now)
    polarity: str = "supporting"   # supporting | negative

    def to_dict(self):
        return dataclasses.asdict(self)


@dataclasses.dataclass
class Candidate:
    """A proposed entry. It is NOT active: it sits at `candidate` until approved, and the
    approval step is where scope and authority can widen."""
    id: str
    subject: str
    statement: str
    answer_class: str
    proposed_authority: str
    proposed_scope: dict
    decision_key: str
    session_id: str
    status: str = "candidate"      # candidate | approved | rejected
    evidence: list = dataclasses.field(default_factory=list)
    conflicts_with: list = dataclasses.field(default_factory=list)
    rejected_reason: str = ""
    approved_by: str = ""
    approved_at: str = ""
    expires_at: str = ""
    created_at: str = dataclasses.field(default_factory=_now)

    @property
    def needs_approval(self):
        return self.answer_class in NEEDS_APPROVAL

    def to_dict(self):
        return dataclasses.asdict(self)

    def support_count(self):
        return sum(1 for e in self.evidence if e.get("polarity") == "supporting")

    def negative_count(self):
        return sum(1 for e in self.evidence if e.get("polarity") == "negative")


def ceiling_for(answer_class):
    """The HIGHEST authority this class of answer may ever reach, approval or not. `hard_policy`
    is deliberately unreachable from any answer: it is the one authority a current task
    instruction may never override (R-031), so it is not something a single conversation can
    mint."""
    if answer_class in NEEDS_APPROVAL:
        return NEEDS_APPROVAL[answer_class]
    if answer_class in SELF_SERVE:
        return SELF_SERVE[answer_class]
    return OBSERVATION_CEILING


def proposed_authority_for(answer_class):
    """What this class of answer may claim. Deliberately returns the LOW option for anything
    needing approval — the high authority is granted at approval time, not proposed at creation
    time, so an unapproved candidate can never be read as if it already carried it."""
    if answer_class in SELF_SERVE:
        return SELF_SERVE[answer_class]
    if answer_class in NEEDS_APPROVAL:
        return "reviewed_human_observation"
    return OBSERVATION_CEILING


class CandidateStore:
    def __init__(self, rows=None):
        self._rows = [Candidate(**r) for r in rows or []]

    def all(self):
        return list(self._rows)

    def to_list(self):
        return [c.to_dict() for c in self._rows]

    def active(self):
        return [c for c in self._rows if c.status == "candidate"]

    # --- deduplication (P4-17) ------------------------------------------------------------

    def find_equivalent(self, decision_key, subject, statement, scope=None):
        """Exact key first, then same subject with compatible scope, then paraphrase. Returns
        (candidate, why) or (None, reason-it-is-new)."""
        for c in self._rows:
            if c.status == "rejected":
                continue
            if c.decision_key and c.decision_key == decision_key:
                return c, "exact_decision_key"
        norm = normalize_subject(subject)
        for c in self._rows:
            if c.status == "rejected":
                continue
            if normalize_subject(c.subject) != norm:
                continue
            if scope is not None and c.proposed_scope and c.proposed_scope != dict(scope):
                continue
            ratio = difflib.SequenceMatcher(
                None, normalize_subject(c.statement), normalize_subject(statement)).ratio()
            if ratio >= PARAPHRASE_RATIO:
                return c, "paraphrase"
            return c, "same_subject_contradiction"
        return None, "new"

    def observe(self, decision_key, subject, statement, answer_class, session_id,
                quote="", scope=None, expires_at=""):
        """Record an answer. Attaches evidence to an equivalent candidate rather than creating a
        second one; records a conflict link when the same subject gets a contradictory statement.
        Returns (candidate, action)."""
        existing, why = self.find_equivalent(decision_key, subject, statement, scope)
        ev = Evidence(id="ev_" + uuid.uuid4().hex[:8], kind="human_answer",
                      quote=quote or statement, session_id=session_id).to_dict()

        if existing and why in ("exact_decision_key", "paraphrase"):
            existing.evidence.append(ev)
            return existing, "evidence_attached"

        cand = Candidate(
            id="cand_" + uuid.uuid4().hex[:8], subject=subject, statement=statement,
            answer_class=answer_class, proposed_authority=proposed_authority_for(answer_class),
            proposed_scope=dict(scope or {}), decision_key=decision_key,
            session_id=session_id, evidence=[ev], expires_at=expires_at)
        if existing and why == "same_subject_contradiction":
            cand.conflicts_with.append(existing.id)
            existing.conflicts_with.append(cand.id)
        self._rows.append(cand)
        return cand, "created" if not existing else "created_with_conflict"

    # --- approval and rejection -------------------------------------------------------------

    def approve(self, candidate_id, approver, authority=None, scope=None):
        """Widening happens HERE and nowhere else, and it records who did it (R-008)."""
        c = self._get(candidate_id)
        if c.status == "rejected":
            raise ValueError(f"{candidate_id} was rejected; reopen it deliberately, do not approve")
        if authority:
            if authority not in AUTHORITIES:
                raise ValueError(f"{authority!r} is not a ledger authority")
            if AUTHORITIES.index(authority) < AUTHORITIES.index(ceiling_for(c.answer_class)):
                raise ValueError(
                    f"a {c.answer_class} answer cannot reach {authority}; its ceiling is "
                    f"{ceiling_for(c.answer_class)}. The class of answer bounds the authority it "
                    f"may reach, whoever approves it — an earlier version skipped this check for "
                    f"exactly the classes that need approval, so a team convention could be "
                    f"approved straight to hard_policy")
            c.proposed_authority = authority
        if scope is not None:
            c.proposed_scope = dict(scope)
        c.status, c.approved_by, c.approved_at = "approved", approver, _now()
        return c

    def reject(self, candidate_id, reason, quote=""):
        """Rejected candidates stay in the store. A rejection is negative evidence about the
        statement, and deleting it would erase the reason the next identical proposal should be
        looked at harder (P4-16)."""
        c = self._get(candidate_id)
        c.status, c.rejected_reason = "rejected", reason
        c.evidence.append(Evidence(id="ev_" + uuid.uuid4().hex[:8], kind="rejection",
                                   quote=quote or reason, session_id=c.session_id,
                                   polarity="negative").to_dict())
        return c

    def correct(self, candidate_id, quote, session_id):
        """A correction is negative evidence. It does not delete the candidate — a statement that
        was believed and then corrected is a more useful record than one that vanished."""
        c = self._get(candidate_id)
        c.evidence.append(Evidence(id="ev_" + uuid.uuid4().hex[:8], kind="correction",
                                   quote=quote, session_id=session_id,
                                   polarity="negative").to_dict())
        return c

    def expire_task_assumptions(self, now=None):
        """Task-local entries die with the task (R-024, R-046). Returns what expired."""
        now = now or _now()
        gone = []
        for c in self._rows:
            if c.status == "candidate" and c.expires_at and c.expires_at <= now:
                c.status = "rejected"
                c.rejected_reason = "expired with the task"
                gone.append(c)
        return gone

    def _get(self, cid):
        for c in self._rows:
            if c.id == cid:
                return c
        raise KeyError(f"no candidate {cid!r}")


def to_entry(candidate, now=None):
    """An APPROVED candidate as a ledger entry. Refuses anything else — the whole point is that
    the unapproved cannot become active by being passed to the wrong function."""
    if candidate.status != "approved":
        raise ValueError(f"candidate {candidate.id} is {candidate.status}; only an approved "
                         f"candidate becomes an entry")
    return LedgerEntry(
        id=candidate.id, version=1, kind="decision" if candidate.answer_class in NEEDS_APPROVAL
        else "preference",
        subject=candidate.subject, statement=candidate.statement,
        scope=Scope(**candidate.proposed_scope) if candidate.proposed_scope else Scope(),
        authority=candidate.proposed_authority, status="active",
        autonomy="advisory", risk="low",
        created_by=candidate.approved_by, created_at=candidate.approved_at or _now(),
        evidence_ids=tuple(e["id"] for e in candidate.evidence),
        retrieval=RetrievalMetadata(decision_keys=(candidate.decision_key,)),
        lifecycle=Lifecycle(created_at=candidate.created_at,
                            approved_by=candidate.approved_by,
                            approved_at=candidate.approved_at,
                            expires_at=candidate.expires_at or None))
