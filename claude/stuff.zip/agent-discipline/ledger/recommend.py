"""Phase 6: say what the ledger would answer, and why — without answering.

A recommendation names its source ids, its intent and its risk, because a recommendation you
cannot check is just an assertion with better formatting. The eligibility rules below are the
same ones Phase 7 would use to ACT; running them here in advisory mode is what produces the
evidence for whether acting is ever safe.

High-risk new decisions are never recommended as an answer. They get an explanation of what is
known and an explicit "this one is yours".
"""
from __future__ import annotations

import dataclasses

from .decision import RISKS
from .types import AUTHORITIES

# What may be recommended as an ANSWER, by intent (P4-26).
#   apply_established / verify_fact -> an existing decision can be pointed at
#   choose_new                      -> only at low risk, and only with exact support
#   change_established              -> never; changing a settled decision is a human's call
#                                      regardless of similarity, confidence or convenience
RECOMMENDABLE_INTENTS = {"apply_established", "verify_fact", "choose_new"}
NEW_DECISION_MAX_RISK = "low"


def _risk_at_or_below(risk, ceiling):
    return RISKS.index(risk) <= RISKS.index(ceiling)


@dataclasses.dataclass
class Recommendation:
    """Advisory. `answer` is empty whenever the ledger declines, and `why_not` says which rule
    declined it — a silent abstention teaches nobody anything."""
    decision_key: str
    intent: str
    risk: str
    answer: str = ""
    confidence: str = "none"
    source_ids: tuple = ()
    conflict_ids: tuple = ()
    stale_ids: tuple = ()
    why_not: str = ""
    human_required_reasons: tuple = ()

    @property
    def recommends(self):
        return bool(self.answer)

    def render(self):
        head = f"[ledger] {self.intent} · risk {self.risk}"
        if self.human_required_reasons:
            return (f"{head}\n  This one is yours: {', '.join(self.human_required_reasons)}.\n"
                    f"  {self._known()}")
        if not self.recommends:
            return f"{head}\n  No recommendation: {self.why_not}\n  {self._known()}"
        out = [head, f"  Would answer: {self.answer}   (confidence {self.confidence})",
               f"  Based on: {', '.join(self.source_ids) or 'nothing'}"]
        if self.conflict_ids:
            out.append(f"  CONFLICTING: {', '.join(self.conflict_ids)} — the recommendation "
                       f"follows the higher authority, both are listed so you can disagree")
        if self.stale_ids:
            out.append(f"  STALE: {', '.join(self.stale_ids)} — past review date, treat as a hint")
        out.append("  Advisory only. Nothing was answered for you.")
        return "\n".join(out)

    def _known(self):
        if not self.source_ids:
            return "The ledger knows nothing relevant."
        return f"What is known: {', '.join(self.source_ids)}"


def recommend(need, supporting, conflicts=(), stale=(), max_new_risk=NEW_DECISION_MAX_RISK):
    """`supporting` is an ordered list of LedgerEntry, most authoritative first."""
    ids = tuple(e.id for e in supporting)
    base = dict(decision_key=need.key, intent=need.intent, risk=need.risk,
                source_ids=ids, conflict_ids=tuple(conflicts), stale_ids=tuple(stale))

    if need.mandatory_human:
        return Recommendation(**base, human_required_reasons=tuple(need.mandatory_human))
    if need.intent == "change_established":
        return Recommendation(**base, why_not="changing an established decision is a human's call")
    if not supporting:
        return Recommendation(**base, why_not="nothing in the ledger speaks to this")
    if conflicts:
        return Recommendation(**base, why_not="an unresolved conflict applies here")
    if need.intent == "choose_new" and not _risk_at_or_below(need.risk, max_new_risk):
        return Recommendation(**base,
                              why_not=f"a new decision at risk {need.risk} is above the "
                                      f"{max_new_risk} ceiling for recommending one")
    top = supporting[0]
    if top.id in stale:
        return Recommendation(**base, why_not="the only support is past its review date")

    # Map to an option only on an EXACT single match (P4-18). Anything else abstains rather than
    # guessing which option the human meant.
    answer, conf = "", "explains_only"
    if need.options:
        exact = [o for o in need.options
                 if o.strip().lower() == top.statement.strip().lower()]
        if len(exact) == 1:
            answer, conf = exact[0], f"exact_option_match:{top.authority}"
        else:
            return Recommendation(**base,
                                  why_not="no option exactly matches what the ledger says; "
                                          "guessing which one you meant is not a recommendation")
    else:
        answer, conf = top.statement, f"statement:{top.authority}"
    return Recommendation(**base, answer=answer, confidence=conf)


def coverage_warning(decision):
    """Phase 6's mutation advisory. Says what enforcement WOULD have done, so the false-positive
    rate can be measured before anything is ever blocked (exit criterion)."""
    if decision.status == "covered":
        return ""
    would = ("denied once to hydrate context" if decision.status == "covered_with_warning"
             else "denied" if decision.status == "blocked_by_conflict" else "allowed with a warning")
    return (f"[coverage] {decision.operation} on {decision.target}: {decision.reason} "
            f"({decision.status}). Under enforcement this would have been {would}. "
            f"Nothing was blocked.")


def subagent_scope(manifest, task, max_items=6):
    """Scoped context for a subagent: the mandatory items and nothing else.

    A subagent handed the parent's whole manifest inherits authority it was never granted and
    context it cannot act on. What crosses the boundary is what must not be violated."""
    items = []
    for section in ("applicable_policies", "active_decisions"):
        for it in manifest.get(section, []):
            if it.get("autonomy") == "mandatory" or it.get("authority") in (
                    "hard_policy", "approved_team_decision"):
                items.append(it)
    if not items:
        return ""
    out = [f"[ledger] Constraints that apply to this subtask ({task[:80]}):"]
    out += [f"  - {i['statement']}  [{i['authority']}]" for i in items[:max_items]]
    out.append("  These are inherited constraints, not the parent's full context.")
    return "\n".join(out)
