"""Context coverage records — NON-ENFORCING in this phase, and there is no flag that changes that.

The spec puts mutation DENIAL in Phase 7, behind a separate review (§26, §29). So this module
records what is and is not covered, and returns a decision object that a caller may report. It
cannot block, and `decide()` never returns anything a hook could turn into a deny.
"""
from __future__ import annotations

import dataclasses
import hashlib
import uuid

OPERATION_KINDS = ("read", "search", "edit", "create", "delete", "execute", "migrate",
                   "deploy", "query", "serialize", "unknown")

STATUSES = ("covered", "covered_with_warning", "blocked_by_conflict", "degraded", "invalidated")

MUTATING = {"edit", "create", "delete", "migrate", "deploy"}

TOOL_OPERATIONS = {
    "Edit": "edit", "Write": "create", "NotebookEdit": "edit", "MultiEdit": "edit",
    "Read": "read", "Grep": "search", "Glob": "search", "Bash": "execute",
}


@dataclasses.dataclass
class ContextCoverage:
    """R-099."""
    id: str
    scope: dict
    operation_kinds: list
    manifest_revision: int
    source_snapshot_hash: str
    workspace_revision: str = ""
    relevant_entry_ids: list = dataclasses.field(default_factory=list)
    conflict_ids: list = dataclasses.field(default_factory=list)
    degraded_source_ids: list = dataclasses.field(default_factory=list)
    status: str = "covered"
    resolved_at: str = ""
    repository_revision: str = ""
    expires_at: str = ""
    invalidation_conditions: list = dataclasses.field(default_factory=list)

    def __post_init__(self):
        if self.status not in STATUSES:
            raise ValueError(f"coverage status {self.status!r} not in {STATUSES}")
        for k in self.operation_kinds:
            if k not in OPERATION_KINDS:
                raise ValueError(f"operation kind {k!r} not in {OPERATION_KINDS}")

    def to_dict(self):
        return dataclasses.asdict(self)

    def covers(self, target, operation, snapshot):
        """Coverage is specific. A record for a different file, a different operation, or a
        different source snapshot does not cover this attempt — treating it as if it did is how
        a stale record becomes a false 'already checked'."""
        return (self.scope.get("path") == target
                and operation in self.operation_kinds
                and self.source_snapshot_hash == snapshot
                and self.status in ("covered", "covered_with_warning"))


def fingerprint(target, operation, snapshot):
    """Stable identity for one mutation attempt (R-104), so a retry is recognisable as a retry."""
    return hashlib.sha1(f"{target}|{operation}|{snapshot}".encode()).hexdigest()[:16]


def operation_for(tool_name, command=""):
    op = TOOL_OPERATIONS.get(tool_name, "unknown")
    if tool_name == "Bash" and command:
        low = command.lower()
        if any(w in low for w in ("drop ", "delete ", "truncate ", "rm -", "alter ")):
            return "delete"
        if "migrat" in low:
            return "migrate"
        if any(w in low for w in ("deploy", "kubectl apply", "helm upgrade")):
            return "deploy"
    return op


def is_mutating(operation):
    return operation in MUTATING


@dataclasses.dataclass(frozen=True)
class CoverageDecision:
    """What a caller MAY report. There is deliberately no `deny` here — mutation blocking is
    Phase 7 and gated on a separate review, so this phase cannot express it even by accident."""
    covered: bool
    status: str
    reason: str
    target: str
    operation: str
    fingerprint: str

    def as_note(self):
        """Silent only when coverage is clean. `covered_with_warning` still counts as covered
        for the purpose of not blocking, but staying silent about it would hide exactly the
        case worth knowing: a mutation whose target no rule speaks to."""
        if self.status == "covered":
            return ""
        return (f"[coverage] {self.operation} on {self.target}: {self.reason} "
                f"({self.status}). Recorded, not blocked.")


class CoverageStore:
    def __init__(self, records=None):
        self._records = list(records or [])

    def add(self, rec):
        self._records.append(rec)
        return rec

    def all(self):
        return list(self._records)

    def to_list(self):
        return [r.to_dict() for r in self._records]

    @classmethod
    def from_list(cls, rows):
        return cls([ContextCoverage(**r) for r in rows or []])

    def decide(self, target, operation, snapshot, manifest_revision=0,
               relevant_entry_ids=(), degraded=(), conflicts=()):
        """Record and report. Never blocks."""
        if not is_mutating(operation):
            return CoverageDecision(True, "covered", "not a mutating operation", target,
                                    operation, fingerprint(target, operation, snapshot))
        for rec in self._records:
            if rec.covers(target, operation, snapshot):
                return CoverageDecision(True, rec.status, "already covered", target, operation,
                                        fingerprint(target, operation, snapshot))
        status = ("blocked_by_conflict" if conflicts else
                  "degraded" if degraded else
                  "covered_with_warning" if not relevant_entry_ids else "covered")
        rec = ContextCoverage(
            id="cov_" + uuid.uuid4().hex[:8],
            scope={"path": target}, operation_kinds=[operation],
            manifest_revision=manifest_revision, source_snapshot_hash=snapshot,
            relevant_entry_ids=list(relevant_entry_ids),
            conflict_ids=list(conflicts), degraded_source_ids=list(degraded),
            status=status)
        self.add(rec)
        reason = {"blocked_by_conflict": "an unresolved conflict applies here",
                  "degraded": "a source was unavailable when this was resolved",
                  "covered_with_warning": "no entry in the manifest speaks to this target",
                  "covered": "resolved"}[status]
        return CoverageDecision(status in ("covered", "covered_with_warning"), status, reason,
                                target, operation, fingerprint(target, operation, snapshot))
