"""Shadow predictions and their outcomes — the measurement lane.

A prediction is written BEFORE the human answers and never shown to them. The outcome is written
after. The gap between the two is the only honest evidence about whether this system could ever
be trusted to answer anything itself, and it is worth nothing if the prediction can be edited
once the answer is known — so both stores are append-only.
"""
from __future__ import annotations

import dataclasses
import datetime
import json
import os
import uuid

MODES = ("observe", "shadow", "recommend", "resolve")


def _now():
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")


@dataclasses.dataclass
class QuestionPrediction:
    """P4-09."""
    id: str
    session_id: str
    decision_key: str
    question_text: str
    options: list
    mode: str
    risk: str
    intent: str
    confidence: str
    tool_use_id: str = ""
    predicted_answer: str = ""
    supporting_entry_ids: list = dataclasses.field(default_factory=list)
    conflicting_entry_ids: list = dataclasses.field(default_factory=list)
    manifest_revision: int = -1
    receipt_id: str = ""
    mandatory_human: list = dataclasses.field(default_factory=list)
    created_at: str = dataclasses.field(default_factory=_now)

    def __post_init__(self):
        if self.mode not in MODES:
            raise ValueError(f"mode {self.mode!r} not in {MODES}")
        if self.mandatory_human and self.predicted_answer:
            raise ValueError(
                "a need in a mandatory-human category must not carry a predicted answer: "
                f"{self.mandatory_human}")

    def to_dict(self):
        return dataclasses.asdict(self)


@dataclasses.dataclass
class QuestionOutcome:
    """P4-10."""
    prediction_id: str
    decision_key: str
    actual_answer: str
    answer_source: str
    agreed_with_prediction: bool
    later_corrected: bool = False
    resulting_resolved_need_id: str = ""
    resulting_candidate_entry_ids: list = dataclasses.field(default_factory=list)
    answer_class: str = ""
    recorded_at: str = dataclasses.field(default_factory=_now)

    def to_dict(self):
        return dataclasses.asdict(self)


class JsonlStore:
    def __init__(self, path):
        self.path = path

    def append(self, obj):
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(obj.to_dict() if hasattr(obj, "to_dict") else obj,
                               ensure_ascii=False) + "\n")
        return obj

    def read_all(self):
        try:
            with open(self.path, encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            yield json.loads(line)
                        except ValueError:
                            continue
        except OSError:
            return

    def find(self, **match):
        for rec in self.read_all():
            if all(rec.get(k) == v for k, v in match.items()):
                yield rec


def new_prediction_id():
    return "qp_" + uuid.uuid4().hex[:10]


# --- calibration -------------------------------------------------------------------------------

GROUPS = ("intent", "risk", "confidence", "retrieval", "mandatory")


def calibrate(predictions, outcomes):
    """P4-21: grouped, never a single headline number.

    Predictions with no answer are counted as ABSTENTIONS, not as errors. Conflating the two is
    how a system that wisely says nothing looks identical to one that guesses wrongly — and the
    whole point of shadow mode is telling those apart."""
    by_id = {p["id"]: p for p in predictions}
    rows = []
    for o in outcomes:
        p = by_id.get(o["prediction_id"])
        if p:
            rows.append((p, o))

    def bucket(p, o, group):
        if group == "retrieval":
            return "exact" if p.get("supporting_entry_ids") else "none"
        if group == "mandatory":
            return "mandatory_human" if p.get("mandatory_human") else "open"
        return p.get(group, "?")

    out = {"total": len(rows), "abstained": 0, "predicted": 0, "agreed": 0, "groups": {}}
    for p, o in rows:
        abstained = not p.get("predicted_answer")
        out["abstained"] += 1 if abstained else 0
        out["predicted"] += 0 if abstained else 1
        out["agreed"] += 1 if (not abstained and o.get("agreed_with_prediction")) else 0
        for g in GROUPS:
            b = out["groups"].setdefault(g, {}).setdefault(bucket(p, o, g),
                                                           {"n": 0, "predicted": 0, "agreed": 0})
            b["n"] += 1
            if not abstained:
                b["predicted"] += 1
                b["agreed"] += 1 if o.get("agreed_with_prediction") else 0
    out["precision"] = (out["agreed"] / out["predicted"]) if out["predicted"] else None
    return out
