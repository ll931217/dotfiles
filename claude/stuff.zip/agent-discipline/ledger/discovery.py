"""Deterministic entity extraction and the scope frontier.

Extraction is regex over what tools actually observed — paths, symbols, imports, SQL objects,
endpoints, config keys, error types, test names (P3-13). Model-assisted extraction is explicitly
NOT here: the spec allows it only as a retrieval hint that can never grant authority or create an
active fact (P3-14), and this phase has no need of a hint it would then have to distrust.

An entity is admitted to the frontier only after normalization and deduplication (P3-15). The
frontier is the memory of what this task has touched, and a duplicate in it becomes a duplicate
refresh, a duplicate delta, and eventually a duplicate injection.
"""
from __future__ import annotations

import dataclasses
import os
import re

ENTITY_TYPES = ("path", "symbol", "module", "table", "dataset", "endpoint", "message_topic",
                "dependency", "config_key", "error_type", "test_name", "concept")

# Deliberately conservative. A false entity costs a pointless refresh; a regex that matches
# ordinary prose costs one on every tool call.
PATTERNS = (
    ("path", re.compile(r"\b(?:[\w.-]+/){1,}[\w.-]+\.(?:py|ts|tsx|js|jsx|sh|sql|toml|ya?ml|md|rs|go)\b")),
    ("symbol", re.compile(r"\b(?:def|class|function|const|fn|type|interface)\s+([A-Za-z_]\w{2,})")),
    ("module", re.compile(r"^\s*(?:from|import)\s+([\w.]+)", re.M)),
    # Case-SENSITIVE on purpose. With re.I this matched Python's `from settlement.core import
    # Loader` and invented a table called `settlement.core`. A phantom table looks authoritative
    # and pulls in the wrong rule; a missed lowercase table only costs a refresh that the
    # mutation-coverage checkpoint would catch later (P3-25). Precision wins here.
    ("table", re.compile(r"\b(?:FROM|JOIN|INTO|UPDATE|TABLE)\s+([A-Za-z_][\w.]{2,})")),
    ("endpoint", re.compile(r"\b(?:GET|POST|PUT|PATCH|DELETE)\s+(/[\w/{}.-]*)")),
    ("config_key", re.compile(r"\b([A-Z][A-Z0-9]{2,}(?:_[A-Z0-9]+)+)\b")),
    ("error_type", re.compile(r"\b(\w*(?:Error|Exception))\b")),
    ("test_name", re.compile(r"\b(test_[a-z0-9_]{3,})\b")),
)

SQL_NOISE = {"select", "where", "values", "table", "set", "and", "or", "not", "null"}


def normalize(kind, value):
    """One canonical form per entity, or None to reject it. Normalization IS the deduplication
    key, so anything that survives here is something the frontier will treat as distinct."""
    v = (value or "").strip().strip("\"'`,;()[]{}")
    if not v:
        return None
    if kind == "path":
        v = os.path.normpath(v).lstrip("./")
        return v or None
    if kind in ("table", "module"):
        v = v.lower()
        return None if v in SQL_NOISE or len(v) < 3 else v
    if kind == "endpoint":
        # /users/123 and /users/456 are the same endpoint; keeping both floods the frontier.
        return re.sub(r"/\d+", "/{id}", v)
    if kind in ("symbol", "test_name", "config_key", "error_type"):
        return v if len(v) >= 3 else None
    return v


def extract(text, limit=40):
    """Every entity a blob of tool output mentions, normalized and deduplicated.

    `limit` is a guard, not a preference: a 5 MB file read would otherwise put thousands of
    entities on the frontier and every one of them would trigger a refresh."""
    found, seen = [], set()
    if not text:
        return found
    text = text[:200_000]
    for kind, pat in PATTERNS:
        for m in pat.finditer(text):
            raw = m.group(1) if pat.groups else m.group(0)
            v = normalize(kind, raw)
            if not v:
                continue
            key = (kind, v)
            if key in seen:
                continue
            seen.add(key)
            found.append({"type": kind, "id": v})
            if len(found) >= limit:
                return found
    return found


@dataclasses.dataclass
class FrontierEntry:
    """P3-16: everything a frontier record must carry."""
    entity_id: str
    entity_type: str
    source_tool_use: str
    confidence: str = "deterministic"
    first_observed: str = ""
    latest_observed: str = ""
    related_scopes: list = dataclasses.field(default_factory=list)
    has_mutation_coverage: bool = False
    context_injected: bool = False

    @property
    def key(self):
        return f"{self.entity_type}:{self.entity_id}"


class ScopeFrontier:
    """What this task has touched. Admission is normalized and deduplicated; a second sighting
    updates `latest_observed` rather than adding a row."""

    def __init__(self, entries=None):
        self._by_key = {}
        for e in entries or []:
            self._by_key[e.key if isinstance(e, FrontierEntry) else
                         f"{e['entity_type']}:{e['entity_id']}"] = (
                e if isinstance(e, FrontierEntry) else FrontierEntry(**e))

    def observe(self, entities, tool_use, when, scopes=None):
        """Returns only the entities that are NEW. An unchanged frontier produces no delta, and
        that is how "unchanged context is not repeatedly injected" (P3-18) is actually achieved —
        upstream of the delta, not by filtering it afterwards."""
        fresh = []
        for ent in entities:
            key = f"{ent['type']}:{ent['id']}"
            existing = self._by_key.get(key)
            if existing:
                existing.latest_observed = when
                continue
            fe = FrontierEntry(entity_id=ent["id"], entity_type=ent["type"],
                               source_tool_use=tool_use, first_observed=when,
                               latest_observed=when, related_scopes=list(scopes or []))
            self._by_key[key] = fe
            fresh.append(fe)
        return fresh

    def all(self):
        return list(self._by_key.values())

    def keys(self):
        return set(self._by_key)

    def to_list(self):
        return [dataclasses.asdict(e) for e in self._by_key.values()]

    @classmethod
    def from_list(cls, rows):
        return cls([FrontierEntry(**r) for r in rows or []])

    def scope_context(self):
        """The frontier expressed as something the resolver can match scopes against."""
        ctx = {}
        for e in self._by_key.values():
            if e.entity_type == "path" and "path" not in ctx:
                ctx["path"] = e.entity_id
            elif e.entity_type == "symbol" and "symbol" not in ctx:
                ctx["symbol"] = e.entity_id
            elif e.entity_type == "module" and "module" not in ctx:
                ctx["module"] = e.entity_id
        return ctx


def terms_from(frontier):
    """Frontier entities as retrieval terms, so a newly discovered table or error type can pull
    in the rule that governs it."""
    out = set()
    for e in frontier.all():
        out.update(t for t in re.split(r"[^a-zA-Z0-9]+", e.entity_id.lower()) if len(t) > 2)
    return out
