"""The resolution pipeline: a request in, a Task Context Manifest out.

Free of Claude Code hook types (R-013). A hook parses its payload, builds a `ResolutionRequest`
of plain values, and renders the manifest itself.

Two rules shape everything here:

- **Retrieval never widens authority** (R-003). The tier that found a candidate decides its
  ORDER among equals, never its rank against a different authority class. A lexical hit on a
  hard policy is still a hard policy; an exact-key hit on an agent inference is still an
  inference.
- **A thin answer must not look like a confident one.** Every source that failed is carried in
  `degraded_sources`, and budget truncation is reported rather than silently applied.
"""
from __future__ import annotations

import dataclasses
import hashlib
import re
import uuid

from .types import AUTHORITIES, Scope

RESOLVER_VERSION = "0.2.0-phase2"

# Where a candidate was found, most trusted tier first. Used ONLY to break ties inside one
# authority class — see the module docstring (R-063).
TIERS = ("exact_decision_key", "current_task_answer", "scope_match", "canon_trigger",
         "memory_trigger", "lexical_fallback")

STOP = {"the", "and", "for", "this", "that", "with", "from", "what", "when", "should", "which",
        "your", "would", "could", "need", "does", "did", "are", "was", "can", "how", "not",
        "you", "all", "but", "have", "will", "use", "one", "two", "into", "about", "make"}


@dataclasses.dataclass(frozen=True)
class ResolutionRequest:
    """R-082. Required first, optional after."""
    request_id: str
    trigger: str
    actor: str
    repository: str
    session: str
    task: str
    operation: str = ""
    current_manifest_revision: int = -1
    paths: tuple = ()
    symbols: tuple = ()
    discovered_entities: tuple = ()
    mutation_targets: tuple = ()
    decision_key: str = ""
    prompt: str = ""
    branch: str = ""
    revision: str = ""
    environment: str = ""
    character_budget: int = 4000
    include_noisy_memory: bool = False

    def terms(self):
        text = f"{self.task} {self.prompt} {' '.join(self.paths)} {' '.join(self.symbols)}"
        return {t for t in re.findall(r"[a-z][a-z0-9-]{2,}", text.lower()) if t not in STOP}

    def scope_context(self):
        ctx = {"repository": self.repository or None}
        if self.branch:
            ctx["branches"] = self.branch
        if self.environment:
            ctx["environments"] = self.environment
        if self.actor:
            ctx["actor_ids"] = self.actor
        for p in self.paths:
            ctx.setdefault("path", p)
        for s in self.symbols:
            ctx.setdefault("symbol", s)
        return {k: v for k, v in ctx.items() if v}

    def snapshot_hash(self):
        return hashlib.sha1(
            f"{self.repository}|{self.branch}|{self.revision}|{self.task}".encode()
        ).hexdigest()[:12]


@dataclasses.dataclass
class TaskContextManifest:
    """R-086. Lives on disk; what the model sees is `render()`."""
    manifest_id: str
    revision: int
    receipt_id: str
    generated_at: str
    resolver_version: str
    trigger: str
    request_summary: str
    repository: str
    task: str
    scope_frontier: list = dataclasses.field(default_factory=list)
    coverage: list = dataclasses.field(default_factory=list)
    applicable_policies: list = dataclasses.field(default_factory=list)
    system_facts: list = dataclasses.field(default_factory=list)
    active_decisions: list = dataclasses.field(default_factory=list)
    preferences: list = dataclasses.field(default_factory=list)
    assumptions: list = dataclasses.field(default_factory=list)
    exceptions: list = dataclasses.field(default_factory=list)
    resolved_needs: list = dataclasses.field(default_factory=list)
    conflicts: list = dataclasses.field(default_factory=list)
    stale_items: list = dataclasses.field(default_factory=list)
    autonomy_boundary: str = "advisory"
    degraded_sources: list = dataclasses.field(default_factory=list)
    parent_manifest_id: str = ""
    truncated: list = dataclasses.field(default_factory=list)

    SECTIONS = (("applicable_policies", "Applicable policies"),
                ("system_facts", "Relevant system facts"),
                ("active_decisions", "Active decisions"),
                ("preferences", "Preferences"),
                ("assumptions", "Assumptions"),
                ("exceptions", "Exceptions"))

    def to_dict(self):
        return dataclasses.asdict(self)

    def render(self):
        """The model-visible projection. Intentionally incomplete (R-014): this is a starting
        view, not a task specification."""
        out = [f"LEDGER TASK CONTEXT",
               f"Manifest: {self.manifest_id}  revision {self.revision}",
               f"Receipt: {self.receipt_id}",
               f"Repository: {self.repository or '(none)'}",
               f"Mode: {self.autonomy_boundary}", ""]
        for attr, title in self.SECTIONS:
            items = getattr(self, attr)
            if not items:
                continue
            out.append(f"{title}:")
            for it in items:
                mark = "  ! " if it.get("stale") else "  - "
                out.append(f"{mark}{it['statement']}")
                out.append(f"      {it['authority']} · {it['source']} · via {it['why']}"
                           + ("  (STALE — past its review date)" if it.get("stale") else ""))
            out.append("")
        if self.conflicts:
            out.append("Conflicts (higher authority wins; both are shown so you can see why):")
            for c in self.conflicts:
                out.append(f"  - {c['subject']}: {c['winner']} beats {', '.join(c['losers'])}"
                           f" by {c['decided_by']}")
            out.append("")
        if self.degraded_sources:
            out.append("DEGRADED SOURCES — this context is thinner than it looks:")
            for d in self.degraded_sources:
                out.append(f"  - {d['source']}: {d['detail']}")
            out.append("")
        if self.truncated:
            out.append(f"Budget: {len(self.truncated)} lower-authority item(s) omitted to stay "
                       f"within {self.character_budget_used} characters. Nothing mandatory was "
                       f"dropped. `ledger-why.py {self.receipt_id}` lists them.")
            out.append("")
        out.append("This is a STARTING view, not a complete specification.")
        return "\n".join(out)

    character_budget_used = 0


def _bucket(entry):
    kind = entry.kind
    if kind in ("policy", "invariant", "constraint"):
        return "applicable_policies"
    if kind == "fact":
        return "system_facts"
    if kind == "decision":
        return "active_decisions"
    if kind in ("preference", "negative_preference", "heuristic"):
        return "preferences"
    if kind == "assumption":
        return "assumptions"
    if kind == "exception":
        return "exceptions"
    return "system_facts"


def _tier_rank(why):
    return TIERS.index(why) if why in TIERS else len(TIERS)


class Resolver:
    def __init__(self, adapters, receipts=None, now=None):
        self.adapters = list(adapters)
        self.receipts = receipts
        self.now = now

    def resolve(self, req, parent=None):
        candidates, degraded = [], []
        for ad in self.adapters:
            try:
                h = ad.health()
            except Exception as err:                       # noqa: BLE001
                degraded.append({"source": ad.name, "detail": f"health check raised: {err}"})
                continue
            if h.degraded:
                degraded.append({"source": h.source, "detail": h.detail or "unavailable"})
                continue
            if h.detail:
                # Available but with something to say — e.g. unreadable records. Not a failure,
                # but the user should not learn about it by noticing an absence.
                degraded.append({"source": h.source, "detail": h.detail})
            try:
                candidates.extend(ad.query(req))
            except Exception as err:                       # noqa: BLE001
                degraded.append({"source": ad.name, "detail": f"query raised: {err}"})

        # Deduplicate on entry id, keeping the most trusted tier that found it.
        best = {}
        for c in candidates:
            cur = best.get(c.entry.id)
            if cur is None or _tier_rank(c.why) < _tier_rank(cur.why):
                best[c.entry.id] = c
        chosen = list(best.values())

        # AUTHORITY first, then the tier that found it, then scope specificity. Tier can only
        # ever break a tie inside one authority class (R-003).
        chosen.sort(key=lambda c: (AUTHORITIES.index(c.entry.authority),
                                   _tier_rank(c.why),
                                   c.entry.scope.specificity(),
                                   c.entry.id))

        kept, dropped, used = [], [], 0
        for c in chosen:
            line = f"{c.entry.statement} {c.entry.authority} {c.source_system} {c.why}"
            mandatory = c.entry.autonomy == "mandatory" or c.entry.authority == "hard_policy"
            if used + len(line) > req.character_budget and not mandatory:
                dropped.append(c)
                continue
            used += len(line)
            kept.append(c)

        receipt_id = "ctxr_" + uuid.uuid4().hex[:8]
        manifest = TaskContextManifest(
            manifest_id=("M0" if parent is None else f"M{parent.revision + 1}"),
            revision=(0 if parent is None else parent.revision + 1),
            receipt_id=receipt_id,
            generated_at=_now_iso(),
            resolver_version=RESOLVER_VERSION,
            trigger=req.trigger,
            request_summary=req.task[:200],
            repository=req.repository,
            task=req.task,
            degraded_sources=degraded,
            parent_manifest_id=(parent.manifest_id if parent else ""),
        )
        manifest.character_budget_used = req.character_budget

        for c in kept:
            item = {"id": c.entry.id, "statement": c.entry.statement,
                    "authority": c.entry.authority, "source": c.source_system,
                    "why": c.why, "autonomy": c.entry.autonomy,
                    "stale": c.entry.is_stale(self.now)}
            getattr(manifest, _bucket(c.entry)).append(item)
            if item["stale"]:
                manifest.stale_items.append(item)
        manifest.truncated = [{"id": c.entry.id, "authority": c.entry.authority,
                               "statement": c.entry.statement} for c in dropped]

        manifest.conflicts = self._conflicts(kept)
        manifest.autonomy_boundary = self._boundary(kept)

        if self.receipts:
            items = ([{"id": c.entry.id, "state": "selected", "why": c.why,
                       "authority": c.entry.authority} for c in kept]
                     + [{"id": c.entry.id, "state": "rejected", "why": "character budget",
                         "authority": c.entry.authority} for c in dropped]
                     + [{"id": c["winner"], "state": "conflicts", "why": c["decided_by"]}
                        for c in manifest.conflicts])
            self.receipts.write(receipt_id, manifest.manifest_id, manifest.revision, items,
                                trigger=req.trigger,
                                degraded=[d["source"] for d in degraded])
        return manifest

    def _conflicts(self, chosen):
        groups = {}
        for c in chosen:
            groups.setdefault(c.entry.subject.strip().lower(), []).append(c)
        out = []
        for subject, group in sorted(groups.items()):
            if len(group) < 2 or len({g.entry.statement.strip() for g in group}) < 2:
                continue
            ranked = sorted(group, key=lambda c: AUTHORITIES.index(c.entry.authority))
            decided = ("authority" if ranked[0].entry.authority != ranked[1].entry.authority
                       else "scope_specificity")
            out.append({"subject": subject, "winner": ranked[0].entry.id,
                        "losers": [g.entry.id for g in ranked[1:]], "decided_by": decided})
        return out

    def _boundary(self, chosen):
        """The most restrictive autonomy any selected entry demands. `mandatory` wins because a
        rule that must be followed cannot be softened by a merely advisory neighbour."""
        levels = {c.entry.autonomy for c in chosen}
        for level in ("never_auto_apply", "ask_before_applying", "mandatory", "default", "advisory"):
            if level in levels:
                return level
        return "advisory"


def _now_iso():
    import datetime
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")
