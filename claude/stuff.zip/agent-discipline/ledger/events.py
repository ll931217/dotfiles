"""Append-only event history and receipt persistence.

`pref_events.tsv` already exists and is append-only, but its rows are LEDGER INTERACTIONS
(deny / inform / reissued) read by the dashboard. Entry-lifecycle events are a different stream
with a different schema, so they go to their own file rather than overloading columns the
dashboard parses positionally (gap analysis R3).

Append-only is a requirement, not a style (R-011): nothing here rewrites or deletes a line.
"""
from __future__ import annotations

import datetime
import json
import os

EVENT_KINDS = ("created", "evidence_added", "promoted", "approved", "activated", "rejected",
               "superseded", "deprecated", "expired", "invalidated", "scope_changed",
               "authority_changed", "outcome_recorded")


def _now():
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")


class EventLog:
    """JSONL. One object per line, appended with a single write so a concurrent hook cannot
    interleave a partial record."""

    def __init__(self, path):
        self.path = path

    def append(self, entry_id, kind, actor, detail=None, revision=None):
        if kind not in EVENT_KINDS:
            raise ValueError(f"{kind!r} is not a ledger event kind: {', '.join(EVENT_KINDS)}")
        rec = {"ts": _now(), "entry_id": entry_id, "kind": kind, "actor": actor,
               "detail": detail or {}, "revision": revision}
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        return rec

    def read(self, entry_id=None):
        try:
            with open(self.path, encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        rec = json.loads(line)
                    except ValueError:
                        continue  # a torn line must not lose the rest of the history
                    if entry_id is None or rec.get("entry_id") == entry_id:
                        yield rec
        except OSError:
            return


class ReceiptStore:
    """A context receipt per resolution: what was considered, selected, rejected, and why.

    Written before the context it explains is used, so a receipt can never describe a decision
    that did not happen."""

    STATES = ("considered", "selected", "rejected", "conflicts", "stale")

    def __init__(self, path):
        self.path = path

    def write(self, receipt_id, manifest_id, revision, items, trigger="", degraded=()):
        for it in items:
            if it.get("state") not in self.STATES:
                raise ValueError(f"receipt item state {it.get('state')!r} not in {self.STATES}")
        rec = {"receipt_id": receipt_id, "manifest_id": manifest_id, "revision": revision,
               "generated_at": _now(), "trigger": trigger, "items": list(items),
               "degraded_sources": list(degraded)}
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        return rec

    def get(self, receipt_id):
        for rec in self.read_all():
            if rec.get("receipt_id") == receipt_id:
                return rec
        return None

    def read_all(self):
        try:
            with open(self.path, encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            yield json.loads(line)
                        except ValueError:
                            continue
        except OSError:
            return
