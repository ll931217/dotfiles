"""Revisioned external session state.

The manifest lives on disk, not in the model's context (R-015). What the model sees is a
projection of it; what survives a compaction, a resume or a fork is this file.

Revisioning is compare-and-swap (R-020 in the Phase 3 set, and R-016 here): a writer that lost a
race is told so rather than silently overwriting a newer revision.
"""
from __future__ import annotations

import contextlib
import datetime
import errno
import fcntl
import json
import os
import tempfile
import time


class RevisionConflict(RuntimeError):
    """Someone else advanced the revision while this writer was working."""


@contextlib.contextmanager
def session_lock(path, timeout=10.0):
    """Serialise a read-compute-write cycle for one session.

    The spec allows a per-session lock OR compare-and-swap (P3-20). CAS alone was not enough
    here and the reason is structural, not tunable: the work between read and write is a full
    resolve, so four parallel tool hooks kept colliding and losing observations even with
    jittered retries. A lock closes the window instead of narrowing it.

    Fails OPEN. A hook that cannot take the lock still does its work — a lost observation is
    better than a stalled tool call, and CAS remains underneath as the correctness backstop."""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    lock_path = path + ".lock"
    fh = None
    try:
        fh = open(lock_path, "w")
    except OSError:
        yield False
        return
    deadline = time.monotonic() + timeout
    got = False
    try:
        while True:
            try:
                fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                got = True
                break
            except OSError as err:
                if err.errno not in (errno.EACCES, errno.EAGAIN):
                    break
                if time.monotonic() >= deadline:
                    break
                time.sleep(0.01)
        yield got
    finally:
        try:
            if got:
                fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
            fh.close()
        except OSError:
            pass


class SessionState:
    def __init__(self, path):
        self.path = path

    def read(self):
        try:
            with open(self.path, encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            return None

    def revision(self):
        st = self.read()
        return -1 if st is None else int(st.get("revision", -1))

    def write(self, state, expected_revision=None):
        """Atomic replace. `expected_revision=None` means "create only" — passing the current
        revision is how a caller says it read before it wrote."""
        current = self.revision()
        if expected_revision is None:
            if current != -1:
                raise RevisionConflict(
                    f"state already exists at revision {current}; pass expected_revision to update")
        elif current != expected_revision:
            raise RevisionConflict(
                f"expected revision {expected_revision}, found {current} — recompute against the "
                f"latest state rather than overwriting it")
        state = dict(state)
        state["revision"] = 0 if current == -1 else current + 1
        state["updated_at"] = datetime.datetime.now().astimezone().isoformat(timespec="seconds")
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        # Write-then-rename: a hook killed mid-write must not leave a half file that reads as
        # valid-but-truncated state.
        fd, tmp = tempfile.mkstemp(dir=os.path.dirname(self.path) or ".", suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(state, f, ensure_ascii=False, indent=2)
            os.replace(tmp, self.path)
        except BaseException:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise
        return state

    def clear(self):
        try:
            os.unlink(self.path)
        except OSError:
            pass
