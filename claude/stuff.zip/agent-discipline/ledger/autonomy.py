"""Phase 7: bounded autonomous resolution — and the gate that keeps it shut.

The spec lists PREREQUISITES for this phase, not just deliverables: a calibration sample count,
a precision threshold, an acceptable coverage false-positive rate, a security review, reliable
persistence, and a verified kill switch. None of those is a checkbox somebody ticks; each is a
claim about evidence.

So the mechanism is built and tested, and `readiness()` measures the prerequisites from real
data. `may_auto_answer()` refuses while ANY of them is unmet, and it fails closed on error. The
result is a Phase 7 that exists, is verifiable, and cannot switch itself on because the code
happened to ship.
"""
from __future__ import annotations

import dataclasses
import os

from .decision import RISKS
from .recommend import Recommendation

MIN_SAMPLES_PER_INTENT = 30
MIN_PRECISION = 0.95
MAX_COVERAGE_FALSE_POSITIVE_RATE = 0.05
KILL_SWITCH_PATH = os.path.expanduser("~/.config/agent-discipline.KILL")


@dataclasses.dataclass
class Prerequisite:
    name: str
    met: bool
    detail: str


@dataclasses.dataclass
class Readiness:
    prerequisites: list

    @property
    def ready(self):
        return all(p.met for p in self.prerequisites)

    def unmet(self):
        return [p for p in self.prerequisites if not p.met]

    def render(self):
        out = ["Phase 7 autonomy prerequisites:"]
        for p in self.prerequisites:
            out.append(f"  [{'x' if p.met else ' '}] {p.name:34} {p.detail}")
        out.append("")
        out.append("READY" if self.ready else
                   f"NOT READY — {len(self.unmet())} prerequisite(s) unmet. Autonomy stays off, "
                   f"and no flag overrides this.")
        return "\n".join(out)


def kill_switch_engaged(path=None):
    return os.path.exists(path or KILL_SWITCH_PATH)


def readiness(predictions=(), outcomes=(), stop_rows=(), security_reviewed=False,
              persistence_ok=None, kill_switch_verified=False, path=None):
    """Measure every prerequisite from evidence. Anything unmeasurable counts as UNMET."""
    from .prediction import calibrate

    preds, outs = list(predictions), list(outcomes)
    cal = calibrate(preds, outs)

    per_intent = {}
    for name, buckets in cal["groups"].get("intent", {}).items():
        per_intent[name] = buckets["n"]
    thin = {k: v for k, v in per_intent.items() if v < MIN_SAMPLES_PER_INTENT}
    samples_met = bool(per_intent) and not thin

    prec = cal["precision"]
    precision_met = prec is not None and prec >= MIN_PRECISION

    stop_rows = list(stop_rows)
    flagged = [r for r in stop_rows if r.get("candidate")]
    confirmed_wrong = [r for r in flagged if r.get("false_positive")]
    # Unreviewed flags are NOT assumed correct. A false-positive rate you have not measured is
    # not a low one.
    unreviewed = [r for r in flagged if "false_positive" not in r]
    fp_rate = (len(confirmed_wrong) / len(flagged)) if flagged else None
    coverage_met = bool(flagged) and not unreviewed and fp_rate <= MAX_COVERAGE_FALSE_POSITIVE_RATE

    if persistence_ok is None:
        persistence_ok = bool(preds) and bool(outs)

    return Readiness([
        Prerequisite("calibration sample count", samples_met,
                     f"{per_intent or 'no predictions at all'}"
                     + (f"; thin: {thin}" if thin else "")
                     + f"  (need {MIN_SAMPLES_PER_INTENT} per intent)"),
        Prerequisite("precision threshold", precision_met,
                     ("undefined — nothing was ever predicted" if prec is None
                      else f"{prec:.0%}") + f"  (need {MIN_PRECISION:.0%})"),
        Prerequisite("coverage false-positive rate", coverage_met,
                     ("no Stop candidates recorded" if not flagged
                      else f"{len(unreviewed)} of {len(flagged)} flags unreviewed"
                      if unreviewed else f"{fp_rate:.0%}")
                     + f"  (need <= {MAX_COVERAGE_FALSE_POSITIVE_RATE:.0%}, all reviewed)"),
        Prerequisite("security review", bool(security_reviewed),
                     "completed" if security_reviewed else "not recorded"),
        Prerequisite("receipt and state persistence", bool(persistence_ok),
                     "predictions and outcomes both persisting" if persistence_ok
                     else "no evidence that both stores survive a session"),
        Prerequisite("kill switch verified", bool(kill_switch_verified),
                     f"verified; engage with: touch {path or KILL_SWITCH_PATH}"
                     if kill_switch_verified else "never exercised"),
    ])


@dataclasses.dataclass
class AutoDecision:
    allowed: bool
    answer: str = ""
    reason: str = ""
    receipt_id: str = ""

    def as_note(self):
        return (f"[ledger] answered automatically: {self.answer}  (receipt {self.receipt_id})"
                if self.allowed else f"[ledger] not answering: {self.reason}")


def may_auto_answer(need, rec: Recommendation, ready: Readiness, *, mode="shadow",
                    receipt_id="", max_new_risk="low", max_established_risk="high",
                    kill_path=None, overrides=None):
    """Every condition must hold. There is no combination of flags that skips one.

    Ordered so the cheapest, most absolute refusals come first — a kill switch must not depend
    on a calibration table being loadable."""
    if kill_switch_engaged(kill_path):
        return AutoDecision(False, reason="kill switch engaged")
    if mode != "resolve":
        return AutoDecision(False, reason=f"mode is {mode}; autonomy needs resolve")
    if not ready.ready:
        return AutoDecision(False, reason="prerequisites unmet: "
                                          + ", ".join(p.name for p in ready.unmet()))
    if need.mandatory_human:
        return AutoDecision(False, reason=f"mandatory human category: "
                                          f"{', '.join(need.mandatory_human)}")
    if need.intent == "change_established":
        return AutoDecision(False, reason="changing an established decision is always a human's")
    if not rec.recommends:
        return AutoDecision(False, reason=rec.why_not or "nothing to answer with")
    if rec.conflict_ids:
        return AutoDecision(False, reason="an unresolved conflict applies")
    if rec.stale_ids:
        return AutoDecision(False, reason="support is past its review date")
    ceiling = max_new_risk if need.intent == "choose_new" else max_established_risk
    # The HIGHER of the two assessments wins. The need classifies risk from its own text; the
    # caller may know more. Reading only `need.risk` let a high-risk new decision through
    # because the question's wording tripped no category — caught by test, and the direction of
    # the bug is the one that matters: it failed open.
    risk = max((need.risk, rec.risk), key=RISKS.index)
    if RISKS.index(risk) > RISKS.index(ceiling):
        return AutoDecision(False, reason=f"risk {risk} exceeds the {ceiling} ceiling")
    if not receipt_id:
        # An automatic answer with no receipt is unexplainable afterwards, which is exactly the
        # situation that makes autonomy indefensible.
        return AutoDecision(False, reason="no context receipt was written")
    if (overrides or {}).get(need.key) == "never":
        return AutoDecision(False, reason="a per-decision override forbids answering this one")
    return AutoDecision(True, answer=rec.answer, receipt_id=receipt_id,
                        reason="all conditions met")
