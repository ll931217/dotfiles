"""Read the EXISTING `pref-*.md` records as typed entries, without touching them.

Spec §2: "Do not silently reinterpret existing ledger records. Migrate them explicitly or retain
a compatibility projection." This is the compatibility projection, and it is the right half of
that choice here — the store is the user's memory directory, shared with memory-kit and written
by hand, so a rewrite is the one irreversible thing in this design (gap analysis R2).

Nothing in this module writes. `report()` says what a migration WOULD do.

The mapping is stated rather than inferred, because every line of it is a judgement:

  kind        -> `preference` for all of them. Today's ledger has exactly one implicit kind.
  status      -> `active` for all of them. They ARE in force today: the hook surfaces every
                 record that scores, whatever its `status:` frontmatter says. Mapping
                 `provisional` to `candidate` would drop those records out of the active
                 projection and silently change retrieval — the reinterpretation §2 forbids.
                 The frontmatter value is preserved in `source_references` instead.
  authority   -> `explicit_human_preference` when `confidence: stated` (the user said it),
                 `agent_inference` when derived. Confidence is an EVIDENCE-strength axis, so it
                 cannot become authority by itself — but "the user stated this" and "the agent
                 inferred this" is a real authority distinction and it is the one the frontmatter
                 already records.
  autonomy    -> the confidence ladder already documents its own autonomy in
                 skills/preference-ledger/procedure.md: stated = "act on it silently",
                 derived-strong = "act, and state the assumption", derived-weak = "act only on
                 low-cost/reversible calls; otherwise ask". Those map onto `default`,
                 `advisory`, `ask_before_applying`.
  scope       -> unscoped. These records are global to the user today. An empty Scope means "not
                 constrained by any dimension", NOT "global authority" (R-020) — which is why
                 they lose every conflict against a scoped policy rather than winning by default.
  risk        -> `low`. Nothing in a record states risk; inventing one would be a fabricated
                 governance field.
"""
from __future__ import annotations

import os
import re

from .types import LedgerEntry, Lifecycle, RetrievalMetadata, Scope, decision_key

AUTHORITY_BY_CONFIDENCE = {
    "stated": "explicit_human_preference",
    "derived-strong": "agent_inference",
    "derived-weak": "agent_inference",
}
AUTONOMY_BY_CONFIDENCE = {
    "stated": "default",
    "derived-strong": "advisory",
    "derived-weak": "ask_before_applying",
}
DEFAULT_CONFIDENCE = "derived-weak"   # unstated confidence gets the MOST cautious autonomy

BODY_FIELDS = ("Preference", "Chose", "Over", "Why", "Generalizes to", "Does NOT apply when")


def parse_frontmatter(text):
    """Flat key: value, plus one level of `metadata:` nesting — the shape these files use."""
    m = re.match(r"^---\n(.*?)\n---\n", text, re.S)
    if not m:
        return {}, text
    fm, body, in_meta = {}, text[m.end():], False
    for line in m.group(1).splitlines():
        if re.match(r"^\s*metadata:\s*$", line):
            in_meta = True
            continue
        kv = re.match(r'^(\s*)([\w-]+):\s*"?(.*?)"?\s*$', line)
        if not kv:
            continue
        indent, key, val = kv.group(1), kv.group(2), kv.group(3)
        if in_meta and not indent:
            in_meta = False
        fm[key] = val
    return fm, body


def _terms(value):
    return tuple(t.strip() for t in re.split(r"[,、,]", value or "") if t.strip())


def read_entry(path):
    """One `pref-*.md` as a typed entry, or None when the file is not a ledger record."""
    try:
        raw = open(path, encoding="utf-8", errors="replace").read()
    except OSError:
        return None
    fm, body = parse_frontmatter(raw)
    if "**Preference:**" not in body:
        return None

    name = fm.get("name") or os.path.basename(path)[:-3]
    conf = (fm.get("confidence") or DEFAULT_CONFIDENCE).strip()
    if conf not in AUTHORITY_BY_CONFIDENCE:
        conf = DEFAULT_CONFIDENCE

    fields = {}
    for f in BODY_FIELDS:
        m = re.search(rf"\*\*{re.escape(f)}:\*\*\s*(.+?)(?=\n\n|\n\*\*|\Z)", body, re.S)
        if m:
            fields[f] = " ".join(m.group(1).split())

    statement = fields.get("Preference", "")
    subject = (fm.get("description") or name).split(".")[0].strip()[:200] or name
    refs = [f"file:{path}", f"frontmatter_status:{fm.get('status', 'unset')}",
            f"confidence:{conf}", f"observations:{fm.get('observations', 'unset')}"]
    if fields.get("Over"):
        refs.append("counterfactual:present")

    return LedgerEntry(
        id=name,
        version=1,
        kind="preference",
        subject=subject,
        statement=statement or subject,
        scope=Scope(),
        authority=AUTHORITY_BY_CONFIDENCE[conf],
        status="active",
        autonomy=AUTONOMY_BY_CONFIDENCE[conf],
        risk="low",
        created_by=fm.get("originSessionId") or "unknown",
        created_at=fm.get("modified") or "unknown",
        source_references=tuple(refs),
        retrieval=RetrievalMetadata(
            trigger_terms=_terms(fm.get("triggers", "")),
            decision_keys=(decision_key(name),),
            applies_when=(fields["Does NOT apply when"],) if fields.get("Does NOT apply when") else (),
        ),
        lifecycle=Lifecycle(created_at=fm.get("modified") or "unknown"),
    )


def read_all(topics_dir):
    """Every readable record, plus the ones that could not be read and why. A file that fails to
    parse is REPORTED, never dropped — a silently skipped record looks identical to one that says
    nothing."""
    entries, skipped = [], []
    if not os.path.isdir(topics_dir):
        return entries, [("<dir>", f"no such directory: {topics_dir}")]
    for fn in sorted(os.listdir(topics_dir)):
        if not (fn.startswith("pref-") and fn.endswith(".md")):
            continue
        path = os.path.join(topics_dir, fn)
        try:
            e = read_entry(path)
        except Exception as err:                     # noqa: BLE001 - report, never crash a hook
            skipped.append((fn, f"{type(err).__name__}: {err}"))
            continue
        if e is None:
            skipped.append((fn, "no **Preference:** line — not a ledger record"))
        else:
            entries.append(e)
    return entries, skipped


def report(topics_dir):
    """What a migration WOULD do. Writes nothing, by design."""
    entries, skipped = read_all(topics_dir)
    by_auth, by_autonomy = {}, {}
    for e in entries:
        by_auth[e.authority] = by_auth.get(e.authority, 0) + 1
        by_autonomy[e.autonomy] = by_autonomy.get(e.autonomy, 0) + 1
    return {
        "source": topics_dir,
        "readable": len(entries),
        "skipped": skipped,
        "by_authority": by_auth,
        "by_autonomy": by_autonomy,
        "unscoped": sum(1 for e in entries if not e.scope.declared()),
        "would_write": [],          # nothing. The compatibility projection needs no write.
        "entries": entries,
    }
