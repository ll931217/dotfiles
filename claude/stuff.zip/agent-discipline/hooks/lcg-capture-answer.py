#!/usr/bin/env python3
"""PostToolUse[AskUserQuestion]: record what the human actually said, and cache it for this task.

Writes a QuestionOutcome against the prediction made moments earlier, and creates a TASK-LOCAL
ResolvedNeed (P4-13). Task-local is the whole scope available: turning one answer into a
repository or team rule needs approval this phase does not have (P4-14), and the ResolvedNeed
type has no field that could express it.

Flag: LCG_SHADOW_ASK. Emits nothing.
"""
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
sys.path.insert(0, ROOT)


def quiet():
    sys.exit(0)


def answers_from(ev):
    """Whatever shape the response arrives in. An unrecognised shape yields nothing, which
    records an outcome with no answer rather than inventing one."""
    resp = ev.get("tool_response")
    out = []
    if isinstance(resp, dict):
        for v in (resp.get("answers") or resp.get("selections") or {}).values() if isinstance(
                resp.get("answers") or resp.get("selections"), dict) else []:
            out.append(str(v))
        for k in ("answer", "selected", "choice"):
            if resp.get(k):
                out.append(str(resp[k]))
    elif isinstance(resp, str) and resp.strip():
        out.append(resp.strip())
    elif isinstance(resp, list):
        out += [str(x) for x in resp if x]
    return out


def main():
    try:
        ev = json.load(sys.stdin)
    except Exception:
        quiet()
    if ev.get("tool_name") != "AskUserQuestion":
        quiet()
    try:
        import config
        if not config.on("LCG_SHADOW_ASK"):
            quiet()
    except Exception:
        quiet()

    try:
        import datetime

        from agent_discipline_paths import mem_file
        from ledger.decision import ResolvedNeed, ResolvedNeedCache, classify_answer
        from ledger.prediction import JsonlStore, QuestionOutcome
        from ledger.session import SessionState, session_lock

        sid = str(ev.get("session_id") or "nosid")
        answers = answers_from(ev)
        preds = JsonlStore(mem_file("lcg_predictions.jsonl"))
        mine = [p for p in preds.read_all() if p.get("session_id") == sid]
        if not mine:
            quiet()
        outcomes = JsonlStore(mem_file("lcg_outcomes.jsonl"))
        done = {o.get("prediction_id") for o in outcomes.read_all()}
        pending = [p for p in mine if p["id"] not in done][-len(answers or [1]):]

        state_path = os.path.expanduser(f"~/.claude/tmp/lcg/{sid}.json")
        state = SessionState(state_path)

        with session_lock(state_path):
            st = state.read() or {}
            cache = ResolvedNeedCache(st.get("resolved_needs"))
            for i, p in enumerate(pending):
                actual = answers[i] if i < len(answers) else ""
                cls = classify_answer(actual, p.get("question_text", ""))
                rn_id = ""
                if actual and cls != "insufficient_to_classify":
                    rn = cache.add(ResolvedNeed(
                        key=p["decision_key"], answer=actual, answer_class=cls, source="human",
                        session_id=sid, task=str((st.get("manifest") or {}).get("task", ""))[:200],
                        created_at=datetime.datetime.now().astimezone().isoformat(
                            timespec="seconds")))
                    rn_id = rn.key
                outcomes.append(QuestionOutcome(
                    prediction_id=p["id"], decision_key=p["decision_key"],
                    actual_answer=actual, answer_source="human",
                    agreed_with_prediction=bool(p.get("predicted_answer")
                                                and p["predicted_answer"].strip().lower()
                                                == actual.strip().lower()),
                    resulting_resolved_need_id=rn_id, answer_class=cls))
            if st:
                st["resolved_needs"] = cache.to_list()
                try:
                    state.write(st, expected_revision=st.get("revision"))
                except Exception:
                    pass
    except Exception:
        quiet()
    quiet()


if __name__ == "__main__":
    main()
