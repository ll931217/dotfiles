#!/usr/bin/env python3
"""PreToolUse[AskUserQuestion]: predict silently. Never decide.

Shadow mode's exit criterion is "no question is suppressed" (P4-22). This hook therefore emits
NOTHING at all — no permission verdict, no injected context, no rewritten input. It writes a
prediction to disk and gets out of the way.

A test asserts this SOURCE FILE contains none of the strings a hook would need to interfere.
That is why they are not written out even in prose here: a guard you have to parse around is a
weaker guard, and the difference between measuring and interfering is one careless line.

`pref-checkpoint.py` is the other handler on this event and it informs. The two do different
jobs: that one helps the model now, this one measures whether it could ever be trusted to answer.

Flag: LCG_SHADOW_ASK, off by default.
"""
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
sys.path.insert(0, ROOT)


def quiet():
    sys.exit(0)


def main():
    try:
        ev = json.load(sys.stdin)
    except Exception:
        quiet()
    if ev.get("tool_name") != "AskUserQuestion":
        quiet()
    try:
        import config
        if not config.on("LCG_SHADOW_ASK"):
            quiet()
        mode = config.mode()
    except Exception:
        quiet()

    try:
        from agent_discipline_paths import mem_file, topics_dir
        from ledger.adapters import LedgerAdapter
        from ledger.decision import ResolvedNeedCache, need_from_question
        from ledger.prediction import JsonlStore, QuestionPrediction, new_prediction_id
        from ledger.session import SessionState, session_lock

        sid = str(ev.get("session_id") or "nosid")
        qs = (ev.get("tool_input") or {}).get("questions") or []
        if not qs:
            quiet()

        state_path = os.path.expanduser(f"~/.claude/tmp/lcg/{sid}.json")
        st = SessionState(state_path).read() or {}
        manifest = st.get("manifest") or {}
        cache = ResolvedNeedCache(st.get("resolved_needs"))
        preds = JsonlStore(mem_file("lcg_predictions.jsonl"))

        proj = None
        try:
            from ledger.projection import ActiveProjection
            from ledger.compat import read_all
            entries, _ = read_all(topics_dir())
            proj = ActiveProjection(entries)
        except Exception:
            proj = None

        for q in qs:
            opts = [o.get("label", "") for o in (q.get("options") or [])]
            need = need_from_question(q.get("question", ""), q.get("header", ""), opts)

            cached = cache.find(need)
            supporting, predicted, confidence = [], "", "none"
            if cached:
                predicted, confidence = cached.answer, "cached_answer"
                supporting = [f"resolved_need:{cached.key}"]
            elif proj is not None:
                hits = proj.by_decision_key(need.key) or []
                if hits:
                    supporting = [h.id for h in proj.rank(hits)]
                    confidence = "exact_key"
                    # Only map to an option when a label EXACTLY matches, and only when no other
                    # option would match too (P4-18). Anything else abstains.
                    top = proj.rank(hits)[0].statement.strip().lower()
                    exact = [o for o in opts if o.strip().lower() == top]
                    predicted = exact[0] if len(exact) == 1 else ""

            # Never predict on a mandatory-human category, in any mode (P4-27). The dataclass
            # enforces it too; this keeps the reason visible at the call site.
            if need.mandatory_human:
                predicted, confidence = "", "mandatory_human"

            preds.append(QuestionPrediction(
                id=new_prediction_id(), session_id=sid,
                tool_use_id=str(ev.get("tool_use_id") or ""),
                decision_key=need.key, question_text=need.original_text, options=opts,
                predicted_answer=predicted, mode=mode if mode in ("observe", "shadow") else "shadow",
                risk=need.risk, intent=need.intent, confidence=confidence,
                supporting_entry_ids=supporting,
                manifest_revision=int(manifest.get("revision", -1)),
                receipt_id=str(manifest.get("receipt_id", "")),
                mandatory_human=list(need.mandatory_human)))
    except Exception:
        quiet()
    quiet()      # ALWAYS silent. The question reaches the user untouched.


if __name__ == "__main__":
    main()
