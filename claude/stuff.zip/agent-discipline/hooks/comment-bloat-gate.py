#!/usr/bin/env python3
"""PreToolUse[Edit|Write|MultiEdit]: a comment block long enough to be an essay is not a comment.

A reviewer reads code to see what it does. A twenty-line prose header in front of eight lines of
shell buries that, and it rots faster than the code it describes — nobody re-reads a paragraph
when they change a flag. The standing rule (global CLAUDE.md) already says one short line;
relying on the model to remember it does not survive a long session, so this makes it mechanical.

Denies rather than nudges: a PostToolUse warning arrives after the essay is already on disk, and
the model has moved on. The deny names the file, the first line of the block, and how long it is.
Anything genuinely long-form belongs in `docs/`, where drift is checked; a comment can link to it.
"""
import json, os, re, sys

LINE = re.compile(r"^\s*(#|//|--(?!\[)|;)(\s?)(.*)$")
SHEBANG = re.compile(r"^#!")
# Counted per PARAGRAPH of flush prose, not per block. A usage listing, an option table or an
# exit-code list is reference a reader looks things up in; the thing this gate exists to stop is
# a wall of narration. Both live in the same header, and only one of them is the problem.
PARAGRAPH_MAX = 5
CODE = (".py", ".sh", ".bash", ".zsh", ".js", ".jsx", ".ts", ".tsx", ".go", ".rs", ".sql", ".c",
        ".cpp", ".h", ".java", ".rb", ".lua", ".tf")


def runs(text):
    """(start_line, length) per paragraph of flush comment prose.

    A lone `#`, an indented continuation, or any code line ends the paragraph — so an indented
    usage block breaks the count instead of inflating it."""
    out, n, start = [], 0, 0
    for i, line in enumerate(text.splitlines(), 1):
        m = LINE.match(line)
        prose = bool(m) and not SHEBANG.match(line.lstrip()) \
            and m.group(3).strip() != "" and not m.group(3).startswith(("  ", "\t"))
        if prose:
            n, start = n + 1, start or i
        else:
            if n:
                out.append((start, n))
            n, start = 0, 0
    if n:
        out.append((start, n))
    return out


def offender(text):
    for start, n in runs(text):
        if n > PARAGRAPH_MAX:
            return start, n, PARAGRAPH_MAX
    return None


def new_text(ti):
    """What this call puts on disk, as far as the gate can see it."""
    if "content" in ti:
        return ti["content"]
    edits = ti.get("edits")
    if edits:
        return "\n".join(e.get("new_string", "") for e in edits)
    return ti.get("new_string", "")


def main():
    try:
        ev = json.load(sys.stdin)
    except Exception:
        return
    ti = ev.get("tool_input") or {}
    path = ti.get("file_path", "")
    if not path.endswith(CODE):
        return                       # prose files are prose; this gate is about code
    hit = offender(new_text(ti))
    if not hit:
        return
    start, n, cap = hit
    print(json.dumps({"hookSpecificOutput": {
        "hookEventName": "PreToolUse", "permissionDecision": "deny",
        "permissionDecisionReason": (
            f"{os.path.basename(path)}: a {n}-line comment paragraph starting at line {start} "
            f"(max {cap}).\n"
            f"A reviewer reads the code; a paragraph in front of it hides what changed and goes "
            f"stale on the next edit. Cut it to the one thing the code cannot say itself — "
            f"usually WHY, never WHAT.\n"
            f"  keep      the non-obvious constraint, the gotcha, the unit\n"
            f"  delete    restating the next line, history, background, alternatives considered\n"
            f"  move      a real explanation into docs/ and link it in one line")}}))


if __name__ == "__main__":
    main()
