#!/usr/bin/env python3
"""PreToolUse[AskUserQuestion]: inject matching preference records AT THE MOMENT of asking.

Rule AS2 (~/.claude/rules/answer-shape.md) says preference-type questions must be answered from
the ledger, not sent to the user. Relying on the model to remember that scores ~16% (measured),
so this hook makes it mechanical: when the ledger has a matching record, the record's CONTENT is
handed back at the moment of asking.

Two behaviours, chosen by LCG_ASK_DENY (see config.py):

  0 (default)  INFORM. The records are injected and the question still reaches the user. This is
               what the spec's own AskUserQuestion interception does — §18.9 emits only
               permissionDecision "allow", at every autonomy level, and its Phase 4 exit
               criterion is "no question is suppressed". It also matches the standing rule that
               hooks here inform and never block.
  1            DENY once per session per question, then allow a re-issue. The original behaviour,
               kept because removing a gate is a behaviour change, not a refactor.

Never acts at all when the ledger has nothing to say.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
from agent_discipline_paths import memory_dir, topics_dir, mem_file  # noqa: E402
import hashlib, json, os, re, sys

PREFS = topics_dir()
STATE_DIR = os.path.expanduser("~/.claude/tmp/pref-checkpoint")
MIN_SCORE = 2

# Reuse memory-kit's stopword list rather than inventing a second one — same matching problem.
# Without this, "should" + "the" alone scored 2 and denied an unrelated question (caught by the
# negative control in pref-effectiveness.py --selftest).
try:
    sys.path.insert(0, os.path.expanduser("~/.claude/scripts"))
    from memory_cue import ASCII_STOP as _STOP
    STOP = set(_STOP) | {"should", "which", "your", "would", "could", "need", "does", "did"}
except Exception:
    STOP = {"the", "and", "for", "this", "that", "with", "from", "what", "when", "should",
            "which", "your", "would", "could", "need", "does", "did", "are", "was", "can",
            "how", "not", "you", "all", "but", "have", "will", "use", "one", "two", "into"}

EVENTS = mem_file("pref_events.tsv")

try:
    import config as _cfg
    DENY = _cfg.on("LCG_ASK_DENY")
except Exception:
    # A missing or broken config must not resurrect blocking. Inform is the safe default.
    DENY = False

def log_event(kind, session, detail, extra=""):
    """One row per ledger interaction. `kind` distinguishes AUTOMATED injection from a
    decision the ledger actually forced (canon evidence-first EF5: never sum the two)."""
    import datetime
    try:
        new = not os.path.exists(EVENTS)
        with open(EVENTS, "a") as f:
            if new:
                f.write("ts\tkind\tsession\tdetail\textra\n")
            f.write("\t".join([
                datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
                kind, str(session), str(detail)[:120].replace("\t", " "),
                str(extra)[:120].replace("\t", " ")]) + "\n")
    except OSError:
        pass


def allow():
    sys.exit(0)

def frontmatter(text):
    m = re.match(r"^---\n(.*?)\n---\n", text, re.S)
    if not m:
        return {}, text
    fm, body = {}, text[m.end():]
    for line in m.group(1).splitlines():
        k = re.match(r'^\s*(\w+):\s*"?(.*?)"?\s*$', line)
        if k:
            fm[k.group(1)] = k.group(2)
    return fm, body

def terms(s):
    ascii_toks = {t for t in re.findall(r"[a-z][a-z0-9-]{2,}", s.lower()) if t not in STOP}
    cjk = {t.strip() for t in re.split(r"[,、,]", s) if re.search(r"[一-鿿]", t)}
    return ascii_toks, {c for c in cjk if c}

def trigger_terms(s):
    """`triggers:` is a comma-separated list, so a multi-word entry is ONE phrase. Tokenizing it
    made "new card" fire on any question containing "new" — that is what broke the negative
    control. Phrase entries match whole, single-word entries still go through the stopword list."""
    out = []
    for item in re.split(r"[,、,]", s):
        item = item.strip().lower()
        if not item:
            continue
        if re.search(r"[一-\u9fff]", item):
            out.append(("cjk", item))
        elif " " in item or "-" in item:
            out.append(("phrase", item))
        elif len(item) > 2 and item not in STOP:
            out.append(("word", item))
    return out

def score(hay, fm):
    hl = hay.lower()
    total = 0
    for kind, t in trigger_terms(fm.get("triggers", "")):
        if kind == "cjk":
            total += 2 * (t in hay)
        else:
            total += 2 * bool(re.search(rf"\b{re.escape(t)}\b", hl))
    a, c = terms(fm.get("description", ""))
    total += sum(1 for t in a if re.search(rf"\b{re.escape(t)}\b", hl))
    total += sum(1 for t in c if t in hay)
    return total

def main():
    try:
        ev = json.load(sys.stdin)
    except Exception:
        allow()
    if ev.get("tool_name") != "AskUserQuestion" or not os.path.isdir(PREFS):
        allow()

    qs = (ev.get("tool_input") or {}).get("questions") or []
    hay = " ".join(
        [q.get("question", "") + " " + q.get("header", "") for q in qs]
        + [o.get("label", "") + " " + o.get("description", "") for q in qs for o in q.get("options", [])]
    )
    if not hay.strip():
        allow()

    hits = []
    for fn in sorted(os.listdir(PREFS)):
        if not (fn.startswith("pref-") and fn.endswith(".md")):
            continue
        raw = open(os.path.join(PREFS, fn), errors="replace").read()
        fm, body = frontmatter(raw)
        if "**Preference:**" not in body:
            continue
        sc = score(hay, fm)
        if sc >= MIN_SCORE:
            keep = [ln for ln in body.splitlines()
                    if ln.startswith(("**Preference:**", "**Chose:**", "**Over:**", "**Why:**",
                                      "**Does NOT apply when:**"))]
            hits.append((sc, fn, fm.get("confidence", "?"), "\n".join(keep[:5])))
    if not hits:
        # The DENOMINATOR. Without this row the dashboard reports "the ledger spoke to 8
        # questions" with nothing to divide by, so 8-of-10 and 8-of-200 look identical.
        # Logged AFTER the ledger has genuinely been consulted, never for a non-question.
        log_event("uncovered", ev.get("session_id", "nosid"), "-", hay[:100])
        allow()
    hits.sort(reverse=True)

    sid = str(ev.get("session_id", "nosid"))
    key = hashlib.sha1((sid + hay).encode()).hexdigest()[:16]
    os.makedirs(STATE_DIR, exist_ok=True)
    seen_path = os.path.join(STATE_DIR, f"{sid}.json")
    try:
        seen = set(json.load(open(seen_path)))
    except Exception:
        seen = set()
    if DENY and key in seen:
        # Re-issued after being challenged: the ledger did NOT settle it. This is the
        # metric's path to red (EF10) — without it the score could never come out bad.
        log_event("reissued", sid, hits[0][1], hay[:100])
        allow()
    seen.add(key)
    json.dump(sorted(seen), open(seen_path, "w"))

    head = ("[pref-checkpoint] The preference ledger already has a record covering this question.",
            "Per rule AS2, a preference-type question is answered from the ledger, not sent to the user.")
    lines = list(head) + [""]
    for sc, fn, conf, excerpt in hits[:3]:
        lines.append(f"── {fn}  (confidence: {conf}, match {sc})")
        lines.append(excerpt)
        lines.append("")
    if DENY:
        lines.append("Decide from the above and state your assumption inline (rule AS1 — carry the "
                     "reasoning, not just the filename). If this is genuinely an intent/trade-off "
                     "question the ledger cannot settle, re-issue the SAME question and it will go "
                     "through.")
    else:
        lines.append("This question is NOT blocked — it is going to the user now. If the records "
                     "above already settle it, withdraw the question and act on them, stating your "
                     "assumption inline (rule AS1 — carry the reasoning, not just the filename).")

    if DENY:
        log_event("deny", sid, hits[0][1], f"match={hits[0][0]} q={hay[:70]}")
        print(json.dumps({"hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": "deny",
            "permissionDecisionReason": "\n".join(lines),
        }}))
        return
    # Inform. The question still reaches the user, so the ledger cannot claim to have prevented
    # it — `inform` is deliberately a DIFFERENT event kind from `deny` so the dashboard can never
    # sum a surfaced record with a question that was actually stopped (canon EF5).
    log_event("inform", sid, hits[0][1], f"match={hits[0][0]} q={hay[:70]}")
    print(json.dumps({"hookSpecificOutput": {
        "hookEventName": "PreToolUse",
        "permissionDecision": "allow",
        "additionalContext": "\n".join(lines),
    }}))

if __name__ == "__main__":
    main()
