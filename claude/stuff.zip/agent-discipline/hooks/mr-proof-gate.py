#!/usr/bin/env python3
"""PreToolUse[Bash]: an MR body without proof the change actually ran is not review-ready.

A worker reports "every lens PASS" and opens the MR; the reviewer gets a shaped diff and a
sentence claiming the tests are green. That claim is unverifiable from the MR page, so the
reviewer either trusts it or re-runs the suite by hand. Proof is cheap at the moment the worker
still has the terminal open and impossible to reconstruct later.

Denies (does not warn) because the MR is outward-facing: once created, a body without proof is
already in front of the reviewer, and a PostToolUse nudge arrives too late to matter. The deny
names what is missing and how to capture it, and `--fill` chores are exempt.
"""
import json, os, re, subprocess, sys

PROOF = re.compile(r"^\s*(#{1,4}\s*|\*\*|__)?(proof|evidence|驗證|證據)\b", re.I | re.M)
# An artifact, not a sentence about one: an image, a fenced block of real output, or an
# uploaded file. Prose claiming "tests pass" is exactly what this gate exists to reject.
ARTIFACT = re.compile(r"!\[[^\]]*\]\([^)]+\)|/uploads/|```")
CREATE = re.compile(r"\bglab\s+mr\s+create\b")


def body_text(cmd, cwd):
    """The description glab will actually send: inline, from a file, or from $(cat FILE)."""
    m = re.search(r"--description[= ]\s*[\"']?\$\(\s*cat\s+([^)\s]+)\s*\)", cmd)
    if not m:
        m = re.search(r"--description-file[= ]\s*[\"']?([^\s\"']+)", cmd)
    if m:
        p = m.group(1).strip("\"'")
        p = p if os.path.isabs(p) else os.path.join(cwd, p)
        try:
            return open(p).read()
        except OSError:
            return ""
    m = re.search(r"--description[= ]\s*(\"([^\"]*)\"|'([^']*)')", cmd, re.S)
    return (m.group(2) or m.group(3) or "") if m else ""


def main():
    try:
        ev = json.load(sys.stdin)
    except Exception:
        return
    cmd = (ev.get("tool_input") or {}).get("command", "")
    if not CREATE.search(cmd) or "--fill" in cmd:
        return                       # --fill is the documented chore path; nobody reviews it
    cwd = ev.get("cwd") or os.getcwd()
    body = body_text(cmd, cwd)
    if not body:
        return                       # no body to judge; glab will complain on its own
    if PROOF.search(body) and ARTIFACT.search(body):
        return

    missing = "a Proof section" if not PROOF.search(body) else "an artifact under Proof"
    msg = (f"MR body is missing {missing}. A reviewer cannot verify a claim that the tests pass "
           f"— paste what you saw, in the body, before creating the MR:\n"
           f"  UI change   -> a screenshot: agent-browser screenshot, then attach it\n"
           f"  CLI / tests -> the run itself in a fenced block: the command AND its last lines\n"
           f"  a long or live run -> tmux capture-pane -p -t <pane> | tail -40, fenced\n"
           f"Shape:\n\n  ## Proof\n  ```\n  $ ./scripts/run-tests.sh\n  ... 42 passed\n  ```\n\n"
           f"Prose asserting it works is what this gate rejects. Genuinely unprovable "
           f"(interactive TTY, real hardware)? Say so IN THE BODY under Proof, with the manual "
           f"transcript, and it passes.")
    print(json.dumps({"hookSpecificOutput": {
        "hookEventName": "PreToolUse", "permissionDecision": "deny",
        "permissionDecisionReason": msg}}))


if __name__ == "__main__":
    main()
