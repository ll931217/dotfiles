#!/usr/bin/env python3
"""UserPromptSubmit: a batch of tasks arrived and no worker exists — dispatch, don't type.

Both existing orchestration guards fire only AFTER a worktree exists: worktree-delegate-nudge
needs one to appear, orchestrator-hands-off needs a delegate.json to edit against. A session
that never dispatches is therefore never nudged, and implements the whole batch itself
(observed 2026-09-04, tmux atlas:0). This closes the gap at the only moment the choice is still
open: the prompt that hands the batch over, before the first edit.

Evidence, never text alone: either the prompt names 2+ issue ids, or it is batch-shaped AND
`bd ready` actually has 2+ items. Silent once any worker is active, and once per session.
"""
import json, os, re, subprocess, sys

STATE_DIR = os.path.expanduser("~/.claude/tmp/batch-dispatch-nudge")
ID = re.compile(r"\b[a-z][a-z0-9-]*-[0-9a-z]{2,6}\b|\b[A-Z]{2,10}-\d+\b")
BATCH = re.compile(r"\b(these (tasks|issues|tickets|beads)|all of these|the sprint|the backlog|"
                   r"this epic|the epic|work through|knock out|churn through|one by one)\b", re.I)
BATCH_ZH = ("這些任務", "這些議題", "這些票", "整個 sprint", "全部做完", "一個一個做")
ALREADY = re.compile(r"/orchestrate|/delegate", re.I)


def sh(cmd, cwd):
    try:
        r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=10)
        return r.returncode, r.stdout
    except Exception:
        return 1, ""


def workers_active(root):
    import glob
    for st in glob.glob(os.path.join(root, ".worktrees", "*", ".claude", "delegate.json")):
        try:
            if json.load(open(st)).get("status") in ("assigned", "rejected", "reported"):
                return True
        except Exception:
            continue
    return False


def ready_count(root):
    rc, out = sh(["bd", "ready", "--json"], root)
    if rc != 0:
        return 0
    try:
        d = json.loads(out)
        return len(d if isinstance(d, list) else d.get("issues", []))
    except Exception:
        return 0


def main():
    try:
        ev = json.load(sys.stdin)
    except Exception:
        return
    prompt = ev.get("prompt") or ""
    if not prompt or ALREADY.search(prompt):
        return
    ids = set(ID.findall(prompt))
    batchy = bool(BATCH.search(prompt)) or any(t in prompt for t in BATCH_ZH)
    if len(ids) < 2 and not batchy:
        return

    cwd = ev.get("cwd") or os.getcwd()
    rc, root = sh(["git", "rev-parse", "--show-toplevel"], cwd)
    root = root.strip()
    if rc != 0 or not root or "/.worktrees/" in root:
        return
    if workers_active(root):
        return                       # already orchestrating; hands-off owns it from here

    n = len(ids)
    if n < 2:
        n = ready_count(root)
        if n < 2:
            return                   # batch-shaped words, no batch behind them

    sid = str(ev.get("session_id") or "nosid")
    mark = os.path.join(STATE_DIR, f"{sid}.done")
    if os.path.exists(mark):
        return                       # said once; a nudge repeated every prompt is noise
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        open(mark, "w").write(prompt[:80])
    except OSError:
        pass

    msg = (f"[orchestrate] This prompt hands over {n} tasks and no worker is running in {root}. "
           f"In this flow you dispatch and review; workers type. Run the `orchestrate` skill "
           f"(/orchestrate) — `orchestrate.py plan`, then one `dispatch` per ready task BEFORE "
           f"reviewing any — instead of implementing them here. One task only, or the batch is "
           f"too small to be worth a worktree? Say so in one clause and carry on.")
    print(json.dumps({"hookSpecificOutput": {
        "hookEventName": "UserPromptSubmit", "additionalContext": msg}, "suppressOutput": True}))


if __name__ == "__main__":
    main()
