#!/usr/bin/env python3
"""PostToolUse[Skill]: preload the preference ledger when a prose-asking skill starts.

`pref-checkpoint.py` only guards the AskUserQuestion TOOL. Skills like /grilling interview the
user in plain prose, so no tool call ever happens and nothing can be intercepted. The only
action-time moment available is skill LOAD — so at that moment the whole ledger goes into
context, before the first question is composed.

Small by construction: one digest, capped, only for skills that actually interview the user.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from agent_discipline_paths import memory_dir, topics_dir, mem_file  # noqa: E402
import json, os, re, sys

PREFS = topics_dir()
CAP = 6000
CONF_ORDER = {"stated": 0, "derived-strong": 1, "derived-weak": 2}

# Skills that interview the user in prose. Extend freely; the regex catches near-misses.
ASKS_IN_PROSE = {
    "grilling", "grill-me", "grill-with-docs", "to-spec", "to-questionnaire",
    "to-tickets", "wizard", "prototype", "codebase-design", "domain-modeling",
    "triage", "handoff", "teach", "research", "implement", "reflect", "visual-plan",
    # Decision-heavy skills: they choose on the user's behalf all the way through, which is
    # exactly when a recorded preference should already be in context.
    "jira-autopilot", "mr-automerge", "code-review", "grilling", "unlazy",
}
NEAR = re.compile(r"grill|spec|question|interview|plan|design|scope|clarif", re.I)

EVENTS = mem_file("pref_events.tsv")

def log_event(kind, session, detail, extra=""):
    """One row per ledger interaction. `kind` distinguishes AUTOMATED injection from a
    decision the ledger actually forced (canon evidence-first EF5: never sum the two)."""
    import datetime
    try:
        new = not os.path.exists(EVENTS)
        with open(EVENTS, "a") as f:
            if new:
                f.write("ts\tkind\tsession\tdetail\textra\n")
            f.write("\t".join([
                datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
                kind, str(session), str(detail)[:120].replace("\t", " "),
                str(extra)[:120].replace("\t", " ")]) + "\n")
    except OSError:
        pass


def quiet():
    sys.exit(0)

def frontmatter(text):
    m = re.match(r"^---\n(.*?)\n---\n", text, re.S)
    if not m:
        return {}, text
    fm = {}
    for line in m.group(1).splitlines():
        k = re.match(r'^\s*(\w+):\s*"?(.*?)"?\s*$', line)
        if k:
            fm[k.group(1)] = k.group(2)
    return fm, text[m.end():]

def main():
    try:
        ev = json.load(sys.stdin)
    except Exception:
        quiet()
    if ev.get("tool_name") != "Skill":
        quiet()
    skill = str((ev.get("tool_input") or {}).get("skill", ""))
    base = skill.split(":")[-1]
    if base not in ASKS_IN_PROSE and not NEAR.search(base):
        quiet()
    if not os.path.isdir(PREFS):
        quiet()

    recs = []
    for fn in sorted(os.listdir(PREFS)):
        if not (fn.startswith("pref-") and fn.endswith(".md")):
            continue
        fm, body = frontmatter(open(os.path.join(PREFS, fn), errors="replace").read())
        keep = [ln.strip() for ln in body.splitlines()
                if ln.startswith(("**Preference:**", "**Chose:**", "**Over:**",
                                  "**Does NOT apply when:**"))]
        if not keep:
            continue
        conf = fm.get("confidence", "derived-weak")
        recs.append((CONF_ORDER.get(conf, 9), fn, conf, keep))
    if not recs:
        quiet()
    recs.sort()

    out = [f"[pref-preload] `{skill}` interviews the user in prose, so the AskUserQuestion "
           f"checkpoint cannot fire. The preference ledger is injected here instead — "
           f"{len(recs)} record(s), highest-confidence first.",
           "",
           "Rule AS2: a question these records already settle must NOT be asked. Decide, and "
           "state the assumption inline (AS1 — carry the reasoning, not the filename). Only "
           "intent / trade-off questions go to the user.",
           ""]
    for _, fn, conf, keep in recs:
        block = [f"── {fn[:-3]}  ({conf})"] + keep
        if sum(len(x) for x in out) + sum(len(x) for x in block) > CAP:
            out.append(f"… {len(recs)} total; remainder truncated, read {PREFS}/ if needed.")
            break
        out += block + [""]
    out.append("New preference learned during this skill? Capture it per AS3 before the topic closes.")

    log_event("preload", ev.get("session_id", "-"), skill, f"records={len(recs)}")
    print(json.dumps({"hookSpecificOutput": {
        "hookEventName": "PostToolUse", "additionalContext": "\n".join(out)}}))

if __name__ == "__main__":
    main()
