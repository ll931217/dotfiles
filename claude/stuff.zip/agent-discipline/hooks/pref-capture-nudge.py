#!/usr/bin/env python3
"""UserPromptSubmit: when the user's message IS a decision, demand it be captured (rule AS3).

AS1/AS2 are enforced (pref-checkpoint, pref-preload). AS3 — write a ledger record for every pick
— had no mechanism, so it decays exactly like every other "remember to" rule. This closes it: the
user's own prompt is the signal, and it arrives before the reply is composed.

Fires on: a bare option pick ("1", "b") that answers an options-shaped reply, or override /
preference language in either language. Silent otherwise.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
from agent_discipline_paths import memory_dir, topics_dir, mem_file  # noqa: E402
import json, os, re, sys

PREFS_DIR = topics_dir()
STATE = os.path.expanduser("~/.claude/tmp/pref-checkpoint")

OVERRIDE = re.compile(
    r"\b(instead|rather than|i'?d (prefer|rather)|i want|i'?d like|prefer\b|avoid|don'?t|do not|"
    r"stop doing|actually|no,|wrong|too much|too detailed|the issue is)\b", re.I)
OVERRIDE_ZH = ("不要", "不用", "改成", "改用", "比較好", "我想要", "我要", "避免", "應該",
               "不對", "太多", "太細", "反而", "其實", "不需要")

# Choosing one of the options just offered, in the shapes people actually type. These were all
# MISSES until 2026-09-01: "go with the second one", "let's do B", "option A please",
# "prefer the terminal version", "就用 A 吧" — every one of them a real pick.
CHOICE = re.compile(
    r"^\s*(go (with|for)|let'?s (do|go with|use)|option\b|i'?ll take|take\b|pick\b|use the\b|"
    r"going with|do\b)\s+\S", re.I)
CHOICE_WORDS = re.compile(
    r"\b(the (first|second|third|last|latter|former)( one)?|option [a-d]\b)", re.I)
CHOICE_ZH = ("就用", "選", "第一個", "第二個", "第三個", "用這個", "照這個")

# A stated reason is the highest-value thing the ledger can hold — never let it pass unrecorded.
REASON = re.compile(r"\b(because|since|the reason|that way|so that|as it'?s|makes more sense)\b", re.I)
REASON_ZH = ("因為", "原因是", "這樣才", "比較快", "比較簡單")

BARE_PICK = re.compile(r"^\s*(\d{1,2}|[a-dA-D])\s*[.)]?\s*$")
# "A, it will be distributed later" / "2 — because ..." : a pick with its reason attached.
PICK_THEN_REASON = re.compile(r"^\s*(\d{1,2}|[a-dA-D])\s*[.,:;—-]\s+\S", re.I)
OFFERED = re.compile(r"(I'?d go\b|^\s*\d\.\s|\*\*Next step|pick one|Want me to)", re.M)


def quiet():
    sys.exit(0)

def last_assistant_text(path, limit=40):
    try:
        lines = open(path, errors="replace").readlines()[-limit:]
    except Exception:
        return ""
    for line in reversed(lines):
        try:
            d = json.loads(line)
        except Exception:
            continue
        m = d.get("message") or {}
        if m.get("role") != "assistant":
            continue
        ct = m.get("content")
        if isinstance(ct, list):
            txt = " ".join(b.get("text", "") for b in ct
                           if isinstance(b, dict) and b.get("type") == "text")
            if txt.strip():
                return txt
        elif isinstance(ct, str) and ct.strip():
            return ct
    return ""

def main():
    try:
        ev = json.load(sys.stdin)
    except Exception:
        quiet()
    prompt = (ev.get("prompt") or "").strip()
    if not prompt or len(prompt) > 1500:
        quiet()

    kind = None
    if BARE_PICK.match(prompt) or PICK_THEN_REASON.match(prompt):
        prev = last_assistant_text(ev.get("transcript_path", ""))
        if OFFERED.search(prev):
            kind = "an option pick answering the options you just offered"
    if kind is None and (CHOICE.match(prompt) or CHOICE_WORDS.search(prompt)
                         or any(t in prompt for t in CHOICE_ZH)):
        kind = "a choice between options"
    if kind is None and (OVERRIDE.search(prompt) or any(t in prompt for t in OVERRIDE_ZH)):
        kind = "override / preference language"
    if kind is None and (REASON.search(prompt) or any(t in prompt for t in REASON_ZH)):
        kind = "a stated reason — the part that makes future decisions derivable"
    if kind is None:
        quiet()

    # don't nudge twice in a row
    sid = str(ev.get("session_id", "nosid"))
    os.makedirs(STATE, exist_ok=True)
    mark = os.path.join(STATE, f"{sid}.nudge")
    try:
        if open(mark).read().strip() == prompt[:80]:
            quiet()
    except Exception:
        pass
    open(mark, "w").write(prompt[:80])

    n = len([f for f in os.listdir(PREFS_DIR) if f.startswith("pref-")]) \
        if os.path.isdir(PREFS_DIR) else 0

    msg = f"""[pref-capture] This prompt reads as {kind} — rule AS3 applies.

Before this topic closes, write or sharpen a ledger record in
{PREFS_DIR}/pref-<slug>.md  (currently {n} records; flat directory only — a subdirectory is
invisible to the recall hook).

Required fields, per ~/.claude/skills/preference-ledger/procedure.md:
  **Preference:** imperative, what to do next time
  **Chose:** ... / **Over:** the option NOT taken  <- without this nothing is derivable later
  **Why:** quote the user if stated; mark (derived) and name the observation if not
  **Generalizes to:** / **Does NOT apply when:** the boundary
  frontmatter: description + triggers, BOTH languages; confidence stated|derived-strong|derived-weak

Already covered by an existing record? Then bump its `observations`, raise confidence, or add the
boundary it just revealed — do not write a duplicate. Genuinely nothing durable here (a plain task
instruction)? Skip it and say so in one clause."""

    print(json.dumps({"hookSpecificOutput": {
        "hookEventName": "UserPromptSubmit", "additionalContext": msg},
        "suppressOutput": True}))

if __name__ == "__main__":
    main()
