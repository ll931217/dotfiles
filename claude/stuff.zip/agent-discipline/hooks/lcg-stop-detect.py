#!/usr/bin/env python3
"""Stop: notice when the model asked for clarification in PLAIN TEXT instead of using the tool.

That is the case the AskUserQuestion interception can never see, so it is the last checkpoint
before a question reaches the user unmeasured (P3-25, P4-25).

Detection is deliberately CONSERVATIVE. Every rule here costs a false positive somewhere, and a
false positive in shadow mode is a wrong row in a calibration table — which is worse than a miss,
because it makes the numbers look like evidence when they are noise. So: a question mark alone is
not enough, a question about the code is not a question for the human, and anything ambiguous is
not a candidate.

This hook NEVER continues the session and never blocks the stop. It records a candidate.

Flag: LCG_STOP_DETECT, off by default.
"""
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
sys.path.insert(0, ROOT)

# Must address the human AND request a decision. Both, not either.
ADDRESSES_HUMAN = re.compile(
    r"\b(would you|do you want|should i|shall i|which would you|let me know|"
    r"your call|up to you|tell me which|do you prefer|confirm whether)\b", re.I)

OFFERS_A_CHOICE = re.compile(
    r"(\bor\b.*\?|\boption [ab12]\b|\beither\b.*\bor\b|^\s*[-*]\s*[AB][.):]|"
    r"\b(a|b)\s*[:.]\s*\w+.*\b(a|b)\s*[:.]\s*\w+)", re.I | re.M)

# Rhetorical or self-directed. A model narrating its own reasoning is not asking anyone.
NOT_A_REQUEST = re.compile(
    r"\b(let me check|i'll check|i will check|let me look|i'm going to|"
    r"the question is whether|why does|what happens when|to answer that)\b", re.I)


def quiet():
    sys.exit(0)


def looks_like_a_question_for_the_human(text):
    """Returns (is_candidate, reason). Conservative by construction: three conditions must hold."""
    if not text or "?" not in text:
        return False, "no question mark"
    tail = text[-1500:]
    if NOT_A_REQUEST.search(tail):
        return False, "reads as narration, not a request"
    if not ADDRESSES_HUMAN.search(tail):
        return False, "does not address the human"
    if not OFFERS_A_CHOICE.search(tail):
        return False, "no choice offered"
    return True, "addresses the human and offers a choice"


def main():
    try:
        ev = json.load(sys.stdin)
    except Exception:
        quiet()
    try:
        import config
        if not config.on("LCG_STOP_DETECT"):
            quiet()
        mode = config.mode()
    except Exception:
        quiet()

    try:
        from agent_discipline_paths import mem_file
        from ledger.decision import need_from_question
        from ledger.prediction import JsonlStore, QuestionPrediction, new_prediction_id

        text = ev.get("last_assistant_message") or ev.get("message") or ev.get("transcript") or ""
        if not isinstance(text, str):
            text = json.dumps(text)
        ok, reason = looks_like_a_question_for_the_human(text)

        # Both outcomes are recorded. Logging only the hits would make the false-positive rate
        # unmeasurable, and measuring it is the point (P4-25).
        JsonlStore(mem_file("lcg_stop_candidates.jsonl")).append({
            "session_id": str(ev.get("session_id") or "nosid"),
            "candidate": ok, "reason": reason, "excerpt": text[-400:],
        })
        if not ok:
            quiet()

        need = need_from_question(text[-400:])
        JsonlStore(mem_file("lcg_predictions.jsonl")).append(QuestionPrediction(
            id=new_prediction_id(), session_id=str(ev.get("session_id") or "nosid"),
            decision_key=need.key, question_text=text[-400:], options=[],
            predicted_answer="", mode=mode if mode in ("observe", "shadow") else "shadow",
            risk=need.risk, intent=need.intent, confidence="stop_recovery_candidate",
            mandatory_human=list(need.mandatory_human)))
    except Exception:
        quiet()
    quiet()      # the session stops exactly as it would have


if __name__ == "__main__":
    main()
