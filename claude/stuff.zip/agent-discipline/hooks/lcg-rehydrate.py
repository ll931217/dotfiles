#!/usr/bin/env python3
"""SessionStart: bring back what a compaction, resume or fork threw away.

The manifest lives on disk precisely so a context reset does not destroy it. This injects a
COMPACT view — revision, frontier size, the mandatory items, and what is degraded. Never the full
manifest and never the event history: rehydrating everything would refill the context the
compaction just cleared.

`PreCompact` is unverified on this Claude Code build, so recovery is driven from SessionStart
where `source` is `compact`, `resume`, `clear` or `startup` (gap analysis R4).

Cannot block: SessionStart has no such power, and this only ever adds context.
"""
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
sys.path.insert(0, ROOT)

MAX_ITEMS = 8


def quiet():
    sys.exit(0)


def main():
    try:
        ev = json.load(sys.stdin)
    except Exception:
        quiet()
    try:
        import config
        if not config.on("LCG_RESOLVER"):
            quiet()
    except Exception:
        quiet()

    source = (ev.get("source") or "startup").lower()
    if source == "startup":
        quiet()          # a fresh session has nothing to rehydrate; M0 will be built normally

    try:
        from ledger.session import SessionState
        sid = str(ev.get("session_id") or "nosid")
        st = SessionState(os.path.expanduser(f"~/.claude/tmp/lcg/{sid}.json")).read()
        if not st or not st.get("manifest"):
            quiet()
        m = st["manifest"]
        lines = [f"LEDGER CONTEXT RECOVERED after {source}",
                 f"Manifest {m.get('manifest_id')} revision {m.get('revision')}"
                 f"  ·  {len(st.get('frontier') or [])} entities in scope",
                 f"Task: {m.get('task', '')[:160]}", ""]

        mandatory = [i for section in ("applicable_policies", "active_decisions")
                     for i in m.get(section, []) if i.get("autonomy") == "mandatory"]
        if mandatory:
            lines.append("Still in force (mandatory):")
            lines += [f"  - {i['statement']}  [{i['authority']}]" for i in mandatory[:MAX_ITEMS]]
            lines.append("")
        others = [i for section in ("applicable_policies", "active_decisions", "preferences")
                  for i in m.get(section, []) if i.get("autonomy") != "mandatory"]
        # The pointer is unconditional. With every source degraded the manifest can be empty, and
        # a recovery note that lists nothing AND says nothing about where to look is worse than
        # silence — it reads as "there was nothing", not "nothing could be read".
        lines.append(f"Also active: {len(others)} item(s). "
                     f"`ledger-why.py {m.get('receipt_id')}` shows what was considered.")
        if m.get("degraded_sources"):
            lines.append("DEGRADED when this was resolved: "
                         + ", ".join(d["source"] for d in m["degraded_sources"]))
        if m.get("conflicts"):
            lines.append(f"{len(m['conflicts'])} unresolved conflict(s) carried over.")
        lines.append("")
        lines.append("This is a summary of state held OUTSIDE the conversation, not a re-read of it.")
        print(json.dumps({"hookSpecificOutput": {
            "hookEventName": "SessionStart", "additionalContext": "\n".join(lines)}}))
    except Exception:
        quiet()


if __name__ == "__main__":
    main()
