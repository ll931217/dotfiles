#!/usr/bin/env python3
"""PostToolUse[Bash]: after a git push, surface Jira<->beads drift for THIS repo.

A rule that must be remembered decays (measured: 16.4%). Push is the moment work becomes
shared, so it is the natural checkpoint. Non-blocking by design — it reports, the human
decides. Silent when the repo has no .claude/jira_issues or no drift.
"""
import json, os, re, subprocess, sys

# Fall back to this file's own location, never a hardcoded checkout path — the checkout moves.
AUDIT = os.path.join(os.environ.get("CLAUDE_PLUGIN_ROOT",
                     os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
                     "scripts", "jira-beads-audit.py")

def main():
    try:
        ev = json.load(sys.stdin)
    except Exception:
        return
    cmd = (ev.get("tool_input") or {}).get("command", "")
    if not re.search(r"\bgit\s+push\b|\bglab\s+mr\s+create\b", cmd):
        return
    cwd = ev.get("cwd") or os.getcwd()
    root = subprocess.run(["git", "rev-parse", "--show-toplevel"], cwd=cwd,
                          capture_output=True, text=True)
    repo = root.stdout.strip() or cwd
    if not os.path.exists(os.path.join(repo, ".claude", "jira_issues")):
        return
    r = subprocess.run([sys.executable, AUDIT, "--repo", repo, "--json"],
                       capture_output=True, text=True, timeout=120)
    try:
        findings = json.loads(r.stdout or "[]")
    except json.JSONDecodeError:
        return
    if not findings:
        return
    fixable = [f for f in findings if f.get("fixable")]
    lines = [f"[jira-drift] {len(findings)} Jira<->beads finding(s) in {os.path.basename(repo)} "
             f"after this push ({len(fixable)} machine-fixable):", ""]
    for f in findings[:8]:
        lines.append(f"  {f['check']:18} {f.get('key','')}  {f['detail'][:110]}")
    if len(findings) > 8:
        lines.append(f"  … {len(findings)-8} more")
    lines += ["", f"Fix the safe ones: python3 {AUDIT} --repo {repo} --fix",
              "Orphan keys and body mismatches need a human call — do not auto-resolve them."]
    print(json.dumps({"hookSpecificOutput": {
        "hookEventName": "PostToolUse", "additionalContext": "\n".join(lines)}}))

if __name__ == "__main__":
    main()
