#!/usr/bin/env python3
"""PostToolUse[Edit|Write|MultiEdit]: name the document that just went stale.

Fires at the moment of the edit, which is the only moment the binding is cheap to act on: the
file is in hand, the reason for the change is in context, and the doc is one edit away. A Stop
hook would arrive after the session has moved on, and a pre-commit gate would have to block --
this informs and never blocks, like every other hook here.

Two cases, one message each:
  bound   -- a doc declares this file in its code_refs and was not edited in this session
  unbound -- no doc claims this file at all: a feature with no document

Silent when the doc was already touched this session, when the file is not code, or when the
repo has no code_refs bindings at all. Once per session per file, so a long edit loop over one
file does not repeat itself.
"""
import json
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
DRIFT = os.path.join(ROOT, "scripts", "docs-drift.py")
STATE_DIR = os.path.expanduser("~/.claude/tmp/docs-drift")
CODE_EXT = (".py", ".sh", ".ts", ".tsx", ".js", ".sql")


def quiet():
    sys.exit(0)


def state_path(sid):
    return os.path.join(STATE_DIR, f"{sid}.json")


def load(sid):
    try:
        return json.load(open(state_path(sid)))
    except Exception:
        return {"seen": [], "edited": []}


def save(sid, st):
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        json.dump(st, open(state_path(sid), "w"))
    except OSError:
        pass


def main():
    try:
        ev = json.load(sys.stdin)
    except Exception:
        quiet()
    path = ((ev.get("tool_input") or {}).get("file_path")
            or (ev.get("tool_input") or {}).get("filePath") or "")
    if not path or not os.path.exists(path):
        quiet()
    sid = str(ev.get("session_id") or "nosid")
    st = load(sid)

    is_doc = path.endswith(".md")
    if is_doc:
        # Editing the doc is the fix. Remember it so the next edit to its code stays silent.
        rel = os.path.relpath(os.path.abspath(path))
        if rel not in st["edited"]:
            st["edited"].append(rel)
            save(sid, st)
        quiet()
    if not path.endswith(CODE_EXT):
        quiet()

    try:
        r = subprocess.run([sys.executable, DRIFT, "--for", path, "--json",
                            "-C", os.path.dirname(os.path.abspath(path))],
                           capture_output=True, text=True, timeout=20)
        m = json.loads(r.stdout)
    except Exception:
        quiet()
    if not m:
        quiet()
    rel, docs = next(iter(m.items()))
    edited = {os.path.basename(p) for p in st["edited"]}

    if docs:
        pending = [d for d in docs if os.path.basename(d) not in edited]
        if not pending:
            quiet()
        key = f"bound:{rel}"
        if key in st["seen"]:
            quiet()
        st["seen"].append(key); save(sid, st)
        lines = [f"[docs-drift] You changed {rel}. {'This doc documents' if len(pending) == 1 else 'These docs document'} it and has not been updated in this session:"]
        lines += [f"  {d}" for d in pending]
        lines.append("Update it in this session — behaviour, flags, and the failure it prevents —")
        lines.append("or say in your reply why the change does not affect it. /docs does the update.")
    else:
        key = f"unbound:{rel}"
        if key in st["seen"]:
            quiet()
        st["seen"].append(key); save(sid, st)
        lines = [f"[docs-drift] No document claims {rel} — a feature with no doc is where drift starts.",
                 "Write or extend one, then list this file in its frontmatter:",
                 "  ---", "  code_refs:", f"    - {rel}", "  ---",
                 "/docs writes it. If this file is not a feature (a one-off script, a shim), say so and move on."]

    print(json.dumps({"hookSpecificOutput": {
        "hookEventName": "PostToolUse",
        "additionalContext": "\n".join(lines)}}))


if __name__ == "__main__":
    main()
