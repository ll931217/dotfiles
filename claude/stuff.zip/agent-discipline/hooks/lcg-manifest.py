#!/usr/bin/env python3
"""UserPromptSubmit: compile a Task Context Manifest and persist it OUTSIDE model context.

Two flags, both off by default (config.py):
  LCG_RESOLVER=1   compile the manifest and write session state. Injects nothing.
  LCG_INJECT_M0=1  additionally inject the manifest projection into context.

So enabling the resolver alone is a pure measurement lane: manifests accumulate on disk and the
session is unchanged. Nothing here can block — UserPromptSubmit has no such power, and the
standing rule is that hooks inform.

R5: `pref-capture-nudge.py` is already on this event. Both inject text, so both share one
context budget. This one stays silent unless LCG_INJECT_M0 is explicitly on.
"""
import json
import os
import sys
import uuid

ROOT = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
sys.path.insert(0, ROOT)


def quiet_exit():
    sys.exit(0)


def main():
    try:
        ev = json.load(sys.stdin)
    except Exception:
        quiet_exit()

    try:
        import config
        if not config.on("LCG_RESOLVER"):
            quiet_exit()
        inject = config.on("LCG_INJECT_M0")
        receipts_on = config.on("LCG_RECEIPTS")
    except Exception:
        quiet_exit()          # a broken config never turns a new behaviour ON

    try:
        from agent_discipline_paths import mem_file, topics_dir
        from ledger.adapters import CanonAdapter, LedgerAdapter, MemoryKitAdapter
        from ledger.events import ReceiptStore
        from ledger.resolver import Resolver, ResolutionRequest
        from ledger.session import SessionState

        prompt = ev.get("prompt") or ev.get("user_prompt") or ""
        sid = str(ev.get("session_id") or "nosid")
        cwd = ev.get("cwd") or os.getcwd()
        repo = os.path.basename(cwd)

        adapters = [LedgerAdapter(topics_dir()),
                    CanonAdapter(os.path.expanduser("~/.claude/canon-disciplines")),
                    MemoryKitAdapter(topics_dir())]
        receipts = ReceiptStore(mem_file("lcg_receipts.jsonl")) if receipts_on else None

        req = ResolutionRequest(
            request_id=uuid.uuid4().hex[:8], trigger="UserPromptSubmit", actor="user",
            repository=repo, session=sid, task=prompt[:400], prompt=prompt)
        manifest = Resolver(adapters, receipts=receipts).resolve(req)

        state = SessionState(os.path.expanduser(f"~/.claude/tmp/lcg/{sid}.json"))
        payload = {"session_id": sid, "manifest": manifest.to_dict(),
                   "snapshot": req.snapshot_hash()}
        try:
            state.write(payload, expected_revision=state.revision() if state.read() else None)
        except Exception:
            pass          # state is a cache; failing to write it must not cost the user a turn

        if not inject:
            quiet_exit()
        print(json.dumps({"hookSpecificOutput": {
            "hookEventName": "UserPromptSubmit",
            "additionalContext": manifest.render()}}))
    except Exception:
        quiet_exit()      # never crash a prompt


if __name__ == "__main__":
    main()
