#!/usr/bin/env python3
"""PostToolUse[Edit|Write|MultiEdit]: the main checkout was edited while workers are active.

The orchestrator holds the context and is supposed to review; the observed failure is that it
starts typing the feature itself while the worker sits idle. Informs, never blocks — the user
may have a reason, and a hook that blocks breaks unattended runs.
"""
import glob, json, os, subprocess, sys


def main():
    try:
        ev = json.load(sys.stdin)
    except Exception:
        return
    path = (ev.get("tool_input") or {}).get("file_path") or ""
    if not path or "/.worktrees/" in path or "/.claude/" in path:
        return
    try:
        root = subprocess.run(["git", "-C", os.path.dirname(path) or ".", "rev-parse", "--show-toplevel"],
                              capture_output=True, text=True, timeout=5).stdout.strip()
    except Exception:
        return
    if not root:
        return
    active = []
    for st in glob.glob(os.path.join(root, ".worktrees", "*", ".claude", "delegate.json")):
        try:
            d = json.load(open(st))
        except Exception:
            continue
        if d.get("status") in ("assigned", "rejected", "reported"):
            active.append((os.path.basename(os.path.dirname(os.path.dirname(st))), d.get("status")))
    if not active:
        return
    who = ", ".join(f"{n} ({s})" for n, s in active[:4])
    msg = (f"[orchestrator] You just edited the main checkout ({os.path.relpath(path, root)}) while "
           f"{len(active)} worker(s) are active: {who}. In this flow you review and approve; the workers "
           f"type. If this edit belongs to one of their tasks, revert it and SendMessage the worker the "
           f"issue. If it is genuinely yours, say so in one clause and carry on.")
    print(json.dumps({"hookSpecificOutput": {"hookEventName": "PostToolUse", "additionalContext": msg}}))


if __name__ == "__main__":
    main()
