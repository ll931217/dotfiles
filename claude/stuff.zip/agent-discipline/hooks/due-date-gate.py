#!/usr/bin/env python3
"""PreToolUse[Bash]: a tracked task with no due date never competes for attention.

An issue without a due date cannot be late, so it is never the thing you pick up — it sits in
the backlog while dated work churns past it. The date also has to be SANE, which means picked
against what is already overdue or due soon at the same or higher priority; a date chosen from
nothing is a number, not a commitment. The gate therefore denies AND prints that landscape, so
the date is picked with the queue in view rather than invented.

Exempt: small beads-only work (P3/P4, no `jira:` label). Those are the cleanup-in-passing
issues the tiering rule already says should not become scheduling noise.
"""
import json, os, re, subprocess, sys

BD_CREATE = re.compile(r"\bbd\s+create\b")
JIRA_CREATE = re.compile(r"\bjira\.py\s+create\b")
PRIORITY = re.compile(r"--priority[= ]\s*[\"']?[pP]?([0-4])")
JIRA_LABEL = re.compile(r"jira:[A-Z]{2,10}-\d+")


def sh(cmd, cwd):
    try:
        r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=15)
        return r.returncode, r.stdout
    except Exception:
        return 1, ""


def landscape(cwd):
    """What the new date has to fit around: overdue first, then due inside two weeks."""
    rows = []
    for args, tag in ((["--overdue"], "OVERDUE"), (["--due-before", "+2w"], "due soon")):
        rc, out = sh(["bd", "list", "--status=open", "--json"] + args, cwd)
        if rc != 0:
            continue
        try:
            d = json.loads(out)
            items = d if isinstance(d, list) else d.get("issues", [])
        except Exception:
            continue
        for it in items:
            key = it.get("id") or it.get("key")
            if not key or any(key == r[1] for r in rows):
                continue            # an overdue issue is also due-before; list it once
            rows.append((tag, key, it.get("priority"), (it.get("due_at") or "")[:10],
                         (it.get("title") or "")[:52]))
    return rows[:8]


def main():
    try:
        ev = json.load(sys.stdin)
    except Exception:
        return
    cmd = (ev.get("tool_input") or {}).get("command", "")
    cwd = ev.get("cwd") or os.getcwd()

    if JIRA_CREATE.search(cmd):
        if "--duedate" in cmd:
            return
        flag, what = "--duedate YYYY-MM-DD", "A Jira issue"
    elif BD_CREATE.search(cmd):
        if "--due" in cmd:
            return
        m = PRIORITY.search(cmd)
        if m and int(m.group(1)) >= 3 and not JIRA_LABEL.search(cmd):
            return                  # small, beads-only, local: the tiering rule's exempt tier
        flag, what = "--due <+1w | 2026-09-18 | next friday>", "A P0-P2 or Jira-mirrored bead"
    else:
        return

    lines = [f"{what} needs a due date. Add `{flag}`.",
             "",
             "Pick it against what is already queued, not from nothing — a date that ignores "
             "overdue work at the same priority is a number, not a commitment:"]
    rows = landscape(cwd)
    if rows:
        for tag, key, pri, due, title in rows:
            lines.append(f"  {tag:<8} {key:<18} P{pri}  {due:<10}  {title}")
        lines.append("")
        lines.append("Land this AFTER anything overdue or higher priority above, unless it "
                     "outranks them — and if it does, say why in one clause.")
    else:
        lines.append("  (nothing open is overdue or due within two weeks — the queue is clear)")
    lines.append("")
    lines.append("Genuinely undatable (blocked on someone else, no scope yet)? `bd defer <id> "
                 "--until=<date>` after creating it, and say so — deferring is a decision, an "
                 "empty due date is not.")
    print(json.dumps({"hookSpecificOutput": {
        "hookEventName": "PreToolUse", "permissionDecision": "deny",
        "permissionDecisionReason": "\n".join(lines)}}))


if __name__ == "__main__":
    main()
