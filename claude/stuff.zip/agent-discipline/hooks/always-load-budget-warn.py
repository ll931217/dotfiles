#!/usr/bin/env python3
"""SessionStart: warn when the always-load tier crosses its token budget.

Everything under ~/.claude/rules/ is injected IN FULL into every session, forever. Nothing
watches that total, so it grows one reasonable-looking addition at a time until sessions feel
heavy and nobody can say when it happened. This prints the ledger, loudest file first, so the
next addition is a decision instead of a drift.

Budget: ALWAYS_LOAD_BUDGET_TOKENS in ~/.claude/memory-kit.conf, else 9000.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from agent_discipline_paths import memory_dir, topics_dir, mem_file  # noqa: E402
import os, re, sys, json, glob

RULES = os.path.expanduser("~/.claude/rules")
INDEX = mem_file("MEMORY.md")
CONF = os.path.expanduser("~/.claude/memory-kit.conf")
DEFAULT_BUDGET = 9000
CHARS_PER_TOKEN = 4

def budget():
    try:
        m = re.search(r"^\s*ALWAYS_LOAD_BUDGET_TOKENS\s*=\s*(\d+)", open(CONF).read(), re.M)
        return int(m.group(1)) if m else DEFAULT_BUDGET
    except Exception:
        return DEFAULT_BUDGET

def main():
    files = []
    for path in glob.glob(os.path.join(RULES, "**", "*.md"), recursive=True):
        try:
            files.append((os.path.getsize(os.path.realpath(path)), path))
        except OSError:
            pass
    idx = 0
    if os.path.exists(INDEX):
        idx = os.path.getsize(INDEX)
        files.append((idx, INDEX))
    if not files:
        return 0

    total = sum(sz for sz, _ in files)
    tok, cap = total // CHARS_PER_TOKEN, budget()
    if tok <= cap:
        return 0

    files.sort(reverse=True)
    lines = [f"⚠ always-load tier is {tok:,} tokens, over the {cap:,} budget "
             f"(every session, forever). Heaviest first:"]
    for sz, path in files[:6]:
        short = path.replace(os.path.expanduser("~"), "~")
        lines.append(f"    {sz//CHARS_PER_TOKEN:>6,} tok  {short}")
    if len(files) > 6:
        lines.append(f"    … {len(files)-6} more")
    lines.append("Trim before adding: move detail to an on-demand topic file (recall surfaces it "
                 "by cue), or fold a rule into an existing one. Raise the bar deliberately with "
                 "ALWAYS_LOAD_BUDGET_TOKENS in ~/.claude/memory-kit.conf — don't let it drift.")

    print(json.dumps({"hookSpecificOutput": {
        "hookEventName": "SessionStart", "additionalContext": "\n".join(lines)}}))
    return 0

if __name__ == "__main__":
    sys.exit(main())
