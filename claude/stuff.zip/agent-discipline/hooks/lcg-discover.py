#!/usr/bin/env python3
"""Discovery: extend the scope frontier from what tools observed, and inject only what changed.

Registered on PostToolBatch (preferred — one aggregated pass per parallel batch),
PostToolUse (the fallback when a batch event does not fire) and PostToolUseFailure
(a failure contradicts an assumption, so it forces a refresh).

Flags, both off by default:
  LCG_DISCOVERY=1    extract entities, extend the frontier, recompute, write the delta.
  LCG_INJECT_DELTA=1 additionally inject the delta. Without it this is a measurement lane.

Concurrency: parallel tool calls mean parallel hooks. Session state is written with
compare-and-swap, and a writer that loses the race recomputes against the latest revision
rather than overwriting it (P3-20, P3-21, P3-23).

Never blocks. Coverage is recorded, never enforced — mutation denial is Phase 7.
"""
import json
import os
import random
import sys
import time
import uuid

ROOT = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
sys.path.insert(0, ROOT)

# Four parallel tool calls means four hooks contending for one revision. With three immediate
# retries and no backoff they collided in lockstep and only two of four observations survived —
# measured, not theorised. Retries are generous and jittered because losing an observation is
# silent: the frontier is simply missing an entity nobody knows to look for.
MAX_CAS_RETRIES = 12
BACKOFF_MAX_MS = 40


def quiet():
    sys.exit(0)


def observed_text(ev):
    """Whatever this event actually saw. A batch carries several results; a single call one."""
    parts = []
    for r in (ev.get("results") or ev.get("tool_results") or []):
        parts.append(json.dumps(r) if not isinstance(r, str) else r)
    resp = ev.get("tool_response")
    if resp is not None:
        parts.append(json.dumps(resp) if not isinstance(resp, str) else resp)
    ti = ev.get("tool_input") or {}
    for k in ("file_path", "command", "pattern", "path", "notebook_path"):
        if ti.get(k):
            parts.append(str(ti[k]))
    if ev.get("error"):
        parts.append(str(ev["error"]))
    return "\n".join(parts)


def main():
    try:
        ev = json.load(sys.stdin)
    except Exception:
        quiet()
    try:
        import config
        if not config.on("LCG_DISCOVERY"):
            quiet()
        inject = config.on("LCG_INJECT_DELTA")
        coverage_on = config.on("LCG_COVERAGE")
    except Exception:
        quiet()

    try:
        from agent_discipline_paths import mem_file, topics_dir
        from ledger.adapters import CanonAdapter, LedgerAdapter, MemoryKitAdapter
        from ledger.coverage import CoverageStore, operation_for
        from ledger.delta import ManifestDelta, diff
        from ledger.discovery import ScopeFrontier, extract, terms_from
        from ledger.events import ReceiptStore
        from ledger.resolver import ResolutionRequest, Resolver, TaskContextManifest
        from ledger.session import RevisionConflict, SessionState, session_lock

        sid = str(ev.get("session_id") or "nosid")
        state = SessionState(os.path.expanduser(f"~/.claude/tmp/lcg/{sid}.json"))
        trigger = ev.get("hook_event_name") or "PostToolUse"
        tool = ev.get("tool_name") or "batch"

        entities = extract(observed_text(ev))
        if not entities and trigger != "PostToolUseFailure":
            quiet()          # nothing observed, nothing to refresh

        rendered = ""
        state_path = os.path.expanduser(f"~/.claude/tmp/lcg/{sid}.json")
        with session_lock(state_path):
          for attempt in range(MAX_CAS_RETRIES):
              st = state.read()
              if st is None:
                  quiet()      # no M0 yet: discovery refines a manifest, it does not create one
              rev = int(st.get("revision", 0))
              frontier = ScopeFrontier.from_list(st.get("frontier"))
              fresh = frontier.observe(entities, tool, _now())
              if not fresh and trigger != "PostToolUseFailure":
                  quiet()      # unchanged frontier -> no delta -> nothing injected (P3-18)

              old = TaskContextManifest(**{k: v for k, v in st["manifest"].items()
                                           if k != "character_budget_used"})
              adapters = [LedgerAdapter(topics_dir()),
                          CanonAdapter(os.path.expanduser("~/.claude/canon-disciplines")),
                          MemoryKitAdapter(topics_dir())]
              receipts = ReceiptStore(mem_file("lcg_receipts.jsonl"))
              req = ResolutionRequest(
                  request_id=uuid.uuid4().hex[:8], trigger=trigger, actor="agent",
                  repository=old.repository, session=sid, task=old.task,
                  prompt=" ".join(sorted(terms_from(frontier))),
                  paths=tuple(e.entity_id for e in frontier.all() if e.entity_type == "path"),
                  symbols=tuple(e.entity_id for e in frontier.all() if e.entity_type == "symbol"))
              new = Resolver(adapters, receipts=receipts).resolve(req, parent=old)
              d = diff(old, new, sid, trigger,
                       discovered=[f.key for f in fresh], now=_now())

              cov_rows = st.get("coverage") or []
              if coverage_on:
                  store = CoverageStore.from_list(cov_rows)
                  ti = ev.get("tool_input") or {}
                  target = ti.get("file_path") or ti.get("notebook_path") or ""
                  if target:
                      dec = store.decide(target, operation_for(tool, ti.get("command", "")),
                                         req.snapshot_hash(), manifest_revision=new.revision,
                                         relevant_entry_ids=[i["id"] for i in d.added],
                                         degraded=[x["source"] for x in new.degraded_sources])
                      if dec.as_note():
                          d.coverage_added.append({"target": target, "status": dec.status})
                          d.no_op = False
                  cov_rows = store.to_list()

              payload = {"session_id": sid, "manifest": new.to_dict(),
                         "snapshot": req.snapshot_hash(),
                         "frontier": frontier.to_list(), "coverage": cov_rows,
                         "last_delta": d.to_dict()}
              try:
                  state.write(payload, expected_revision=rev)
              except RevisionConflict:
                  # Someone advanced it. Recompute against the latest (P3-23), after a jittered
                  # pause so the losers do not all retry into each other again.
                  time.sleep(random.uniform(0, BACKOFF_MAX_MS / 1000.0))
                  continue
              except Exception:
                  quiet()
              rendered = d.render()
              break

        if inject and rendered:
            print(json.dumps({"hookSpecificOutput": {
                "hookEventName": trigger, "additionalContext": rendered}}))
    except Exception:
        quiet()


def _now():
    import datetime
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")


if __name__ == "__main__":
    main()
