#!/usr/bin/env python3
"""PostToolUse[Bash]: a worktree was just created — a session exists in it, so delegate.

worktrunk's post-start hook opens a tmux window and starts claude in the new worktree. Left to
a rule, the creating session implements there anyway and the new one sits idle at 0% context —
observed 2026-09-01: a whole feature was built in the parent session while its worker window
stayed untouched from spawn to reap.

Fires at the moment of creation, which is the only moment the choice is still open.

The command STRING is only a cheap pre-filter. What decides is `git worktree list`: a nudge
needs a worktree path that was not there before. Matching text alone told the orchestrator to
delegate after a `bd create` whose issue description merely mentioned `git worktree add`, and
listed panes from an unrelated repo — pushing it to hand off work that had no worktree at all.
"""
import json, os, re, subprocess, sys

CREATE = re.compile(r"\bwt\s+(switch\s+--create|new|create)\b|\bgit\s+worktree\s+add\b")
STATE_DIR = os.path.expanduser("~/.claude/tmp/worktree-nudge")
FRESH_SECONDS = 120          # a worktree younger than this counts as "just created"


def worktree_paths(cwd):
    """Every worktree path git knows about, excluding the main checkout. () when not a repo."""
    try:
        r = subprocess.run(["git", "worktree", "list", "--porcelain"], cwd=cwd,
                           capture_output=True, text=True, timeout=10)
    except Exception:
        return ()
    if r.returncode != 0:
        return ()
    paths = [ln[9:].strip() for ln in r.stdout.splitlines() if ln.startswith("worktree ")]
    return tuple(paths[1:])          # [0] is the main checkout


def new_worktrees(sid, cwd):
    """Paths that appeared since this session last looked.

    With no snapshot yet (first Bash call of a session) there is nothing to diff, so fall back
    to mtime: a worktree created seconds ago is still evidence, and refusing to nudge on the
    first command would miss the dispatch that opens a session.
    """
    seen = worktree_paths(cwd)
    path = os.path.join(STATE_DIR, f"{sid}.json")
    try:
        before = set(json.load(open(path)))
        first_look = False
    except Exception:
        before, first_look = set(), True
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        json.dump(sorted(seen), open(path, "w"))
    except OSError:
        pass
    fresh = [p for p in seen if p not in before]
    if first_look:
        import time
        now = time.time()
        fresh = [p for p in fresh
                 if os.path.isdir(p) and (now - os.path.getmtime(p)) < FRESH_SECONDS]
    return fresh

def main():
    try:
        ev = json.load(sys.stdin)
    except Exception:
        return
    cmd = (ev.get("tool_input") or {}).get("command", "")
    if not CREATE.search(cmd):
        return                       # cheap pre-filter only; it proves nothing on its own
    cwd = ev.get("cwd") or os.getcwd()
    sid = str(ev.get("session_id") or "nosid")
    fresh = new_worktrees(sid, cwd)
    if not fresh:
        # The command mentioned creating a worktree and no worktree appeared: a heredoc, a
        # doc, a grep, a failed command, or an issue description. Nothing to delegate to.
        return
    # Name the window if tmux can see it — a pointer the orchestrator can act on.
    win = ""
    try:
        r = subprocess.run(["tmux", "list-panes", "-a", "-F",
                            "#{session_name}:#{window_index} #{window_name} #{pane_current_path}"],
                           capture_output=True, text=True, timeout=5)
        # Only panes sitting in a worktree THIS command created. Filtering on the substring
        # ".worktrees" listed three panes from an unrelated repo, which reads as the worker
        # already being up somewhere it is not.
        hits = [l for l in r.stdout.splitlines() if any(p in l for p in fresh)]
        if hits:
            win = "\n".join(f"    {l}" for l in hits[-3:])
    except Exception:
        pass

    msg = [f"[delegate] A worktree was just created ({fresh[0]}), so a WORKER Claude (opus, high) is",
           "starting in a new",
           "tmux window with a clean context window and that worktree checked out.",
           "",
           "You hold the context; it has the room to work. Do NOT implement here.",
           "Follow the `orchestrate` skill (batch) or `delegate-to-worktree` (one task):",
           "  1. orchestrate.py dispatch wrote <worktree>/.claude/TASK.md — if you created the worktree",
           "     by hand, write that file now (task, your session name, constraints)",
           "  2. ListAgents to find the worker AND confirm it is actually up",
           "  3. SendMessage it: \"Read .claude/TASK.md and begin.\" — the worker writes its own DoD",
           "     with its DoD teammates and reports only when every lens passes",
           "  4. review against .claude/DOD.md only; reject with the issue, never the fix; 3 rounds max"]
    if win:
        msg += ["", "  worktree panes tmux can see right now:", win]
    msg += ["", "If this worktree has no session (no tmux, hook disabled), say so in one clause",
            "and do the work yourself — this is delegation, not ceremony."]
    print(json.dumps({"hookSpecificOutput": {
        "hookEventName": "PostToolUse", "additionalContext": "\n".join(msg)}}))

if __name__ == "__main__":
    main()
