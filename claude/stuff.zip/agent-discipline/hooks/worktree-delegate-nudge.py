#!/usr/bin/env python3
"""PostToolUse[Bash]: a worktree was just created — a session exists in it, so delegate.

worktrunk's post-start hook opens a tmux window and starts claude in the new worktree. Left to
a rule, the creating session implements there anyway and the new one sits idle at 0% context —
observed 2026-09-01: a whole feature was built in the parent session while its worker window
stayed untouched from spawn to reap.

Fires at the moment of creation, which is the only moment the choice is still open.
"""
import json, os, re, subprocess, sys

CREATE = re.compile(r"\bwt\s+(switch\s+--create|new|create)\b|\bgit\s+worktree\s+add\b")

def main():
    try:
        ev = json.load(sys.stdin)
    except Exception:
        return
    cmd = (ev.get("tool_input") or {}).get("command", "")
    if not CREATE.search(cmd):
        return
    # Name the window if tmux can see it — a pointer the orchestrator can act on.
    win = ""
    try:
        r = subprocess.run(["tmux", "list-panes", "-a", "-F",
                            "#{session_name}:#{window_index} #{window_name} #{pane_current_path}"],
                           capture_output=True, text=True, timeout=5)
        fresh = [l for l in r.stdout.splitlines() if ".worktrees" in l]
        if fresh:
            win = "\n".join(f"    {l}" for l in fresh[-3:])
    except Exception:
        pass

    msg = ["[delegate] A worktree was just created, so a second Claude session is starting in a new",
           "tmux window with a clean context window and that worktree checked out.",
           "",
           "You hold the context; it has the room to work. Do NOT implement here.",
           "Follow the `delegate-to-worktree` skill:",
           "  1. write the DoD to <worktree>/.claude/DOD.md  (delegate.py start)",
           "  2. ListAgents to find the worker AND confirm it is actually up",
           "  3. SendMessage the task — what done looks like, not how to get there",
           "  4. review against DOD.md only; reject with the issue, never the fix; 3 rounds max"]
    if win:
        msg += ["", "  worktree panes tmux can see right now:", win]
    msg += ["", "If this worktree has no session (no tmux, hook disabled), say so in one clause",
            "and do the work yourself — this is delegation, not ceremony."]
    print(json.dumps({"hookSpecificOutput": {
        "hookEventName": "PostToolUse", "additionalContext": "\n".join(msg)}}))

if __name__ == "__main__":
    main()
