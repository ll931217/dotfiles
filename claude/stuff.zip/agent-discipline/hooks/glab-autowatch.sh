#!/usr/bin/env bash
# PostToolUse(Bash) hook: after any command that puts commits on a GitLab remote,
# start a watcher in the background so a red pipeline reports itself, and tell THIS
# session how to be woken when the MR reaches a terminal state.
#
# Covers `glab mr create` (watch the MR) and `git push` (watch the MR if one is
# open for the branch, else the branch's own pipeline). The MR watcher hands off
# to the branch watcher when it merges, so a post-merge pipeline is covered too.
#
# ponytail: literal substring matching. A push made from the web UI or by another
# machine is nobody's PostToolUse event and cannot be caught here.
set -euo pipefail

payload="$(cat)"
cmd="$(printf '%s' "$payload" | jq -r '.tool_input.command // ""')"
case "$cmd" in
  *"glab mr create"*|*"git push"*) ;;
  *) exit 0 ;;
esac

out="$(printf '%s' "$payload" | jq -r '.tool_response | (.stdout // .output // (. | tostring))' 2>/dev/null || true)"
# A rejected push has nothing to watch, and reporting the PREVIOUS pipeline for the
# branch as if it were this push's is worse than saying nothing.
case "$out" in
  *"[rejected]"*|*"failed to push"*|*"pre-receive hook declined"*) exit 0 ;;
esac
# A push leaves a trace in its own output. Without this, any command whose TEXT contains
# "git push" -- a doc, a heredoc, a commit message, a grep -- started a pipeline watcher.
case "$cmd" in
  *"git push"*)
    case "$out" in
      *"->"*|*"Everything up-to-date"*|*"new branch"*|*"set up to track"*|*"remote:"*) ;;
      *) exit 0 ;;
    esac ;;
esac
# For an MR create, the URL is the only proof it worked -- and it has to be a real URL. The
# bare substring "/merge_requests/" also appears in `glab api projects/:id/merge_requests?...`,
# so a plain grep over these very scripts printed it and started a live watcher on master from
# a command that created nothing. Require scheme + host + a numeric iid.
kind="pipeline"
case "$cmd" in
  *"glab mr create"*)
    # `|| true`: under set -e -o pipefail a non-matching grep makes this assignment the
    # hook's exit path, so every legitimate "no MR here, stay silent" case exited 1 — a hook
    # error, not a decision.
    mr_url="$(printf '%s' "$out" | grep -oE 'https?://[^[:space:]]+/-/merge_requests/[0-9]+' | head -1 || true)"
    if [ -n "$mr_url" ]; then
      kind="mr"; mr_iid="${mr_url##*/}"
    else
      exit 0
    fi ;;
esac

# The watchers ship beside this hook. Prefer the plugin's own copies so the hook
# works wherever the plugin is installed; ~/.scripts is only the local symlink farm.
SELF="$(readlink -f "${BASH_SOURCE[0]}")"
WATCH_DIR="$(dirname "$(dirname "$SELF")")/scripts"
[ -x "$WATCH_DIR/glab-watch-mr.sh" ] || WATCH_DIR="$HOME/.scripts"

cwd="$(printf '%s' "$payload" | jq -r '.cwd // ""')"
[ -n "$cwd" ] && cd "$cwd" 2>/dev/null || exit 0
git rev-parse --git-dir >/dev/null 2>&1 || exit 0
branch="$(git branch --show-current 2>/dev/null || true)"
[ -z "$branch" ] && exit 0

# One watcher per repo+branch. The lock records WHAT is being watched, because the
# normal sequence is `git push` then `glab mr create` seconds later: the push starts a
# branch-PIPELINE watcher, and a plain "is something running?" lock then made the MR
# create a no-op. The pipeline went green, that watcher exited, and the MR itself was
# never watched by anything — which is how a merge went unreported.
lock="/tmp/glab-watch-$(printf '%s' "$cwd$branch" | md5sum | cut -c1-12).lock"
running_pid=""; running_kind=""
if [ -e "$lock" ]; then
  read -r running_pid running_kind < "$lock" 2>/dev/null || true
  if kill -0 "${running_pid:-0}" 2>/dev/null; then
    if [ "$kind" = "mr" ] && [ "${running_kind:-}" != "mr" ]; then
      # An MR watch supersedes a branch-pipeline watch: it covers the pipeline too.
      pkill -P "$running_pid" 2>/dev/null || true
      kill "$running_pid" 2>/dev/null || true
    else
      exit 0
    fi
  fi
fi

log="$HOME/.cache/glab-watch/$(printf '%s' "$branch" | tr / _).log"
mkdir -p "$(dirname "$log")"
export WATCH_CWD="$cwd" WATCH_LOCK="$lock" WATCH_LOG="$log" WATCH_BRANCH="$branch" WATCH_DIR WATCH_KIND="$kind"
setsid bash -c '
  echo "$$ $WATCH_KIND" > "$WATCH_LOCK"
  cd "$WATCH_CWD" || exit
  # GitLab needs a moment to create the pipeline for what was just pushed.
  sleep 10
  # exit 1 from the MR watcher means "no open MR for this branch" — not a failure,
  # just the case where the branch pipeline is the only thing to watch.
  "$WATCH_DIR/glab-watch-mr.sh" >> "$WATCH_LOG" 2>&1
  if [ $? -eq 1 ]; then
    "$WATCH_DIR/glab-watch-pipeline.sh" "$WATCH_BRANCH" >> "$WATCH_LOG" 2>&1
  fi
  rm -f "$WATCH_LOCK"
' </dev/null >/dev/null 2>&1 &

# A detached watcher notifies the DESKTOP. It cannot notify this session — which is why
# "my MR merged" had to be carried to the agent by hand. Hand the session the one command that
# wakes it.
#
# It polls the MR API, and it used to tail this watcher's log instead. The watcher died at
# 11:16:35, the MR merged at 11:46:52, and the until-loop waited forever: a dead producer's
# silence is identical to "still running". mr-await.sh has no producer to die, and its timeout
# means the wait always ends in a message.
[ "$kind" = "mr" ] || exit 0
AWAIT="$(dirname "$(dirname "$SELF")")/scripts/mr-await.sh"
[ -x "$AWAIT" ] || AWAIT="$HOME/.scripts/mr-await.sh"
cat <<CTX
{"hookSpecificOutput":{"hookEventName":"PostToolUse","additionalContext":"[mr-watch] A watcher is now following !${mr_iid} on branch ${branch} (log: ${log}). It notifies the desktop; it CANNOT notify you.\n\nYou are not done with this task until you know how the MR ended. Arm your own wake-up now — Bash with run_in_background:true and this exact command, then carry on or report to the orchestrator:\n\n  ${AWAIT} ${mr_iid}\n\nIt asks GitLab directly, prints every state change, and exits: 0 merged, 1 closed, 2 pipeline red, 3 conflict, 5 timeout after 2h (nothing failed, nothing merged — check it yourself). Red pipeline or conflict: fix it and push again. Merged: the worktree is reaped for you — say so and stop."}}
CTX
exit 0
