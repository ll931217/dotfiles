#!/usr/bin/env bash
# PostToolUse(Bash) hook: after any command that puts commits on a GitLab remote,
# start a watcher in the background so a red pipeline reports itself, and tell THIS
# session how to be woken when the MR reaches a terminal state.
#
# Covers `glab mr create` (watch the MR) and `git push` (watch the MR if one is
# open for the branch, else the branch's own pipeline). The MR watcher hands off
# to the branch watcher when it merges, so a post-merge pipeline is covered too.
#
# ponytail: literal substring matching. A push made from the web UI or by another
# machine is nobody's PostToolUse event and cannot be caught here.
set -euo pipefail

payload="$(cat)"
cmd="$(printf '%s' "$payload" | jq -r '.tool_input.command // ""')"
case "$cmd" in
  *"glab mr create"*|*"git push"*) ;;
  *) exit 0 ;;
esac

out="$(printf '%s' "$payload" | jq -r '.tool_response | (.stdout // .output // (. | tostring))' 2>/dev/null || true)"
# A rejected push has nothing to watch, and reporting the PREVIOUS pipeline for the
# branch as if it were this push's is worse than saying nothing.
case "$out" in
  *"[rejected]"*|*"failed to push"*|*"pre-receive hook declined"*) exit 0 ;;
esac
# For an MR create, the URL is the only proof it worked.
kind="pipeline"
case "$cmd" in
  *"glab mr create"*)
    case "$out" in *"/merge_requests/"*) kind="mr" ;; *) exit 0 ;; esac ;;
esac

# The watchers ship beside this hook. Prefer the plugin's own copies so the hook
# works wherever the plugin is installed; ~/.scripts is only the local symlink farm.
SELF="$(readlink -f "${BASH_SOURCE[0]}")"
WATCH_DIR="$(dirname "$(dirname "$SELF")")/scripts"
[ -x "$WATCH_DIR/glab-watch-mr.sh" ] || WATCH_DIR="$HOME/.scripts"

cwd="$(printf '%s' "$payload" | jq -r '.cwd // ""')"
[ -n "$cwd" ] && cd "$cwd" 2>/dev/null || exit 0
git rev-parse --git-dir >/dev/null 2>&1 || exit 0
branch="$(git branch --show-current 2>/dev/null || true)"
[ -z "$branch" ] && exit 0

# One watcher per repo+branch. The lock records WHAT is being watched, because the
# normal sequence is `git push` then `glab mr create` seconds later: the push starts a
# branch-PIPELINE watcher, and a plain "is something running?" lock then made the MR
# create a no-op. The pipeline went green, that watcher exited, and the MR itself was
# never watched by anything — which is how a merge went unreported.
lock="/tmp/glab-watch-$(printf '%s' "$cwd$branch" | md5sum | cut -c1-12).lock"
running_pid=""; running_kind=""
if [ -e "$lock" ]; then
  read -r running_pid running_kind < "$lock" 2>/dev/null || true
  if kill -0 "${running_pid:-0}" 2>/dev/null; then
    if [ "$kind" = "mr" ] && [ "${running_kind:-}" != "mr" ]; then
      # An MR watch supersedes a branch-pipeline watch: it covers the pipeline too.
      pkill -P "$running_pid" 2>/dev/null || true
      kill "$running_pid" 2>/dev/null || true
    else
      exit 0
    fi
  fi
fi

log="$HOME/.cache/glab-watch/$(printf '%s' "$branch" | tr / _).log"
mkdir -p "$(dirname "$log")"
# Where this watch starts in the log. The file is appended across pushes, so a
# terminal line from a PREVIOUS MR on this branch must not count as this one's.
offset=$(( $(wc -c < "$log" 2>/dev/null || echo 0) + 1 ))

export WATCH_CWD="$cwd" WATCH_LOCK="$lock" WATCH_LOG="$log" WATCH_BRANCH="$branch" WATCH_DIR WATCH_KIND="$kind"
setsid bash -c '
  echo "$$ $WATCH_KIND" > "$WATCH_LOCK"
  cd "$WATCH_CWD" || exit
  # GitLab needs a moment to create the pipeline for what was just pushed.
  sleep 10
  # exit 1 from the MR watcher means "no open MR for this branch" — not a failure,
  # just the case where the branch pipeline is the only thing to watch.
  "$WATCH_DIR/glab-watch-mr.sh" >> "$WATCH_LOG" 2>&1
  if [ $? -eq 1 ]; then
    "$WATCH_DIR/glab-watch-pipeline.sh" "$WATCH_BRANCH" >> "$WATCH_LOG" 2>&1
  fi
  rm -f "$WATCH_LOCK"
' </dev/null >/dev/null 2>&1 &

# A detached watcher notifies the DESKTOP. It cannot notify this session — which is why
# "my MR merged" had to be carried to the agent by hand. Hand the session the one command
# that wakes it: a background shell that exits when a terminal line lands in the log.
[ "$kind" = "mr" ] || exit 0
cat <<CTX
{"hookSpecificOutput":{"hookEventName":"PostToolUse","additionalContext":"[mr-watch] A watcher is now following this MR on branch ${branch} and writing to ${log}. It notifies the desktop; it CANNOT notify you.\n\nYou are not done with this task until you know how the MR ended. Arm your own wake-up now — Bash with run_in_background:true and this exact command, then carry on or report to the orchestrator:\n\n  until tail -c +${offset} '${log}' | grep -qE 'MERGED|CLOSED|PIPELINE (FAILED|CANCELED)|MERGE CONFLICT'; do sleep 30; done; tail -c +${offset} '${log}' | tail -5\n\nIt exits when the MR merges, closes, hits a merge conflict, or the pipeline goes red, and you are re-invoked with those lines. Red pipeline or conflict: fix it and push again. Merged: the worktree is reaped for you — say so and stop."}}
CTX
exit 0
