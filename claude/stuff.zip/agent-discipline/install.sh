#!/usr/bin/env bash
# agent-discipline installer. Idempotent: safe to re-run after a git pull.
#
#   ./install.sh              install / update
#   ./install.sh --check      report what WOULD change, touch nothing
#   ./install.sh --cron       also install the weekday Jira drift scan
#   ./install.sh --uninstall  remove everything this script added
set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CLAUDE="$HOME/.claude"
SETTINGS="$CLAUDE/settings.json"
RULES_DIR="$CLAUDE/rules"
NAME="agent-discipline"
MODE="${1:-install}"

say()  { printf '  %s\n' "$*"; }
ok()   { printf '  \033[32m✓\033[0m %s\n' "$*"; }
warn() { printf '  \033[33m!\033[0m %s\n' "$*"; }

[ -f "$ROOT/.claude-plugin/plugin.json" ] || { echo "not an agent-discipline checkout: $ROOT"; exit 1; }
command -v python3 >/dev/null || { echo "python3 is required"; exit 1; }
echo "agent-discipline · $ROOT"

# ── settings.json: marketplace + enable, and drop any legacy inline hook entries ──────────
settings_py() {
python3 - "$ROOT" "$SETTINGS" "$1" <<'PY'
import json, os, shutil, sys
root, path, mode = sys.argv[1], sys.argv[2], sys.argv[3]
name = "agent-discipline"
owned = ["pref-checkpoint.py", "pref-preload-on-skill.py", "pref-capture-nudge.py",
         "always-load-budget-warn.py", "jira-drift-checkpoint.py"]
d = json.load(open(path)) if os.path.exists(path) else {}
before = json.dumps(d, sort_keys=True)

mk = d.setdefault("extraKnownMarketplaces", {})
ep = d.setdefault("enabledPlugins", {})
if mode == "uninstall":
    mk.pop(name, None); ep.pop(f"{name}@{name}", None)
else:
    mk[name] = {"source": {"source": "directory", "path": root}}
    ep[f"{name}@{name}"] = True
    # a hook registered BOTH inline and by the plugin fires twice — remove the inline copy
    for event, entries in list(d.get("hooks", {}).items()):
        d["hooks"][event] = [e for e in entries
                             if not any(o in json.dumps(e) for o in owned)]

after = json.dumps(d, sort_keys=True)
if before == after:
    print("nochange"); sys.exit(0)
if mode == "check":
    print("would-change"); sys.exit(0)
if os.path.exists(path):
    shutil.copy(path, path + ".bak-agent-discipline")
json.dump(d, open(path, "w"), indent=2)
print("changed")
PY
}

case "$MODE" in
  --uninstall)
    r=$(settings_py uninstall); [ "$r" = changed ] && ok "settings.json: marketplace + plugin removed" || say "settings.json: nothing to remove"
    for f in "$RULES_DIR"/answer-shape.md; do
      if [ -L "$f" ] && [ "$(readlink -f "$f")" = "$ROOT/rules/answer-shape.md" ]; then rm -f "$f"; ok "unlinked $f"; fi
    done
    crontab -l 2>/dev/null | grep -v 'agent-discipline.*jira-drift-nightly' > "$HOME/ct.new" 2>/dev/null || true
    crontab "$HOME/ct.new" 2>/dev/null && rm -f "$HOME/ct.new" && ok "cron entry removed"
    echo; say "Your memory data was NOT touched — records and logs live in your memory dir by design."
    exit 0 ;;
  --check) : ;;
esac

# 1. plugin registration
r=$(settings_py "$([ "$MODE" = --check ] && echo check || echo install)")
case "$r" in
  changed)      ok "settings.json: marketplace registered, plugin enabled, inline duplicates removed" ;;
  would-change) warn "settings.json WOULD change (marketplace / enable / duplicate removal)" ;;
  nochange)     say "settings.json: already correct" ;;
esac

# 2. always-load rules — a plugin cannot write this channel, so symlink it
mkdir -p "$RULES_DIR"
target="$RULES_DIR/answer-shape.md"
src="$ROOT/rules/answer-shape.md"
if [ -L "$target" ] && [ "$(readlink -f "$target")" = "$src" ]; then
  say "rules/answer-shape.md: already linked"
elif [ -L "$target" ]; then
  # A symlink pointing at a DIFFERENT checkout. Without this branch the plain `ln -s` below
  # fails with "File exists" while the script still prints a tick — the marketplace and cron
  # move to the new checkout, the rule stays bound to the old one, and nothing says so.
  oldtarget="$(readlink -f "$target")"
  if [ "$MODE" = --check ]; then warn "answer-shape.md points at $oldtarget — would repoint here"
  else ln -sfn "$src" "$target"; ok "answer-shape.md repointed from $oldtarget"; fi
elif [ -e "$target" ] && [ ! -L "$target" ]; then
  if [ "$MODE" = --check ]; then warn "answer-shape.md exists as a REAL FILE — would back up and replace with a symlink"
  else
    # NOTE: the backup must NOT stay in rules/ — everything in that directory is injected in
    # full every session, so a .pre-plugin copy there silently doubles the file's token cost.
    mkdir -p "$CLAUDE/rules-backup"
    mv "$target" "$CLAUDE/rules-backup/answer-shape.md.pre-plugin"
    ln -s "$src" "$target"
    ok "answer-shape.md linked (previous file -> ~/.claude/rules-backup/, NOT left in rules/)"
  fi
else
  if [ "$MODE" = --check ]; then warn "would symlink $target -> $src"
  else ln -s "$src" "$target" && ok "answer-shape.md linked" || warn "could not link answer-shape.md"; fi
fi

# 3. cron: the nightly drift scan. Checked on EVERY run, not just --cron, because a
#    commented-out entry looks installed but never fires.
if [ "${AGENT_DISCIPLINE_NO_CRON:-0}" = "1" ]; then
  say "cron: skipped (AGENT_DISCIPLINE_NO_CRON=1)"
else
  # crontab silently truncates a long filename argument at 99 chars — stage via a SHORT path
  stage="$HOME/ct.new"
  crontab -l > "$stage" 2>/dev/null || : > "$stage"
  action=$(ADD_IF_MISSING="$([ "$MODE" = --cron ] && echo 1 || echo 0)" \
           MODE="$MODE" ROOT="$ROOT" python3 - "$stage" <<'PY2'
import os, re, sys
stage, root = sys.argv[1], os.environ["ROOT"]
mode, add_missing = os.environ["MODE"], os.environ["ADD_IF_MISSING"] == "1"
MARK = "AGENT-DISCIPLINE:CRON"
want = f"25 7 * * 1-5 {root}/scripts/jira-drift-nightly.sh  # {MARK}"
# A cron SCHEDULE line, optionally commented out. The descriptive header comment above it
# is not a schedule and must stay a comment.
SCHED = re.compile(r"^(#*\s*)((?:[\d*/,\-]+\s+){5}\S.*jira-drift-nightly\.sh.*)$")

lines = open(stage).read().splitlines()
out, states = [], []
seen = False
for ln in lines:
    m = SCHED.match(ln)
    if not m:
        out.append(ln); continue
    seen = True
    commented = "#" in m.group(1)
    body = m.group(2)
    stale = root not in body
    if commented and stale:
        out.append(want); states.append("uncommented+repathed")
    elif commented:
        out.append(want); states.append("uncommented")
    elif stale:
        out.append(want); states.append("repathed")
    else:
        out.append(ln); states.append("active")
if not seen:
    if add_missing:
        out.append(f"# agent-discipline: Jira<->beads drift scan (detection only)")
        out.append(want); states.append("added")
    else:
        states.append("absent")

if mode == "--check" or not states or set(states) == {"active"} or states == ["absent"]:
    print(",".join(states) or "active"); sys.exit(0)
open(stage, "w").write("\n".join(out) + "\n")
print(",".join(states))
PY2
)
  case "$action" in
    active)               say "cron: drift scan present and active" ;;
    absent)               warn "cron: drift scan NOT installed — re-run with --cron to schedule it" ;;
    added)                crontab "$stage" && ok "cron: weekday 07:25 drift scan installed" ;;
    *uncommented*|*repathed*)
      if [ "$MODE" = --check ]; then warn "cron: entry is $action — WOULD repair it"
      else crontab "$stage" && ok "cron: entry was $action — repaired and re-enabled"
           say "     to keep it off on purpose: AGENT_DISCIPLINE_NO_CRON=1 ./install.sh"; fi ;;
    *)                    say "cron: $action" ;;
  esac
  rm -f "$stage"
fi

# 4. dependencies — report, never fail. Beads is OPTIONAL by design.
echo; echo "dependencies"
command -v bd    >/dev/null && ok "bd (beads) — mirror checks enabled" || say "bd not found — Jira-only mode, key checks still run"
command -v glab  >/dev/null && ok "glab — derived status available"    || warn "glab not found — derived status unavailable"
[ -f "$HOME/Projects/llm_library/plugins/data-skills/skills/jira/scripts/jira.py" ] \
  && ok "jira.py — Jira status checks available" \
  || warn "jira.py not found — audit will report status checks as SKIPPED, never as passed"

# 5. portability check — honest about what is still machine-specific
echo; echo "portability"
hits=$(grep -rlE 'projects/-(home|Users)-[a-z]' "$ROOT/hooks" "$ROOT/scripts" 2>/dev/null | wc -l)
if [ "$hits" -gt 0 ]; then
  warn "$hits file(s) hardcode a specific user's memory path — they will find no data here"
  grep -rlE 'projects/-(home|Users)-[a-z]' "$ROOT/hooks" "$ROOT/scripts" 2>/dev/null | sed 's#^#      #'
else
  MEMDIR=$(python3 -c "import sys;sys.path.insert(0,'$ROOT');from agent_discipline_paths import memory_dir;print(memory_dir())")
  ok "paths resolve at runtime"
  SHORT=$(printf '%s' "$MEMDIR" | sed "s#^$HOME#~#")
  if [ -d "$MEMDIR" ]; then say "memory dir: $SHORT"
  else warn "memory dir does not exist yet: $SHORT"
       say "     harmless — it is created on first write. Override with AGENT_DISCIPLINE_MEMORY_DIR."; fi
fi

echo
[ "$MODE" = --check ] && say "check only — nothing was written." || say "Restart Claude Code so the plugin loads. Verify with /ledger."
