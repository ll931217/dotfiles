---
description: Show the agent dashboard — ledger effectiveness, blockers, and whether the preventable share is shrinking. Renders the panels in chat, not a summary of them.
allowed-tools: Bash(python3:*)
---

The dashboard has already run. Its full output:

!`python3 "${CLAUDE_PLUGIN_ROOT}/scripts/agent-dashboard.py" --days 30`

**Reprint that output verbatim inside one fenced code block, first, before any words of your
own.** Every line, in order, including the `└─` annotations — those exist to stop a number from
being read as a pass. Do not summarise it, reorder it, drop panels, round numbers, or replace
the bars with prose. The panels ARE the answer; the user reads them, not your description of
them.

Then, under the block, at most three lines: the single most actionable finding, and plainly
that there is not enough data when a panel says so. An empty result is not a good score.

Panel 5 (urgent-lane debt) reads beads in the CURRENT repo, so run it from the repo you care
about. A rising open count, or an oldest-unpaid age that keeps growing, means urgent fixes are
shipping and their deferred review is never happening — point at
`bd list --label urgent-lane-debt`.
