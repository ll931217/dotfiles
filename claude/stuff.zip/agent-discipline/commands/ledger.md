---
description: Show the agent dashboard — ledger effectiveness, blockers, and whether the preventable share is shrinking.
---

Run the bundled script and interpret the output for the user — do not just paste it.

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/agent-dashboard.py" --days 30
```

Report what the numbers mean, name the single most actionable finding, and say plainly when
there is not enough data to conclude anything. An empty result is not a good score.
