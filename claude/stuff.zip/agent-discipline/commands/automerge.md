---
description: Find MRs boring enough to merge without the user (docs/chore/style/test), review each, merge and reap. Never merges without showing the list first.
---

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/mr-automerge.py" --all
```

That lists candidates and merges nothing. Then, for **each ELIGIBLE MR only**:

1. Read the actual diff — `glab api "projects/:id/merge_requests/<iid>/changes"`.
2. Review it in a subagent, with a brief that asks for a verdict and a reason, not a summary.
   Reject on: anything factually wrong, a doc that now contradicts the code, a "chore" that
   changes behaviour, or a diff whose title undersells what it does.
3. Merge only what the review passes:
   `python3 "${CLAUDE_PLUGIN_ROOT}/scripts/mr-automerge.py" --repo <path> --merge <iid> --yes`
   The script re-checks eligibility at merge time and refuses if anything changed. Reaping is
   automatic unless `--no-reap`.
4. Report per MR: merged, or held with the reason. Never a bare count.

**The eligibility gate is the safety, not the review.** A subagent approving a diff another
agent just wrote is weak evidence — it is a second opinion, not an independent one. If you find
yourself wanting to widen the gate to fit a specific MR, that MR is not a simple MR: leave it
for the user.

Anything on HOLD stays on hold. Do not merge it because the reason looks minor to you.
