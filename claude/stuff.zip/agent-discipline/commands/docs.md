---
description: Write or update the document bound to the code you just changed, so the docs cannot drift away from it.
---

Documentation here is bound to code by `code_refs` in the document's own frontmatter, and the
binding is checked against git. Your job is to leave that binding true.

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/docs-drift.py" --changed
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/docs-drift.py"
```

Work through what those two commands report, in this order:

1. **Stale docs** — a bound file has moved on and the doc has not. Read the code, then update
   the doc: what it now does, the flags or arguments that changed, and the failure the change
   prevents. Do not rewrite the whole document when one section is wrong.
2. **Broken `code_refs`** — the ref matches no file, so the doc looks bound while documenting
   nothing. Repoint it at the file's new path, or drop the ref if the feature is gone.
3. **Unbound code you changed or added** — a feature with no document. Extend the nearest
   existing document if one covers the same area; only add a new file when nothing does. Then
   list the file in that document's frontmatter:

   ```yaml
   ---
   code_refs:
     - hooks/docs-drift-nudge.py
     - scripts/docs-drift.py
   ---
   ```

Rules for what you write:

- Describe behaviour a reader can check, and name the failure the code prevents. A doc that
  only restates the function names is drift waiting to happen.
- One document per feature, not per file. Several `code_refs` pointing at one doc is correct.
- Not every file is a feature. A shim, a one-off script, or generated output should be said so
  out loud rather than given a document nobody will read.
- Never leave a `code_refs` entry pointing at a path that does not exist — `docs-drift.py`
  reports that as a broken binding, and it is worse than no binding.

Report at the end: which docs you updated, which you created, and which unbound files you
deliberately left unbound and why.
