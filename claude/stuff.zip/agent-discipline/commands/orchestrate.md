---
description: Fan a batch of tasks out to parallel worker sessions (one worktree + one opus worker each); this session dispatches, reviews against each worker's DoD, approves. Never implements.
---

Follow `${CLAUDE_PLUGIN_ROOT}/skills/orchestrate/SKILL.md`.

Start with `orchestrate.py plan`, then `ListAgents` for your own session name, then one
`dispatch` per ready task. Review only rows whose status says `REVIEW`.
