---
description: Report logged blockers grouped by class; a class with 2+ hits is a process fix.
---

Run the bundled script and interpret the output for the user — do not just paste it.

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/blocker-log.py" report --days 90
```

Report what the numbers mean, name the single most actionable finding, and say plainly when
there is not enough data to conclude anything. An empty result is not a good score.
