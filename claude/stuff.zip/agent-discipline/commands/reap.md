---
description: Remove worktrees, local branches and MR-watch cron entries left behind by merged MRs. Dry run first.
---

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/worktree-reap.py" --all
```

Show the user what is reapable and what was kept **with the reason it was kept** — "no MR" and
"MR closed without merging" are deliberate holds, not failures. Only after they see the list,
re-run with `--reap`. Never pass `--reap` on the first invocation.

Cleanup after a merge is NOT this command's job and is never the user's decision: the MR watcher
(`scripts/glab-watch-mr.sh`) reaps the moment it sees the MR merge. This command is the manual
sweep for what the watcher never saw -- a merge that happened while nothing was watching, or a
worktree from another machine. The two-step is kept here because `--all` crosses every repo,
which is a wider blast radius than the one branch a watcher owns.
