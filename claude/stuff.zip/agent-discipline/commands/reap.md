---
description: Remove worktrees, local branches and MR-watch cron entries left behind by merged MRs. Dry run first.
---

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/worktree-reap.py" --all
```

Show the user what is reapable and what was kept **with the reason it was kept** — "no MR" and
"MR closed without merging" are deliberate holds, not failures. Only after they see the list,
re-run with `--reap`. Never pass `--reap` on the first invocation.
