---
description: Hand a worktree task to the Claude session running in that worktree, then review it against a written DoD. Orchestrator stays the reviewer.
---

Follow `${CLAUDE_PLUGIN_ROOT}/skills/delegate-to-worktree/SKILL.md`.

Start by writing the DoD — never assign before it exists on disk — and confirm via `ListAgents`
that the worker session is actually up before waiting on it.
