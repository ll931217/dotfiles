---
description: Audit Jira<->beads drift in this repo (read-only). Add --fix for the machine-safe rows only.
---

Run the bundled script and interpret the output for the user — do not just paste it.

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/jira-beads-audit.py" --repo .
```

Report what the numbers mean, name the single most actionable finding, and say plainly when
there is not enough data to conclude anything. An empty result is not a good score.
