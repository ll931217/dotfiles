---
description: Detect how THIS repo is verified — unit, E2E, property-based, mutation — and write it as a project skill the worker loads before reporting anything finished. Missing tools are recorded as MISSING, never omitted.
---

Follow `${CLAUDE_PLUGIN_ROOT}/skills/testing-handbook/SKILL.md`.

Run `--check` first and read the detected rows; a wrong row becomes a wrong instruction for every
future worker in this repo.
