---
title: Install, bootstrap, doctor — how the plugin reaches a machine and how you know it landed
code_refs:
  - install.sh
  - bootstrap.sh
  - scripts/doctor.sh
  - scripts/run-tests.sh
  - config.py
  - agent_discipline_paths.py
---

# Install, bootstrap, doctor

Four entry points, one property: re-running any of them is safe.

| Command | What it does |
| --- | --- |
| `glab api "projects/liangshih.lin%2Fagent-discipline/repository/files/bootstrap.sh/raw?ref=master" \| sh` | clone (or update) the repo, then run its installer |
| `./install.sh` | install / update. `--check` reports without writing, `--cron` adds the weekday Jira drift scan, `--uninstall` removes what it added, `--doctor` diagnoses only |
| `./scripts/doctor.sh` | read-only health report. `--quiet` prints problems only; exit 1 on any FAIL, warnings alone pass |
| `./scripts/run-tests.sh` | the whole suite under one coverage number. `--no-cov` skips the floor |

`bootstrap.sh` is POSIX `sh` and goes through the GitLab **API** route, not `/-/raw/`: for an
internal project the web route redirects to `sign_in` even with a `PRIVATE-TOKEN` header, and
piped into `sh` there is no TTY, so nothing may prompt.

## What install writes

Hooks and rules into `~/.claude`, plus symlinks in `~/.scripts` for the entry points the
user's always-load rules call by short path (`~/.scripts/blocker-log.py` and friends). A
missing link there fails **silently** — the rule names a path that does not exist and nothing
gets logged — which is why `doctor.sh` checks the same list `install.sh` creates.

## Two runtime details the rest of the code depends on

**`agent_discipline_paths.py`** resolves this machine's Claude Code global-memory directory
(`$HOME` with `/`, `.` and `_` replaced by `-`). Every hook imports it instead of hardcoding a
resolved name, which would pin the plugin to one user. `AGENT_DISCIPLINE_MEMORY_DIR` overrides.

**`config.py`** holds the Ledger Context Governor feature flags. Every default is today's
behaviour; nothing here turns a new behaviour on. Resolution order: environment variable →
`~/.config/agent-discipline.env` → default. `python3 config.py` prints each flag, its value and
where it came from. It targets Python 3.12 on purpose — Claude Code runs hooks under the system
`python3`, not the uv environment `pyproject.toml` describes.

## Coverage

The floor is `fail_under = 80`. Half the tests are shell scripts driving the CLI scripts as
`python3` subprocesses, which plain `coverage run -m pytest` cannot see into. `run-tests.sh`
puts `tests/coverage-subprocess/sitecustomize.py` on `PYTHONPATH` and a shim dir holding only
`python3`/`python` on `PATH` — not the whole `.venv/bin`, because that makes `mutmut` visible
to the tool detection in `scripts/testing-handbook.py` and its test asserts that tool is
absent. So: do not run the suite with `uv run`.
