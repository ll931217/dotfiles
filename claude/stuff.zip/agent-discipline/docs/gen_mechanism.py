#!/usr/bin/env python3
"""The mechanism map: what fires when, and where the data lives.

Companion to gen_workflow.py, NOT a replacement. That one answers "what happens to a ticket
and where am I needed"; this one answers "which hook runs on which event, what does it write,
and what do I see". Same renderer, different question — a call graph belongs in its own diagram.
"""
import diagram_lib as D

LANES = ["Trigger", "What runs", "Where it lands", "What you get"]

# id, lane, row, text, shape
NODES = [
    ("t_prompt",  0,  0, "You send a prompt",                              "start"),
    ("h_recall",  1,  0, "recall hook\n(memory-kit)",                      "box"),
    ("d_topics",  2,  0, "topics/pref-*.md\nread",                         "box"),
    ("o_ptr",     3,  0, "matching records\nsurfaced in context",          "box"),

    ("t_pick",    0,  1, "Your reply is a pick\nor an override",           "start"),
    ("h_nudge",   1,  1, "pref-capture-nudge\nUserPromptSubmit",           "box"),
    ("d_new",     2,  1, "new / sharpened\npref-*.md record",              "box"),
    ("o_asked",   3,  1, "the reasoning is kept,\nnot just the outcome",   "box"),

    ("t_skill",   0,  2, "/grilling or /to-spec\nstarts",                  "start"),
    ("h_pre",     1,  2, "pref-preload-on-skill\nPostToolUse[Skill]",      "box"),
    ("d_all",     2,  2, "whole ledger\nread",                             "box"),
    ("o_fewer",   3,  2, "it interviews you\nalready knowing",             "box"),

    ("t_ask",     0,  3, "It is about to\nask you something",              "start"),
    ("h_chk",     1,  3, "pref-checkpoint\nPreToolUse\nAskUserQuestion",   "box"),
    ("d_ev",      2,  3, "pref_events.tsv\ndeny / reissued",               "box"),
    ("o_noask",   3,  3, "settled from the ledger —\nyou never see it",    "box"),

    ("t_push",    0,  4, "git push /\nglab mr create",                     "start"),
    ("h_drift",   1,  4, "jira-drift-checkpoint\nPostToolUse[Bash]",       "box"),
    ("d_audit",   2,  4, "reads jira_issues\n+ bd labels + Jira",          "box"),
    ("o_drift",   3,  4, "drift listed while\nit still matters",           "box"),

    ("t_cron",    0,  5, "Weekdays 07:25",                                 "start"),
    ("h_night",   1,  5, "jira-drift-nightly.sh\ncron",                    "box"),
    ("d_log",     2,  5, "logs/jira-drift.log",                            "box"),
    ("o_trend",   3,  5, "silent drift becomes\na dated list",             "box"),

    ("t_start",   0,  6, "Session start",                                  "start"),
    ("h_budget",  1,  6, "always-load-budget-warn\nSessionStart",          "box"),
    ("d_rules",   2,  6, "sizes ~/.claude/rules/\n+ MEMORY.md",            "box"),
    ("o_budget",  3,  6, "warned before the\nnext rule costs you",         "box"),

    ("t_you",     0,  7, "You run a command",                              "start"),
    ("h_cmds",    1,  7, "/ledger  /drift\n/blockers  /reap",              "box"),
    ("d_scripts", 2,  7, "blocker_log.tsv,\nworktrees, MRs, cron",         "box"),
    ("o_cmds",    3,  7, "dashboard, audit,\ncleanup — on demand",         "box"),

    ("t_merged",  0,  8, "An MR merges",                                   "start"),
    ("h_reap",    1,  8, "worktree-reap.py\n(via /reap or autopilot)",     "box"),
    ("d_reap",    2,  8, "worktree + branch\n+ mr-watch cron removed",     "box"),
    ("o_clean",   3,  8, "no stale worktrees,\nno watcher polling forever","box"),

    ("note",      1, 10, "Every check fails CLOSED:\nunprovable = kept,\nreported, never green", "box"),
    ("note2",     3, 10, "Empty panels say\n'not enough data',\nnever green",  "box"),
]

E = []
for r in range(9):
    row = [n[0] for n in NODES if n[2] == r]
    for a, b in zip(row, row[1:]):
        E.append((a, b, "", 0))
# the two feedback loops that make the ledger self-improving
E.append(("d_new", "d_topics", "next prompt can match it", 1))
E.append(("d_ev", "o_cmds", "scored by /ledger", 2))
EDGES = E

if __name__ == "__main__":
    D.configure(LANES, NODES, EDGES)
    D.FILL = {0: "#e8f0fe", 1: "#ffffff", 2: "#fff4e5", 3: "#eaf7ee"}
    D.write("agent_discipline_mechanism")
