#!/usr/bin/env python3
"""The mechanism map: what fires when, and where the data lives. Three pages in one .drawio,
made for a team-meeting demo:

  1. Mechanism map        — which hook runs on which event, what it writes, what you see
  2. Orchestrator / worker — one batch of tasks, from your hand-over to the reap, actor by actor
  3. Roles                 — who runs which model, what each owns, what each never does

Companion to gen_workflow.py, NOT a replacement. That one answers "what happens to a ticket
and where am I needed"; this one answers "which mechanism, and why it cannot be skipped".
Edit the lists, re-run, never drag boxes in diagrams.net.
"""
import diagram_lib as D

# ───────────────────────────── page 1: mechanism map ─────────────────────────────
LANES1 = ["Trigger", "What runs", "Where it lands", "What you get"]
FILL1 = {0: "#e8f0fe", 1: "#ffffff", 2: "#fff4e5", 3: "#eaf7ee"}
STROKE1 = {0: "#1a56b0", 1: "#444444", 2: "#b56a00", 3: "#1e7a3c"}

# id, lane, row, text, shape — four cells per row, left to right
ROWS1 = [
    (("t_prompt", "You send a prompt", "start"),
     ("h_recall", "recall hook\n(memory-kit)", "box"),
     ("d_topics", "topics/pref-*.md\nread", "box"),
     ("o_ptr", "matching records\nsurfaced in context", "box")),
    (("t_pick", "Your reply is a pick\nor an override", "start"),
     ("h_nudge", "pref-capture-nudge\nUserPromptSubmit", "box"),
     ("d_new", "new / sharpened\npref-*.md record", "box"),
     ("o_asked", "the reasoning is kept,\nnot just the outcome", "box")),
    (("t_skill", "/grilling or /to-spec\nstarts", "start"),
     ("h_pre", "pref-preload-on-skill\nPostToolUse[Skill]", "box"),
     ("d_all", "whole ledger\nread", "box"),
     ("o_fewer", "it interviews you\nalready knowing", "box")),
    (("t_ask", "It is about to\nask you something", "start"),
     ("h_chk", "pref-checkpoint\nPreToolUse\nAskUserQuestion", "box"),
     ("d_ev", "pref_events.tsv\ndeny / reissued", "box"),
     ("o_noask", "settled from the ledger —\nyou never see it", "box")),
    (("t_wt", "wt switch --create\n(a worktree is born)", "start"),
     ("h_delegate", "worktree-delegate-nudge\nPostToolUse[Bash]", "box"),
     ("d_task", "<worktree>/.claude/\nTASK.md", "box"),
     ("o_orch", "you stay the orchestrator;\nthe worktree gets the work", "box")),
    (("t_window", "worktree tmux\nwindow opens", "start"),
     ("h_worker", "agent-worker.sh\n(wt post-start)", "box"),
     ("d_role", "claude --model opus\n--effort high\n+ prompts/worker.md", "box"),
     ("o_role", "worker knows its role\nbefore anyone types", "box")),
    (("t_edit", "You edit main checkout\nwhile workers run", "start"),
     ("h_hands", "orchestrator-hands-off\nPostToolUse[Edit|Write]", "box"),
     ("d_deleg", "reads .worktrees/*/\n.claude/delegate.json", "box"),
     ("o_note", "a note: review, don't type.\nNever a block", "box")),
    (("t_push", "git push /\nglab mr create", "start"),
     ("h_drift", "jira-drift-checkpoint\n+ glab-autowatch\nPostToolUse[Bash]", "box"),
     ("d_audit", "jira_issues + bd labels\n+ Jira; MR watcher started", "box"),
     ("o_drift", "drift listed while it matters;\none popup per MR event", "box")),
    (("t_cron", "Weekdays 07:25", "start"),
     ("h_night", "jira-drift-nightly.sh\ncron", "box"),
     ("d_log", "logs/jira-drift.log", "box"),
     ("o_trend", "silent drift becomes\na dated list", "box")),
    (("t_start", "Session start", "start"),
     ("h_budget", "always-load-budget-warn\nSessionStart", "box"),
     ("d_rules", "sizes ~/.claude/rules/\n+ MEMORY.md", "box"),
     ("o_budget", "warned before the\nnext rule costs you", "box")),
    (("t_you", "You run a command", "start"),
     ("h_cmds", "/orchestrate  /delegate\n/automerge  /reap\n/ledger  /drift  /blockers", "box"),
     ("d_scripts", "TASK.md, DOD.md, MRs,\nblocker_log.tsv, cron", "box"),
     ("o_cmds", "dispatch, review, merge,\ncleanup — on demand", "box")),
    (("t_merged", "An MR merges", "start"),
     ("h_reap", "glab-watch-mr.sh sees it\n→ worktree-reap.py", "box"),
     ("d_reap", "worktree + branch + tmux\nwindow + cron removed", "box"),
     ("o_clean", "no stale worktrees,\nno watcher polling forever", "box")),
]
NODES1 = [(nid, lane, r, text, sh) for r, row in enumerate(ROWS1) for lane, (nid, text, sh) in enumerate(row)]
last = len(ROWS1) + 1
NODES1 += [
    ("note", 1, last, "Every check fails CLOSED:\nunprovable = kept,\nreported, never green", "box"),
    ("note2", 3, last, "Hooks inform, never block:\nthe flow runs unattended", "box"),
]
EDGES1 = [(a[0], b[0], "", 0) for row in ROWS1 for a, b in zip(row, row[1:])]
EDGES1 += [
    ("d_new", "d_topics", "next prompt can match it", 1),   # the ledger feeds the next recall
    ("d_ev", "o_cmds", "scored by /ledger", 2),
]

# ───────────────────────── page 2: orchestrator / worker ─────────────────────────
LANES2 = ["You", "Orchestrator\n(your main session)", "Worker\n(the worktree's Claude)", "5 DoD teammates", "GitLab"]
FILL2 = {0: "#e8f0fe", 1: "#ffffff", 2: "#fff4e5", 3: "#f3e8fd", 4: "#eaf7ee"}
STROKE2 = {0: "#1a56b0", 1: "#444444", 2: "#b56a00", 3: "#6b2fa0", 4: "#1e7a3c"}

NODES2 = [
    ("u_batch",   0, 0,  "You hand over a batch\nof tasks — then step back", "start"),
    ("o_plan",    1, 1,  "plan: bd ready =\ntasks with no open blocker\n→ these run in parallel", "box"),
    ("o_disp",    1, 2,  "dispatch, one per task:\nwt worktree + TASK.md\n(task, my name, your prefs)", "box"),
    ("w_start",   2, 2,  "worker starts by itself:\nopus · high · role prompt.\nTold: read TASK.md, begin", "box"),
    ("w_spawn",   2, 3,  "reads TASK.md, spawns\n5 DoD teammates first", "box"),
    ("d_write",   3, 3,  "each lens writes ≤5 checkable\nitems: intent · tests · UX ·\ndiscipline · prefs → DOD.md", "box"),
    ("w_impl",    2, 4,  "implements: phases ≤5 files,\nchecks green, commit, push\n(no MR yet)", "box"),
    ("w_verify",  2, 5,  "asks the 5 to verify\nagainst HEAD", "box"),
    ("d_pass",    3, 5,  "all five PASS?", "dia"),
    ("w_report",  2, 6,  "reports: branch, DOD.md,\nverdict per lens, the one\ncommand that checks it", "box"),
    ("o_review",  1, 6,  "reviews the diff against\nDOD.md — and nothing else", "box"),
    ("o_ok",      1, 7,  "approve?", "dia"),
    ("w_mr",      2, 8,  "push + MR into staging\n(never main)", "box"),
    ("g_pipe",    4, 8,  "pipeline runs;\nwatcher follows it", "box"),
    ("g_simple",  4, 9,  "docs / chore / style / test\nAND docs-like paths only?", "dia"),
    ("o_auto",    1, 10, "/automerge: reviewed by\na subagent, merged", "box"),
    ("u_merge",   0, 10, "you review and merge —\nthe only step that is yours", "start"),
    ("g_merged",  4, 11, "merged", "box"),
    ("g_reap",    4, 12, "watcher reaps: worktree,\nbranch, tmux window, cron", "box"),
    ("u_done",    0, 12, "one notification.\nnothing left to clean up", "start"),
]
EDGES2 = [
    ("u_batch", "o_plan", "", 0),
    ("o_plan", "o_disp", "", 0),
    ("o_disp", "w_start", "", 0),
    ("w_start", "w_spawn", "", 0),
    ("w_spawn", "d_write", "", 0),
    ("w_spawn", "w_impl", "", 0),
    ("w_impl", "w_verify", "", 0),
    ("w_verify", "d_pass", "", 0),
    ("d_pass", "w_impl", "FAIL: item + evidence — fix, re-ask that lens (max 3 rounds)", 1),
    ("d_pass", "w_report", "yes", 0),
    ("w_report", "o_review", "", 0),
    ("o_review", "o_ok", "", 0),
    ("o_ok", "w_impl", "no — the issue and the DoD item, never the fix", 1),
    ("o_ok", "w_mr", "yes", 0),
    ("w_mr", "g_pipe", "", 0),
    ("g_pipe", "g_simple", "", 0),
    ("g_simple", "o_auto", "yes", 0),
    ("g_simple", "u_merge", "no", 0),
    ("o_auto", "g_merged", "", 0),
    ("u_merge", "g_merged", "", 0),
    ("g_merged", "g_reap", "", 0),
    ("g_reap", "u_done", "", 0),
]

# ──────────────────────────────── page 3: roles ────────────────────────────────
LANES3 = ["Role", "Model · effort", "Owns", "Never"]
FILL3 = {0: "#e8f0fe", 1: "#ffffff", 2: "#fff4e5", 3: "#fde8e8"}
STROKE3 = {0: "#1a56b0", 1: "#444444", 2: "#b56a00", 3: "#9a2b2b"}
ROWS3 = [
    ("You", "—", "the goal, the batch,\nmerging non-simple MRs,\nDoD-vs-approach calls", "cleaning up worktrees\nor chasing pipelines"),
    ("Orchestrator\n(main session)", "your default model\n--effort xhigh\n(agent-orchestrator.sh)", "plan · dispatch · review\nagainst DOD.md · approve", "editing code\n(a hook says so)"),
    ("Worker\n(worktree Claude)", "opus · high\n(agent-worker.sh)", "the DoD, the phases,\nthe commits, the MR\ninto staging", "reaping, merging,\npushing to main"),
    ("5 DoD teammates\n(worker's subagents)", "sonnet\n(REVIEWER_MODEL)", "one lens each: intent, tests,\nUX, discipline, prefs.\nWrite items, then verify", "writing code or\nnegotiating the task"),
    ("Watcher + reaper\n(scripts, no model)", "—\nall of the above:\n~/.config/agent-discipline.env", "pipeline: one popup per\nevent. On merge: worktree,\nbranch, tmux window, cron", "removing anything\nit cannot prove merged"),
]
NODES3 = [(f"r{r}c{c}", c, r, text, "start" if c == 0 else "box")
          for r, row in enumerate(ROWS3) for c, text in enumerate(row)]
EDGES3 = []

# the same five rows without the plugin: one model does everything, and what the plugin owns
# falls back on you — or on nobody
LANES3B = ["Role", "Model · effort", "Does", "What slips"]
ROWS3B = [
    ("You", "—", "the goal; every preference\nquestion, again; merging\nevery MR; all the cleanup", "the same answers given\ntwice; worktrees and tmux\nwindows pile up"),
    ("Main session", "your default model\nand effort, for\neverything", "plans, implements,\nand reviews its own work", "reviewer = author;\nthe worktree Claude\nsits idle"),
    ("Worktree Claude", "same as main\n(bare `claude`)", "nothing, unless\nyou type to it", "a clean context window\nat 0% until reaped"),
    ("5 DoD agents", "sonnet —\nif spawned at all", "write the DoD when\nthe rule is remembered", "no verify round,\nno round cap, no record"),
    ("Watcher + reaper", "— (none)", "you refresh the MR page,\nremove the worktree,\nclose the window, kill cron", "stale worktrees and\nwatcher logs, unnoticed"),
]
NODES3B = [(f"b{r}c{c}", c, r, text, "start" if c == 0 else "box")
           for r, row in enumerate(ROWS3B) for c, text in enumerate(row)]

if __name__ == "__main__":
    D.write_pages("agent_discipline_mechanism", [
        ("Mechanism map", LANES1, NODES1, EDGES1, FILL1, STROKE1),
        ("Orchestrator / worker", LANES2, NODES2, EDGES2, FILL2, STROKE2),
        ("Roles without the plugin", LANES3B, NODES3B, [], FILL3, STROKE3),
        ("Roles with the plugin", LANES3, NODES3, EDGES3, FILL3, STROKE3,
         "agent_discipline_mechanism-roles.svg"),
    ])
