---
title: Hooks fire on evidence, not on the words in a command
code_refs:
  - hooks/worktree-delegate-nudge.py
  - hooks/glab-autowatch.sh
  - scripts/mr-await.sh
  - hooks/batch-dispatch-nudge.py
---

# Hooks fire on evidence

A `PostToolUse[Bash]` hook sees the command string and its output. Both are *text*, and text is
easy to match and easy to be wrong about. These two hooks now require an observable
consequence, because matching text made them act on commands that did nothing.

## What went wrong

| Hook | What it accepted as proof | What the command actually was |
| --- | --- | --- |
| `worktree-delegate-nudge.py` | `git worktree add` appearing anywhere in the command | a `bd create` whose issue **description** quoted that command |
| `glab-autowatch.sh` | the substring `/merge_requests/` in the output | a `grep` over these scripts, printing `glab api "projects/:id/merge_requests?…"` |
| `batch-dispatch-nudge.py` | — | built to the same rule: batch-shaped words fire only when 2+ issue ids are named or `bd ready` actually has 2+ |

Neither failure was quiet, which made it worse: one told the orchestrator to hand work to a
worker Claude that did not exist (and listed tmux panes from an unrelated repo), the other
started a **live background watcher on `master`** from a command that created nothing.

## The rule

**A pre-filter may read text. The decision may not.**

- `worktree-delegate-nudge.py` keeps the regex as a cheap pre-filter, then diffs
  `git worktree list --porcelain` against a per-session snapshot
  (`~/.claude/tmp/worktree-nudge/<sid>.json`). It fires only for a path that was not there
  before, names that path, and never fires twice for the same one. On the first Bash call of a
  session there is no snapshot to diff, so it falls back to mtime: a worktree created in the
  last 120 seconds still counts, because refusing to fire on the first command would miss the
  dispatch that opens a session.
- `glab-autowatch.sh` requires a real MR URL — scheme, host and a **numeric** iid
  (`https?://…/-/merge_requests/[0-9]+`) — and, for a push, output that a push actually
  produces (`->`, `new branch`, `Everything up-to-date`, `remote:`).

The nudge's *text* — the 4-step orchestrator procedure it prints — is not part of that
decision and changes with the procedure (lens counts, DoD file, review rounds; see
`docs/delegation-dod.md`). Only the two paragraphs above are the detection rule, so editing the
message never loosens what counts as evidence.

## Testing this

The test for a hook like this asserts the **observable**, not the exit code, which a hook always
returns as 0:

- `tests/test_delegate_nudge.sh` — the mention, the grep, and a *failed* creation are silent; a
  real `git worktree add` fires once, names the path, and a second new worktree fires again
  without re-listing the first.
- `tests/test_autowatch_hook.sh` — probes for whether a watcher process was **spawned** (its
  lock file is the evidence), including the grep and the issue-description cases, and it kills
  what it spawns so a throwaway repo does not leave pollers behind.

Every one of those false-positive cases is a probe with `want=0`. A hook that cannot stay
silent is not a detector.

## The same rule for waiting: ask the source, do not watch a proxy

The MR wake-up this hook hands out used to be an `until`-loop over `glab-watch-mr.sh`'s log
file. The watcher died at 11:16:35, the MR merged at 11:46:52, and the loop waited forever — a
dead producer's silence is byte-for-byte identical to "still running", so a human had to carry
the news in.

`scripts/mr-await.sh <iid>` asks GitLab instead. There is no producer to die, and every path
ends in a message:

| Exit | Meaning |
| --- | --- |
| 0 | merged |
| 1 | closed without merging |
| 2 | pipeline failed or canceled |
| 3 | merge conflict (`cannot_be_merged`) |
| 4 | could not query GitLab — explicitly **not** a verdict on the MR |
| 5 | timeout (default 2h): still open, nothing failed, nothing merged |

Two silence traps it closes: an **empty** API reply is exit 4, not an open MR to wait out (it
used to print `!7  · pipeline` and burn the whole timeout), and the timeout says how long it
waited and that it is not a verdict. `tests/test_mr_await.sh` drives all seven paths against a
fake glab, and `tests/test_autowatch_hook.sh` fails if the emitted wake-up ever contains
`tail -c +` again.
