---
title: Optional tools — worktrunk, beads and glab, and what runs without them
code_refs:
  - agent_tools.py
  - scripts/agent-tools.sh
  - scripts/orchestrate.py
  - scripts/worktree-reap.py
  - scripts/glab-watch-mr.sh
  - scripts/glab-watch-pipeline.sh
  - scripts/mr-automerge.py
  - scripts/jira-derive-status.py
  - scripts/jira-beads-audit.py
  - commands/automerge.md
  - commands/reap.md
  - commands/drift.md
  - skills/mr-automerge/SKILL.md
  - hooks/jira-drift-checkpoint.py
  - scripts/jira-drift-nightly.sh
---

# Optional tools

Three tools make this plugin nicer and none of them is required. What you get instead:

| Preferred | Fallback | Needs |
| --- | --- | --- |
| `wt` (worktrunk) | `git worktree add` / `remove` + `git branch -D` | git |
| `bd` (beads) | `jira.py search` / `edit` | jira.py on `JIRA_PY` or its default path |
| `glab` | GitLab REST v4 | a token, and `curl` for the shell half |

```bash
python3 agent_tools.py          # what is present and what runs instead
python3 agent_tools.py --json
```

Exit 1 means one capability has neither a tool nor a working fallback — usually a missing
GitLab token.

## The rule every fallback obeys

**A narrower answer is labelled, never passed off as the full one.** The plugin's whole subject
is drift caused by silence, so a degraded run says which check did not happen:

- `orchestrate plan` on jira prints *"jira has no dependency graph: 'ready' here means assigned
  and not done. Blocked-by relationships were NOT checked."* `bd ready` genuinely knows about
  blockers; the fallback does not, and pretending otherwise would dispatch a worker onto a
  blocked task.
- `orchestrate dispatch --urgent` without `bd` says the follow-up review is **NOT BOOKED**, in
  the dispatch output and in TASK.md, and tells the worker to escalate it. It never falls back
  to silently shipping the skip — "nothing is owed" and "nobody can see what is owed" are
  opposite facts, and `/ledger` panel 5 reports the same distinction as UNAVAILABLE vs 0.
- `orchestrate dispatch` without `wt` says **no worker session was started** and prints the
  command to start one, because only worktrunk's post-start hook launches a worker. It also
  stops printing "SendMessage it: …", which would send you waiting for a session that is never
  coming.
- `orchestrate dispatch --lane repay` reads the skipped lenses back off the debt bead. Without
  `bd` it does not guess and does not quietly run the full set: dispatch prints `!! bead
  unreadable: no bd on PATH` and TASK.md tells the worker to read the bead itself and say so.
- **Opening the MR has no fallback, by design.** The worker writes `.claude/mr-body.md` with the
  `show-me` skill and passes `glab mr create --description "$(cat …)"`; without `glab` the plugin
  prints that command instead of running it. A REST-created MR would silently drop the
  description file, and an MR body that says nothing is the drift this plugin is about.
- Without `bd`, the Jira↔beads **mirror** checks cannot run at all — there are no mirrors to
  check. They are reported as SKIPPED. Key-level checks still run.
- The MR watcher exits **4** when it could not reach GitLab, distinct from **1** for "no MR
  exists". Both used to be exit 1 with the same message.

`dispatch` also decides where the worker's definition of done goes and makes the delegation
bookkeeping invisible to git — separate concerns, each with its own failure history, in
`docs/delegation-dod.md`.

## GitLab without glab

`glab api <path>` is a token-and-host wrapper over `/api/v4`, so one adapter covers every call
site: `gl_api` in `agent_tools.py` (urllib) and in `scripts/agent-tools.sh` (curl). `projects/:id`
is substituted with the project resolved from the `origin` remote.

Token, first hit wins:

1. `$GITLAB_TOKEN`, `$GLAB_TOKEN`, `$CI_JOB_TOKEN`
2. `gopass show -o vici/gitlab/api_token` — override the slot with `$GITLAB_TOKEN_GOPASS`
3. neither → a refusal naming both options. **Never an empty body**, which would read as "no
   results".

A caller that cannot reach the API must not die on the spot. `glab-watch-mr.sh` resolves the
project name with a trailing `|| true` for that reason: under `set -e -o pipefail` an unreachable
API made that one line the whole script's exit path, so the basename fallback right below it
could never run and the watcher printed nothing at all.

Host comes from `$GITLAB_HOST` or the `origin` remote. A bare `GITLAB_HOST=gitlab.example.com`
(glab's own convention) is normalised to `https://` — passed raw to urllib it fails with
"unknown url type". The SSH port in `ssh://git@host:8022/group/repo` is dropped: git speaks SSH
there, the API is HTTPS.

## Testing absence

`tests/test_agent_tools.sh` simulates a missing tool with a **symlink farm** — a directory
holding exactly the binaries the fallback may use — and asserts the tool is really gone before
testing anything. Stripping `PATH` does not work here: `glab` and `curl` both live in
`/usr/bin`, so removing that directory removes the fallback's own dependency and the test would
pass for the wrong reason. Two hand-checks written that way "passed" while glab was still on
`PATH`.
