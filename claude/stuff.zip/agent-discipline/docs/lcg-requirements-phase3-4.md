---
code_refs:
  - ledger/discovery.py
  - ledger/delta.py
  - ledger/coverage.py
  - ledger/decision.py
  - ledger/prediction.py
  - ledger/autonomy.py
  - ledger/curation.py
  - ledger/recommend.py
---

# Ledger Context Governor — normalized requirements, Phases 3-4, and the configuration surface

Derived from the spec at `docs/ledger-context-governor-implementation-spec.md` v0.2.0 — sections read: §15 (resolution and refresh pipeline), §16 (dynamic task context manifest), §17 (risk model and autonomy policy), §19 (decision-need normalization, question resolution, answer capture), §21 (configuration), §25 (rollout modes), §26 (implementation phases, Phase 3 and Phase 4 entries) — 2026-09-03.

| ID | Requirement (one line, imperative) | Spec § | Mandatory? |
|---|---|---|---|
| P3-01 | Trigger an incremental refresh when a previously unseen repository path or symbol becomes active | 15.9 | MUST ("A refresh is required when") |
| P3-02 | Trigger a refresh when a newly read file imports or references another module or service | 15.9 | MUST |
| P3-03 | Trigger a refresh when a new dataset, table, endpoint, message topic, dependency, or external system is discovered | 15.9 | MUST |
| P3-04 | Trigger a refresh when a tool or test failure contradicts an active assumption | 15.9 | MUST |
| P3-05 | Trigger a refresh when the implementation target expands to another module or service | 15.9 | MUST |
| P3-06 | Trigger a refresh when a source file supporting an active entry changes | 15.9 | MUST |
| P3-07 | Trigger a refresh when the agent attempts to mutate an uncovered scope | 15.9 | MUST |
| P3-08 | Trigger a refresh when the agent attempts to ask a clarification question | 15.9 | MUST |
| P3-09 | Trigger a refresh when a subagent is spawned for a distinct scope | 15.9 | MUST |
| P3-10 | Trigger a refresh when a session resumes, clears, forks, or compacts | 15.9 | MUST |
| P3-11 | Trigger a refresh when a Memory Kit, Canon, or Ledger source version changes | 15.9 | MUST |
| P3-12 | Keep the incremental resolution request narrow — query newly discovered entities and their direct relationships, never an unconstrained repository-wide semantic search | 15.8 | MUST ("must be narrow"); second clause SHOULD |
| P3-13 | Extract entities deterministically first: paths, symbols, imports/package/module refs, SQL tables/schema objects/dataset ids, endpoint routes/queue topics/event names/configuration keys, error types/test names/stack-trace paths/failing assertions, Memory Kit aliases and canonical entity IDs | 15.10 | SHOULD ("Use deterministic extraction first") |
| P3-14 | Treat optional model-assisted extraction output as a retrieval hint only — it cannot grant authority or create an active fact | 15.10 | MUST ("cannot") |
| P3-15 | Admit an entity into the scope frontier only after normalization and deduplication | 15.11 | MUST ("only after") |
| P3-16 | Record per frontier update: canonical entity ID, source tool use, confidence, first and latest observation, relationship to already known scopes, whether the entity has mutation coverage, whether its context was injected into the model | 15.11 | MUST |
| P3-17 | Restrict a material delta to newly applicable entries, entries no longer applicable, newly stale/invalidated/superseded entries, new or resolved conflicts, changed autonomy boundaries, new decision resolutions, added or invalidated context coverage | 15.12 | MUST ("must include only") |
| P3-18 | Do not re-inject unchanged entries; keep the external manifest complete while model-visible deltas stay minimal | 15.12 | MUST (imperative prohibition) |
| P3-19 | Make the same normalized trigger and source snapshot produce the same outcome (idempotency) | 15.13 | MUST |
| P3-20 | Use a per-session lock or transactional compare-and-swap on manifest revision | 15.13 | MUST (imperative) |
| P3-21 | Prevent concurrent `PostToolUse` hooks from creating conflicting revisions | 15.13 | MUST |
| P3-22 | Prefer `PostToolBatch` to aggregate parallel tool calls when supported | 15.13 | SHOULD ("Prefer") |
| P3-23 | Recompute a stale writer's delta against the latest state when it loses a revision race | 15.13 | MUST |
| P3-24 | Keep receipt chains ordered and gap-free | 15.13, 16.3 | MUST |
| P3-25 | Retain three later recovery checkpoints after a proactive retrieval miss: `1. Mutation coverage gate`, `2. AskUserQuestion interception`, `3. Plain-text Stop recovery` | 15.14 | MUST ("The system must still retain") |
| P3-26 | Emit `M0` with fields `Manifest`, `Receipt`, `Repository revision`, `Source snapshot`, `Mode`, and the sections `Task`, `Known scope frontier`, `Applicable policies`, `Relevant system facts`, `Active decisions`, `Conflicts and stale information`, `Autonomy boundary` | 16.1 | SHOULD (format "similar to") |
| P3-27 | State explicitly in `M0` that it reflects only currently known scope | 16.1 | MUST |
| P3-28 | Emit a delta headed `LEDGER CONTEXT DELTA` carrying `Manifest: Mn -> Mn+1`, `Receipt`, `Trigger` (e.g. `scope_discovered`), `Observed from`, and only the changed sections (`New scope`, `Added system facts`, `Added active decisions`, `Invalidated assumptions`, `Updated autonomy boundary`) | 16.2 | SHOULD |
| P3-29 | Maintain a receipt chain (`M0 / ctxr_…` per trigger) and treat it, not the transcript, as authoritative | 16.3 | MUST ("is authoritative") |
| P3-30 | Inject a compact `LEDGER CONTEXT REHYDRATED` view on resume, clear, fork, or compaction, listing current manifest, receipt chain head, active scope, critical active entries, resolved needs, open conflicts | 16.4 | SHOULD |
| P3-31 | Do not inject all evidence or every historical delta on rehydration; provide IDs for on-demand explanation | 16.4 | MUST (imperative prohibition) |
| P3-32 | Expose coverage separately from the manifest in the context command, with `COVERED` / `UNCOVERED` / `BLOCKED` groupings | 16.5 | SHOULD |
| P3-33 | Record coverage in non-enforcing mode in Phase 3 (`coverageGate.enforcement: "shadow"`) — no mutation is actually delayed | 26 Phase 3, 21 | MUST default non-enforcing |
| P3-34 | Keep the full manifest within budget: soft 6,000 / hard 9,000 characters; deltas soft 1,500 / hard 3,000; max rationale 240 characters per item | 15.7 | SHOULD ("Recommended defaults") |
| P3-35 | Prioritize on truncation: hard policies and invariants, exact directly relevant facts, active decisions, applicable exceptions, task-specific preferences, assumptions, advisory heuristics | 15.7 | SHOULD |
| P3-36 | Never truncate identifiers, authority, risk, or conflict warnings | 15.7 | MUST ("Never") |
| P3-37 | Never combine all factors into a single weighted relevance score in either pipeline | 15 | MUST ("may not") |
| P3-38 | Apply authorization before returning source text; never surface unauthorized candidates as rejected receipt items — record only a count or opaque access-denied marker | 15.2 | MUST |
| P3-39 | Retrieve deterministically in the fixed order: current-task resolved-need cache, exact decision key, exact task ID, exact repository/service/module/path/symbol, exact endpoint/dataset/table/message topic/dependency, canon rule applicability, direct source references and relationship edges, business concepts and operations | 15.3 | MUST (imperative order) |
| P3-40 | Use semantic fallback only to discover candidates not found by exact keys, and let semantic relevance order candidates only after authorization, lifecycle eligibility, scope compatibility, entry-kind compatibility, and authority-group constraints | 15.4 | MUST ("only") |
| P3-41 | Classify every candidate's temporal state as one of `current`, `possibly_stale`, `stale`, `invalid`, `unknown` | 15.5 | MUST |
| P3-42 | Include a stale fact only under `staleItems`, and never let it independently drive autonomous resolution | 15.5 | MUST |
| P3-43 | Group conflicts by exact decision key, explicit `conflictKey`, shared normalized subject, explicit `conflictsWith` links, then conservative semantic contradiction detection; emit a conflict when no candidate dominates safely | 15.6 | MUST |
| P4-01 | Normalize question text using decision-need type, canonical subject, operation, exact scope, material constraints, proposed options, and existing active decision keys — raw text is not a durable key | 19.1 | MUST |
| P4-02 | Retain the original question text for audit even when Memory Kit aliases are used in normalization | 19.1 | MUST |
| P4-03 | Generate the decision key as `hash(normalized type, normalized subject, normalized operation, canonical scopes, material constraints)` | 19.2 | SHOULD ("Conceptually") |
| P4-04 | Exclude incidental wording, punctuation, and option order from the decision key | 19.2 | MUST (imperative prohibition) |
| P4-05 | Retain separate keys rather than incorrectly merging unrelated decisions when normalization confidence is insufficient | 19.2 | MUST |
| P4-06 | Resolve every question in order: exact current-task resolved need, exact prior human answer with compatible scope and constraints, exact active decision key, exact Canon applicability, exact repository/service/path/symbol/entity scope, related Memory Kit facts and invariants, semantic fallback, noisy memory for advisory explanation only | 19.3 | MUST |
| P4-07 | On an exact compatible `ResolvedNeed`, return it without re-querying expensive semantic sources, validate its source snapshot and invalidation conditions, update usage metadata, and do not show the question to the user again | 19.4 | MUST |
| P4-08 | Invalidate or bypass a cached resolution when scope or constraints materially changed, resolve again, and explain why the previous answer no longer applies | 19.4 | MUST |
| P4-09 | Persist a `QuestionPrediction` with fields `id`, `sessionId`, `toolUseId?`, `decisionNeed`, `questionText`, `options`, `predictedAnswer?`, `mode` (`observe`\|`shadow`\|`recommend`\|`resolve`), `risk`, `intent`, `confidence`, `supportingEntryIds`, `conflictingEntryIds`, `manifestRevision`, `receiptId`, `createdAt` | 19.5 | MUST (typed interface) |
| P4-10 | Persist a `QuestionOutcome` with `predictionId`, `decisionKey`, `actualAnswer`, `answerSource` (`human`\|`ledger`\|`canon`\|`memory_kit`\|`current_task_cache`\|`stop_recovery`), `agreedWithPrediction`, `laterCorrected`, `resultingResolvedNeedId`, `resultingCandidateEntryIds`, `recordedAt` | 19.6 | MUST |
| P4-11 | Classify each received answer as one of `task_choice`, `personal_preference`, `team_convention`, `architectural_decision`, `factual_correction`, `temporary_workaround`, `exception`, `rejection`, `insufficient_to_classify` | 19.7 | MUST |
| P4-12 | Base classification on wording, task context, actor authority, affected scope, and supporting evidence | 19.7 | MUST ("must consider") |
| P4-13 | Create a task-scoped `ResolvedNeed` immediately for every accepted human answer unless the answer is explicitly non-binding | 19.8 | SHOULD |
| P4-14 | Expire auto-created task-local choices with the task; gate repository, team, architecture, security, and organization entries behind scope-appropriate approval | 19.9 | MUST for approval-gating; MAY for auto-activation ("may become") |
| P4-15 | Keep agent observations at `observed` until corroborated, and never promote an observation directly to hard policy (candidate at most) | 19.9 | MUST ("never") |
| P4-16 | Store rejected options as negative evidence; let corrections and reversions reduce confidence and possibly invalidate active entries | 19.9 | SHOULD |
| P4-17 | Deduplicate before creating a candidate: search exact decision key, then same subject with compatible scope; attach evidence to an existing candidate when materially equivalent; create a conflict link on contradiction; avoid paraphrased duplicates; preserve original human wording in evidence | 19.10 | MUST (imperative checklist) |
| P4-18 | Permit option mapping only when an option label exactly equals the normalized resolution, or a configured canonical alias maps one-to-one, and no other option is semantically equivalent | 19.11 | MUST ("Permit mapping only when") |
| P4-19 | Require every selected option of a multi-select question to map independently | 19.11 | MUST |
| P4-20 | Do not auto-answer free-form "Other" choices unless the tool contract and policy have an explicitly tested path | 19.11 | MUST |
| P4-21 | Group shadow-mode calibration precision by decision-need type, intent, risk, repository/team, authority class, exact versus semantic retrieval, new decision versus established-decision application, proactive discovery hit versus last-chance interception | 19.12 | MUST ("must group") |
| P4-22 | Suppress no question in Phase 4 — intercept `AskUserQuestion` against the full stores, predict, and let the human answer | 26 Phase 4, 25 `shadow` | MUST (exit criterion) |
| P4-23 | Map semantically equivalent questions to consistent decision keys | 26 Phase 4 | MUST (exit criterion) |
| P4-24 | Turn human answers into task-local resolved needs | 26 Phase 4 | MUST (exit criterion) |
| P4-25 | Detect plain-text Stop candidates conservatively and measure them for false positives | 26 Phase 4, 21 `stopRecovery.classification` | MUST (exit criterion) |
| P4-26 | Classify decision-need intent and honor its ceilings: `apply_established` / `verify_fact` may apply established answers; `choose_new` needs the new-decision ceiling; `change_established` defaults to asking a human regardless of similarity, confidence, or convenience | 17.4–17.6 | MUST |
| P4-27 | Require a human for the mandatory categories (public API/protocol/wire-format/back-compat, DB schema and risky migrations, data derivation/timestamp/trading-calendar/financial/raw-data meaning, auth/authorization/access control/secrets/crypto/security boundaries, destructive or irreversible actions, legal/compliance/audit/retention, production infrastructure or deployment topology, customer-visible behavior with no approved decision, expensive or hard-to-reverse platform choices, direct conflict between authoritative sources, anything marked `never_auto_apply`) | 17.3 | MUST ("require a human") |
| P4-28 | Gate established-decision application on all 11 conditions and new-decision auto-answer on all 11 conditions, including a successfully written context receipt | 17.4, 17.5 | MUST ("only when all conditions are true") |
| P4-29 | Use `RiskLevel` values exactly `trivial`, `low`, `medium`, `high`, `critical` | 17.1 | MUST (typed) |
| P4-30 | Make mode independently configurable for `context injection`, `coverage enforcement`, `question answering`, `Stop recovery`, `subagent context` | 25 | SHOULD |
| P4-31 | Allow a repository, team, or user to select a lower-autonomy mode than the organization maximum | 25 | MAY/SHOULD |
| P4-32 | Implement the four rollout modes `observe`, `shadow`, `recommend`, `resolve` as explicit configuration values with the behaviors listed in §25 | 25 | MUST ("Support these modes") |

## Configuration and feature flags

| Config key | Type | Default per spec | What it gates |
|---|---|---|---|
| `mode` | enum `observe`\|`shadow`\|`recommend`\|`resolve` | `"shadow"` | Global rollout mode; spec: "Initial mode: `shadow`" |
| `storage.driver` | string | `"existing"` | Which storage backend the ledger uses |
| `storage.path` | string (path) | `".ledger/ledger.db"` | Ledger database location |
| `storage.sessionStatePath` | string (path) | `".ledger/sessions"` | External (out-of-context) session state location |
| `sources.memoryKit.enabled` | boolean | `true` | Memory Kit as a retrieval source |
| `sources.memoryKit.required` | boolean | `false` | Whether Memory Kit absence is fatal (default tolerant) |
| `sources.canon.enabled` | boolean | `true` | Canon as a retrieval source |
| `sources.canon.requiredForHardPolicy` | boolean | `true` | Canon must be available before hard-policy enforcement |
| `context.softCharacterTarget` | number | `6000` | Manifest soft size target |
| `context.hardCharacterCap` | number | `9000` | Manifest hard size cap |
| `context.deltaSoftCharacterTarget` | number | `1500` | Delta soft size target |
| `context.deltaHardCharacterCap` | number | `3000` | Delta hard size cap |
| `context.includeStaleWarnings` | boolean | `true` | Whether stale warnings appear in the manifest |
| `context.includeNoisyMemory` | boolean | `false` | **OFF by default** — noisy memory excluded from normal manifests |
| `context.injectOnlyDeltas` | boolean | `true` | Suppress re-injection of unchanged entries |
| `context.rehydrateOn` | string[] | `["resume","clear","fork","compact"]` | Which lifecycle events trigger rehydration injection |
| `dynamicManifest.enabled` | boolean | `true` | Phase-3 dynamic discovery/refresh as a whole ("Dynamic manifest refresh: enabled") |
| `dynamicManifest.refreshOnToolBatch` | boolean | `true` | Refresh from aggregated `PostToolBatch`/`PostToolUse` observations |
| `dynamicManifest.refreshOnToolFailure` | boolean | `true` | Failure-driven refresh |
| `dynamicManifest.deterministicEntityExtraction` | boolean | `true` | Deterministic path/symbol/table/endpoint extraction |
| `dynamicManifest.modelAssistedEntityExtraction` | boolean | `false` | **OFF by default** — optional model-assisted extraction (hint-only) |
| `dynamicManifest.persistExternalSessionState` | boolean | `true` | Writing manifest/frontier state outside model context (required for `resolve` mode) |
| `dynamicManifest.maxManifestRevisionsPerTurn` | number | `10` | Upper bound on manifest revisions produced in one turn |
| `coverageGate.enabled` | boolean | `true` | Whether coverage records/gating logic runs at all |
| `coverageGate.enforcement` | enum (`"shadow"` shown) | `"shadow"` | **Non-enforcing by default** — "Coverage gate enforcement: shadow-only until calibrated" |
| `coverageGate.mutationTools` | string[] | `["Edit","Write","NotebookEdit","Bash"]` | Which tools count as mutations for coverage |
| `coverageGate.denyOnceForNewContext` | boolean | `true` | Delay an uncovered mutation exactly once when new context is found |
| `coverageGate.maximumHydrationAttemptsPerFingerprint` | number | `1` | Cap on re-hydration retries per mutation fingerprint |
| `coverageGate.failPolicy` | enum (`"fail_open"` shown) | `"fail_open"` | Behavior when the gate itself errors |
| `questionResolution.searchCompleteStores` | boolean | `true` | Full-store search on `AskUserQuestion` interception |
| `questionResolution.cacheResolvedNeeds` | boolean | `true` | Current-task resolved-need cache |
| `questionResolution.minimumNormalizationConfidence` | number | `0.9` | Threshold below which keys are kept separate rather than merged |
| `questionResolution.requireExactOptionMapping` | boolean | `true` | Deterministic option mapping requirement |
| `stopRecovery.enabled` | boolean | `true` | Plain-text Stop detection/recovery |
| `stopRecovery.classification` | enum (`"conservative"` shown) | `"conservative"` | How aggressively plain-text stops are classified as questions |
| `stopRecovery.maximumRecoveriesPerDecisionKey` | number | `1` | Cap per decision key |
| `stopRecovery.maximumRecoveriesPerTurn` | number | `2` | Cap per turn |
| `stopRecovery.ignoreWhileBackgroundTasksActive` | boolean | `true` | Suppress Stop recovery while background tasks run |
| `subagents.enabled` | boolean | `true` | Subagent context handling |
| `subagents.scopeAgentPrompt` | boolean | `true` | Scope-limit the injected subagent prompt |
| `subagents.injectRepositoryHardPolicy` | boolean | `true` | Always give subagents repository hard policy |
| `subagents.shareTaskResolvedNeedCache` | boolean | `true` | Share the task resolved-need cache with subagents |
| `autonomy.enabled` | boolean | `false` | **OFF by default** — "Autonomous answer filling: disabled"; gates all auto-answering |
| `autonomy.maximumNewDecisionRisk` | `RiskLevel` | `"low"` | Ceiling for auto-answering a `choose_new` need |
| `autonomy.maximumEstablishedDecisionRisk` | `RiskLevel` | `"high"` | Ceiling for applying an established decision |
| `autonomy.allowEstablishedHighRiskApplication` | boolean | `true` | Whether high-risk established decisions may be applied at all |
| `autonomy.minimumConfidence` | number | `0.95` | Confidence floor for automatic action |
| `autonomy.requiredCalibrationSamples` | number | `50` | Shadow samples required before autonomy unlocks |
| `autonomy.requiredPrecision` | number | `0.98` | Measured precision required before autonomy unlocks |
| `autonomy.mandatoryHumanChangeCategories` | string[] | `["public_contract","database_schema","data_semantics","security","destructive_operation","compliance","production_infrastructure"]` | Categories that always require a human |
| `capture.recordAnswers` | boolean | `true` | Persist `QuestionOutcome` records |
| `capture.createCandidates` | boolean | `true` | Create candidate entries from answers |
| `capture.createTaskResolvedNeeds` | boolean | `true` | Create task-local `ResolvedNeed` from answers |
| `capture.autoActivateTaskChoices` | boolean | `true` | Auto-activate `task_choice` entries (task-scoped, expiring) |
| `capture.autoActivatePersonalPreferences` | boolean | `false` | **OFF by default** — personal preferences stay candidates |
| `failurePolicy.contextRetrieval` | enum (`"fail_open"`) | `"fail_open"` | Optional context retrieval failure behavior |
| `failurePolicy.hardPolicyEnforcement` | enum (`"fail_closed"`) | `"fail_closed"` | Hard-policy enforcement failure behavior — kept separate from optional retrieval |
| `failurePolicy.sessionStateWrite` | enum (`"disable_autonomy"`) | `"disable_autonomy"` | Behavior when external session state cannot be written |
| `failurePolicy.receiptWrite` | enum (`"disable_autonomy"`) | `"disable_autonomy"` | Behavior when a context receipt cannot be written |

Additional stated defaults not expressed as a single key (§21 "Defaults must be conservative"): "External session state: required for resolve mode"; "Hard-policy enforcement: separated from optional context retrieval"; "No remote network dependency required for normal local hook execution"; and §17.2's recommended ceilings (`maximum new-decision risk: low`, `maximum established-decision application risk: high`, critical established decisions enforced or escalated according to hard policy).

## Flags the spec requires to default off or non-enforcing

- `autonomy.enabled` = `false` — "Autonomous answer filling: disabled".
- `coverageGate.enforcement` = `"shadow"` — "Coverage gate enforcement: shadow-only until calibrated"; Phase 3 records coverage in non-enforcing mode only.
- `context.includeNoisyMemory` = `false` — "Noisy memory: excluded from normal manifests".
- `capture.autoActivatePersonalPreferences` = `false` — personal preferences may not auto-activate.
- `dynamicManifest.modelAssistedEntityExtraction` = `false` — model-assisted extraction is optional and hint-only.
- `sources.memoryKit.required` = `false` — Memory Kit is an optional, degradable source.
- `mode` = `"shadow"` — "Initial mode: `shadow`"; `resolve` (the only enforcing/auto-answering mode) is not a default.
- `failurePolicy.contextRetrieval` = `"fail_open"` and `coverageGate.failPolicy` = `"fail_open"` — failures never block work; only `failurePolicy.hardPolicyEnforcement` is `"fail_closed"`.
