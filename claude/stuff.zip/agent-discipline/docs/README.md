# Diagrams

Two diagrams, two questions. Neither replaces the other.

**`ai_agent_dev_workflow_v2`** — the workflow, from your point of view. What happens to a
ticket, and the four moments a human is actually needed. Contains no hook names or file paths
on purpose: a human-facing flow diagram that turns into a call graph stops being readable.

**`agent_discipline_mechanism`** — the mechanism. Which trigger fires which hook, what it
reads or writes, and what you get out. This is the one to read when something did not fire.

Both are generated. Layout lives in the `NODES` / `EDGES` lists at the top of each
`gen_*.py`; rendering is shared in `diagram_lib.py` so the `.svg` and the `.drawio` cannot
disagree. Edit the lists and re-run:

```sh
python3 gen_workflow.py       # -> ai_agent_dev_workflow_v2.{svg,drawio}
python3 gen_mechanism.py      # -> agent_discipline_mechanism.{svg,drawio}
```

Do not drag boxes in diagrams.net — the next regeneration overwrites it.

**One shared renderer is deliberate.** These files used to have two: the SVG routed edges
through a side gutter, the `.drawio` emitted no waypoints at all and let diagrams.net
auto-route, which drew every loop straight through the nodes of a lane. Same source, two
routers, one unreadable output.
