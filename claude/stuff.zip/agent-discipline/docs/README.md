# Diagrams

Two diagrams, two questions. Neither replaces the other.

**`ai_agent_dev_workflow_v2`** — the workflow, from your point of view. What happens to a
ticket, and the four moments a human is actually needed. Contains no hook names or file paths
on purpose: a human-facing flow diagram that turns into a call graph stops being readable.
Two pages, before then after: **Without the plugin** — the same ticket with the plugin's boxes
dropped or reworded — then **With agent-discipline**. The without page is derived from the
with page in the generator, so the two cannot drift. Flip the tabs in a meeting to show what
the plugin changes. The bare `.svg` is the with-plugin page.

**`agent_discipline_mechanism`** — the mechanism, as a four-page `.drawio` for team demos:

1. **Mechanism map** — which trigger fires which hook, what it reads or writes, what you get.
   The one to read when something did not fire. (`agent_discipline_mechanism.svg`)
2. **Orchestrator / worker** — one batch of tasks, actor by actor: you hand over, the main
   session dispatches, each worktree's Claude implements, its DoD teammates verify, the
   orchestrator approves, GitLab merges, the watcher reaps. (`…-orchestrator-worker.svg`)
3. **Roles without the plugin** — one model does everything; what the plugin owns falls back
   on you, or on nobody. (`…-roles-without-the-plugin.svg`)
4. **Roles with the plugin** — who runs which model at which effort, what each owns, what each
   never does. (`…-roles.svg`)

Open the `.drawio` in diagrams.net and use the page tabs at the bottom. The SVGs are the same
pages for READMEs and slides.

Both are generated. Layout lives in the `NODES` / `EDGES` lists at the top of each
`gen_*.py`; rendering is shared in `diagram_lib.py` so the `.svg` and the `.drawio` cannot
disagree. Edit the lists and re-run:

```sh
python3 gen_workflow.py       # -> ai_agent_dev_workflow_v2.{svg,drawio}
python3 gen_mechanism.py      # -> agent_discipline_mechanism.drawio (4 pages) + one .svg per page
```

Do not drag boxes in diagrams.net — the next regeneration overwrites it. This directory is the
source of truth; a copy for presenting lives at `~/Downloads/diagram/` and is refreshed with
`cp docs/*.drawio docs/*.svg ~/Downloads/diagram/` after regenerating.

**One shared renderer is deliberate.** These files used to have two: the SVG routed edges
through a side gutter, the `.drawio` emitted no waypoints at all and let diagrams.net
auto-route, which drew every loop straight through the nodes of a lane. Same source, two
routers, one unreadable output.
