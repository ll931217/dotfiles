---
title: Ledger Context Governor
subtitle: Technical Design and Implementation Specification for Claude Code
status: Draft implementation contract
version: 0.2.0
date: 2026-09-03
audience:
  - Claude Code
  - Ledger plugin maintainers
  - Memory Kit maintainers
  - Canon maintainers
code_refs:
  - ledger/*.py
---

# Ledger Context Governor

## Technical Design and Implementation Specification

> **Implementation directive for Claude Code**
>
> Use this document as the implementation contract for upgrading the existing Ledger plugin. Treat the repository's current architecture, runtime, persistence layer, naming, tests, and public APIs as constraints. Inspect them before editing. Extend existing components rather than creating parallel replacements. Do not perform a greenfield rewrite unless the existing implementation is demonstrably incompatible and the migration is documented.
>
> Do not stop after producing a plan. Perform the repository audit, write the gap analysis, implement the highest-priority compatible phases, add tests, run validation, and report any requirements that could not be completed. Resolve low-risk implementation details from the codebase, Canon, Memory Kit, and this specification before asking the user.

---

## Document revision summary

Version `0.2.0` replaces the static-manifest assumption from version `0.1.0`.

The major changes are:

1. The Task Context Manifest is now a **revisioned, session-scoped materialized view**. The pre-implementation manifest is only revision `M0`.
2. Ledger must continuously discover newly relevant scopes and inject compact manifest deltas.
3. A **context coverage gate** checks newly encountered mutation targets before consequential edits or commands proceed.
4. `AskUserQuestion` becomes a last-chance resolver query against the complete Memory Kit, Canon, Ledger, current-task answer cache, and resolved-need cache—not merely the current manifest.
5. A conservative `Stop` recovery path resolves plain-text blocking clarification requests that bypass `AskUserQuestion`.
6. Context state must survive resume, clear, fork, and context compaction.
7. Subagents receive scoped context through the `Agent` tool input and `SubagentStart`.
8. The autonomy model now distinguishes **applying an established decision** from **making a new decision**. An existing approved high-risk invariant may be applied; changing or inventing high-risk semantics still requires a human.

The governing runtime invariant is:

> **No consequential mutation or user clarification should proceed until Ledger has had a final opportunity to resolve the newly relevant scope or decision need.**

---

## 1. Executive summary

Ledger should become the **context-governance and decision-resolution layer** that sits above Memory Kit and Canon.

The responsibilities of the three systems are distinct:

```text
Memory Kit  = what the organization believes is true about its systems
Canon       = what developers and coding agents are required or expected to do
Ledger      = what was decided, preferred, assumed, excepted, or learned
Resolver    = what applies to the current task and what the agent may do with it
```

The existing problem is not merely that Claude Code lacks memory. The problem is that available knowledge is not consistently:

- Retrieved at the moment it becomes relevant.
- Classified by meaning and authority.
- Scoped to the correct organization, team, repository, service, module, path, symbol, task, or user.
- Reconciled with contradictory or stale information.
- Converted into an explicit autonomy boundary.
- Made explainable after implementation decisions are taken.

Ledger must therefore provide an **active context compiler** rather than another undifferentiated memory store. For every task, it should combine relevant information from Memory Kit, Canon, and Ledger into an initial bounded **Task Context Manifest**, designated `M0`. That manifest is not final. It must be maintained as a revisioned session view and expanded through compact deltas whenever implementation reveals new paths, symbols, services, datasets, dependencies, failures, or decision needs.

The runtime must provide overlapping recovery checkpoints: proactive discovery after tools, a context-coverage gate before uncovered consequential mutations, full-store resolution before `AskUserQuestion`, and a conservative Stop fallback for plain-text blocking questions. Each manifest transition and autonomous resolution must retain a **Context Receipt** explaining exactly which facts, rules, decisions, preferences, assumptions, exceptions, and sources were applied or rejected.

During the initial rollout Ledger should operate in **shadow mode**, predicting questions and coverage decisions without suppressing or blocking them. After sufficient calibration, it may apply exact established decisions at the configured risk ceiling and may make only low-risk reversible choices backed by active authoritative entries. Creating or changing consequential behavior still requires a human.

The product principle is:

> **Do not eliminate questions. Eliminate questions whose answers the organization has already established.**

---

## 2. Required repository-first workflow

Before changing code, Claude Code must inspect the current Ledger repository and record its findings in:

```text
docs/ledger-context-governor-gap-analysis.md
```

The gap analysis must identify:

1. The runtime, language, package manager, build system, and test framework.
2. The current Claude Code plugin structure and manifest.
3. Existing hook registrations and hook entry points.
4. Existing data models, persistence layer, migrations, repositories, and services.
5. Existing interfaces to Memory Kit and Canon.
6. Existing ledger entry types, scopes, precedence behavior, approval workflow, and audit behavior.
7. Existing CLI commands, skills, MCP tools, HTTP endpoints, or UI surfaces.
8. Existing observability, logging, metrics, tracing, and error handling.
9. Existing compatibility promises and public APIs.
10. A requirement-by-requirement matrix with one of:
    - `implemented`
    - `partially implemented`
    - `missing`
    - `incompatible`
    - `intentionally deferred`

Implementation rules:

- Preserve existing naming and module boundaries where practical.
- Reuse the current database and migration mechanism.
- Reuse the current configuration system.
- Reuse existing Memory Kit and Canon contracts rather than importing their internals.
- Add adapters around incompatible existing components before replacing them.
- Keep migrations idempotent and backward-compatible wherever practical.
- Protect new autonomous behavior behind feature flags.
- Do not silently reinterpret existing ledger records. Migrate them explicitly or retain a compatibility projection.
- Add characterization tests before altering unclear existing behavior.

When the repository differs from examples in this document, preserve the intent and adapt the implementation shape.

---

## 3. Problem statement

Claude Code can receive project instructions, repository context, hook output, and previous decisions yet still ask repetitive questions or make inconsistent choices. The failure normally occurs because one or more of the following is missing:

- **Applicability:** the agent cannot tell whether an item applies to this task.
- **Authority:** the agent cannot tell whether an item is mandatory, approved, advisory, or inferred.
- **Precedence:** the agent cannot reconcile two relevant but conflicting items.
- **Freshness:** the agent cannot tell whether an item still reflects the current branch or system.
- **Provenance:** the agent cannot inspect the evidence behind a statement.
- **Autonomy:** the agent cannot tell whether it may act without human confirmation.
- **Timing:** the relevant context is loaded too early, too late, or in excessive volume.
- **Accountability:** maintainers cannot reconstruct why the agent made a decision.

A generic semantic-memory lookup does not solve these problems. A high-similarity result must never be allowed to outrank a more authoritative rule merely because its embedding score is higher.

Ledger must make resolution deterministic where possible and explicitly uncertain where it is not.

---

## 4. Goals

### 4.1 Primary goals

Ledger must:

1. Query Memory Kit, Canon, and Ledger through stable source adapters.
2. Represent different knowledge types explicitly rather than storing everything as a preference.
3. Support multi-dimensional scope and deterministic authority precedence.
4. Track provenance, evidence, freshness, supersession, expiry, conflicts, and invalidation conditions.
5. Compile an initial task-specific context manifest, designated `M0`.
6. Maintain that manifest as a live, revisioned materialized view for the complete session.
7. Detect newly relevant paths, symbols, services, datasets, tables, endpoints, dependencies, and business concepts during implementation.
8. Emit compact manifest deltas rather than repeatedly injecting the entire manifest.
9. Maintain a scope frontier and explicit context-coverage records.
10. Gate consequential mutations whose target scope has not yet been resolved.
11. Search the complete backing stores before presenting an implementation clarification to the user.
12. Normalize semantically equivalent clarification requests into stable decision keys.
13. Cache task-local and previously resolved answers so the same question is not shown again.
14. Rehydrate current context after resume, clear, fork, and compaction.
15. Supply subagents with context restricted to their assigned work.
16. Record a context receipt for every manifest revision, delta, coverage resolution, and autonomous answer.
17. Predict answers to clarification questions in shadow mode.
18. Capture human answers as evidence and candidate ledger entries.
19. Autonomously apply established decisions only when authority, freshness, scope, conflict, and risk rules permit.
20. Keep genuinely new, consequential, stale, or conflicted decisions visible to humans.
21. Verify final implementation against applicable rules and decisions.
22. Remain usable if Memory Kit or non-critical Ledger retrieval is unavailable.

### 4.2 Secondary goals

Ledger should:

- Remain independent of Claude Code internally so other agents can reuse the resolver.
- Provide a human-readable explanation for every applied, rejected, invalidated, or deferred item.
- Support local-first operation for fast hook execution.
- Support future centralized or multi-user deployments without redesigning the domain model.
- Measure whether fewer questions lead to better outcomes rather than merely fewer interruptions.
- Permit exact, deterministic retrieval before semantic fallback.
- Make missed proactive discovery recoverable through mutation, question, and Stop checkpoints.

---

## 5. Non-goals

The initial implementation must not attempt to:

- Replace Memory Kit.
- Replace Canon.
- Store general conversation history without a decision-governance purpose.
- Automatically convert every user answer into permanent team policy.
- Let semantic similarity override authority or scope.
- Make autonomous decisions about security, authorization, compliance, destructive operations, financial meaning, or public contracts.
- Introduce a knowledge graph before structured resolution proves insufficient.
- Introduce a vector database merely because retrieval is involved.
- Rewrite Claude Code permissions or organization-managed settings.
- Copy credentials, tokens, secrets, production values, or customer data into Ledger.
- Treat generated summaries as authoritative evidence for themselves.

---

## 6. Domain terminology

### Memory Kit

A source of system knowledge, including architecture, system behavior, data lineage, derivation rules, raw-data meaning, operational constraints, and supporting evidence.

Memory Kit entries primarily become normalized candidates of kind `fact`, `invariant`, `heuristic`, `constraint`, or `assumption`. They do not become policy merely because they are retrieved from memory.

### Canon

A source of coding and engineering rules. Canon may contain mandatory rules, preferred conventions, exceptions, validation logic, and remediation guidance.

Canon remains the owner of deterministic rule enforcement. Ledger consumes Canon applicability and results; it must not create a second independent rule engine that can disagree with Canon.

### Ledger

An append-only history and curated active view of decisions, preferences, assumptions, exceptions, evidence, approvals, supersessions, and outcomes.

### Context Resolver

A runtime service or library that determines what knowledge applies to the current task, scope, operation, and decision need; how conflicting items should be handled; and whether the agent may proceed without a human.

### Task Context Manifest

A bounded, human-readable and machine-readable **revisioned materialized view** for a specific task, session, repository state, actor, and working scope.

The manifest generated before implementation is revision `M0`. It is intentionally incomplete. Later discoveries produce `M1`, `M2`, and subsequent revisions.

### Manifest delta

The minimal difference between two manifest revisions. A delta contains only newly added, removed, invalidated, superseded, or conflicting items, plus changed autonomy boundaries and coverage.

### Scope frontier

The set of repository and domain scopes the session has discovered so far, including paths, symbols, modules, services, datasets, tables, endpoints, message topics, dependencies, and business concepts.

### Context coverage

A record proving that Ledger resolved applicable context for a scope and operation against a specific repository and source snapshot.

Coverage does not mean that the area has no rules. It means the relevant sources were queried and the applicable result was recorded.

### Decision need

A normalized representation of an uncertainty the agent must resolve before proceeding. It captures the decision type, subject, operation, scope, constraints, proposed options, and risk.

### Decision key

A stable identifier derived from a normalized decision need. Semantically equivalent questions should resolve to the same decision key.

### Resolved need

A decision need whose answer has been established for the current task or by an active authoritative entry. It includes the resolution, supporting IDs, authority, scope, manifest revision, and resolution mode.

### Context Receipt

An immutable record of resolution inputs, selected items, rejected items, conflicts, stale entries, manifest transition, autonomy decision, and resolver version.

Receipts form a chain across manifest revisions.

### Evidence

A source-backed observation supporting or contradicting a ledger entry. Evidence may come from code, documentation, schemas, ADRs, tests, user answers, accepted reviews, merged changes, reversions, incidents, or approved external systems.

### Candidate

A proposed ledger entry that has not yet received the authority required for its requested scope.

### Active entry

A ledger entry that is approved or otherwise valid for its scope, has not expired, has not been superseded, and is not invalidated by newer evidence.

### Noisy memory

Low-authority observations and agent inferences that remain available as evidence but cannot independently drive autonomous decisions.

### Established-decision application

Execution of an existing active decision, policy, invariant, or exact task answer without altering its meaning.

### New-decision selection

Choosing, inventing, or changing behavior where no active authoritative answer already exists. This has a stricter autonomy ceiling than established-decision application.

---

## 7. Governing invariants

These invariants are mandatory:

1. **Facts, policies, preferences, assumptions, and exceptions are different types.**
2. **No entry is active without a scope, authority, lifecycle status, and provenance record.**
3. **No autonomous decision is made from agent inference alone.**
4. **No vector or text relevance score can cross an authority boundary.**
5. **Narrower scope cannot weaken a higher-authority hard policy.**
6. **A personal preference cannot override team or organization policy.**
7. **Observed legacy code cannot overrule an approved current rule.**
8. **A stale fact cannot be presented as current without an explicit warning.**
9. **Every autonomous resolution produces a context receipt.**
10. **Every durable promotion records who or what granted its authority.**
11. **Team-wide or organization-wide policy cannot be learned automatically from a single answer.**
12. **Authorization is enforced before retrieval and ranking.**
13. **The raw evidence/event history is append-only.**
14. **Derived summaries cannot cite themselves or other derived summaries as primary evidence.**
15. **Hard enforcement and advisory context use separate failure policies.**
16. **The resolver core must not depend on Claude Code hook payload types.**
17. **Autonomy and tool permission are separate decisions.** Ledger may know the preferred action while Claude Code permissions still require user approval.
18. **The initial manifest is incomplete by design.** `M0` is a starting view, not a complete task specification.
19. **The active manifest must exist outside the model context.** Model-visible context is a projection of session state, not the source of truth.
20. **Every material context change increments the manifest revision and writes a receipt.**
21. **Only deltas should be injected during normal implementation.** The complete manifest is re-injected only during explicit rehydration or diagnosis.
22. **Newly discovered scopes must be resolved before consequential mutation when the coverage gate is enforced.**
23. **Before any user-facing implementation clarification, the resolver must query the complete authorized backing stores and current-task caches.**
24. **Semantically equivalent questions must converge on the same decision key.**
25. **A question already answered for the current task must not be shown again unless its scope, evidence, or constraints materially changed.**
26. **Plain-text blocking clarification is a recoverable path.** The Stop hook must get one conservative opportunity to resolve it.
27. **Subagents receive only the context applicable to their assigned work, plus repository-wide hard policy.**
28. **Applying an established decision is not the same as making a new decision.** The resolver may enforce an existing approved invariant at a higher risk level than it may invent a new choice.
29. **A manifest refresh must be idempotent for the same normalized trigger and source snapshot.**
30. **Coverage records must be invalidated when relevant repository state, source versions, scope, or operation changes.**
31. **A hook must never loop indefinitely.** Mutation retries and Stop recoveries require bounded fingerprints and attempt counters.

---

## 8. Knowledge and decision types

Ledger must support at least the following entry kinds.

| Kind | Meaning | Example | Default treatment |
|---|---|---|---|
| `fact` | A statement believed to describe the current system | “Position timestamps are exchange-local at ingestion.” | Must have evidence and freshness |
| `invariant` | A property that must remain true for correctness | “Trade date follows the exchange calendar.” | High consequence; normally not auto-modified |
| `policy` | A required or governed behavior | “HTTP handlers may not query the database directly.” | Canon or approved policy authority |
| `decision` | A selected approach among alternatives | “This API uses cursor pagination.” | Active when approved and in scope |
| `preference` | A default choice that can be overridden by stronger information | “Prefer Effect Schema for new TypeScript validation.” | Advisory or default |
| `heuristic` | A useful but non-guaranteed rule of thumb | “Batch sizes near 500 usually perform well.” | Confidence-based and advisory |
| `assumption` | A temporary belief used to proceed with a task | “Stable ordering is not required for this internal report.” | Task-scoped and expiring |
| `exception` | A narrow, explicit departure from a rule | “The legacy reconciliation endpoint may bypass this rule until migration.” | Requires exact scope and expiry/review |
| `negative_preference` | A choice that should not be repeatedly proposed | “Do not introduce class-based React components.” | Prevents rediscovery of rejected options |
| `constraint` | A technical or operational boundary | “The deployment VM has no GPU.” | Treated as factual boundary |

Do not collapse these into a single `preference` table with optional metadata. The kind must be first-class and validated.

---

## 9. Scope model

Scope must be multi-dimensional. A single path string is insufficient.

Supported scope dimensions:

```text
organization
team
repository
service
module
path
symbol
task
branch
actor/user
environment
time window
```

A ledger entry may contain several dimensions simultaneously, for example:

```json
{
  "organization": "vici",
  "team": "data",
  "repository": "rom",
  "service": "position-api",
  "path": "src/export/**",
  "environment": ["development", "staging"]
}
```

### 9.1 Scope matching rules

- Missing dimensions mean “not constrained by this dimension,” not “global authority.”
- A candidate must match every scope dimension that it declares.
- Task-specific entries normally expire when the task closes.
- Branch-specific facts must not leak into unrelated branches.
- Symbol and path matches should use canonical repository-relative identifiers.
- Repository identity should use a stable repository ID when available, not only the local directory name.
- User scope is evaluated separately from organizational authority. A user-scoped preference cannot override organization or team policy.
- Environment-scoped entries must never be applied to another environment by semantic similarity.

### 9.2 Scope specificity

Within the same authority class and compatible entry kind, use the following general specificity order:

```text
task
symbol
path
module
service
repository
team
organization
unscoped
```

Branch, environment, and actor scope act as eligibility filters before this comparison.

---

## 10. Authority model

Use an explicit authority enum. Do not derive authority solely from source name.

Recommended authority classes, highest first:

```text
hard_policy
current_task_instruction
approved_architectural_decision
approved_team_decision
approved_repository_decision
explicit_human_preference
reviewed_human_observation
code_or_schema_observation
repeated_agent_observation
agent_inference
generated_summary
```

### 10.1 Interpretation

- `hard_policy` includes organization security, legal, compliance, and Canon rules marked mandatory.
- `current_task_instruction` applies only to the active task and cannot override `hard_policy`.
- Approved decisions require an approval record appropriate to their scope.
- `explicit_human_preference` is normally actor- or task-scoped unless the user explicitly requests broader scope and has authority to do so.
- `code_or_schema_observation` may be strong evidence for a fact but does not become policy.
- `agent_inference` and `generated_summary` are never sufficient for autonomous resolution.

### 10.2 Kind-specific precedence

A single global score is forbidden. Use kind-specific conflict handling.

#### Policy conflicts

Resolve by:

1. Hard-policy authority.
2. Explicit approved exception with permission to exempt that rule.
3. Approval scope.
4. Scope specificity.
5. Explicit supersession.
6. Effective date.

Legacy code never overrides policy.

#### Fact conflicts

Resolve by:

1. Direct current source evidence, such as a schema or implementation at the active commit.
2. Source validation against the active branch/commit.
3. Explicit supersession.
4. Freshness and invalidation conditions.
5. Source reliability.
6. Scope specificity.

When two authoritative current sources disagree, expose a conflict. Do not guess.

#### Decision conflicts

Resolve by:

1. Required approval level.
2. Scope match and specificity.
3. Explicit supersession chain.
4. Effective date.
5. Status.

#### Preference conflicts

Resolve by:

1. Applicable policy or approved decision.
2. Team preference over personal preference for team-owned code.
3. Task-specific explicit instruction over general preference.
4. Scope specificity.
5. Recency.

#### Heuristic and assumption conflicts

Use them only when no stronger fact, policy, decision, or preference answers the question. Conflicts reduce confidence and normally prevent autonomous resolution.

---

## 11. Lifecycle model

Every ledger entry must have a lifecycle status:

```text
observed
candidate
approved
active
deprecated
superseded
rejected
expired
invalidated
quarantined
```

Recommended transition rules:

```text
observed -> candidate
candidate -> approved -> active
candidate -> rejected
active -> superseded
active -> deprecated
active -> expired
active -> invalidated
any unsafe/malformed entry -> quarantined
```

Required lifecycle fields:

- `created_at`
- `effective_from`
- `expires_at`, when applicable
- `last_validated_at`
- `last_validated_revision`
- `supersedes`
- `superseded_by`
- `invalidation_conditions`
- `review_after`
- `approved_by`
- `approved_at`

Task-local assumptions should receive a default expiry tied to task completion or a short configured duration.

---

## 12. Logical data model

Adapt these logical structures to the existing persistence layer. Do not force these exact table names if the repository already has equivalents.

### 12.1 Core entry

```ts
export type LedgerEntryKind =
  | "fact"
  | "invariant"
  | "policy"
  | "decision"
  | "preference"
  | "heuristic"
  | "assumption"
  | "exception"
  | "negative_preference"
  | "constraint";

export type LedgerAuthority =
  | "hard_policy"
  | "current_task_instruction"
  | "approved_architectural_decision"
  | "approved_team_decision"
  | "approved_repository_decision"
  | "explicit_human_preference"
  | "reviewed_human_observation"
  | "code_or_schema_observation"
  | "repeated_agent_observation"
  | "agent_inference"
  | "generated_summary";

export type LedgerStatus =
  | "observed"
  | "candidate"
  | "approved"
  | "active"
  | "deprecated"
  | "superseded"
  | "rejected"
  | "expired"
  | "invalidated"
  | "quarantined";

export type AutonomyLevel =
  | "mandatory"
  | "default"
  | "advisory"
  | "ask_before_applying"
  | "never_auto_apply";

export interface LedgerScope {
  organization?: string;
  team?: string;
  repository?: string;
  service?: string;
  module?: string;
  paths?: string[];
  symbols?: string[];
  taskIds?: string[];
  branches?: string[];
  actorIds?: string[];
  environments?: string[];
  validFrom?: string;
  validUntil?: string;
}

export interface LedgerEntry {
  id: string;
  version: number;
  kind: LedgerEntryKind;
  subject: string;
  statement: string;
  rationale?: string;
  scope: LedgerScope;
  retrieval?: RetrievalMetadata;
  authority: LedgerAuthority;
  status: LedgerStatus;
  autonomy: AutonomyLevel;
  risk: RiskLevel;
  confidence?: number;
  sourceReferences: SourceReference[];
  evidenceIds: string[];
  conflictKey?: string;
  supersedes?: string[];
  conflictsWith?: string[];
  rejectedAlternatives?: RejectedAlternative[];
  invalidationConditions?: string[];
  createdBy: ActorReference;
  createdAt: string;
  effectiveFrom?: string;
  expiresAt?: string;
  lastValidatedAt?: string;
  lastValidatedRevision?: string;
  approvedBy?: ActorReference[];
  approvedAt?: string;
  metadata?: Record<string, unknown>;
}
```

### 12.2 Evidence

```ts
export type EvidenceType =
  | "source_code"
  | "schema"
  | "test"
  | "documentation"
  | "adr"
  | "user_answer"
  | "review_comment"
  | "merged_change"
  | "reverted_change"
  | "incident"
  | "canon_rule"
  | "memory_kit_record"
  | "external_system"
  | "agent_observation";

export interface EvidenceRecord {
  id: string;
  type: EvidenceType;
  polarity: "supports" | "contradicts" | "neutral";
  statement: string;
  source: SourceReference;
  observedAt: string;
  observedBy: ActorReference;
  repositoryRevision?: string;
  contentHash?: string;
  reliability: number;
  metadata?: Record<string, unknown>;
}
```

### 12.3 Source reference

```ts
export interface SourceReference {
  sourceSystem: "memory-kit" | "canon" | "ledger" | "repository" | "user" | string;
  sourceId: string;
  sourceVersion?: string;
  repository?: string;
  revision?: string;
  path?: string;
  symbol?: string;
  uri?: string;
  contentHash?: string;
  capturedAt?: string;
}
```

### 12.4 Append-only event

```ts
export interface LedgerEvent {
  id: string;
  entryId: string;
  sequence: number;
  eventType:
    | "created"
    | "evidence_added"
    | "promoted"
    | "approved"
    | "activated"
    | "rejected"
    | "superseded"
    | "deprecated"
    | "expired"
    | "invalidated"
    | "scope_changed"
    | "authority_changed"
    | "outcome_recorded";
  payload: Record<string, unknown>;
  actor: ActorReference;
  createdAt: string;
  previousEventHash?: string;
  eventHash: string;
}
```

The event hash chain is recommended for high-authority records. If it is not implemented in the MVP, preserve fields and interfaces so it can be added later.

### 12.5 Active projection

The resolver should query a materialized active projection rather than replaying the entire event history in a hook.

The projection must include:

- Current entry version.
- Current lifecycle status.
- Effective scope.
- Effective authority.
- Latest validation metadata.
- Supersession state.
- Evidence summary.
- Searchable subject and statement fields.

Projection updates must be transactional with event writes or safely rebuildable.



### 12.6 Retrieval metadata

Each source adapter should expose structured retrieval metadata. The fields may be generated from scope and source evidence when older entries do not contain them.

```ts
export interface RetrievalMetadata {
  repositories?: string[];
  services?: string[];
  modules?: string[];
  pathGlobs?: string[];
  symbols?: string[];

  endpoints?: string[];
  datasets?: string[];
  tables?: string[];
  messageTopics?: string[];
  dependencies?: string[];

  concepts?: string[];
  operations?: string[];

  decisionKeys?: string[];
  triggerTerms?: string[];
  appliesWhen?: ApplicabilityPredicate[];
}

export interface ApplicabilityPredicate {
  field: string;
  operator:
    | "equals"
    | "not_equals"
    | "contains"
    | "matches"
    | "in"
    | "exists";
  value?: unknown;
}
```

Recommended exact retrieval order:

```text
1. Exact decision key
2. Current task answer
3. Repository, service, module, path, and symbol
4. Endpoint, dataset, table, message topic, or dependency
5. Business concept and operation
6. Relationship traversal supplied by Memory Kit
7. Semantic fallback
8. Recent noisy observations for advisory use only
```

Semantic retrieval may discover candidates but must not determine authority.

---

## 13. Source adapter contracts

The resolver core must consume normalized candidates through adapters.

```ts
export interface KnowledgeSourceAdapter {
  readonly id: string;
  readonly sourceSystem: string;

  query(request: SourceQuery): Promise<KnowledgeCandidate[]>;
  getById(id: string): Promise<KnowledgeCandidate | null>;
  validateReference(reference: SourceReference, context: ValidationContext): Promise<ValidationResult>;
  health(): Promise<SourceHealth>;
}
```

```ts
export interface KnowledgeCandidate {
  sourceSystem: string;
  sourceId: string;
  kind: LedgerEntryKind;
  subject: string;
  statement: string;
  rationale?: string;
  scope: LedgerScope;
  retrieval?: RetrievalMetadata;
  authority: LedgerAuthority;
  autonomy: AutonomyLevel;
  risk: RiskLevel;
  status: LedgerStatus;
  confidence?: number;
  evidence: EvidenceRecord[];
  sourceReferences: SourceReference[];
  conflictKey?: string;
  supersedes?: string[];
  invalidationConditions?: string[];
  effectiveFrom?: string;
  expiresAt?: string;
  lastValidatedAt?: string;
  lastValidatedRevision?: string;
  metadata?: Record<string, unknown>;
}
```

### 13.1 Memory Kit adapter

The Memory Kit adapter must:

- Query by decision key, repository, service, module, path, symbol, endpoint, dataset, table, dependency, task terms, operation, and data concepts.
- Preserve Memory Kit record IDs and versions.
- Preserve citations to code, schemas, documentation, or source data.
- Map Memory Kit content to `fact`, `invariant`, `constraint`, `heuristic`, or `assumption`.
- Mark generated summaries as `generated_summary` unless backed by stronger primary evidence.
- Expose staleness and validation metadata.
- Avoid copying the entire Memory Kit record into Ledger unless a snapshot is necessary for audit.

### 13.2 Canon adapter

The Canon adapter must:

- Query rules by repository, path, language, framework, operation, and task.
- Preserve Canon rule IDs, severity, rationale, remediation, exceptions, and enforcement level.
- Map mandatory rules to `policy` or `invariant` with `hard_policy` authority where appropriate.
- Map conventions to `preference` or non-hard `policy` as defined by Canon.
- Delegate deterministic compliance checks to Canon rather than reimplementing them.
- Never permit Ledger preferences to override mandatory Canon rules.

### 13.3 Ledger adapter

The Ledger adapter must:

- Query the active projection by exact decision key and structured scope before semantic fallback.
- Return only entries the current actor is authorized to read.
- Include candidate/noisy-memory entries only when explicitly requested for advisory use.
- Preserve approval, supersession, expiry, and conflict metadata.
- Support exact lookup for receipts and explanations.

### 13.4 Integration boundary

Do not import files from another plugin's installation directory. Prefer, in order:

1. Existing stable library/package contract.
2. Existing local CLI or Unix-socket contract.
3. Existing HTTP or MCP contract.
4. A newly defined narrow adapter API.

Direct access to another plugin's internal database is a last resort and must be isolated behind an adapter.

---

## 14. Resolver input, manifest state, and output

### 14.1 Resolution trigger

```ts
export type ResolutionTrigger =
  | "initial_prompt"
  | "scope_discovered"
  | "tool_batch_completed"
  | "tool_failed"
  | "mutation_coverage_check"
  | "question_intercepted"
  | "plain_text_question"
  | "subagent_spawn"
  | "session_resume"
  | "session_clear"
  | "session_fork"
  | "session_compact"
  | "source_invalidated"
  | "manual_refresh";
```

### 14.2 Resolution request

```ts
export interface ResolutionRequest {
  requestId: string;
  trigger: ResolutionTrigger;

  actor: ActorReference;
  repository: RepositoryContext;
  session: SessionContext;
  task: TaskContext;
  operation?: OperationContext;

  currentManifestRevision?: number;
  paths?: string[];
  symbols?: string[];
  discoveredEntities?: EntityReference[];
  mutationTargets?: MutationTarget[];
  decisionNeed?: DecisionNeed;

  prompt?: string;
  branch?: string;
  revision?: string;
  workspaceRevision?: number;
  environment?: string;

  tokenBudget?: number;
  characterBudget?: number;
  includeNoisyMemory?: boolean;
}
```

### 14.3 Scope and entity references

```ts
export type ScopeDimension =
  | "organization"
  | "team"
  | "repository"
  | "service"
  | "module"
  | "path"
  | "symbol"
  | "task"
  | "branch"
  | "actor"
  | "environment"
  | "endpoint"
  | "dataset"
  | "table"
  | "message_topic"
  | "dependency"
  | "concept";

export interface ScopeReference {
  type: ScopeDimension;
  value: string;
  qualifiers?: Record<string, string>;
}

export interface EntityReference {
  type:
    | "path"
    | "symbol"
    | "module"
    | "service"
    | "endpoint"
    | "dataset"
    | "table"
    | "message_topic"
    | "dependency"
    | "concept"
    | "error"
    | "test"
    | "external_system";
  canonicalId: string;
  observedValue: string;
  sourceToolUseId?: string;
  sourcePath?: string;
  confidence: number;
}
```

### 14.4 Revisioned Task Context Manifest

```ts
export interface TaskContextManifest {
  manifestId: string;
  revision: number;
  parentManifestId?: string;
  receiptId: string;

  generatedAt: string;
  resolverVersion: string;
  trigger: ResolutionTrigger;
  requestSummary: string;

  repository: RepositoryContext;
  task: TaskContext;

  scopeFrontier: ScopeReference[];
  coverage: ContextCoverage[];

  applicablePolicies: ManifestItem[];
  systemFacts: ManifestItem[];
  activeDecisions: ManifestItem[];
  preferences: ManifestItem[];
  assumptions: ManifestItem[];
  exceptions: ManifestItem[];

  resolvedNeeds: ResolvedNeedSummary[];
  conflicts: ManifestConflict[];
  staleItems: ManifestItem[];

  autonomyBoundary: AutonomyBoundary;
  degradedSources: SourceHealth[];
}
```

The manifest is the materialized active view. It is not reconstructed by reading Claude's transcript.

### 14.5 Manifest delta

```ts
export interface ManifestDelta {
  deltaId: string;
  sessionId: string;
  fromRevision: number;
  toRevision: number;
  trigger: ResolutionTrigger;
  generatedAt: string;

  discoveredScopes: ScopeReference[];
  added: ManifestItem[];
  removed: ManifestItemReference[];
  invalidated: ManifestItemReference[];
  superseded: ManifestItemReference[];
  conflictsAdded: ManifestConflict[];
  conflictsResolved: ManifestConflictReference[];

  coverageAdded: ContextCoverage[];
  coverageInvalidated: ContextCoverageReference[];

  resolvedNeedsAdded: ResolvedNeedSummary[];
  assumptionsInvalidated: ManifestItemReference[];
  autonomyBoundaryChanged?: AutonomyBoundary;

  receiptId: string;
  noOp: boolean;
}
```

A no-op refresh may update internal observation state without incrementing the visible revision. A material change must increment it.

Supporting reference types may reuse existing repository equivalents:

```ts
export interface ManifestItemReference {
  id: string;
  sourceSystem: string;
  reason?: string;
}

export interface ManifestConflictReference {
  id: string;
}

export interface ContextCoverageReference {
  id: string;
}

export interface ResolvedNeedSummary {
  id: string;
  decisionKey: string;
  resolution: string;
  sourceEntryIds: string[];
}

export interface AssumptionReference {
  id: string;
}

export interface CoverageDecision {
  status: ContextCoverage["status"];
  targetScopes: ScopeReference[];
  relevantEntryIds: string[];
  reason: string;
}
```

### 14.6 Context receipt

```ts
export interface ContextReceipt {
  id: string;
  previousReceiptId?: string;

  requestId: string;
  trigger: ResolutionTrigger;
  manifestId?: string;
  manifestRevision?: number;
  deltaId?: string;

  resolverVersion: string;
  resolverConfigHash: string;
  repositoryRevision?: string;
  workspaceRevision?: number;
  sourceSnapshotHash: string;

  actor: ActorReference;
  createdAt: string;

  sourceQueries: SourceQueryReceipt[];
  considered: ReceiptCandidate[];
  selected: ReceiptCandidate[];
  rejected: ReceiptCandidate[];
  conflicts: ManifestConflict[];
  stale: ReceiptCandidate[];

  coverageDecision?: CoverageDecision;
  autonomyDecision?: AutonomyDecision;
  decisionNeed?: DecisionNeed;
  resolvedNeedId?: string;

  outputHash: string;
}
```

Receipts must store identifiers, reasons, hashes, and concise snapshots. Avoid copying large sensitive source contents into receipts.

### 14.7 External session state

```ts
export interface SessionContextState {
  sessionId: string;
  taskId?: string;

  repository: RepositoryContext;
  branch?: string;
  baseRevision?: string;
  workspaceRevision: number;

  manifest: TaskContextManifest;
  receiptChain: string[];

  scopeFrontier: ScopeReference[];
  observedEntities: EntityReference[];
  coverage: ContextCoverage[];

  activeEntryIds: string[];
  staleEntryIds: string[];
  conflicts: ManifestConflict[];

  resolvedNeeds: Record<string, ResolvedNeed>;
  pendingAssumptions: AssumptionReference[];

  mutationAttempts: Record<string, MutationAttemptState>;
  stopRecoveries: Record<string, StopRecoveryState>;

  sourceSnapshotHash: string;
  createdAt: string;
  updatedAt: string;
}
```

The active state must be persisted outside model context using the existing Ledger store or a session-state store with transactional updates and per-session locking.

```ts
export interface StopRecoveryState {
  decisionKey: string;
  attempts: number;
  lastManifestRevision: number;
  lastSourceSnapshotHash: string;
  updatedAt: string;
}
```

### 14.8 Context coverage

```ts
export type OperationKind =
  | "read"
  | "search"
  | "edit"
  | "create"
  | "delete"
  | "execute"
  | "migrate"
  | "deploy"
  | "query"
  | "serialize"
  | "unknown";

export interface ContextCoverage {
  id: string;
  scope: ScopeReference[];
  operationKinds: OperationKind[];

  manifestRevision: number;
  sourceSnapshotHash: string;
  repositoryRevision?: string;
  workspaceRevision: number;

  relevantEntryIds: string[];
  conflictIds: string[];
  degradedSourceIds: string[];

  status:
    | "covered"
    | "covered_with_warning"
    | "blocked_by_conflict"
    | "degraded"
    | "invalidated";

  resolvedAt: string;
  expiresAt?: string;
  invalidationConditions?: string[];
}
```

Coverage validity depends on scope, operation, active source snapshot, repository state, and unresolved conflicts. Read coverage does not automatically imply mutation coverage.

### 14.9 Mutation target and operation fingerprint

```ts
export interface MutationTarget {
  toolName: string;
  operationKind: OperationKind;
  scopes: ScopeReference[];
  paths?: string[];
  symbols?: string[];
  resources?: string[];
}

export interface MutationAttemptState {
  fingerprint: string;
  hydrationRevision: number;
  attempts: number;
  lastDecision:
    | "allowed"
    | "denied_for_hydration"
    | "denied_for_conflict"
    | "degraded";
  updatedAt: string;
}
```

The fingerprint must include the normalized tool name, mutation target, operation kind, material input hash, source snapshot, and current manifest revision.

### 14.10 Decision need and resolved need

```ts
export type DecisionNeedType =
  | "implementation_choice"
  | "business_semantics"
  | "data_derivation"
  | "architecture"
  | "dependency_selection"
  | "compatibility"
  | "security"
  | "schema"
  | "product_behavior"
  | "operational_action"
  | "unknown";

export interface DecisionNeed {
  decisionKey: string;
  type: DecisionNeedType;
  subject: string;
  operation?: string;
  scopes: ScopeReference[];
  constraints: string[];
  proposedOptions?: string[];
  risk: RiskLevel;
  intent:
    | "apply_established"
    | "choose_new"
    | "change_established"
    | "verify_fact";
  originalQuestion?: string;
}

export interface ResolvedNeed {
  id: string;
  decisionKey: string;
  resolution: string;
  normalizedOption?: string;
  sourceEntryIds: string[];
  authority: LedgerAuthority;
  scope: ScopeReference[];
  risk: RiskLevel;
  intent: DecisionNeed["intent"];
  resolutionMode:
    | "canon"
    | "memory_kit"
    | "ledger"
    | "current_task_answer"
    | "human_answer"
    | "approved_inference";
  manifestRevision: number;
  sourceSnapshotHash: string;
  resolvedAt: string;
  expiresAt?: string;
  invalidationConditions?: string[];
}
```

The decision key must be stable across paraphrases. It should be derived from normalized type, subject, operation, scope, and material constraints—not raw question text.

---

## 15. Resolution and refresh pipeline

Ledger uses two related pipelines:

1. **Full compile**, used for `M0`, explicit rehydration, and diagnosis.
2. **Incremental refresh**, used when implementation reveals new scope or invalidates previous assumptions.

Neither pipeline may combine all factors into one weighted relevance score.

### 15.1 Full compile pipeline

```mermaid
flowchart TD
    A[Resolution Request] --> B[Resolve actor, repository, task, and session]
    B --> C[Authorize source access]
    C --> D[Retrieve exact decision keys and task answers]
    D --> E[Retrieve exact structured scopes and entities]
    E --> F[Traverse explicit Memory Kit relationships]
    F --> G[Retrieve semantic fallback candidates]
    G --> H[Normalize candidate types]
    H --> I[Filter inactive, expired, invalid, and unauthorized]
    I --> J[Validate freshness and source evidence]
    J --> K[Group by subject or conflict key]
    K --> L[Apply kind-specific precedence]
    L --> M[Detect unresolved conflicts]
    M --> N[Classify intent, risk, and autonomy]
    N --> O[Compile bounded manifest]
    O --> P[Write receipt and external session state]
```

### 15.2 Identity and authorization

Resolve:

- Actor identity and team memberships.
- Repository identity.
- Current branch and commit/revision.
- Session and task identity.
- Environment.
- Current source versions.

Apply authorization before returning source text to the resolver. Unauthorized candidates must not appear as rejected receipt items because their existence may itself be sensitive. Record only a count or opaque access-denied marker when required.

### 15.3 Deterministic retrieval

Retrieve in this order:

1. Current-task resolved-need cache.
2. Exact decision key.
3. Exact task ID.
4. Exact repository, service, module, path, and symbol.
5. Exact endpoint, dataset, table, message topic, and dependency.
6. Canon rule applicability.
7. Direct source references and relationship edges.
8. Business concepts and operations.

### 15.4 Semantic fallback

Use full-text or vector retrieval only to discover candidates not found by exact keys.

Semantic relevance may order candidates only after they pass:

- Authorization.
- Lifecycle eligibility.
- Scope compatibility.
- Entry-kind compatibility.
- Authority-group constraints.

### 15.5 Temporal validation

Classify each candidate as:

```text
current
possibly_stale
stale
invalid
unknown
```

Validation may compare:

- Stored revision to active revision.
- Content hash to current source content.
- Source modification time.
- Explicit expiry.
- Invalidation conditions.
- Supersession relationships.
- Canon rule version.
- Memory Kit record version.
- Current task constraints.

A stale fact may be included under `staleItems` but must not independently drive autonomous resolution.

### 15.6 Conflict grouping and precedence

Group candidates using:

1. Exact decision key.
2. Explicit `conflictKey`.
3. Shared normalized subject.
4. Explicit `conflictsWith` links.
5. Conservative semantic contradiction detection.

Within each conflict group:

1. Apply kind-specific precedence.
2. Apply authority.
3. Apply scope specificity.
4. Apply explicit supersession.
5. Apply freshness.
6. Apply evidence quality.
7. Apply semantic relevance only as the final tie-breaker.

If no single candidate dominates safely, emit a conflict.

### 15.7 Context budgeting

The complete human-readable manifest should remain concise. Recommended defaults:

```text
soft character target: 6,000
hard character cap: 9,000
maximum items per section: configurable
maximum rationale length per item: 240 characters
```

For runtime deltas:

```text
soft character target: 1,500
hard character cap: 3,000
```

Prioritize:

1. Hard policies and invariants.
2. Exact directly relevant facts.
3. Active decisions.
4. Applicable exceptions.
5. Task-specific preferences.
6. Assumptions.
7. Advisory heuristics.

Never truncate identifiers, authority, risk, or conflict warnings.

### 15.8 Incremental refresh pipeline

```mermaid
flowchart TD
    A[Tool result, failure, mutation, question, or subagent] --> B[Extract normalized entities and scopes]
    B --> C{New or invalidated frontier?}
    C -- No --> D[Record no-op observation]
    C -- Yes --> E[Build narrow resolution request]
    E --> F[Query full authorized sources]
    F --> G[Diff against current manifest]
    G --> H{Material delta?}
    H -- No --> I[Add or refresh coverage]
    H -- Yes --> J[Persist M n+1 and receipt]
    J --> K[Inject compact delta]
    I --> L[Continue]
    K --> L
```

The incremental request must be narrow. It should query newly discovered entities and their direct relationships, not re-run an unconstrained repository-wide semantic search.

### 15.9 Discovery triggers

A refresh is required when any of the following occurs:

- A previously unseen repository path or symbol becomes active.
- A newly read file imports or references another module or service.
- A new dataset, table, endpoint, message topic, dependency, or external system is discovered.
- A tool or test failure contradicts an active assumption.
- The implementation target expands to another module or service.
- A source file supporting an active entry changes.
- The agent attempts to mutate an uncovered scope.
- The agent attempts to ask a clarification question.
- A subagent is spawned for a distinct scope.
- A session resumes, clears, forks, or compacts.
- A Memory Kit, Canon, or Ledger source version changes.

### 15.10 Entity extraction

Use deterministic extraction first:

- Paths from tool input and output.
- Symbols from language-server or parser output.
- Imports, package names, and module references.
- SQL tables, schema objects, and dataset identifiers.
- Endpoint routes, queue topics, event names, and configuration keys.
- Error types, test names, stack-trace paths, and failing assertions.
- Known Memory Kit aliases and canonical entity IDs.

Optional model-assisted extraction may discover business concepts, but its output is only a retrieval hint. It cannot grant authority or create an active fact.

### 15.11 Scope-frontier updates

An entity enters the frontier only after normalization and deduplication.

Each frontier update records:

- Canonical entity ID.
- Source tool use.
- Confidence.
- First and latest observation.
- Relationship to already known scopes.
- Whether the entity has mutation coverage.
- Whether its context was injected into the model.

### 15.12 Delta rules

A material delta must include only:

- Newly applicable entries.
- Entries no longer applicable.
- Newly stale, invalidated, or superseded entries.
- New or resolved conflicts.
- Changed autonomy boundaries.
- New decision resolutions.
- Added or invalidated context coverage.

Do not re-inject unchanged entries. The external manifest remains complete; model-visible deltas remain minimal.

### 15.13 Refresh idempotency and concurrency

- The same normalized trigger and source snapshot must produce the same outcome.
- Use a per-session lock or transactional compare-and-swap on manifest revision.
- Concurrent `PostToolUse` hooks must not create conflicting revisions.
- Prefer `PostToolBatch` to aggregate parallel tool calls when supported.
- If a stale writer loses a revision race, recompute its delta against the latest state.
- Receipt chains must remain ordered and gap-free.

### 15.14 Retrieval miss behavior

A proactive miss is not proof that no context exists.

The system must still retain three later recovery checkpoints:

```text
1. Mutation coverage gate
2. AskUserQuestion interception
3. Plain-text Stop recovery
```

---

## 16. Dynamic Task Context Manifest

### 16.1 Initial manifest `M0`

Generate a concise format similar to:

```text
LEDGER TASK CONTEXT
Manifest: M0
Receipt: ctxr_4a91
Repository revision: 7bc19f2
Source snapshot: ss_319e
Mode: shadow

Task
- Add CSV export to the position history endpoint.

Known scope frontier
- repository: trading-platform
- service: position-api
- path: src/positions/**
- dataset: position_history

Applicable policies
- [CANON-17][mandatory] Public API responses require runtime schema validation.
- [CANON-31][mandatory] HTTP handlers may not access the database directly.

Relevant system facts
- [MEM-108][current] Position timestamps are stored in UTC.

Active decisions
- [DEC-91][approved] Exports above 10,000 rows use asynchronous jobs.

Conflicts and stale information
- None currently known.

Autonomy boundary
- May choose the internal serializer implementation.
- May apply DEC-91 without asking.
- Must ask before changing the public response schema.
- Must not infer timestamp or trading-date semantics.
```

`M0` must explicitly state that it reflects only currently known scope.

### 16.2 Manifest delta after discovery

Suppose Claude reads `src/positions/export.ts` and discovers the `exchange-calendar` service and `exchange_sessions` dataset.

Inject only:

```text
LEDGER CONTEXT DELTA
Manifest: M0 -> M1
Receipt: ctxr_51bc
Trigger: scope_discovered
Observed from: Read src/positions/export.ts

New scope
- service: exchange-calendar
- dataset: exchange_sessions
- concept: exchange trading date

Added system facts
- [MEM-441][current] Trading date is derived from the exchange session,
  not the UTC calendar date.

Added active decisions
- [DEC-182][approved][mandatory] Position exports expose exchange trading date.

Invalidated assumptions
- [ASM-12] UTC calendar date can be used as trading date.

Updated autonomy boundary
- Apply DEC-182 when serializing position exports.
- Any change to trade-date semantics requires an approved human decision.
```

### 16.3 Manifest receipt chain

```text
M0 / ctxr_4a91  initial task
M1 / ctxr_51bc  exchange-calendar discovered
M2 / ctxr_70d3  failed test invalidated ordering assumption
M3 / ctxr_921a  question resolved from DEC-204
M4 / ctxr_b602  human supplied a new task-local choice
```

The receipt chain is authoritative. The transcript is not.

### 16.4 Context rehydration

On resume, clear, fork, or compaction, inject a compact rehydration view:

```text
LEDGER CONTEXT REHYDRATED
Current manifest: M4
Receipt chain head: ctxr_b602

Active scope
- position-api
- exchange-calendar
- src/positions/**
- src/calendar/**
- position_history
- exchange_sessions

Critical active entries
- CANON-17
- CANON-31
- DEC-91
- DEC-182

Resolved needs
- position-export-format -> CSV
- position-export-date-semantics -> exchange trading date

Open conflicts
- None
```

Do not inject all evidence or every historical delta. Provide IDs for on-demand explanation.

### 16.5 Context coverage display

The context command should expose coverage separately from the manifest:

```text
COVERED
- edit src/positions/** at M3
- serialize position_history at M3

UNCOVERED
- edit src/calendar/**
- migrate exchange_sessions

BLOCKED
- none
```

This allows maintainers to understand why a mutation was allowed, delayed, or escalated.

---

## 17. Risk model and autonomy policy

### 17.1 Risk levels

```ts
export type RiskLevel =
  | "trivial"
  | "low"
  | "medium"
  | "high"
  | "critical";
```

Suggested interpretation:

| Risk | Typical characteristics |
|---|---|
| `trivial` | Local, reversible, no external behavior change |
| `low` | Internal implementation choice, easy to test and revert |
| `medium` | Cross-module effects or meaningful maintenance cost |
| `high` | Public behavior, data meaning, schema, authorization, or production effects |
| `critical` | Security, compliance, destructive action, irreversible behavior, or financial correctness |

### 17.2 Separate autonomy ceilings

The resolver must distinguish two actions.

#### Applying an established decision

Examples:

- Following an active Canon rule.
- Preserving an approved data-derivation invariant.
- Reusing a task answer already supplied by the user.
- Applying an exact repository decision to a matching path.

This may be permitted at a higher risk level because the agent is not inventing policy. It is executing an already governed answer.

#### Making or changing a decision

Examples:

- Choosing new timestamp semantics.
- Changing a public response schema.
- Selecting a new authorization model.
- Introducing a new database architecture.
- Overriding an existing approved decision.

This must have a lower autonomy ceiling.

Recommended defaults:

```text
maximum new-decision risk: low
maximum established-decision application risk: high
critical established decisions: enforce or escalate according to hard policy
```

### 17.3 Mandatory human-decision categories

The following require a human when the action would create, change, weaken, supersede, or ambiguously interpret the governing behavior:

- Public API, protocol, wire-format, or backward-compatibility changes.
- Database schema changes and migrations with data-loss or semantic risk.
- Data derivation, timestamp meaning, trading-calendar meaning, financial calculations, or raw-data interpretation.
- Authentication, authorization, access control, secrets, cryptography, or security boundaries.
- Destructive actions or irreversible transformations.
- Legal, compliance, audit, or retention behavior.
- Production infrastructure or deployment topology changes.
- Customer-visible product behavior where no approved decision exists.
- Expensive or difficult-to-reverse platform choices.
- Direct conflict between authoritative sources.
- Any decision marked `never_auto_apply`.

An exact, active, approved instruction to preserve one of these behaviors may be applied without asking when the operation does not alter it and policy explicitly permits established-decision application.

Example:

```text
Allowed:
- Apply DEC-182: position exports use exchange trading date.

Not allowed:
- Decide whether position exports should switch from exchange trading date to UTC.
```

### 17.4 Established-decision application eligibility

An established answer may be applied only when all conditions are true:

1. Global and scoped mode permit it.
2. The decision need intent is `apply_established` or `verify_fact`.
3. An exact active authoritative entry or current-task answer directly resolves it.
4. Source evidence is current and validated.
5. Scope and operation match.
6. No unresolved conflict exists.
7. The implementation preserves, rather than changes, the established meaning.
8. Any presented option maps unambiguously.
9. The entry's autonomy is `mandatory` or `default`.
10. The risk is within the configured established-decision ceiling.
11. A context receipt is successfully written.

### 17.5 New-decision eligibility

A new choice may be answered automatically only when all conditions are true:

1. Global and scoped mode permit it.
2. The decision need intent is `choose_new`.
3. Risk is within the configured new-decision ceiling.
4. At least one active authoritative preference or decision directly covers the choice.
5. The winner is current and source-grounded.
6. No unresolved conflict exists.
7. Scope matches.
8. The answer maps unambiguously to a presented option.
9. The entry's autonomy is `default` or `mandatory`.
10. No mandatory-human category applies.
11. A context receipt is successfully written.

### 17.6 Change-established behavior

Any decision need with intent `change_established` defaults to asking a human regardless of similarity, confidence, or convenience.

### 17.7 Resolution matrix

| Situation | Expected behavior |
|---|---|
| Exact current task answer | Apply and cache |
| Exact approved active decision, same scope, preserving behavior | Apply if within established ceiling |
| Strong preference for a reversible internal choice | Apply only within new-decision ceiling |
| Two authoritative entries conflict | Ask and show conflict |
| Stale source | Revalidate; otherwise ask |
| High-risk new behavior | Ask |
| Agent inference only | Do not apply as fact |
| No matching context | Ask |
| Existing answer but materially changed constraints | Invalidate cached need and resolve again |

---

## 18. Claude Code plugin integration

This specification is designed around current Claude Code plugin and hook capabilities. Before implementation, verify the installed Claude Code version and official schemas. Feature-detect newer events where practical.

### 18.1 Recommended plugin layout

Adapt to the existing repository rather than duplicating structures.

```text
ledger/
├── .claude-plugin/
│   └── plugin.json
├── hooks/
│   └── hooks.json
├── skills/
│   ├── context/
│   │   └── SKILL.md
│   ├── why/
│   │   └── SKILL.md
│   ├── conflicts/
│   │   └── SKILL.md
│   ├── candidates/
│   │   └── SKILL.md
│   ├── approve/
│   │   └── SKILL.md
│   ├── reject/
│   │   └── SKILL.md
│   └── doctor/
│       └── SKILL.md
├── src/
│   ├── cli/
│   ├── hooks/
│   │   ├── session-start/
│   │   ├── prompt-submit/
│   │   ├── discovery/
│   │   ├── mutation-coverage/
│   │   ├── question-resolution/
│   │   ├── subagent-context/
│   │   └── stop-recovery/
│   ├── resolver/
│   ├── context/
│   │   ├── manifest/
│   │   ├── delta/
│   │   ├── coverage/
│   │   └── session-state/
│   ├── domain/
│   ├── sources/
│   │   ├── memory-kit/
│   │   ├── canon/
│   │   └── ledger/
│   ├── persistence/
│   ├── capture/
│   ├── policy/
│   └── observability/
├── migrations/
├── tests/
├── docs/
└── package.json or equivalent
```

### 18.2 Plugin manifest

Preserve the existing plugin name when updating the current plugin.

```json
{
  "name": "ledger",
  "description": "Maintains governed live task context and resolves established implementation decisions for Claude Code.",
  "version": "0.2.0"
}
```

Do not overwrite additional existing manifest fields.

### 18.3 Conceptual hook registration

Tool names and event availability must be validated against the installed version.

```json
{
  "hooks": {
    "SessionStart": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "node \"${CLAUDE_PLUGIN_ROOT}/dist/cli.js\" hook session-start",
            "timeout": 5
          }
        ]
      }
    ],
    "UserPromptSubmit": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "node \"${CLAUDE_PLUGIN_ROOT}/dist/cli.js\" hook user-prompt-submit",
            "timeout": 5
          }
        ]
      }
    ],
    "PreToolUse": [
      {
        "matcher": "AskUserQuestion",
        "hooks": [
          {
            "type": "command",
            "command": "node \"${CLAUDE_PLUGIN_ROOT}/dist/cli.js\" hook pre-question",
            "timeout": 5
          }
        ]
      },
      {
        "matcher": "Edit|Write|NotebookEdit|Bash",
        "hooks": [
          {
            "type": "command",
            "command": "node \"${CLAUDE_PLUGIN_ROOT}/dist/cli.js\" hook pre-mutation",
            "timeout": 5
          }
        ]
      },
      {
        "matcher": "Agent",
        "hooks": [
          {
            "type": "command",
            "command": "node \"${CLAUDE_PLUGIN_ROOT}/dist/cli.js\" hook pre-subagent",
            "timeout": 5
          }
        ]
      }
    ],
    "PostToolUse": [
      {
        "matcher": "AskUserQuestion",
        "hooks": [
          {
            "type": "command",
            "command": "node \"${CLAUDE_PLUGIN_ROOT}/dist/cli.js\" hook post-question"
          }
        ]
      },
      {
        "matcher": "Read|Glob|Grep|Bash|Edit|Write|NotebookEdit|Agent",
        "hooks": [
          {
            "type": "command",
            "command": "node \"${CLAUDE_PLUGIN_ROOT}/dist/cli.js\" hook post-tool-observation"
          }
        ]
      }
    ],
    "PostToolUseFailure": [
      {
        "matcher": "Read|Glob|Grep|Bash|Edit|Write|NotebookEdit|Agent",
        "hooks": [
          {
            "type": "command",
            "command": "node \"${CLAUDE_PLUGIN_ROOT}/dist/cli.js\" hook post-tool-failure"
          }
        ]
      }
    ],
    "PostToolBatch": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "node \"${CLAUDE_PLUGIN_ROOT}/dist/cli.js\" hook post-tool-batch",
            "timeout": 5
          }
        ]
      }
    ],
    "SubagentStart": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "node \"${CLAUDE_PLUGIN_ROOT}/dist/cli.js\" hook subagent-start",
            "timeout": 5
          }
        ]
      }
    ],
    "Stop": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "node \"${CLAUDE_PLUGIN_ROOT}/dist/cli.js\" hook stop",
            "timeout": 30
          }
        ]
      }
    ],
    "SessionEnd": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "node \"${CLAUDE_PLUGIN_ROOT}/dist/cli.js\" hook session-end"
          }
        ]
      }
    ]
  }
}
```

`PostToolBatch` has no matcher. If the installed Claude Code version does not support it, use `PostToolUse` with per-session locking and a short deduplication window.

Use lightweight handlers. Do not run an expensive general-purpose LLM synchronously on every tool call.

### 18.4 `SessionStart`: rehydrate external state

Responsibilities:

- Resolve repository identity and active revision.
- Inspect the `source` value: startup, resume, clear, compact, or fork.
- Load existing session state when available.
- Validate source snapshot and coverage.
- Recompile `M0` only when no compatible state exists.
- Inject a compact rehydration view after resume or compaction.
- Warm local projections and caches.
- Check source health.
- Optionally set a concise session title.
- Optionally register watch paths for relevant local source files.

The injected context should establish:

```text
This repository uses Ledger Context Governor.
The active Task Context Manifest is revisioned and may expand during work.
Before implementation clarification, use AskUserQuestion so Ledger can
search governed context.
A newly discovered mutation target may be delayed once while Ledger
hydrates applicable context.
Apply established active decisions without re-asking.
Ask only for genuinely new, conflicted, stale, or unauthorized decisions.
```

Do not inject the complete Memory Kit or event history.

### 18.5 `UserPromptSubmit`: generate `M0`

Responsibilities:

1. Parse the submitted task prompt.
2. Combine it with session, repository, branch, revision, issue, and current-path context.
3. Create or reset task-scoped session state.
4. Query all adapters.
5. Compile initial manifest revision `M0`.
6. Persist the receipt and session state.
7. Return the human-readable manifest as `additionalContext`.

Conceptual output:

```json
{
  "hookSpecificOutput": {
    "hookEventName": "UserPromptSubmit",
    "additionalContext": "LEDGER TASK CONTEXT\nManifest: M0\nReceipt: ctxr_4a91\n..."
  }
}
```

Performance requirements:

- Use a local active projection and cache.
- Target sub-second execution under normal local operation.
- Configure a strict internal deadline below the hook timeout.
- On non-critical source timeout, return a degraded manifest rather than stalling the prompt.
- State clearly that `M0` contains currently known scope only.

### 18.6 `PostToolBatch` and `PostToolUse`: proactive discovery

`PostToolBatch` is the preferred successful-tool discovery checkpoint because it observes the entire parallel batch before the next model call.

Responsibilities:

1. Extract paths, symbols, imports, modules, services, endpoints, datasets, tables, dependencies, concepts, test failures, and source changes.
2. Normalize and deduplicate them.
3. Compare them with the current scope frontier.
4. Issue a narrow refresh for new or invalidated scope.
5. Persist the next manifest revision and receipt when material.
6. Inject only the manifest delta.

Conceptual output:

```json
{
  "hookSpecificOutput": {
    "hookEventName": "PostToolBatch",
    "additionalContext": "LEDGER CONTEXT DELTA\nManifest: M2 -> M3\nReceipt: ctxr_921a\n..."
  }
}
```

`PostToolUse` remains necessary for:

- Capturing the answer produced by `AskUserQuestion`.
- Supporting versions without `PostToolBatch`.
- Tool-specific structured outputs that are easier to process before serialization.
- Observability and touched-source invalidation.

When `PostToolBatch` is available, ordinary `PostToolUse` handlers should accumulate normalized observations but should not independently inject overlapping manifest deltas. The batch handler owns the single visible refresh before the next model request.

Do not rebuild the complete manifest after every read.

### 18.7 `PostToolUseFailure`: failure-driven refresh

A failed test or command may reveal missing context more reliably than the initial task.

Responsibilities:

- Extract error type, stack-trace paths, missing symbols, modules, configuration keys, tables, endpoints, and violated assumptions.
- Query full sources for the newly revealed scope.
- Invalidate assumptions contradicted by the failure.
- Inject a compact corrective delta.
- Avoid parsing unstable free-form error text beyond conservative patterns.

Conceptual output:

```json
{
  "hookSpecificOutput": {
    "hookEventName": "PostToolUseFailure",
    "additionalContext": "LEDGER FAILURE CONTEXT DELTA\nManifest: M3 -> M4\nThe failing test reveals CANON-44 and DEC-208 apply to this module..."
  }
}
```

### 18.8 `PreToolUse` mutation coverage gate

This checkpoint covers `Edit`, `Write`, `NotebookEdit`, mutating `Bash`, and configured MCP mutation tools.

The handler must:

1. Classify whether the operation is mutating.
2. Extract mutation targets and operation kind.
3. Check current valid context coverage.
4. If covered, permit normal tool processing.
5. If uncovered, synchronously resolve the target against all authorized sources.
6. Persist any manifest delta and coverage.
7. Decide whether the current attempt may safely proceed.

#### No new context

When the target is resolved and no relevant context is added, record coverage and allow the tool call.

#### New relevant context

The model has not seen the new context yet. Deny this attempt once, deliver the delta in the denial reason, and instruct Claude to retry after reconsidering the operation.

Conceptual output:

```json
{
  "hookSpecificOutput": {
    "hookEventName": "PreToolUse",
    "permissionDecision": "deny",
    "permissionDecisionReason": "Ledger hydrated context for this previously uncovered mutation target. Manifest M4 -> M5. DEC-182 requires exchange trading date and CANON-31 forbids direct database access. Reconsider the edit using these constraints, then retry. Receipt: ctxr_a81e."
  }
}
```

#### Conflict or unresolved high-risk decision

Deny the mutation and instruct Claude to use `AskUserQuestion` with the identified conflict. Do not fabricate an answer.

#### Retry-loop prevention

Use a mutation fingerprint containing:

```text
tool name
normalized target scopes
operation kind
material input hash
manifest revision
source snapshot
```

After one hydration denial for the same logical operation:

- Allow a compliant retry if coverage is valid.
- Deny only when the retry still conflicts with active context.
- Cap hydration attempts.
- Never rely on Claude Code's outer loop cap as the primary protection.

In observe or shadow rollout modes, the coverage gate may record what it would have blocked without denying.

### 18.9 `PreToolUse` for `AskUserQuestion`

This is the primary question-resolution interception point.

The handler must:

1. Read each question and its options.
2. Normalize each into a `DecisionNeed`.
3. Compute stable decision keys.
4. Check current-task and resolved-need caches.
5. Search the complete authorized Memory Kit, Canon, and Ledger stores.
6. Resolve each question independently.
7. Classify intent and risk.
8. Write prediction/resolution receipts.
9. Apply the configured mode.

It must not search only the current manifest.

#### Shadow mode

- Record predicted answers and evidence.
- Do not modify tool input.
- Let the user answer normally.

#### Recommend mode

- Add concise supporting context.
- Preserve the human question.
- Do not fill answers unless explicitly configured.

#### Resolve mode

Only when every question passes autonomous eligibility, return the complete original input plus an `answers` map.

```json
{
  "hookSpecificOutput": {
    "hookEventName": "PreToolUse",
    "permissionDecision": "allow",
    "permissionDecisionReason": "Resolved by active Ledger decision DEC-182.",
    "updatedInput": {
      "questions": [
        {
          "question": "Should the export use UTC date or exchange trading date?",
          "header": "Date semantics",
          "options": [
            { "label": "UTC date" },
            { "label": "Exchange trading date" }
          ],
          "multiSelect": false
        }
      ],
      "answers": {
        "Should the export use UTC date or exchange trading date?": "Exchange trading date"
      }
    },
    "additionalContext": "Applied established decision DEC-182. Manifest M5 -> M6. Do not ask again unless scope or evidence changes. Receipt: qrr_82ab."
  }
}
```

`updatedInput` replaces the whole tool input. Preserve every unchanged field.

If one of several questions is ineligible and the installed tool contract requires all answers together, do not partially auto-answer unless the implementation has a tested safe strategy. Prefer preserving the full user interaction.

### 18.10 `PostToolUse` for `AskUserQuestion`

Responsibilities:

- Capture the actual human or programmatic answer.
- Match it to the prediction and decision key.
- Record agreement or disagreement.
- Store the answer as raw evidence.
- Add a task-scoped resolved need immediately.
- Create a broader candidate only when classification and approval rules support it.
- Never promote broad team policy directly from this hook.

### 18.11 `PreToolUse` for `Agent` and `SubagentStart`

`SubagentStart` receives the agent ID and type but not necessarily the assigned prompt. Therefore scope the subagent before creation through `PreToolUse` on the `Agent` tool.

`PreToolUse` on `Agent` must:

1. Read the proposed subagent type, prompt, and working mode.
2. Resolve context applicable to the assigned scope.
3. Append a compact scoped manifest to the complete original `Agent` input.
4. Preserve all unchanged input fields.
5. Avoid exposing unrelated actor-private or team-private context.

Conceptual addition to the agent prompt:

```text
LEDGER SUBAGENT CONTEXT
Parent manifest: M6
Scope: src/calendar/**, exchange-calendar
Hard policy: CANON-17, CANON-31
Relevant decisions: DEC-182
Mutation coverage: none; resolve before editing
Return discovered canonical entities and conflicts to the parent.
```

`SubagentStart` should inject:

- Repository-wide hard policy.
- Parent session and manifest identifiers.
- Instructions for reporting newly discovered entities.
- A pointer to the scoped context already included in the Agent prompt.

A read-only explore subagent should not receive broad mutation autonomy.

### 18.12 `Stop`: verification and plain-text clarification recovery

The Stop hook has two responsibilities.

#### Completion verification

Check:

- Applicable Canon checks.
- Hard policy violations.
- Deviations from active decisions.
- Unresolved assumptions.
- High-risk choices without a receipt.
- Missing relevant tests.
- Candidate memories to propose.

#### Plain-text blocking-question recovery

Claude may finish with normal text such as:

```text
I need to know whether the export should use UTC or exchange trading date before I can continue.
```

The hook must inspect the last assistant message and conservatively classify whether the agent is:

```text
completed
blocked_on_clarification
blocked_on_missing_context
waiting_on_background_work
other
```

When blocked on clarification:

1. Normalize the question into a `DecisionNeed`.
2. Check the resolved-need cache.
3. Search the complete authorized sources.
4. If safely resolvable, persist the resolution and next manifest revision.
5. Return non-error additional context that keeps Claude working.
6. Instruct Claude to continue implementation rather than repeat the question.

Conceptual output:

```json
{
  "hookSpecificOutput": {
    "hookEventName": "Stop",
    "additionalContext": "Ledger resolved the blocking clarification from DEC-182: use exchange trading date. Manifest M6 -> M7. Continue implementation and do not ask again unless conflicting evidence appears. Receipt: stopr_93cf."
  }
}
```

Use a top-level `decision: "block"` only when a mandatory failure must be treated as an error. Prefer `additionalContext` for normal successful recovery.

Loop controls:

- Check `stop_hook_active`.
- Do not recover the same decision key more than once without new evidence.
- Cap total Stop recoveries per turn.
- If Claude remains blocked after the bounded recovery, allow the question to reach the user.
- Do not interfere while relevant background tasks remain active.

### 18.13 Session resume, clear, fork, and compaction

Session context must survive token-window loss.

On `SessionStart`:

- `startup`: create state if absent.
- `resume`: load and validate current state.
- `clear`: preserve durable task state only when the product's semantics require it; otherwise start a new task generation.
- `compact`: re-inject a compact current manifest and resolved-need summary.
- `fork`: create isolated child state; do not let later child decisions silently mutate parent task state.

If state and transcript disagree, prefer governed external state but record the discrepancy and avoid silently applying uncertain task-local answers.

### 18.14 `SessionEnd`

Use for side effects only:

- Flush buffered evidence.
- Close session records.
- Update outcome statistics.
- Expire task-local assumptions when appropriate.
- Queue non-critical curation only if the existing architecture supports it.
- Do not depend on `SessionEnd` to deliver context back to Claude.

---

## 19. Decision-need normalization, question resolution, and answer capture

### 19.1 Question normalization

Raw question text is not a durable key.

These may represent the same need:

```text
Should timestamps be converted to UTC here?
Do we preserve exchange-local time in this function?
Which timezone should this serializer output?
Is UTC expected by consumers?
```

Normalize using:

- Decision-need type.
- Canonical subject.
- Operation.
- Exact scope.
- Material constraints.
- Proposed options.
- Existing active decision keys.

The normalizer may use aliases from Memory Kit but must retain the original text for audit.

### 19.2 Decision-key generation

Conceptually:

```text
decision key =
  hash(
    normalized type,
    normalized subject,
    normalized operation,
    canonical scopes,
    material constraints
  )
```

Do not include incidental wording, punctuation, or option order.

When confidence in normalization is insufficient, retain separate keys rather than incorrectly merging unrelated decisions.

### 19.3 Resolution search order

For every question:

```text
1. Exact current-task resolved need
2. Exact prior human answer with compatible scope and constraints
3. Exact active decision key
4. Exact Canon applicability
5. Exact repository/service/path/symbol/entity scope
6. Related Memory Kit facts and invariants
7. Semantic fallback
8. Noisy memory for advisory explanation only
```

### 19.4 Repeated-question behavior

If an exact compatible `ResolvedNeed` exists:

- Return it without re-querying expensive semantic sources.
- Validate its source snapshot and invalidation conditions.
- Update usage metadata.
- Do not show the question to the user again.

If scope or constraints materially changed:

- Invalidate or bypass the cached resolution.
- Resolve again.
- Explain why the previous answer no longer applies.

### 19.5 Prediction record

```ts
export interface QuestionOption {
  label: string;
  description?: string;
}

export interface QuestionPrediction {
  id: string;
  sessionId: string;
  toolUseId?: string;

  decisionNeed: DecisionNeed;
  questionText: string;
  options: QuestionOption[];

  predictedAnswer?: string | string[];
  mode: "observe" | "shadow" | "recommend" | "resolve";
  risk: RiskLevel;
  intent: DecisionNeed["intent"];

  confidence: number;
  supportingEntryIds: string[];
  conflictingEntryIds: string[];

  manifestRevision: number;
  receiptId: string;
  createdAt: string;
}
```

### 19.6 Answer outcome

```ts
export interface QuestionOutcome {
  predictionId: string;
  decisionKey: string;
  actualAnswer: string | string[];
  answerSource:
    | "human"
    | "ledger"
    | "canon"
    | "memory_kit"
    | "current_task_cache"
    | "stop_recovery";

  agreedWithPrediction: boolean;
  laterCorrected: boolean;

  resultingResolvedNeedId: string;
  resultingCandidateEntryIds: string[];
  recordedAt: string;
}
```

### 19.7 Capture classification

When an answer is received, classify it as one of:

```text
task_choice
personal_preference
team_convention
architectural_decision
factual_correction
temporary_workaround
exception
rejection
insufficient_to_classify
```

Classification must consider wording, task context, actor authority, affected scope, and supporting evidence.

Examples:

- “Use PostgreSQL for this migration” -> `task_choice`.
- “We use PostgreSQL for all transactional services” -> candidate `architectural_decision`, requiring appropriate approval.
- “I personally prefer PostgreSQL for prototypes” -> `personal_preference`.
- “Do not use PostgreSQL here because this service is ClickHouse-only” -> factual constraint or negative preference depending on evidence.

### 19.8 Immediate task-local caching

Every accepted human answer should create a task-scoped `ResolvedNeed` immediately unless the answer is explicitly non-binding.

This prevents the same question from recurring during the same implementation even when the answer is not promoted into the durable Ledger.

### 19.9 Promotion rules

- Task-local choices may become active task-scoped entries automatically and expire with the task.
- Explicit personal preferences may become actor-scoped candidates or active preferences according to policy.
- Repository, team, architecture, security, and organization entries require approval appropriate to scope.
- Agent observations remain `observed` until corroborated.
- Repeated independent evidence may promote an observation to a candidate, never directly to hard policy.
- Rejected options should be stored as negative evidence.
- Corrections and reversions reduce confidence and may invalidate active entries.

### 19.10 Candidate deduplication

Before creating a candidate:

1. Search by exact decision key.
2. Search for the same subject and compatible scope.
3. Attach evidence to an existing candidate when statements are materially equivalent.
4. Create a conflict link when statements contradict.
5. Avoid creating paraphrased duplicates.
6. Preserve original human wording in evidence.

### 19.11 Option mapping

Auto-answering `AskUserQuestion` requires deterministic option mapping.

Permit mapping only when:

- An option label exactly equals the normalized resolution; or
- A configured canonical alias maps one-to-one to the option; and
- No other option is semantically equivalent.

For multi-select questions, every selected option must map independently.

Do not auto-answer free-form “Other” choices unless the tool contract and policy have an explicitly tested path.

### 19.12 Shadow calibration

Shadow-mode reports must group precision by:

- Decision-need type.
- Intent.
- Risk.
- Repository/team.
- Authority class.
- Exact versus semantic retrieval.
- New decision versus established-decision application.
- Proactive discovery hit versus last-chance interception.

---

## 20. Context receipt and explainability

Every selected or rejected candidate needs a reason code.

Recommended reason codes:

```text
selected_exact_scope
selected_authority
selected_supersedes
selected_freshest_source
selected_task_instruction
rejected_unauthorized
rejected_scope_mismatch
rejected_inactive
rejected_expired
rejected_superseded
rejected_stale
rejected_lower_authority
rejected_conflict
rejected_low_confidence
rejected_context_budget
rejected_duplicate
selected_current_task_cache
selected_exact_decision_key
coverage_added
coverage_invalidated
manifest_delta_noop
mutation_delayed_for_hydration
question_resolved_from_cache
stop_recovery_applied
subagent_context_scoped
```

Provide user- and agent-facing commands or skills:

```text
/ledger:context
/ledger:why <entry-or-receipt-id>
/ledger:conflicts
/ledger:candidates
/ledger:approve <candidate-id>
/ledger:reject <candidate-id>
/ledger:doctor
```

If the existing plugin has another command style, preserve it.

`ledger:context` must show the current manifest revision, receipt-chain head, scope frontier, coverage, resolved needs, and open conflicts.

`ledger:why` must show:

- The question or task.
- The selected answer.
- Supporting entries.
- Authority and scope.
- Evidence references.
- Rejected alternatives.
- Conflicts and stale information.
- Risk classification.
- Why autonomous resolution was or was not allowed.

---

## 21. Configuration

Add configuration through the existing Ledger configuration system. A conceptual schema follows.

```json
{
  "mode": "shadow",
  "storage": {
    "driver": "existing",
    "path": ".ledger/ledger.db",
    "sessionStatePath": ".ledger/sessions"
  },
  "sources": {
    "memoryKit": {
      "enabled": true,
      "required": false
    },
    "canon": {
      "enabled": true,
      "requiredForHardPolicy": true
    }
  },
  "context": {
    "softCharacterTarget": 6000,
    "hardCharacterCap": 9000,
    "deltaSoftCharacterTarget": 1500,
    "deltaHardCharacterCap": 3000,
    "includeStaleWarnings": true,
    "includeNoisyMemory": false,
    "injectOnlyDeltas": true,
    "rehydrateOn": [
      "resume",
      "clear",
      "fork",
      "compact"
    ]
  },
  "dynamicManifest": {
    "enabled": true,
    "refreshOnToolBatch": true,
    "refreshOnToolFailure": true,
    "deterministicEntityExtraction": true,
    "modelAssistedEntityExtraction": false,
    "persistExternalSessionState": true,
    "maxManifestRevisionsPerTurn": 10
  },
  "coverageGate": {
    "enabled": true,
    "enforcement": "shadow",
    "mutationTools": [
      "Edit",
      "Write",
      "NotebookEdit",
      "Bash"
    ],
    "denyOnceForNewContext": true,
    "maximumHydrationAttemptsPerFingerprint": 1,
    "failPolicy": "fail_open"
  },
  "questionResolution": {
    "searchCompleteStores": true,
    "cacheResolvedNeeds": true,
    "minimumNormalizationConfidence": 0.9,
    "requireExactOptionMapping": true
  },
  "stopRecovery": {
    "enabled": true,
    "classification": "conservative",
    "maximumRecoveriesPerDecisionKey": 1,
    "maximumRecoveriesPerTurn": 2,
    "ignoreWhileBackgroundTasksActive": true
  },
  "subagents": {
    "enabled": true,
    "scopeAgentPrompt": true,
    "injectRepositoryHardPolicy": true,
    "shareTaskResolvedNeedCache": true
  },
  "autonomy": {
    "enabled": false,
    "maximumNewDecisionRisk": "low",
    "maximumEstablishedDecisionRisk": "high",
    "allowEstablishedHighRiskApplication": true,
    "minimumConfidence": 0.95,
    "requiredCalibrationSamples": 50,
    "requiredPrecision": 0.98,
    "mandatoryHumanChangeCategories": [
      "public_contract",
      "database_schema",
      "data_semantics",
      "security",
      "destructive_operation",
      "compliance",
      "production_infrastructure"
    ]
  },
  "capture": {
    "recordAnswers": true,
    "createCandidates": true,
    "createTaskResolvedNeeds": true,
    "autoActivateTaskChoices": true,
    "autoActivatePersonalPreferences": false
  },
  "failurePolicy": {
    "contextRetrieval": "fail_open",
    "hardPolicyEnforcement": "fail_closed",
    "sessionStateWrite": "disable_autonomy",
    "receiptWrite": "disable_autonomy"
  }
}
```

Defaults must be conservative:

- Initial mode: `shadow`.
- Autonomous answer filling: disabled.
- Coverage gate enforcement: shadow-only until calibrated.
- Dynamic manifest refresh: enabled.
- External session state: required for resolve mode.
- Noisy memory: excluded from normal manifests.
- Hard-policy enforcement: separated from optional context retrieval.
- No remote network dependency required for normal local hook execution.

---

## 22. Failure behavior

### 22.1 Optional source unavailable

When Memory Kit or optional Ledger retrieval fails:

- Mark the source degraded.
- Return available context.
- Do not claim that no rule or decision exists.
- Let ordinary read-only work proceed.
- Disable autonomous answers that depend on the unavailable source.
- Record health and latency in the receipt.

### 22.2 Canon unavailable

If Canon owns mandatory enforcement:

- Follow Canon's existing failure policy.
- Do not silently replace missing Canon enforcement with Ledger's semantic interpretation.
- In fail-closed contexts, block only with a clear operational error and remediation.

### 22.3 Session-state write failure

External session state is required for reliable dynamic behavior.

When a state write fails:

- Do not advance the visible manifest revision.
- Disable autonomous question resolution for that decision.
- Disable mutation hydration enforcement if retry state cannot be persisted.
- Fall back to asking the user rather than risk repeated or inconsistent behavior.
- Preserve a concise diagnostic outside model context when possible.

### 22.4 Receipt write failure

Autonomous resolution requires a successful receipt write.

If it fails:

- Do not auto-answer.
- Do not claim coverage.
- Fall back to asking the user.
- Do not reconstruct the receipt later from memory.

### 22.5 Coverage resolution unavailable

In observe or shadow mode:

- Record a would-block event.
- Fail open unless Canon separately requires blocking.

In resolve mode:

- Follow the configured coverage failure policy.
- Never mark an unresolved target as covered.
- Hard-policy-sensitive operations may fail closed.

### 22.6 Conflicts

When authoritative sources conflict:

- Include the conflict in the manifest.
- Do not choose by embedding score.
- Deny consequential mutation when the conflict governs the target.
- Ask a scoped question identifying source IDs and consequences.
- Store the answer as task evidence and possibly a candidate supersession.

### 22.7 Stale source

- Exclude stale entries from autonomous decisions.
- Include concise stale warnings when relevant.
- Attempt narrow revalidation.
- Ask when revalidation cannot establish a current winner.

### 22.8 Malformed or suspicious source content

- Quarantine the candidate.
- Do not inject instructions copied from untrusted code comments or external text.
- Retain a sanitized diagnostic.
- Never let extracted text assign authority to itself.

### 22.9 Discovery extractor failure

- Retain paths and tool identifiers that can be extracted without parsing.
- Skip uncertain concept extraction.
- Rely on the mutation, question, and Stop recovery checkpoints.
- Record the miss for later replay analysis.

### 22.10 Stop-recovery uncertainty

If the final message might be a clarification but classification is uncertain:

- Do not force continuation.
- Allow the message to reach the user.
- Record it as a plain-text-question candidate for calibration.

### 22.11 Retry-loop protection

When a mutation or Stop recovery exceeds its configured attempt cap:

- Stop intercepting that fingerprint or decision key.
- Surface the unresolved state to the user.
- Record the complete receipt chain.
- Never reset the counter merely because Claude paraphrased the same question.

---

## 23. Security and privacy requirements

These requirements are mandatory:

1. Authorize before retrieval.
2. Isolate organization, team, repository, and actor data.
3. Redact or reject secrets and credentials during capture.
4. Do not store `.env` contents, private keys, access tokens, session cookies, production passwords, or customer records.
5. Treat repository comments, issue text, generated documentation, and external pages as untrusted evidence until classified.
6. Never allow source text to assign authority to itself.
7. Record the actor and approval chain for high-authority entries.
8. Prevent user-scoped private preferences from appearing in another user's context.
9. Keep logs concise and avoid storing full prompts when an identifier/hash is sufficient.
10. Support deletion or retention policies for user-generated evidence where required.
11. Validate repository paths and prevent path traversal.
12. Do not execute commands embedded in ledger text.
13. Sanitize context output so it is represented as factual project information, not arbitrary out-of-band instructions.
14. Make remote synchronization opt-in and authenticated.
15. Ensure summaries reference primary source IDs and cannot become circular evidence.
16. Treat tool output and error text as untrusted retrieval hints, not policy.
17. Protect session-state files with user-appropriate filesystem permissions.
18. Prevent state, resolved needs, and private preferences from leaking across sessions, forks, repositories, or actors.
19. Redact secrets from questions, receipts, mutation fingerprints, and Stop messages before persistence.
20. Authorize every dynamic refresh independently; prior manifest access does not imply access to newly discovered scopes.
21. Scope subagent context narrowly and exclude unrelated private Ledger entries.
22. Do not append governed context to shell commands or executable source text; inject it only through supported hook context or agent prompts.
23. Hash or minimize material tool input stored for fingerprints.

---

## 24. Observability and metrics

### 24.1 Required structured events

Emit structured events for:

```text
manifest_compiled
manifest_rehydrated
manifest_refreshed
manifest_delta_created
manifest_delta_injected
manifest_refresh_noop
receipt_written

scope_discovered
scope_frontier_expanded
coverage_checked
coverage_added
coverage_invalidated
coverage_miss
mutation_delayed_for_hydration
mutation_retry_allowed
mutation_blocked_by_conflict

source_query_completed
source_query_failed
candidate_selected
candidate_rejected
conflict_detected
stale_entry_detected
assumption_invalidated

decision_need_normalized
decision_key_cache_hit
question_predicted
question_answered
question_repeated_prevented
prediction_agreed
prediction_disagreed

autonomous_resolution_attempted
autonomous_resolution_applied
autonomous_resolution_aborted
established_decision_applied
new_decision_escalated

plain_text_question_detected
stop_recovery_attempted
stop_recovery_applied
stop_recovery_aborted

subagent_context_compiled
subagent_context_injected

candidate_created
candidate_promoted
candidate_rejected
stop_verification_failed
```

### 24.2 Required metrics

Measure:

- Initial manifest compilation latency.
- Incremental refresh latency by trigger.
- Source-query latency and failure rate.
- Context characters/tokens injected for full manifests and deltas.
- Manifest revisions per turn and per task.
- Delta no-op rate.
- Scope-discovery precision and recall in replay tests.
- Coverage hit, miss, invalidation, and hydration-delay rates.
- Mutation retries caused by coverage.
- Retry-loop prevention activations.
- Decision-key cache hit rate.
- Repeated questions prevented.
- Unnecessary-question prediction precision.
- Necessary-question recall.
- Wrong autonomous-resolution rate.
- Established-decision application accuracy.
- Human override rate.
- Decision compliance rate.
- Rework or revert rate after autonomous decisions.
- Stale-memory incidents.
- Conflict frequency.
- Candidate promotion and rejection rate.
- Plain-text questions bypassing `AskUserQuestion`.
- Stop-recovery success and false-positive rates.
- Subagent context size and scope leakage incidents.
- Session rehydration success and state divergence.

Do not optimize only for fewer questions. The primary safety metrics are:

```text
1. Precision of suppressed questions
2. Accuracy of established-decision application
3. Necessary-question recall
4. Wrong mutation allowed after a context miss
```

---

## 25. Rollout modes

Support these modes as explicit configuration values.

### `observe`

- Compile receipts and metrics.
- Maintain external state.
- Do not inject context.
- Do not delay mutations.
- Do not predict or answer questions.

### `shadow`

- Inject `M0` and dynamic deltas.
- Track scope frontier and coverage.
- Record which mutations would have been delayed.
- Predict answers.
- Let the user answer.
- Compare predictions and coverage decisions with actual outcomes.

### `recommend`

- Inject dynamic context.
- Present likely answers with evidence.
- Warn about uncovered mutation targets.
- Keep the final choice and mutation retry human-visible.

### `resolve`

- Inject dynamic context and enforce configured coverage gates.
- Delay an uncovered mutation once when new relevant context is found.
- Auto-apply eligible established decisions.
- Auto-answer only eligible low-risk new decisions.
- Ask every ineligible, stale, ambiguous, unauthorized, or conflicting question.
- Produce a receipt for every automatic action.

A repository, team, or user may select a lower-autonomy mode than the organization maximum.

Mode should be independently configurable for:

```text
context injection
coverage enforcement
question answering
Stop recovery
subagent context
```

---

## 26. Implementation phases

### Phase 0: repository audit and compatibility baseline

Deliverables:

- Gap analysis document.
- Characterization tests for existing ledger and hook behavior.
- Installed Claude Code version and supported-event matrix.
- Updated architecture diagram reflecting the actual repository.
- Feature flags with conservative defaults.

Exit criteria:

- Existing tests pass unchanged.
- Current behavior is documented.
- Migration and compatibility risks are identified.

### Phase 1: typed ledger and active projection

Deliverables:

- Entry kinds, authority, scope, lifecycle, evidence, retrieval metadata, and autonomy model.
- Append-only event history or compatible event abstraction.
- Active projection.
- Migration of existing records with explicit compatibility rules.
- Receipt persistence.

Exit criteria:

- Existing records remain readable.
- New entries cannot omit required governance fields.
- Supersession, expiry, invalidation, and exact decision-key retrieval are tested.

### Phase 2: read-only resolver, `M0`, and external session state

Deliverables:

- Memory Kit, Canon, and Ledger adapters.
- Full resolver pipeline.
- UserPromptSubmit `M0` injection.
- Revisioned session state.
- Context receipts and `/ledger:why` or equivalent.
- Degraded-source behavior.

Exit criteria:

- A task creates `M0`.
- Session state is persisted outside model context.
- Exact-scope items outrank semantic fallback.
- Context remains within budget.

### Phase 3: dynamic discovery and manifest deltas

Deliverables:

- Deterministic entity extraction.
- Scope frontier.
- `PostToolBatch` or compatible PostToolUse aggregation.
- Failure-driven refresh.
- Manifest diffing and delta injection.
- Coverage records in non-enforcing mode.
- Rehydration after resume and compaction.

Exit criteria:

- Newly discovered relevant scope produces `M1+`.
- Unchanged context is not repeatedly injected.
- Concurrent tool observations preserve a valid receipt chain.
- State survives compaction and resume.

### Phase 4: shadow question and Stop resolution

Deliverables:

- Decision-need normalization and stable decision keys.
- `AskUserQuestion` full-store interception in shadow mode.
- Current-task resolved-need cache.
- Post-answer capture and comparison.
- Conservative plain-text Stop detection and shadow prediction.
- Calibration report.

Exit criteria:

- No question is suppressed.
- Semantically equivalent questions map consistently.
- Human answers become task-local resolved needs.
- Stop candidates are measured for false positives.

### Phase 5: candidate curation

Deliverables:

- Answer classifier.
- Candidate deduplication.
- Approval and rejection workflow.
- Negative evidence and correction handling.
- Expiry for task assumptions.

Exit criteria:

- One answer cannot silently become team policy.
- Repeated observations attach evidence rather than generate duplicates.
- Rejected candidates remain auditable.

### Phase 6: recommendation and coverage advisory

Deliverables:

- Recommendation context for eligible questions.
- Conflict-aware explanation.
- Mutation coverage warnings.
- Scoped subagent context.
- Per-repository and team controls.

Exit criteria:

- Recommendations identify source IDs, intent, and risk.
- Uncovered mutation warnings are accurate enough for enforcement calibration.
- High-risk new decisions remain human-controlled.

### Phase 7: bounded autonomous resolution

Prerequisites:

- Required calibration sample count reached by decision type and intent.
- Precision threshold reached.
- Coverage false-positive rate acceptable.
- Security review completed.
- Receipt and session-state persistence reliable.
- Kill switch verified.

Deliverables:

- Programmatic `AskUserQuestion.answers`.
- Established-versus-new decision eligibility gates.
- Mutation hydration deny-once enforcement.
- Plain-text Stop recovery.
- Per-category and per-repository controls.
- Override tracking.

Exit criteria:

- Only configured new-decision risk levels are auto-answered.
- Established decisions are applied only with exact current authority.
- Every automatic resolution has a receipt.
- Any conflict, staleness, ambiguous option, state-write failure, or receipt failure falls back safely.
- Mutation and Stop loops remain bounded.

### Phase 8: outcome learning and advanced retrieval

Possible later work:

- PR review and merge outcomes.
- Reversion and incident feedback.
- Temporal knowledge graph for cross-system lineage.
- Centralized synchronization.
- Multi-agent resolver API.
- Language-aware symbol graphs.
- Predictive prefetch based on repository dependency graphs.

Do not begin this phase before structured resolution quality is measured.

---

## 27. Test strategy

### 27.1 Unit tests

Cover:

- Scope matching for every dimension.
- Authority ordering.
- Kind-specific conflict precedence.
- Expiry, supersession, invalidation, and staleness.
- Authorization filtering.
- Exact retrieval before semantic fallback.
- Context-budget truncation.
- Manifest ordering and deterministic output.
- Manifest revision monotonicity.
- Delta generation and application.
- Receipt chaining and hashes.
- Scope-frontier normalization.
- Context-coverage validity and invalidation.
- Mutation-target extraction.
- Mutating versus read-only Bash classification.
- Operation fingerprints and retry counters.
- Decision-need normalization.
- Stable decision keys across paraphrases.
- Resolved-need cache validation.
- Established versus new-decision risk classification.
- Autonomous eligibility.
- Question option mapping.
- Plain-text blocking-question classification.
- Candidate deduplication.
- Promotion rules.
- Secret redaction.

### 27.2 Property and invariant tests

Add property-based tests where supported:

- Adding a lower-authority candidate cannot change a higher-authority winner.
- An expired entry can never drive autonomous resolution.
- An unauthorized entry can never appear in output or receipts.
- A hard policy cannot be weakened by a preference.
- Resolver output is stable for the same normalized input and source snapshot.
- Removing semantic scores does not change winners decided by authority and scope.
- Every material manifest change increments the revision exactly once.
- Applying all deltas to `M0` reconstructs the current manifest.
- A no-op refresh does not inject duplicate context.
- Coverage cannot remain valid after its source snapshot is invalidated.
- Read coverage cannot satisfy mutation coverage unless explicitly configured.
- The same decision key and constraints cannot be shown to the user twice in one task.
- A receipt exists for every autonomous resolution.
- Retry counters remain bounded under repeated paraphrases.

### 27.3 Hook contract tests

Use recorded or synthetic Claude Code hook payload fixtures for:

- `SessionStart` startup, resume, clear, compact, and fork.
- `UserPromptSubmit` `M0` context injection.
- `PostToolBatch` with one and several parallel tools.
- `PostToolUseFailure` with command and MCP failures.
- `PreToolUse` mutation target covered and uncovered.
- Mutation hydration deny-once and retry.
- Read-only versus mutating Bash.
- `PreToolUse` with one and several questions.
- Multi-select questions.
- Ambiguous option mapping.
- `PostToolUse` human answers.
- `PreToolUse` on the `Agent` tool.
- `SubagentStart` context injection.
- `Stop` with `last_assistant_message`.
- `Stop` with `stop_hook_active`.
- `Stop` while background tasks are active.
- Source timeout, state-write failure, receipt failure, and malformed input.

Validate that `updatedInput` preserves all original fields.

### 27.4 Adapter integration tests

Use fakes or test instances for:

- Memory Kit exact entity and relationship queries.
- Canon applicability and violation checks.
- Ledger exact decision-key and active-projection queries.
- Source version change and revalidation.
- Source outage and timeout behavior.
- Access-control boundaries.
- Cross-repository and cross-actor isolation.

### 27.5 End-to-end tests

At minimum:

1. Validate the plugin with the Claude Code plugin validator.
2. Load it from a local plugin directory.
3. Submit a task and confirm `M0` is injected.
4. Read a previously unknown module and confirm a relevant delta is injected.
5. Confirm an unrelated read produces no duplicate delta.
6. Trigger a failing test and confirm a relevant assumption is invalidated.
7. Attempt to edit an uncovered target and confirm shadow or deny-once behavior according to mode.
8. Retry the edit and confirm the loop is bounded.
9. Trigger `AskUserQuestion` in shadow mode and confirm the user still receives it.
10. Answer once and confirm the same decision key is not asked again.
11. In controlled resolve mode, confirm a low-risk exact option is auto-filled.
12. Confirm an exact approved established data invariant may be applied without creating new semantics.
13. Confirm a request to change that invariant is escalated.
14. Confirm a stale source prevents autonomous resolution.
15. Confirm a Canon hard policy cannot be overridden by a user preference.
16. Confirm a plain-text blocking clarification is caught by Stop recovery when safely resolvable.
17. Confirm an unresolved plain-text question reaches the user after bounded recovery.
18. Spawn an explore subagent and confirm it receives scoped, read-only context.
19. Compact and resume the session; confirm active context and resolved needs are rehydrated.
20. Confirm optional-source failure does not make ordinary development unusable.

### 27.6 Replay suite

Create fixtures based on realistic tasks with deliberately seeded traps:

- Obsolete architectural decision.
- Conflicting personal and team preferences.
- Path-specific exception.
- Legacy code that violates current Canon.
- Recently changed data derivation.
- Low-risk implementation detail that should be resolved.
- Existing high-risk invariant that should be applied.
- High-risk semantic change that must be escalated.
- Highly similar but out-of-scope memory.
- Unauthorized cross-team knowledge.
- Relevant module discovered only after several reads.
- Failure output revealing a hidden dependency.
- Repeated paraphrased clarification.
- Subagent discovering new scope.
- Context compaction midway through implementation.
- Mutation retry loop.

Compare behavior for:

```text
Claude Code alone
Memory Kit only
Memory Kit + Canon
Memory Kit + Canon + static Ledger manifest
Memory Kit + Canon + dynamic Ledger Resolver
```

---

## 28. Acceptance criteria

The dynamic-context MVP is complete when all of the following are true:

1. Ledger distinguishes facts, invariants, policies, decisions, preferences, heuristics, assumptions, exceptions, and constraints.
2. Every active entry has scope, authority, lifecycle, provenance, retrieval, and autonomy metadata.
3. Existing Ledger records are migrated or exposed through a documented compatibility layer.
4. The resolver reads from Memory Kit, Canon, and Ledger through adapters.
5. A task prompt produces manifest revision `M0`.
6. The manifest is persisted outside model context.
7. Every material update produces a monotonically increasing revision, delta, and receipt.
8. Reading a previously unknown module produces a delta when relevant context exists.
9. Unchanged context is not repeatedly injected.
10. Scope-frontier and context-coverage state are inspectable.
11. An uncovered consequential mutation is resolved before enforcement mode permits it.
12. A mutation delayed for context hydration can retry without an infinite loop.
13. Tool failure can invalidate assumptions and add relevant context.
14. Every manifest and delta produces a Context Receipt.
15. Receipts explain selected, rejected, stale, conflicting, added, removed, and invalidated items.
16. Authority and scope are applied before semantic relevance.
17. Canon mandatory rules cannot be overridden by Ledger preferences.
18. Questions are normalized into stable decision keys.
19. Semantically equivalent questions reuse the same compatible resolved need.
20. Before a question reaches the user, full authorized stores and task caches are searched.
21. Shadow mode records predictions without suppressing questions.
22. Human answers immediately become task-scoped resolved needs.
23. Broad policy requires explicit approval.
24. Stale, unauthorized, ambiguous, or conflicted entries cannot drive autonomous resolution.
25. The autonomy gate distinguishes applying established decisions from making new decisions.
26. Changing high-risk semantics always escalates.
27. Resolve mode is disabled by default and protected by configuration.
28. Every automatic `AskUserQuestion` answer maps exactly to a presented option and has a successful receipt.
29. A plain-text blocking clarification is conservatively evaluated by the Stop hook.
30. Stop recovery is bounded and does not loop indefinitely.
31. Subagents receive scoped context and do not receive unrelated private entries.
32. Manifest state survives supported resume and compaction flows.
33. Session forks have isolated mutable task state.
34. Failure of optional context retrieval does not make Claude Code unusable.
35. Failure of required hard-policy enforcement follows configured fail-closed behavior.
36. State-write or receipt-write failure disables autonomy safely.
37. Plugin validation passes.
38. Unit, property, integration, hook-contract, replay, and end-to-end tests pass.
39. Documentation covers configuration, modes, migration, troubleshooting, rollback, and dynamic lifecycle.
40. Metrics report question precision, coverage misses, overrides, conflicts, staleness, latency, context size, and Stop-recovery accuracy.

---

## 29. Suggested implementation sequence for Claude Code

Execute in this order unless the existing repository creates a clear dependency reason to adjust it:

1. Read the repository structure and existing plugin documentation.
2. Determine the installed Claude Code version and supported hook events.
3. Run all current tests and record the baseline.
4. Write the gap analysis.
5. Add characterization tests for unclear behavior.
6. Introduce domain types without changing runtime behavior.
7. Add persistence migrations and compatibility projection.
8. Add retrieval metadata and exact decision-key indexes.
9. Add source adapter interfaces and wrap current integrations.
10. Implement exact structured retrieval and lifecycle filtering.
11. Implement kind-specific precedence and conflict detection.
12. Implement receipt persistence and receipt chaining.
13. Implement external session state with transactional revision updates.
14. Implement `M0` compilation.
15. Add `UserPromptSubmit` injection behind a feature flag.
16. Implement scope-frontier and deterministic entity extraction.
17. Implement manifest diffing and compact delta rendering.
18. Integrate `PostToolBatch`, with `PostToolUse` fallback.
19. Integrate failure-driven refresh.
20. Implement coverage records in shadow mode.
21. Implement decision-need normalization and stable decision keys.
22. Add `AskUserQuestion` shadow interception against full stores.
23. Add task-local resolved-need caching and answer capture.
24. Add conservative Stop-question detection in shadow mode.
25. Add scoped `Agent` and `SubagentStart` context.
26. Add resume and compaction rehydration.
27. Add explanation and administration commands or skills.
28. Add observability and calibration reporting.
29. Run replay tests and collect shadow metrics.
30. Only after thresholds are met, enable recommendation mode.
31. Only after separate review, enable bounded mutation hydration and autonomous question resolution.
32. Run unit, property, integration, end-to-end, migration, and plugin-validation checks.
33. Update documentation and changelog.
34. Report completed phases, deferred phases, migrations, compatibility risks, and exact commands run.

Do not enable autonomous resolution or mutation blocking by default during the first implementation pass.

---

## 30. Expected deliverables

Claude Code should leave the repository with:

- Updated Ledger plugin implementation.
- Gap analysis.
- Architecture documentation and lifecycle diagram.
- Domain-model documentation.
- Persistence migration and rollback notes.
- Source adapter documentation.
- Dynamic manifest and delta specification.
- External session-state specification.
- Context-coverage and mutation-gate specification.
- Decision-need normalization and cache specification.
- Hook payload fixtures.
- Tests covering resolver and dynamic-lifecycle invariants.
- Configuration reference.
- User guide for context, explanation, coverage, candidates, approvals, and modes.
- Operational troubleshooting guide.
- Security considerations.
- Changelog entry.
- Final implementation report containing:
  - Changed files.
  - Implemented requirements.
  - Deferred requirements and reasons.
  - Migration behavior.
  - Claude Code version and validated hook features.
  - Commands and tests run.
  - Known risks.
  - Calibration results.
  - Recommended next phase.

---

## 31. Example scenarios

### Scenario A: low-risk choice already covered by team preference

Question:

```text
Should this new validator use the repository's existing schema library or introduce another library?
```

Relevant context:

- `CANON-21`: new runtime validation must use an approved schema library.
- `PREF-14`: this repository defaults to Effect Schema.
- No exception or conflict.
- Internal and reversible.

Expected behavior:

- Shadow mode predicts `Effect Schema`.
- Resolve mode may auto-answer when calibrated and option mapping is exact.
- Receipt cites `CANON-21` and `PREF-14`.

### Scenario B: established high-risk data invariant

Question:

```text
Should this existing position export use UTC calendar date or exchange trading date?
```

Relevant context:

- `MEM-201`: trading date follows the exchange calendar.
- `DEC-182`: position exports expose exchange trading date.
- Both are current, approved, exact-scope, and unconflicted.
- The implementation preserves existing semantics.

Expected behavior:

- Classify intent as `apply_established`, not `choose_new`.
- Apply exchange trading date when configured established-decision policy permits.
- Do not ask the user to restate an already approved invariant.
- Any attempt to change the semantics is separately escalated.

### Scenario C: data-semantics conflict

Question:

```text
Should trade date be calculated in UTC or exchange-local time?
```

Relevant context:

- `MEM-201`: trade date follows the exchange calendar.
- A current schema contract appears to state UTC calendar date.
- No explicit supersession.
- Data meaning is high risk.

Expected behavior:

- Emit a conflict.
- Do not auto-answer.
- Ask the owner with source IDs and consequences.
- Capture the answer as task evidence and a candidate correction or supersession.

### Scenario D: context discovered after implementation starts

Initial task:

```text
Add CSV export to position history.
```

`M0` includes only `position-api`.

During a read, Claude discovers:

- `exchange-calendar`.
- `exchange_sessions`.
- `trading date`.

Expected behavior:

- Expand the scope frontier.
- Query all sources for those entities.
- Produce `M1` containing `MEM-441` and `DEC-182`.
- Inject only the delta.
- Invalidate an incompatible UTC-date assumption.

### Scenario E: mutation reaches an uncovered module

Claude attempts to edit:

```text
src/calendar/trading-date.ts
```

Current coverage contains only:

```text
src/positions/**
```

Expected behavior:

- Resolve context for `src/calendar/**`.
- If new relevant context is found, delay the first edit and inject the delta.
- Permit a compliant retry.
- Prevent repeated hydration denial through the operation fingerprint.

### Scenario F: proactive discovery misses, question checkpoint succeeds

Claude asks:

```text
Should retries preserve the existing request ID?
```

The current manifest lacks the answer, but Ledger contains:

- `DEC-309`: retry attempts preserve request IDs for reconciliation.

Expected behavior:

- Search the complete Ledger, not only the manifest.
- Add the resolution to the active manifest and task cache.
- Auto-answer only when eligibility and option mapping pass.
- Prevent the same question from recurring.

### Scenario G: plain-text clarification bypasses the tool

Claude attempts to stop with:

```text
I cannot continue until I know whether retries preserve the request ID.
```

Expected behavior:

- Stop hook classifies the message as blocked on clarification.
- Resolver finds `DEC-309`.
- Stop feedback injects the resolution and keeps Claude working.
- The same decision key is recovered at most once without new evidence.

### Scenario H: stale memory

Question:

```text
Should this service use the v1 or v2 settlement endpoint?
```

Relevant context:

- Memory Kit says v1.
- Its source changed after validation.
- An approved v2 decision applies only to another service.

Expected behavior:

- Mark v1 stale.
- Reject v2 as scope mismatch.
- Ask the user.
- Do not guess from recency or semantic similarity.

### Scenario I: personal preference versus mandatory policy

Question:

```text
Can this handler query ClickHouse directly for convenience?
```

Relevant context:

- Personal preference supports direct queries for prototypes.
- Canon mandates service-layer access.

Expected behavior:

- Canon wins.
- Ledger may answer “No” as an established policy application.
- Record the personal preference as rejected due to lower authority.

### Scenario J: task-local workaround

User answer:

```text
Use the existing parser only for this migration; remove it after the backfill.
```

Expected behavior:

- Create a task-scoped resolved need and assumption or exception.
- Set an expiry or invalidation condition tied to migration completion.
- Do not promote it to repository-wide preference.

### Scenario K: scoped subagent

The parent launches an Explore subagent for:

```text
src/calendar/**
```

Expected behavior:

- `PreToolUse` on `Agent` appends only calendar-relevant decisions and hard policy.
- `SubagentStart` injects session and manifest identifiers.
- The subagent reports newly discovered entities.
- Actor-private preferences unrelated to the task are excluded.

---

## 32. Design decisions that should remain stable

Unless the existing implementation already has an equivalent superior mechanism, preserve these decisions:

1. Resolver core is agent-agnostic.
2. Raw events and evidence are append-only.
3. Active records are projections.
4. Entry kind is first-class.
5. Authority, scope, lifecycle, retrieval metadata, and autonomy are explicit.
6. Precedence is lexicographic and kind-specific, not one weighted score.
7. Exact structured retrieval precedes semantic fallback.
8. The Task Context Manifest is a revisioned external materialized view.
9. `M0` is intentionally incomplete.
10. Runtime context updates are deltas.
11. Scope frontier and context coverage are first-class.
12. Mutation coverage is checked before consequential uncovered work in enforcement mode.
13. Questions search complete stores, not only the manifest.
14. Semantically equivalent questions use stable decision keys.
15. Human task answers become immediate task-local resolved needs.
16. Receipts are mandatory for autonomy and coverage claims.
17. Shadow mode precedes enforcement and resolve modes.
18. Established-decision application and new-decision selection use separate autonomy ceilings.
19. High-risk changes remain human-controlled.
20. Canon owns deterministic coding-policy enforcement.
21. Memory Kit owns system knowledge; Ledger references it rather than copying indiscriminately.
22. User answers become evidence before durable organizational truth.
23. Stop recovery is conservative and bounded.
24. Subagent context is scoped.
25. Session state survives supported compaction and resume flows.

---

## 33. Open implementation choices and defaults

Resolve these from the repository where possible. Use the defaults below only when the repository provides no answer.

| Choice | Preferred source | Default |
|---|---|---|
| Runtime/language | Existing plugin | Preserve current runtime; TypeScript examples are illustrative |
| Persistence | Existing Ledger store | SQLite for local MVP if no store exists |
| Session state | Existing persistence | Transactional table keyed by session ID |
| Search | Existing index | Exact structured SQL/full-text first; embeddings optional |
| Entity extraction | Existing parser/LSP | Deterministic parser and regex aliases |
| Memory Kit integration | Existing contract | Narrow local CLI/HTTP/MCP adapter |
| Canon integration | Existing contract | Read applicable rules and delegate enforcement |
| Identity | Existing organization identity | Local actor marked non-authoritative if unavailable |
| Approval UI | Existing CLI/UI | CLI or skill commands |
| Post-tool aggregation | Installed Claude Code | `PostToolBatch`; `PostToolUse` fallback |
| Mutation classification | Canon/existing command parser | Conservative; unknown Bash treated as potentially mutating in enforcement mode |
| Coverage enforcement | Organization/team config | Shadow only |
| Stop classifier | Existing local classifier | Conservative deterministic rules |
| Subagent scoping | Agent tool input | Append compact context to subagent prompt |
| Remote synchronization | Existing platform | Disabled in MVP |
| Autonomous answers | Organization/team config | Disabled; shadow enabled |
| New-decision risk | Policy | Maximum `low` |
| Established-decision risk | Policy | Maximum `high` when exact and approved |
| Full context size | Existing constraints | 6,000 soft / 9,000 hard characters |
| Delta size | Existing constraints | 1,500 soft / 3,000 hard characters |

Document every default used because repository evidence was unavailable.

---

## 34. Claude Code compatibility notes

The implementation must account for current official integration behavior and verify it against the installed version:

- Plugin hooks are packaged in `hooks/hooks.json` or inline in the plugin manifest.
- `SessionStart` runs for startup, resume, clear, compact, and fork and can inject context. It cannot block.
- `UserPromptSubmit` can inject `additionalContext`; it should remain fast because it runs before model processing.
- `PreToolUse` can allow, deny, ask, defer, replace complete tool input, and add context.
- For `AskUserQuestion`, an `answers` map can be supplied through `PreToolUse.updatedInput`; the original `questions` array must be preserved.
- `updatedInput` replaces the entire tool input, so every unchanged field must be echoed.
- A `PreToolUse` denial reason is visible to Claude and is suitable for a one-time mutation hydration delay.
- Context returned by an allowed `PreToolUse` call is delivered with the tool result, so it cannot reliably change the already-proposed mutation. Deny and retry when the model must reconsider new context before execution.
- `PostToolUse` receives successful tool information.
- `PostToolUseFailure` can inject corrective context after a started tool fails.
- `PostToolBatch` fires once after the complete parallel batch, has no matcher, and can inject one aggregated context delta before the next model call.
- `SubagentStart` can inject context but does not provide all assignment details. Use `PreToolUse` on the `Agent` tool to scope or augment the subagent prompt.
- `Stop` receives `last_assistant_message` and `stop_hook_active` and may keep the conversation running with additional context or a block decision.
- Claude Code applies an outer limit to repeated Stop continuations; Ledger must enforce a stricter internal cap.
- `SessionEnd` is for side effects and cannot deliver context back to Claude.
- Permission rules still apply even when Ledger recommends or supplies an answer.
- Static repository conventions are better kept in normal Claude instructions; dynamic task context belongs in Ledger hooks.
- Hook outputs and tool responses may be truncated or version-dependent. Parse conservatively.
- Validate the plugin with the installed Claude Code plugin validator and run recorded hook-contract fixtures.
- Do not hard-code undocumented internal state.

When a required event is unavailable:

```text
PostToolBatch unavailable -> aggregate PostToolUse events with locking
SubagentStart unavailable -> embed scoped context in Agent prompt
Stop last message unavailable -> disable plain-text recovery
Session compact source unavailable -> rehydrate on next prompt
```

Feature degradation must be explicit in `/ledger:doctor`.

---

## 35. Final implementation instruction

Implement this specification as an incremental upgrade of the current Ledger plugin.

The first safe production milestone is:

```text
Typed governed ledger
+ active projection and exact retrieval metadata
+ Memory Kit and Canon adapters
+ revisioned external session state
+ initial manifest M0
+ dynamic scope discovery
+ compact manifest deltas
+ non-enforcing context coverage
+ stable decision keys
+ shadow AskUserQuestion prediction
+ task-local resolved-need cache
+ shadow Stop-question detection
+ human-answer evidence capture
+ completion verification
```

Do not enable automatic question answering, Stop continuation, or mutation denial until shadow evidence demonstrates sufficient precision for each enabled category and the receipt, session-state, security, and rollback paths have been verified.

The resulting system should make Claude Code more autonomous because it receives **governed, scoped, current, continuously refreshed, explainable context** before consequential actions—not because it has been instructed to guess more aggressively.

The product principle remains:

> **Do not eliminate questions. Eliminate questions whose answers the organization has already established.**

---

## 36. Official compatibility references

These references are implementation inputs, not substitutes for validating the installed Claude Code version:

- Claude Code hooks reference: https://code.claude.com/docs/en/hooks
- Claude Code plugins reference: https://code.claude.com/docs/en/plugins-reference

Compatibility review date: `2026-09-03`.

