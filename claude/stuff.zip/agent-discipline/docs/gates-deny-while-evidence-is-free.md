---
title: Gates deny at the moment the evidence is still free
code_refs:
  - hooks/mr-proof-gate.py
  - hooks/due-date-gate.py
  - hooks/comment-bloat-gate.py
  - rules/comment-density.md
---

# Gates deny at the moment the evidence is still free

Most hooks in this plugin inform and never block, because a blocking hook breaks unattended
runs. These three block, and the reason is the same in both: the thing they demand costs nothing
at the instant the command is typed, and cannot be reconstructed afterwards.

| Gate | Denies | Because after that moment |
| --- | --- | --- |
| `mr-proof-gate.py` | `glab mr create` whose body has no `## Proof` section AND no artifact | the MR is already in front of the reviewer; a nudge is too late, and the worker no longer holds the terminal that produced the output |
| `due-date-gate.py` | `bd create` / `jira.py create` with no due date | an undated issue can never be late, so it is never the thing anyone picks up — it is not a backlog item, it is a disappearance |
| `comment-bloat-gate.py` | a `Write` / `Edit` to a code file carrying a paragraph of more than 5 consecutive comment-prose lines | the essay is on disk and the model has moved on; nobody deletes a paragraph they did not write, so it stays and goes stale |

## A claim is not evidence

Both gates reject the shape that looks like compliance:

- A `## Proof` heading over the sentence "all tests pass" is denied. The heading is not the
  artifact; a fenced run, a screenshot or a `tmux capture-pane` tail is.
- A due date invented without looking at the queue is a number, not a commitment. So the deny
  prints what is already overdue or due within two weeks, at what priority — the date is chosen
  against that list or it is not chosen at all.

## Every gate names its escape hatch

A gate with no exit gets worked around, and the workaround is invisible. Both name theirs in
the deny text:

- `--fill` chore MRs skip the proof gate — nobody reviews them.
- Genuinely unprovable work (interactive TTY, real hardware) passes by saying so **in the body**
  under Proof, with the manual transcript. Silence is not a pass.
- Small beads-only issues (P3/P4, no `jira:` label) skip the due-date gate — the tiering rule
  already says cleanup-in-passing should not become scheduling noise.
- Work that genuinely has no date yet is `bd defer --until=<date>`, which is a decision. An
  empty due date is not.

## Comment bloat

`rules/comment-density.md` sets the cap and `hooks/comment-bloat-gate.py` enforces it: 5
consecutive lines of comment prose, header or mid-function. It counts paragraphs, not blocks — a
lone `#` ends one and an indented line never counts, so a twelve-line usage listing passes and a
six-line paragraph of narration does not. Prose files are skipped.

The rule already existed in the always-load tier and still drifted — a long session produced a
twenty-line prose header in front of eight lines of shell. That is the argument for the hook and
not for more prose: a rule the model has to remember at the moment of writing loses to the
context it is competing with, so the check runs at the moment of the write instead.

The deny names the file, the line the paragraph starts on, its length, and the three moves that
fix it — keep the non-obvious constraint, delete the restatement and the history, move a
real explanation into `docs/` where `code_refs` keeps it honest.
