---
code_refs:
  - ledger/__init__.py
  - src/agent_discipline/__init__.py
  - scripts/ledger-inspect.py
  - scripts/ledger-why.py
---

# Ledger Context Governor — repository gap analysis

Required by the specification's §2 repository-first workflow, against
`docs/ledger-context-governor-implementation-spec.md` v0.2.0.
Audited 2026-09-03 at commit `23290c1`.

## 0. The finding that shapes everything else

The specification is written for a **service**: a database, migrations, repositories, services,
adapters, HTTP endpoints, MCP tools. This repository is a **Claude Code plugin made of standalone
Python scripts and bash hooks**, and its ledger is **markdown files in the user's memory
directory, outside this repository**.

| Spec assumes | This repo has |
|---|---|
| database + migrations | markdown files + append-only TSV; no database, no migration mechanism |
| repositories / services / DI | 22 standalone scripts, no shared package, no imports between them |
| an ORM data model | YAML frontmatter and `**Bold:**` body lines parsed with regular expressions |
| HTTP endpoints, MCP tools | slash commands and hooks only |
| the ledger inside the repo | `~/.claude/projects/<enc>/memory/topics/pref-*.md`, user-owned, git-ignored |

§2 anticipates this: *"When the repository differs from examples in this document, preserve the
intent and adapt the implementation shape."* This analysis therefore maps every requirement onto
the shapes that exist here, and states plainly where a spec construct has no counterpart.

**The single largest consequence:** the ledger's storage is **not owned by this repository**. It
is the user's memory directory, shared with memory-kit, written by other tools and by hand. Any
typed schema, migration, or projection must therefore be *additive and reversible*, and must keep
the existing markdown readable by memory-kit's recall hook. A destructive migration here would
damage user data that predates this plugin.

## 1. Runtime, language, package manager, build, tests

| Aspect | Finding | Evidence |
|---|---|---|
| Language | Python 3 and bash | 22 `.py` (3,282 lines), 20 `.sh` (1,518 lines) |
| Declared runtime | `requires-python = ">=3.14"` | `pyproject.toml` |
| Interpreter on PATH | Python **3.12.3** | `python3 --version` |
| Provisioned interpreter | Python **3.14.3** via `uv` | `uv run python -c ...` |
| Package manager | `uv` 0.12.5, `uv.lock` present | `uv --version` |
| Build backend | `uv_build>=0.12.5,<0.13.0` | `pyproject.toml` |
| Package | `src/agent_discipline/__init__.py` — **a `main()` that prints a greeting** | the file |
| Dev dependencies | `mutmut>=3.7.0` (brings `pytest` 9.1.1 transitively) | `pyproject.toml`, `uv run pytest --version` |
| Test framework | **None.** Nine `tests/*.sh` driving real entry points, plus `tests/test_gates.py`, a script of `assert`s | `tests/` |
| `uv run pytest` | **Collects 0 tests.** | `uv run pytest --collect-only -q` |

**Compatibility risk (high).** The `pyproject.toml`/`src/` package skeleton was added in commit
`dcfbe9a` and is **empty of real code** — every script and hook lives outside it and is executed
by absolute path, not imported. Nothing in the plugin is installed or imported as
`agent_discipline`. Phase 1's "typed ledger" is the first thing that would justify that package.

**Compatibility risk (high).** The declared floor `>=3.14` exceeds the interpreter on PATH
(3.12.3). Hooks are executed by Claude Code as `#!/usr/bin/env python3`, i.e. **3.12.3, not the
uv environment**. Any new typed-ledger code imported by a hook must therefore run on 3.12, or
hooks must be rewritten to enter the uv environment. This is a genuine fork in the road and is
recorded as risk R1.

## 2. Claude Code plugin structure and manifest

```
.claude-plugin/plugin.json     name, version 0.1.0, description, author, license, keywords
.claude-plugin/marketplace.json
hooks/hooks.json               8 handler registrations
hooks/*.py *.sh                8 handlers
commands/*.md                  9 slash commands
skills/*/SKILL.md              6 plugin skills
rules/*.md                     2 always-load rules, symlinked into ~/.claude/rules by install.sh
scripts/*.py *.sh              17 executables
install.sh, bootstrap.sh       installer; registers the marketplace and enables the plugin
```

`plugin.json` carries **no `hooks` key** — hooks are discovered from `hooks/hooks.json`. There is
no MCP server, no LSP server, no agents directory.

## 3. Hook registrations

| Event | Matcher | Handler | Blocking? |
|---|---|---|---|
| `PreToolUse` | `AskUserQuestion` | `pref-checkpoint.py` | **Yes — `permissionDecision: deny`**, once per session per question hash |
| `PostToolUse` | `Skill` | `pref-preload-on-skill.py` | no |
| `PostToolUse` | `Bash` | `jira-drift-checkpoint.py` | no |
| `PostToolUse` | `Bash` | `worktree-delegate-nudge.py` | no |
| `PostToolUse` | `Bash` | `glab-autowatch.sh` | no |
| `PostToolUse` | `Edit\|Write\|MultiEdit` | `orchestrator-hands-off.py` | no |
| `UserPromptSubmit` | `*` | `pref-capture-nudge.py` | no |
| `SessionStart` | `startup` | `always-load-budget-warn.py` | no |

**Not registered, and required by the spec:** `SessionEnd`, `Stop`, `PostToolUseFailure`,
`PostToolBatch`, `SubagentStart`, `PreToolUse` for `Agent`, `PostToolUse` for `AskUserQuestion`.

### Installed Claude Code and supported-event matrix

Claude Code **2.1.259**. Events observed in use on this machine
(`~/.claude/settings.json`) or in the published plugin catalog:

| Event | Available | Evidence |
|---|---|---|
| `PreToolUse`, `PostToolUse`, `UserPromptSubmit`, `SessionStart`, `SessionEnd`, `Stop` | yes | configured locally |
| `PostToolUseFailure` | yes | configured locally (1 handler) |
| `SubagentStart`, `SubagentStop` | yes | configured locally |
| `PostToolBatch` | yes | registered by a published plugin in `plugin-catalog-cache.json` |
| `Notification`, `PermissionRequest`, `StopFailure`, `TeammateIdle` | yes | configured locally |
| `PreCompact` | **unverified** | not configured locally, not seen in the catalog — treat as unavailable until proven |

The spec's §18.13 compaction handling therefore cannot rely on `PreCompact`; rehydration must be
driven from `SessionStart` instead. Recorded as risk R4.

## 4. Data models, persistence, migrations, repositories, services

There is **no database, no ORM, no migration mechanism, and no repository or service layer.**
Persistence is files:

| Store | Path | Shape | Owner |
|---|---|---|---|
| Ledger entries | `<memory>/topics/pref-*.md` | YAML frontmatter + `**Bold:**` body lines | **user / memory-kit** |
| Ledger events | `<memory>/pref_events.tsv` | append-only TSV: `ts,kind,session,detail,extra` | this plugin |
| Rule effects | `<memory>/rule_effect_log.tsv` | append-only TSV: `iso_ts,session_id,event,rule_key,summary,evidence` | memory-kit + this plugin |
| Blockers | `<memory>/blocker_log.tsv` | append-only TSV | this plugin |
| Question-seen state | `~/.claude/tmp/pref-checkpoint/<session_id>.json` | a JSON array of question hashes | this plugin |
| Delegation state | `<worktree>/.claude/delegate.json` | JSON: task, dod, round, history, status | this plugin |
| Verification handbook | `<repo>/.claude/skills/verify-changes/SKILL.md` | generated skill + preserved learned section | this plugin |

`agent_discipline_paths.py` resolves the memory directory at runtime from `$HOME`
(`AGENT_DISCIPLINE_MEMORY_DIR` overrides). It is the closest thing to a persistence abstraction
and **should be the seam** the typed ledger is built behind.

**The append-only event log already exists** in a compatible form (`pref_events.tsv`), and
`~/.claude/tmp/pref-checkpoint/<sid>.json` is already **external session state** — unrevisioned,
but outside model context. Both are reusable rather than replaceable.

## 5. Interfaces to Memory Kit and Canon

Both are consumed **as files, at conventional paths**; there is no API, and no import of their
internals.

| Source | How this repo touches it |
|---|---|
| Memory Kit | reads `topics/pref-*.md`; reuses `memory_cue.ASCII_STOP` via a `sys.path` insert into `~/.claude/scripts`, wrapped in `try/except` so absence degrades rather than fails; writes through `~/.claude/scripts/memory-capture-append.py` |
| Canon | **no code path touches canon at all.** Canon reaches the model only as always-load rules injected by memory-kit's SessionStart hook |

**Gap:** the spec's §13.2 canon adapter has no counterpart. Canon is currently *context*, not a
*queryable source*, and its authority (`mandatory` policy outranking personal preference, §10) is
enforced only by the model reading rule text.

## 6. Ledger entry types, scope, precedence, approval, audit

The existing ledger is a **single flat kind** with no scope and no precedence.

| Spec construct | Existing counterpart |
|---|---|
| Entry kinds (§8) | one implicit kind: a preference record |
| Scope (§9) | **none.** Files are global to the user; no repo/path/entity scoping |
| Scope specificity (§9.2) | none |
| Authority (§10) | `confidence: stated \| derived-strong \| derived-weak` — an *evidence-strength* axis, not an authority one |
| Lifecycle (§11) | `status: provisional \| settled`, `observations: <n>`, `modified:` — no supersession, expiry, or invalidation |
| Evidence (§12.2) | prose `**Why:**` with an optional quote; `originSessionId` in frontmatter |
| Active projection (§12.5) | none — every matching file is a hit |
| Retrieval metadata (§12.6) | `description` + `triggers` frontmatter, consumed by lexical scoring |
| Exact decision-key retrieval | **none.** Retrieval is `score >= 2` over token overlap; there is no key |
| Approval workflow | none — records are written directly by the model |
| Audit | `pref_events.tsv` (`deny`, `reissued`) and `rule_effect_log.tsv` (`human-correction`, `disposition`) |

**Precedence today is `sort(reverse=True)` on a lexical score, truncated to the top 3.** Nothing
distinguishes a mandatory policy from a weak personal inference.

## 7. CLI commands, skills, MCP tools, HTTP endpoints, UI

Slash commands: `/ledger`, `/drift`, `/blockers`, `/reap`, `/automerge`, `/delegate`,
`/orchestrate`, `/testing-handbook`. Plugin skills: `preference-ledger`, `mr-automerge`,
`delegate-to-worktree`, `orchestrate`, `testing-handbook`. **No MCP tools, no HTTP endpoints, no
UI.** Output is terminal text and hook `additionalContext`.

There is **no `/ledger:why`** or any receipt-explaining surface (spec §20). `/ledger` today is
`scripts/agent-dashboard.py`, an effectiveness dashboard, not a per-decision explanation.

## 8. Observability

Structured events exist but are **TSV rows, not the spec's event schema**. `--selftest` on the
dashboard and the drift audit runs a positive *and* a negative control — a discipline the spec's
§27 property tests should preserve. There is no tracing, no metrics export, and no log levels.
Error handling is per-script `try/except` with a bias to degrade silently, except where a
previous incident forced loudness.

## 9. Compatibility promises and public APIs

| Surface | Promise |
|---|---|
| `pref-*.md` frontmatter (`description`, `triggers`) | **shared with memory-kit's recall hook.** Changing these keys breaks retrieval in a tool this repo does not own |
| `pref_events.tsv` columns | read by `scripts/agent-dashboard.py` |
| `rule_effect_log.tsv` columns | written by memory-kit's cadence hook; schema is memory-kit's |
| Slash command names | user-facing muscle memory |
| `~/.scripts/*.sh` symlinks | referenced by the user's worktrunk config |
| `install.sh` flags | documented in README |

**The frontmatter contract is the sharpest constraint on Phase 1.** A typed entry may *add* keys;
it may not rename or repurpose `description` or `triggers`.

## 10. Requirement matrix

Statuses: `implemented` · `partially implemented` · `missing` · `incompatible` ·
`intentionally deferred`.

### Phase 0 — audit and baseline

| # | Requirement | Status | Note |
|---|---|---|---|
| 0.1 | Gap analysis document | implemented | this file |
| 0.2 | Characterization tests for existing ledger and hook behavior | missing | to be added this phase |
| 0.3 | Installed Claude Code version and supported-event matrix | implemented | §3 above; `PreCompact` unverified |
| 0.4 | Updated architecture diagram reflecting the actual repository | missing | `docs/gen_mechanism.py` exists and is the right place |
| 0.5 | Feature flags with conservative defaults | missing | to be added this phase |
| 0.6 | Existing tests pass unchanged | implemented | 9 shell suites + `test_gates.py` green at `23290c1` |

### Phase 1 — typed ledger and active projection

Implemented 2026-09-03. `ledger/` at the repository root: `types.py`, `events.py`,
`projection.py`, `compat.py`. Pure Python, 3.12-compatible, and free of Claude Code hook payload
types per R-013 — asserted by a test that greps the package for `tool_input` and
`hookSpecificOutput`.

| # | Requirement | Status | Note |
|---|---|---|---|
| 1.1 | Entry kinds | implemented | all ten `KINDS`, spec strings verbatim |
| 1.2 | Authority model | implemented | all eleven `AUTHORITIES`; order IS the precedence rule. `confidence` is left alone as the evidence axis it always was, and mapped to authority rather than renamed |
| 1.3 | Scope model and specificity | implemented | `Scope` with every dimension optional; a missing dimension is "not constrained", never global authority |
| 1.4 | Lifecycle: supersede, expire, invalidate | implemented | ten `STATUSES`, a transition table, and `is_active()` that consults the clock, not only the status |
| 1.5 | Evidence records | **partially implemented** | entries carry `evidence_ids` and `source_references`, but the §12.2 `Evidence` record type itself is not built. Deferred to Phase 2, where the adapters produce it |
| 1.6 | Retrieval metadata | implemented | all fifteen `RetrievalMetadata` fields |
| 1.7 | Autonomy model | implemented | five `AUTONOMY` levels |
| 1.8 | Append-only event history | implemented | `EventLog`, JSONL, its own file so the dashboard's positional TSV columns are untouched (R3). A torn line does not lose the rest of the history |
| 1.9 | Active projection | implemented | `ActiveProjection`; only active AND in-date entries answer a query |
| 1.10 | Migration with explicit compatibility rules | implemented **as a compatibility projection** | §2 permits either. A projection is the right half here: the store is the user's, shared with memory-kit. **Nothing writes.** The mapping is stated field by field at the top of `compat.py` |
| 1.11 | Receipt persistence | implemented | `ReceiptStore`, with `considered`/`selected`/`rejected`/`conflicts`/`stale` states enforced |
| 1.12 | Exact decision-key retrieval | implemented | `decision_key()` is stable and scope-aware, and deliberately NOT session-dependent — unlike the existing question hash |

**Exit criteria — all met.**

- *Existing records remain readable* — 25 of the user's 26 real records read as typed entries.
  The 26th, `pref-delegate-to-worktree-claude.md`, uses `**Rule:**` instead of `**Preference:**`.
  **Today's live hook skips it silently too**, so this is a pre-existing invisibility, not a
  regression — but it is now reported rather than dropped. That record has never participated in
  retrieval.
- *New entries cannot omit required governance fields* — construction raises `LedgerError`.
- *Supersession, expiry, invalidation and exact decision-key retrieval are tested* — 45 tests.

**Proven to have teeth.** Three mutations, each caught: ranking by specificity before authority
(1 test), ignoring expiry (2), and treating a missing scope dimension as a match (1).

### Phase 2 — resolver, `M0`, external session state

| # | Requirement | Status | Note |
|---|---|---|---|
| 2.1 | Memory Kit adapter | partially implemented | direct file reads + `memory_cue` import |
| 2.2 | Canon adapter | missing | no code path touches canon |
| 2.3 | Ledger adapter | partially implemented | the reader inside `pref-checkpoint.py`, not extracted |
| 2.4 | Full resolver pipeline | missing | |
| 2.5 | `UserPromptSubmit` `M0` injection | partially implemented | `pref-capture-nudge.py` occupies the event; injects a nudge, not a manifest |
| 2.6 | Revisioned session state | partially implemented | `<sid>.json` exists, unrevisioned |
| 2.7 | Context receipts and `/ledger:why` | missing | |
| 2.8 | Degraded-source behavior | partially implemented | `try/except` degradation exists, unspecified |
| 2.9 | Exact-scope beats semantic fallback | missing | no scope, no semantic tier |
| 2.10 | Context budgeting | missing | top-3 truncation is the only bound |

### Phase 3 — discovery and manifest deltas

Implemented 2026-09-03. `ledger/discovery.py`, `ledger/delta.py`, `ledger/coverage.py`,
`hooks/lcg-discover.py`, `hooks/lcg-rehydrate.py`. All flags default off.

| # | Requirement | Status | Note |
|---|---|---|---|
| 3.1 | Deterministic entity extraction | implemented | eight patterns; model-assisted extraction deliberately NOT built, since the spec allows it only as a hint that cannot grant authority |
| 3.2 | Scope frontier | implemented | normalized and deduplicated on admission; a repeat updates the sighting rather than adding a row |
| 3.3 | `PostToolBatch` or PostToolUse aggregation | implemented | registered on both, plus `PostToolUseFailure` |
| 3.4 | Failure-driven refresh | implemented | a failure refreshes even with no new entity, because it contradicts an assumption |
| 3.5 | Manifest diffing and delta injection | implemented | a no-op delta renders as the empty string; silence is the correct output for nothing changed |
| 3.6 | Coverage records, non-enforcing | implemented | `CoverageDecision` has no `deny` field and `coverage.py` contains no `permissionDecision`, asserted by a test. Mutation blocking is Phase 7 |
| 3.7 | Rehydration after resume and compaction | implemented | driven from `SessionStart` where `source` is `resume`/`clear`/`compact`, since `PreCompact` is unverified (R4) |

**Exit criteria — all met**, and two of them only after fixing bugs the tests exposed.

**Three defects found by running it, not by reading it.**

1. **A phantom SQL table.** With a case-insensitive `FROM`, Python's
   `from settlement.core import Loader` produced a table entity called `settlement.core`. A
   phantom table looks authoritative and pulls in the wrong rule. The SQL patterns are now
   case-sensitive: a missed lowercase table costs a refresh the later checkpoints catch, an
   invented one costs correctness.

2. **Lost writes under real concurrency.** Compare-and-swap with three immediate retries lost
   two of four parallel observations. The window between read and write is a full resolve, so
   narrowing it with backoff was not enough — 2 of 3 runs still failed. A per-session `flock`
   closes the window instead, which the spec explicitly permits (P3-20). It fails open: a hook
   that cannot take the lock still does its work, with CAS underneath as the backstop.

3. **A concurrency test that was not concurrent.** It spawned four processes then fed each
   stdin with `communicate()` in turn — so each blocked on stdin until the previous finished.
   Serial execution wearing a concurrency test's clothes, and it passed with the revision-race
   retry removed. Now every stdin is written and closed before anything is waited on. With the
   lock removed it fails 2 runs in 3; the detection is probabilistic, which is stated in the
   test rather than hidden.

### Phase 4 — shadow question and Stop resolution

Implemented 2026-09-03. `ledger/decision.py`, `ledger/prediction.py`, `hooks/lcg-shadow-ask.py`,
`hooks/lcg-capture-answer.py`, `hooks/lcg-stop-detect.py`, `scripts/ledger-calibration.py`.

| # | Requirement | Status | Note |
|---|---|---|---|
| 4.1 | Decision-need normalization | implemented | subject, intent, operation, scope, constraints and the option SET; wording, punctuation and option ORDER excluded |
| 4.2 | Stable decision keys | implemented | not session-dependent, unlike the existing question hash. Unconfident normalization keeps keys separate rather than merging |
| 4.3 | `AskUserQuestion` interception in shadow | implemented | the hook emits nothing at all; a test asserts the source file contains none of the strings a hook would need to interfere |
| 4.4 | Current-task resolved-need cache | implemented | task-scoped by construction — `ResolvedNeed` has no field that could widen it to a repository or team |
| 4.5 | Post-answer capture and comparison | implemented | `QuestionOutcome` with the answer class; an unreadable response records an outcome with no answer rather than inventing one |
| 4.6 | Conservative plain-text Stop detection | implemented | three conditions must all hold; every stop is logged, not only the hits |
| 4.7 | Calibration report | implemented | grouped by intent, risk, confidence, retrieval tier and mandatory category |
| 4.8 | Mandatory-human categories | implemented | nine categories. `QuestionPrediction` REFUSES to hold a predicted answer alongside one |

**Exit criteria — all met.**

- *No question is suppressed* — the shadow hook writes to disk and exits silently, always.
- *Semantically equivalent questions map consistently* — different wording and option order give
  one key; a different option set gives a different key.
- *Human answers become task-local resolved needs* — with the answer class recorded.
- *Stop candidates are measured for false positives* — rejections are logged with their reason,
  so the threshold can be tuned against evidence rather than intuition.

**Four defects found by mutation, two of them in the tests rather than the code.**

1. **Option labels lost their identity.** The subject normalizer drops stopwords and one-letter
   tokens, so options `a`/`b` and `a`/`c` produced the SAME decision key — two different
   questions merged into one. Options are identities, not prose, and now normalize separately.
2. **The abstention test had no path to red.** Its abstention row carried
   `agreed_with_prediction: False`, so counting abstentions as answers changed no number. The
   row now says `True`, which is the only shape that can catch the error.
3. **The Stop detector's addresses-the-human check was untested.** Every negative case failed for
   some other reason. Two cases were added that have a question mark, offer a choice and are not
   narration, but ask about the code rather than the human.
4. **A precedence-style gap in Phase 2 recurred here** — see items 2 and 3. Both were assertions
   that looked thorough and could not fail. Mutation is the only thing that found them.

### Phases 5-7 — curation, recommendation, and the autonomy gate

Implemented 2026-09-03. `ledger/curation.py`, `ledger/recommend.py`, `ledger/autonomy.py`,
`scripts/ledger-readiness.py`. All six new flags default off.

**Phase 5 — candidate curation.** An answer becomes a `candidate`, never an active entry. The
class of answer sets a ceiling on the authority it may ever reach, and `hard_policy` is
unreachable from any of them: it is the one authority a task instruction may never override, so
a single conversation must not be able to mint it. Repeats attach evidence; paraphrases attach
evidence; contradictions create a conflict link. Rejections and corrections stay in the store as
negative evidence, because a statement that was believed and then corrected is a more useful
record than one that vanished.

**Phase 6 — recommendation and advisory.** A recommendation names its source ids, intent and
risk, and abstains loudly with a reason rather than silently. Mandatory categories, changes to
established decisions, unresolved conflicts, stale support and inexact option matches all
abstain. Coverage warnings state what enforcement *would* have done, which is what makes the
false-positive rate measurable before anything is blocked. A subagent inherits mandatory
constraints, not the parent's whole manifest.

**Phase 7 — built, and shut.** The spec gives this phase PREREQUISITES, not just deliverables:
calibration sample count, precision threshold, coverage false-positive rate, security review,
persistence reliability, and a verified kill switch. `readiness()` measures each from real data
and treats anything unmeasurable as unmet. On this machine **all six are unmet**, because shadow
mode has never run. `may_auto_answer()` refuses while any is unmet, and forcing `LCG_MODE=resolve`
does not bypass it — there is a test for exactly that.

The kill switch is checked FIRST, before the calibration table is even loaded, so it cannot be
defeated by the thing it exists to stop.

**Three defects found here, one of them a genuine fail-open:**

1. **A team convention could be approved straight to `hard_policy`.** The ceiling check skipped
   any class in the needs-approval set — precisely the classes that need it. Now every class has
   a ceiling and it applies whoever approves.
2. **A high-risk new decision was auto-answered.** The gate read the need's own risk, classified
   from the question's wording, and ignored the higher risk its caller had assessed. It now takes
   the maximum of the two. The direction of that bug is the one that matters: it failed open.
3. **The ambiguous-option guard had no path to red.** The test used a statement matching zero
   options, so loosening "exactly one match" to "at least one" changed nothing. A case with two
   equally matching options was added.

### Phase 8 — NOT begun, per the spec's own instruction

§26 closes Phase 8 with: *"Do not begin this phase before structured resolution quality is
measured."*

Resolution quality has not been measured. There are zero predictions, zero outcomes and zero
reviewed Stop candidates on this machine, which is the same evidence gap that keeps Phase 7 shut.
Phase 8's items — PR and merge outcome learning, reversion and incident feedback, a temporal
knowledge graph, centralized synchronization, a multi-agent resolver API, language-aware symbol
graphs, predictive prefetch — are all described in the spec as *"possible later work"*.

Building them now would produce code with no way to tell whether it helps, on top of a resolver
whose quality is unknown. The deliverable for Phase 8 is therefore the measurement that unlocks
it, and that is the same first step Phase 7 needs: run shadow mode.

## 11. Conflicts requiring a decision before implementation

**C1 — shadow mode versus the existing deny, and versus a standing user preference.**
Spec §26 Phase 4 exit criterion: *"No question is suppressed."* The existing
`pref-checkpoint.py` **denies** the first occurrence of a matching question. Independently, the
user's own ledger record `pref-hooks-inform-never-block` (confidence: `stated`) says to add only
hooks that inject context or log, and to leave out any hook that denies, asks, or exits 2 —
because the goal is unattended execution. The user's instruction for this work repeats it: *"Do
not enable autonomous question answering ... by default."*

**Verified in the spec, and it settles more than it first appeared.** §18.9 — the
`PreToolUse[AskUserQuestion]` interception — emits only `"permissionDecision": "allow"` with an
`updatedInput`, in every mode including the most autonomous. **It never denies.** The single hook
in the whole design that emits `"deny"` is the §18.8 mutation coverage gate, and even that says:
*"In observe or shadow rollout modes, the coverage gate may record what it would have blocked
without denying."*

So the existing deny is not a stylistic difference from the spec. The spec's mechanism for this
exact hook has no deny in it at any autonomy level. Three independent sources now agree that this
hook should not block: the spec's design, the spec's Phase 4 exit criterion, and the user's own
`pref-hooks-inform-never-block`.

Three readings are possible and they differ materially:
- the deny is legacy to be replaced by shadow mode (spec-literal, and matches the standing
  preference), or
- the deny is the product and shadow mode is an additional measurement lane, or
- both, behind a flag defaulting to shadow.

**RESOLVED 2026-09-03: the user chose B. `LCG_ASK_DENY` now defaults to `0` — inform, never
block.** The legacy deny-once path remains available at `LCG_ASK_DENY=1` and stays under test, so
the decision is reversible with one flag. Below is the reasoning as it stood when the choice was
put to them.

Previously held as: keep the existing deny byte-for-byte under `LCG_ASK_DENY`, default 1.
Rationale: §2 forbids silently reinterpreting existing behaviour, and removing a gate the user
relies on is a visible behaviour change, not a refactor. Characterization tests (0.2) pin the
current behaviour first, so the choice stays reversible and is one flag wide.

**Recommendation: flip it (`LCG_ASK_DENY=0`).** The evidence above is one-sided — the spec's own
mechanism for this hook never denies at any autonomy level, and the user has already stated the
same rule for their own reasons. **This is the one item worth confirming before Phase 4 lands.**

**C2 — the ledger store is not ours.** `topics/pref-*.md` is written by memory-kit, by other
sessions, and by hand. Phase 1's migration must be additive, must not rename `description` or
`triggers`, and must leave files readable by memory-kit's recall hook.

**C3 — hooks run on system Python 3.12, the package declares 3.14.** See risk R1.

**C4 — the resolver core may not depend on Claude Code hook payload types** (spec §7.16). Every
hook here parses its own payload inline and calls its logic in the same file; there is no
core/adapter separation anywhere in the repository. Phase 2 is the first work that requires one.
Recorded because it is an architectural constraint, not a preference, and retrofitting it later
is expensive.

## 11b. Where the blocking behaviour actually lives (confirmed against §26)

Cross-checked against the spec's own phase numbering, and it settles what phases 0-4 may do:

| Behaviour | Spec phase | Consequence for this work |
|---|---|---|
| Mutation coverage **denial** | **Phase 7** | far beyond the requested 0-4. `LCG_COVERAGE` records only, and there is deliberately no flag in `config.py` that makes coverage deny |
| Scoped subagent context | Phase 6 | out of scope here |
| Writing `AskUserQuestion.answers` (autonomous answering) | **Phase 7** | out of scope; `autonomy.enabled` is `false` in the spec's own defaults too |
| `AskUserQuestion` interception in shadow | Phase 4 | in scope, and it never denies at any phase (§18.9) |

**No hook in phases 0-4 blocks anything.** Verified mechanically: zero rows in the phase 0-4 hook
contracts mention deny or block. This matches the user's instruction and the spec's §29 closing
line, so the two constraints are not in tension.

## 12. Risks

| ID | Risk | Severity | Mitigation |
|---|---|---|---|
| R1 | Hooks execute under `#!/usr/bin/env python3` = 3.12.3, while `pyproject.toml` declares `>=3.14`. Shared typed-ledger code imported by a hook would fail on syntax or stdlib newer than 3.12 | high | keep the shared module 3.12-compatible and add a CI check that imports it under 3.12; do not lower the floor without asking |
| R2 | Migration touches user-owned memory files shared with memory-kit | high | additive only; dry-run first; never rename contractual keys; back up before writing |
| R3 | `pref_events.tsv` columns are read by the dashboard | medium | append columns, never reorder |
| R4 | `PreCompact` unverified | medium | rehydrate from `SessionStart`; do not depend on it |
| R5 | Manifest injection on `UserPromptSubmit` shares the event with `pref-capture-nudge.py`; two handlers both injecting context compete for budget | medium | one handler, or a shared budget |
| R6 | The spec's §27 property and replay suites have no framework here — `pytest` collects nothing | medium | Phase 0 adds the runner and the fixtures before Phase 1 code |
| R8 | `updatedInput` on `PreToolUse` **replaces the whole tool input** (spec §18.9) — every unchanged field must be echoed, or fields are silently dropped | medium |
| R7 | Spec scope is very large (36 sections, 9 phases) against a 2,540-line codebase | high | phase gates and feature flags; do not begin a phase before its predecessor's exit criteria are met and tested |

## 13. Phase 0 plan

1. This document. *(done)*
2. Characterization tests pinning today's behaviour of `pref-checkpoint.py` (deny once, allow on
   re-issue, never deny with an empty ledger, event rows written) and of the ledger reader.
3. A test runner that actually collects — `pytest` configured over `tests/`, alongside the
   existing shell suites, without breaking either.
4. `config.py` feature flags, all conservative: every new behaviour OFF, existing behaviour
   unchanged.
5. Architecture diagram page reflecting the real repository.
