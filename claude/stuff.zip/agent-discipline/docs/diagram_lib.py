"""Shared swimlane renderer. ONE router for both SVG and .drawio — two emitters each doing
their own routing is what made the .drawio unreadable (edges auto-routed through every node).
Callers set LANES / NODES / EDGES via configure(), then call svg() / drawio().
"""
import html, os

LANES = ["You", "Claude Code", "Jira / beads", "GitLab"]
LANE_W, LANE_GAP, ROW_H = 250, 18, 112
DIA_W = LANE_W - 8
BOX_W, BOX_H, DIA_H = 208, 62, 88
M = 44
HEAD_H = 46

# id, lane, row, text, shape  (shape: box | dia | start)
NODES = [
    ('want', 0, 0, 'You want something built', 'start'),
    ('brain', 1, 1, 'Search gbrain + memory\n+ preference ledger', 'box'),
    ('ledgerq', 1, 2, 'Already decided\nsomething like this?', 'dia'),
    ('grill', 1, 3, '/grilling — asks you\nquestions until aligned', 'box'),
    ('specok', 0, 4, 'Spec right?', 'dia'),
    ('record', 1, 5, 'Record the pick:\nchose / over / why', 'box'),
    ('tospec', 1, 6, '/to-spec — writes spec', 'box'),
    ('totick', 1, 7, '/to-tickets', 'box'),
    ('jtick', 2, 7, 'Task/subtask under H1/H2 or\nmaintenance epic + beads\n.claude/jira_issues', 'box'),
    ('airdy', 1, 8, 'AI_READY?\n(/jira-autopilot)', 'dia'),
    ('wt', 1, 9, 'wt creates worktree', 'box'),
    ('dod', 1, 10, 'Spawn 5 agents —\nthey write the DoD', 'box'),
    ('step0', 1, 11, 'Step 0: file >300 LOC?\nstrip dead code,\ncommit on its own', 'box'),
    ('phase', 1, 12, 'Implement one phase\n(max 5 files)', 'box'),
    ('chk', 1, 13, 'tsc --noEmit + eslint\n+ browser check', 'box'),
    ('verify', 1, 14, 'Checks green?', 'dia'),
    ('dodok', 1, 15, '5 agents verify:\nmeets DoD?', 'dia'),
    ('commit', 1, 16, 'Commit + one-line\nstatus to you', 'box'),
    ('jstat', 2, 16, 'Status updated\n(never drifts)', 'box'),
    ('bug', 1, 17, 'Found unrelated bug?', 'dia'),
    ('bead', 2, 17, 'beads issue + Jira subtask,\nkeep scope', 'box'),
    ('more', 1, 18, 'More unblocked tasks?', 'dia'),
    ('blocked', 1, 19, 'Any blocked tasks\nleft?', 'dia'),
    ('recheck', 1, 20, 'Re-check each blocker:\ndep merged? answer arrived?\naccess granted?', 'box'),
    ('nowfree', 1, 21, 'Unblocked now?', 'dia'),
    ('clearlog', 1, 22, 'Log the clear:\nwho unblocked it,\nhow long it sat', 'box'),
    ('jblock', 2, 22, 'Mark blocked + reason,\nlink the bd dependency,\nlog the blocker event', 'box'),
    ('blockrep', 0, 22, 'Blocker list: what is stuck,\nwhat only you can clear', 'box'),
    ('mr', 1, 23, 'Push + open MR\n(ship what is done)', 'box'),
    ('pipe', 3, 23, 'Pipeline runs', 'box'),
    ('green', 3, 24, 'Pipeline green?', 'dia'),
    ('review', 3, 25, 'Reviewer comments', 'box'),
    ('rework', 1, 25, 'Rework + reply threads\n(glab-watch-mr.sh)', 'box'),
    ('merge', 0, 26, 'You merge', 'dia'),
    ('done', 2, 27, 'Mark done,\nclean up worktree', 'box'),
    ('reflect', 1, 28, '/reflect: memory +\nledger records +\ncanon draft', 'box'),
    ('canon', 0, 29, 'You merge canon\n(human gate)', 'start'),
    ('report', 1, 30, 'Implementation report\n+ blockers by class\n(2+ hits = fix the process)', 'box'),
]

# src, dst, label, back?
EDGES = [
    ('want', 'brain', '', 0),
    ('brain', 'ledgerq', '', 0),
    ('ledgerq', 'tospec', "Yes — decide, state the assumption, don't ask", 2),
    ('ledgerq', 'grill', 'No', 0),
    ('grill', 'specok', '', 0),
    ('specok', 'grill', 'No', 1),
    ('specok', 'record', 'Yes', 0),
    ('record', 'tospec', '', 0),
    ('tospec', 'totick', '', 0),
    ('totick', 'jtick', '', 0),
    ('totick', 'airdy', '', 0),
    ('airdy', 'grill', 'No — go ask', 1),
    ('airdy', 'wt', 'Yes', 0),
    ('wt', 'dod', '', 0),
    ('dod', 'step0', '', 0),
    ('step0', 'phase', '', 0),
    ('phase', 'chk', '', 0),
    ('chk', 'verify', '', 0),
    ('verify', 'phase', 'No — fix', 1),
    ('verify', 'dodok', 'Yes', 0),
    ('dodok', 'phase', 'No — keep fixing', 1),
    ('dodok', 'commit', 'Yes', 0),
    ('commit', 'jstat', '', 0),
    ('commit', 'bug', '', 0),
    ('bug', 'bead', 'Yes', 0),
    ('bug', 'more', 'No', 0),
    ('more', 'phase', 'Yes', 1),
    ('more', 'blocked', 'No', 0),
    ('blocked', 'mr', 'No — nothing parked', 2),
    ('blocked', 'recheck', 'Yes', 0),
    ('recheck', 'nowfree', '', 0),
    ('nowfree', 'clearlog', 'Yes', 0),
    ('clearlog', 'phase', 'pick it up', 1),
    ('nowfree', 'jblock', 'No', 0),
    ('nowfree', 'blockrep', 'No', 0),
    ('blockrep', 'mr', '', 0),
    ('mr', 'pipe', '', 0),
    ('pipe', 'green', '', 0),
    ('green', 'rework', 'No — fix', 1),
    ('green', 'review', 'Yes', 0),
    ('review', 'rework', '', 0),
    ('rework', 'mr', 'push again', 1),
    ('review', 'merge', 'clean', 0),
    ('merge', 'done', '', 0),
    ('done', 'reflect', '', 0),
    ('reflect', 'canon', '', 0),
    ('reflect', 'report', '', 0),
]

def configure(lanes, nodes, edges):
    """Point the renderer at a different diagram. Recomputes every derived global."""
    global LANES, NODES, EDGES, N, ROWS, W, H, GUT
    LANES, NODES, EDGES = lanes, nodes, edges
    N = {n[0]: n for n in NODES}
    ROWS = max(n[2] for n in NODES) + 1
    W = M * 2 + len(LANES) * LANE_W + (len(LANES) - 1) * LANE_GAP + 200
    H = M * 2 + HEAD_H + ROWS * ROW_H
    GUT = M + len(LANES) * (LANE_W + LANE_GAP) + 40
    longest = max((len(lab) for _, _, lab, back in EDGES if back), default=0)
    W = max(W, GUT + 26 * 3 + 10 + int(longest * 7.6) + 20)


def write(basename, out_dir="."):
    import os
    open(os.path.join(out_dir, basename + ".svg"), "w").write(svg())
    open(os.path.join(out_dir, basename + ".drawio"), "w").write(drawio())
    print(f"wrote {basename}.svg + {basename}.drawio  ({W}x{H})")


N = {n[0]: n for n in NODES}
ROWS = max(n[2] for n in NODES) + 1
W = M * 2 + len(LANES) * LANE_W + (len(LANES) - 1) * LANE_GAP + 200   # provisional; widened below for gutter labels   # +gutter
H = M * 2 + HEAD_H + ROWS * ROW_H
GUT = M + len(LANES) * (LANE_W + LANE_GAP) + 40
# Gutter labels are left-anchored just right of the outermost gutter lane, so the canvas has to
# clear the LONGEST of them — measured, not guessed (a guess clipped it twice).
_LONGEST = max((len(lab) for _, _, lab, back in EDGES if back), default=0)
W = max(W, GUT + 26 * 3 + 10 + int(_LONGEST * 7.6) + 20)

def lane_x(l):
    return M + l * (LANE_W + LANE_GAP)

def row_boundary(r):
    """Y of the gap between row r-1 and row r. Every node is centred in its row, so this
    band is empty across ALL lanes — the only safe height for a long horizontal run."""
    return M + HEAD_H + r * ROW_H

def gutter_path(i, src, dst):
    """Point list for a gutter-routed edge (back-loop or forward skip), node-crossing-free."""
    x1, y1, w1, h1 = geo(src)
    x2, y2, w2, h2 = geo(dst)
    g = GUT + 26 * (i % 4)
    cx1, cx2 = x1 + w1 / 2, x2 + w2 / 2
    yb1 = row_boundary(N[src][2] + 1)      # gap just below the source row
    yb2 = row_boundary(N[dst][2])          # gap just above the target row
    return [(cx1, y1 + h1), (cx1, yb1), (g, yb1), (g, yb2), (cx2, yb2), (cx2, y2)]


def geo(nid):
    _, l, r, _, sh = N[nid]
    h, w = (DIA_H, DIA_W) if sh == "dia" else (BOX_H, BOX_W)
    x = lane_x(l) + (LANE_W - w) / 2
    y = M + HEAD_H + r * ROW_H + (ROW_H - h) / 2
    return x, y, w, h

FILL = {0: "#e8f0fe", 1: "#ffffff", 2: "#fff4e5", 3: "#eaf7ee"}
STROKE = {0: "#1a56b0", 1: "#444444", 2: "#b56a00", 3: "#1e7a3c"}

def svg():
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" font-family="DejaVu Sans, sans-serif">',
         f'<rect width="{W}" height="{H}" fill="#ffffff"/>',
         '<defs><marker id="a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="#333"/></marker>'
         '<marker id="ab" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="#9a2b2b"/></marker><marker id="as" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="#1e7a3c"/></marker></defs>']
    for i, name in enumerate(LANES):
        x = lane_x(i)
        o.append(f'<rect x="{x}" y="{M}" width="{LANE_W}" height="{H-2*M}" fill="{FILL[i]}" fill-opacity="0.45" stroke="{STROKE[i]}" stroke-width="1.5"/>')
        o.append(f'<rect x="{x}" y="{M}" width="{LANE_W}" height="{HEAD_H}" fill="{STROKE[i]}"/>')
        o.append(f'<text x="{x+LANE_W/2}" y="{M+29}" text-anchor="middle" font-size="19" font-weight="bold" fill="#ffffff">{name}</text>')
    for i, (src, dst, lab, back) in enumerate(EDGES):
        x1, y1, w1, h1 = geo(src); x2, y2, w2, h2 = geo(dst)
        if back == 1:
            col, mk, dash = "#9a2b2b", "ab", ' stroke-dasharray="7,5"'
        elif back == 2:
            col, mk, dash = "#1e7a3c", "as", ""
        else:
            col, mk, dash = "#333", "a", ""
        if back:
            pts = gutter_path(i, src, dst)
            d = "M" + " L".join(f"{px},{py}" for px, py in pts)
            lx, ly, anchor = pts[2][0] + 10, pts[2][1] - 7, "start"
        elif N[src][1] == N[dst][1]:
            d = f"M{x1+w1/2},{y1+h1} L{x2+w2/2},{y2}"
            lx, ly, anchor = x1 + w1 / 2 + 8, (y1 + h1 + y2) / 2 + 4, "start"
        else:
            mid = (y1 + h1 + y2) / 2 if y2 > y1 + h1 else y1 + h1 / 2
            if abs(N[src][2] - N[dst][2]) == 0:
                sx = x1 + w1 if x2 > x1 else x1
                ex = x2 if x2 > x1 else x2 + w2
                d = f"M{sx},{y1+h1/2} L{ex},{y2+h2/2}"
                lx, ly, anchor = (sx + ex) / 2, y1 + h1 / 2 - 8, "middle"
            else:
                d = f"M{x1+w1/2},{y1+h1} L{x1+w1/2},{mid} L{x2+w2/2},{mid} L{x2+w2/2},{y2}"
                lx, ly, anchor = (x1 + w1 / 2 + x2 + w2 / 2) / 2, mid - 8, "middle"
        o.append(f'<path d="{d}" fill="none" stroke="{col}" stroke-width="2"{dash} marker-end="url(#{mk})"/>')
        if lab:
            o.append(f'<text x="{lx}" y="{ly}" text-anchor="{anchor}" font-size="14" fill="{col}" font-weight="bold">'
                     f'<tspan stroke="#ffffff" stroke-width="4" paint-order="stroke">{html.escape(lab)}</tspan></text>')
    for nid, l, r, text, sh in NODES:
        x, y, w, h = geo(nid)
        st, fl = STROKE[l], "#ffffff"
        if sh == "dia":
            cx, cy = x + w / 2, y + h / 2
            o.append(f'<polygon points="{cx},{y} {x+w},{cy} {cx},{y+h} {x},{cy}" fill="{fl}" stroke="{st}" stroke-width="2"/>')
        else:
            rx = 26 if sh == "start" else 4
            o.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fl}" stroke="{st}" stroke-width="2"/>')
        lines = text.split("\n")
        fs = 14 if (sh == "dia" or len(lines) > 2) else 15
        y0 = y + h / 2 - (len(lines) - 1) * (fs + 3) / 2 + fs / 3
        for i, ln in enumerate(lines):
            o.append(f'<text x="{x+w/2}" y="{y0+i*(fs+3)}" text-anchor="middle" font-size="{fs}" fill="#111">{html.escape(ln)}</text>')
    o.append("</svg>")
    return "\n".join(o)

def drawio():
    c = ['<mxfile host="app.diagrams.net" type="device"><diagram name="workflow-v2" id="wf2">'
         f'<mxGraphModel dx="1000" dy="700" grid="0" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="{W}" pageHeight="{H}" math="0" shadow="0"><root>'
         '<mxCell id="0"/><mxCell id="1" parent="0"/>']
    for i, name in enumerate(LANES):
        c.append(f'<mxCell id="lane{i}" value="{name}" style="swimlane;horizontal=1;startSize={HEAD_H};'
                 f'fillColor={FILL[i]};strokeColor={STROKE[i]};fontStyle=1;fontSize=16;html=1;" vertex="1" parent="1">'
                 f'<mxGeometry x="{lane_x(i)}" y="{M}" width="{LANE_W}" height="{H-2*M}" as="geometry"/></mxCell>')
    for nid, l, r, text, sh in NODES:
        x, y, w, h = geo(nid)
        shape = "rhombus;" if sh == "dia" else ("rounded=1;arcSize=50;" if sh == "start" else "rounded=0;")
        c.append(f'<mxCell id="{nid}" value="{html.escape(text).replace(chr(10), "&#10;")}" '
                 f'style="{shape}whiteSpace=wrap;html=1;fillColor=#ffffff;strokeColor={STROKE[l]};strokeWidth=2;" '
                 f'vertex="1" parent="1"><mxGeometry x="{x}" y="{y}" width="{w}" height="{h}" as="geometry"/></mxCell>')
    for i, (src, dst, lab, back) in enumerate(EDGES):
        x1, y1, w1, h1 = geo(src)
        x2, y2, w2, h2 = geo(dst)
        colour = ("strokeColor=#9a2b2b;dashed=1;" if back == 1
                  else "strokeColor=#1e7a3c;" if back == 2 else "strokeColor=#333333;")
        # Explicit exit/entry + waypoints, mirroring svg(). Without these diagrams.net
        # auto-routes straight down the lane and the line crosses every node in it.
        pts = []
        if back:
            anchor = "exitX=0.5;exitY=1;entryX=0.5;entryY=0;"
            pts = gutter_path(i, src, dst)[1:-1]
        elif N[src][1] == N[dst][1]:
            anchor = "exitX=0.5;exitY=1;entryX=0.5;entryY=0;"
        elif N[src][2] == N[dst][2]:
            right = x2 > x1
            anchor = ("exitX=1;exitY=0.5;entryX=0;entryY=0.5;" if right
                      else "exitX=0;exitY=0.5;entryX=1;entryY=0.5;")
        else:
            mid = (y1 + h1 + y2) / 2 if y2 > y1 + h1 else y1 + h1 / 2
            anchor = "exitX=0.5;exitY=1;entryX=0.5;entryY=0;"
            pts = [(x1 + w1 / 2, mid), (x2 + w2 / 2, mid)]
        style = ("edgeStyle=orthogonalEdgeStyle;rounded=1;html=1;endArrow=open;endSize=12;"
                 "exitDx=0;exitDy=0;entryDx=0;entryDy=0;jettySize=auto;orthogonalLoop=1;"
                 "labelBackgroundColor=#ffffff;fontSize=11;" + anchor + colour)
        geom = ['<mxGeometry relative="1" as="geometry">']
        if pts:
            geom.append('<Array as="points">')
            geom += [f'<mxPoint x="{px:.0f}" y="{py:.0f}"/>' for px, py in pts]
            geom.append("</Array>")
        geom.append("</mxGeometry>")
        c.append(f'<mxCell id="e{i}" value="{html.escape(lab)}" style="{style}" edge="1" parent="1" '
                 f'source="{src}" target="{dst}">' + "".join(geom) + "</mxCell>")
    c.append("</root></mxGraphModel></diagram></mxfile>")
    return "".join(c)

