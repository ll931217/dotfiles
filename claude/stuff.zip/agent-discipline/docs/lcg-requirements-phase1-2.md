---
code_refs:
  - ledger/types.py
  - ledger/events.py
  - ledger/session.py
  - ledger/adapters.py
  - ledger/resolver.py
  - ledger/projection.py
  - ledger/compat.py
---

# Ledger Context Governor — normalized requirements, Phases 1-2

Derived from the spec at `docs/ledger-context-governor-implementation-spec.md` v0.2.0, sections §7–§14 (governing invariants, knowledge/decision types, scope model, authority model, lifecycle, logical data model, source adapter contracts, resolver input/manifest/state), on 2026-09-03.

| ID | Requirement (one line, imperative) | Spec § | Mandatory? |
|---|---|---|---|
| R-001 | Model `fact`, `invariant`, `policy`, `decision`, `preference`, `heuristic`, `assumption`, `exception`, `negative_preference`, `constraint` as distinct first-class, validated `LedgerEntryKind` values — never one `preference` table with optional metadata | §7.1, §8, §12.1 | MUST |
| R-002 | Reject as inactive any entry lacking scope, authority, lifecycle status, and provenance record | §7.2 | MUST |
| R-003 | Never let a vector or text relevance score cross an authority boundary | §7.4 | MUST |
| R-004 | Never let narrower scope weaken a higher-authority `hard_policy` | §7.5 | MUST |
| R-005 | Never let a `preference` scoped to a user override team or organization policy | §7.6, §9.1 | MUST |
| R-006 | Never let `code_or_schema_observation` of legacy code overrule an approved active rule | §7.7, §10.2 | MUST |
| R-007 | Attach an explicit staleness warning to any stale fact surfaced as current | §7.8 | MUST |
| R-008 | Record who or what granted authority on every durable promotion (`approvedBy`, `approvedAt`) | §7.10, §11 | MUST |
| R-009 | Forbid automatic learning of team- or organization-wide policy from a single answer | §7.11 | MUST |
| R-010 | Enforce authorization before retrieval and ranking, not after | §7.12 | MUST |
| R-011 | Keep the evidence/event history append-only | §7.13, §12.4 | MUST |
| R-012 | Forbid a `generated_summary` from citing itself or another derived summary as primary evidence | §7.14 | MUST |
| R-013 | Keep the resolver core free of any dependency on Claude Code hook payload types | §7.16 | MUST |
| R-014 | Treat `M0` as an intentionally incomplete starting view, not a complete task specification | §7.18 | MUST |
| R-015 | Persist the active manifest outside model context; model-visible context is only a projection | §7.19, §14.7 | MUST |
| R-016 | Increment the manifest `revision` and write a `ContextReceipt` on every material context change | §7.20, §14.5 | MUST |
| R-017 | Make a manifest refresh idempotent for the same normalized trigger and source snapshot | §7.29 | MUST |
| R-018 | Support all scope dimensions: `organization`, `team`, `repository`, `service`, `module`, `path`, `symbol`, `task`, `branch`, `actor/user`, `environment`, time window | §9 | MUST |
| R-019 | Allow an entry to declare several scope dimensions simultaneously | §9 | MAY |
| R-020 | Treat a missing scope dimension as "not constrained by this dimension", never as global authority | §9.1 | MUST |
| R-021 | Require a candidate to match every scope dimension it declares | §9.1 | MUST |
| R-022 | Prevent branch-specific facts from leaking into unrelated branches | §9.1 | MUST |
| R-023 | Never apply an environment-scoped entry to another environment via semantic similarity | §9.1 | MUST |
| R-024 | Expire task-specific entries when the task closes | §9.1 | SHOULD |
| R-025 | Use canonical repository-relative identifiers for `symbols` and `paths` matching | §9.1 | SHOULD |
| R-026 | Identify repositories by a stable repository ID when available, not only local directory name | §9.1 | SHOULD |
| R-027 | Order specificity `task > symbol > path > module > service > repository > team > organization > unscoped` within one authority class and compatible kind | §9.2 | SHOULD |
| R-028 | Apply `branches`, `environments`, `actorIds` as eligibility filters before specificity comparison | §9.2 | SHOULD |
| R-029 | Represent authority as the explicit `LedgerAuthority` enum, never derived solely from source name | §10, §12.1 | MUST |
| R-030 | Order authority highest-first: `hard_policy`, `current_task_instruction`, `approved_architectural_decision`, `approved_team_decision`, `approved_repository_decision`, `explicit_human_preference`, `reviewed_human_observation`, `code_or_schema_observation`, `repeated_agent_observation`, `agent_inference`, `generated_summary` | §10 | SHOULD |
| R-031 | Forbid `current_task_instruction` from overriding `hard_policy` | §10.1 | MUST |
| R-032 | Require an approval record appropriate to scope for approved-decision authorities | §10.1 | MUST |
| R-033 | Scope `explicit_human_preference` to actor or task unless the user explicitly and authoritatively widens it | §10.1 | SHOULD |
| R-034 | Never promote `code_or_schema_observation` into policy | §10.1 | MUST |
| R-035 | Treat `agent_inference` and `generated_summary` as never sufficient for autonomous resolution | §10.1, §7.3 | MUST |
| R-036 | Forbid a single global relevance score; implement kind-specific conflict handling | §10.2 | MUST |
| R-037 | Resolve policy conflicts by hard-policy authority → approved exception with exempt permission → approval scope → scope specificity → explicit supersession → effective date | §10.2 | MUST |
| R-038 | Resolve fact conflicts by current source evidence at active commit → source validation against active branch/commit → explicit supersession → freshness/`invalidationConditions` → source reliability → scope specificity | §10.2 | MUST |
| R-039 | Expose a conflict rather than guessing when two authoritative current sources disagree | §10.2 | MUST |
| R-040 | Resolve decision conflicts by required approval level → scope match/specificity → supersession chain → effective date → status | §10.2 | MUST |
| R-041 | Resolve preference conflicts by applicable policy/approved decision → team over personal for team-owned code → task-specific instruction over general preference → scope specificity → recency | §10.2 | MUST |
| R-042 | Use `heuristic` and `assumption` only when no stronger fact/policy/decision/preference answers the question, and let their conflicts reduce confidence and block autonomous resolution | §10.2 | MUST |
| R-043 | Give every entry a `LedgerStatus` from `observed`, `candidate`, `approved`, `active`, `deprecated`, `superseded`, `rejected`, `expired`, `invalidated`, `quarantined` | §11, §12.1 | MUST |
| R-044 | Enforce transitions `observed→candidate`, `candidate→approved→active`, `candidate→rejected`, `active→superseded/deprecated/expired/invalidated`, and any unsafe/malformed entry → `quarantined` | §11 | SHOULD |
| R-045 | Store lifecycle fields `created_at`, `effective_from`, `expires_at`, `last_validated_at`, `last_validated_revision`, `supersedes`, `superseded_by`, `invalidation_conditions`, `review_after`, `approved_by`, `approved_at` | §11 | MUST |
| R-046 | Give task-local `assumption` entries a default expiry tied to task completion or a short configured duration | §11 | SHOULD |
| R-047 | Implement `LedgerEntry` with `id`, `version`, `kind`, `subject`, `statement`, `scope`, `authority`, `status`, `autonomy`, `risk`, `sourceReferences`, `evidenceIds`, `createdBy`, `createdAt` as required fields | §12.1 | MUST |
| R-048 | Implement optional `LedgerEntry` fields `rationale`, `retrieval`, `confidence`, `conflictKey`, `supersedes`, `conflictsWith`, `rejectedAlternatives`, `invalidationConditions`, `effectiveFrom`, `expiresAt`, `lastValidatedAt`, `lastValidatedRevision`, `approvedBy`, `approvedAt`, `metadata` | §12.1 | MAY |
| R-049 | Define `AutonomyLevel` as `mandatory`, `default`, `advisory`, `ask_before_applying`, `never_auto_apply` | §12.1 | MUST |
| R-050 | Define `LedgerScope` with `organization`, `team`, `repository`, `service`, `module`, `paths`, `symbols`, `taskIds`, `branches`, `actorIds`, `environments`, `validFrom`, `validUntil` — all optional | §12.1 | MUST |
| R-051 | Define `EvidenceType` as `source_code`, `schema`, `test`, `documentation`, `adr`, `user_answer`, `review_comment`, `merged_change`, `reverted_change`, `incident`, `canon_rule`, `memory_kit_record`, `external_system`, `agent_observation` | §12.2 | MUST |
| R-052 | Implement `EvidenceRecord` with `id`, `type`, `polarity` (`supports`/`contradicts`/`neutral`), `statement`, `source`, `observedAt`, `observedBy`, `reliability`, plus optional `repositoryRevision`, `contentHash`, `metadata` | §12.2 | MUST |
| R-053 | Implement `SourceReference` with required `sourceSystem` (`memory-kit`/`canon`/`ledger`/`repository`/`user`/other string) and `sourceId`, plus optional `sourceVersion`, `repository`, `revision`, `path`, `symbol`, `uri`, `contentHash`, `capturedAt` | §12.3 | MUST |
| R-054 | Implement `LedgerEvent` with `id`, `entryId`, `sequence`, `eventType`, `payload`, `actor`, `createdAt`, `eventHash`, and optional `previousEventHash` | §12.4 | MUST |
| R-055 | Support `eventType` values `created`, `evidence_added`, `promoted`, `approved`, `activated`, `rejected`, `superseded`, `deprecated`, `expired`, `invalidated`, `scope_changed`, `authority_changed`, `outcome_recorded` | §12.4 | MUST |
| R-056 | Chain event hashes for high-authority records, or preserve the hash fields/interfaces for later addition if omitted in MVP | §12.4 | SHOULD |
| R-057 | Query a materialized active projection instead of replaying full event history inside a hook | §12.5 | SHOULD |
| R-058 | Include in the projection current entry version, current lifecycle status, effective scope, effective authority, latest validation metadata, supersession state, evidence summary, searchable `subject` and `statement` | §12.5 | MUST |
| R-059 | Make projection updates transactional with event writes, or safely rebuildable | §12.5 | MUST |
| R-060 | Implement `RetrievalMetadata` with `repositories`, `services`, `modules`, `pathGlobs`, `symbols`, `endpoints`, `datasets`, `tables`, `messageTopics`, `dependencies`, `concepts`, `operations`, `decisionKeys`, `triggerTerms`, `appliesWhen` | §12.6 | SHOULD |
| R-061 | Implement `ApplicabilityPredicate` with `field`, `operator` (`equals`, `not_equals`, `contains`, `matches`, `in`, `exists`), optional `value` | §12.6 | SHOULD |
| R-062 | Generate `RetrievalMetadata` fields from scope and source evidence when legacy entries lack them | §12.6 | SHOULD |
| R-063 | Apply retrieval order: exact decision key → current task answer → repository/service/module/path/symbol → endpoint/dataset/table/message topic/dependency → business concept and operation → Memory Kit relationship traversal → semantic fallback → recent noisy observations (advisory only) | §12.6 | SHOULD |
| R-064 | Forbid semantic retrieval from determining authority, allowing it only to discover candidates | §12.6, §7.4 | MUST |
| R-065 | Consume all sources through `KnowledgeSourceAdapter` exposing `id`, `sourceSystem`, `query`, `getById`, `validateReference`, `health` | §13 | MUST |
| R-066 | Normalize adapter output to `KnowledgeCandidate` carrying `sourceSystem`, `sourceId`, `kind`, `subject`, `statement`, `scope`, `authority`, `autonomy`, `risk`, `status`, `evidence`, `sourceReferences` | §13 | MUST |
| R-067 | Make the Memory Kit adapter query by decision key, repository, service, module, path, symbol, endpoint, dataset, table, dependency, task terms, operation, and data concepts | §13.1 | MUST |
| R-068 | Preserve Memory Kit record IDs, versions, and citations to code/schemas/docs/source data | §13.1 | MUST |
| R-069 | Map Memory Kit content only to `fact`, `invariant`, `constraint`, `heuristic`, or `assumption` | §13.1 | MUST |
| R-070 | Mark Memory Kit generated summaries as `generated_summary` unless backed by stronger primary evidence, and expose staleness/validation metadata | §13.1 | MUST |
| R-071 | Avoid copying whole Memory Kit records into Ledger unless an audit snapshot is necessary | §13.1 | MUST |
| R-072 | Make the Canon adapter query rules by repository, path, language, framework, operation, and task | §13.2 | MUST |
| R-073 | Preserve Canon rule IDs, severity, rationale, remediation, exceptions, and enforcement level | §13.2 | MUST |
| R-074 | Map mandatory Canon rules to `policy` or `invariant` with `hard_policy` authority, and conventions to `preference` or non-hard `policy` | §13.2 | MUST |
| R-075 | Delegate deterministic compliance checks to Canon instead of reimplementing them, and never let Ledger preferences override mandatory Canon rules | §13.2 | MUST |
| R-076 | Make the Ledger adapter query the active projection by exact decision key and structured scope before semantic fallback | §13.3 | MUST |
| R-077 | Return only entries the current actor is authorized to read | §13.3 | MUST |
| R-078 | Include candidate/noisy-memory entries only when explicitly requested (`includeNoisyMemory`) for advisory use | §13.3 | MUST |
| R-079 | Preserve approval, supersession, expiry, and conflict metadata, and support exact lookup for receipts and explanations | §13.3 | MUST |
| R-080 | Never import files from another plugin's installation directory; prefer library contract → local CLI/Unix-socket → HTTP/MCP → narrow adapter API, and isolate direct DB access behind an adapter | §13.4 | MUST |
| R-081 | Define `ResolutionTrigger` as `initial_prompt`, `scope_discovered`, `tool_batch_completed`, `tool_failed`, `mutation_coverage_check`, `question_intercepted`, `plain_text_question`, `subagent_spawn`, `session_resume`, `session_clear`, `session_fork`, `session_compact`, `source_invalidated`, `manual_refresh` | §14.1 | MUST |
| R-082 | Implement `ResolutionRequest` with required `requestId`, `trigger`, `actor`, `repository`, `session`, `task`, and optional `operation`, `currentManifestRevision`, `paths`, `symbols`, `discoveredEntities`, `mutationTargets`, `decisionNeed`, `prompt`, `branch`, `revision`, `workspaceRevision`, `environment`, `tokenBudget`, `characterBudget`, `includeNoisyMemory` | §14.2 | MUST |
| R-083 | Define `ScopeDimension` including `endpoint`, `dataset`, `table`, `message_topic`, `dependency`, `concept` in addition to the core dimensions | §14.3 | MUST |
| R-084 | Implement `ScopeReference` with `type`, `value`, optional `qualifiers` | §14.3 | MUST |
| R-085 | Implement `EntityReference` with `type` (`path`, `symbol`, `module`, `service`, `endpoint`, `dataset`, `table`, `message_topic`, `dependency`, `concept`, `error`, `test`, `external_system`), `canonicalId`, `observedValue`, `confidence`, optional `sourceToolUseId`, `sourcePath` | §14.3 | MUST |
| R-086 | Implement `TaskContextManifest` with `manifestId`, `revision`, `receiptId`, `generatedAt`, `resolverVersion`, `trigger`, `requestSummary`, `repository`, `task`, `scopeFrontier`, `coverage`, `applicablePolicies`, `systemFacts`, `activeDecisions`, `preferences`, `assumptions`, `exceptions`, `resolvedNeeds`, `conflicts`, `staleItems`, `autonomyBoundary`, `degradedSources`, optional `parentManifestId` | §14.4 | MUST |
| R-087 | Build the manifest as a materialized active view, never reconstructed by reading Claude's transcript | §14.4 | MUST |
| R-088 | Implement `ManifestDelta` with `deltaId`, `sessionId`, `fromRevision`, `toRevision`, `trigger`, `generatedAt`, `discoveredScopes`, `added`, `removed`, `invalidated`, `superseded`, `conflictsAdded`, `conflictsResolved`, `coverageAdded`, `coverageInvalidated`, `resolvedNeedsAdded`, `assumptionsInvalidated`, optional `autonomyBoundaryChanged`, `receiptId`, `noOp` | §14.5 | MUST |
| R-089 | Let a `noOp` refresh update internal observation state without incrementing the visible `revision`, while a material change must increment it | §14.5 | MUST |
| R-090 | Inject only deltas during normal implementation, re-injecting the complete manifest only on explicit rehydration or diagnosis | §7.21 | SHOULD |
| R-091 | Implement `ManifestItemReference` (`id`, `sourceSystem`, optional `reason`), `ManifestConflictReference`, `ContextCoverageReference`, `AssumptionReference`, `ResolvedNeedSummary` (`id`, `decisionKey`, `resolution`, `sourceEntryIds`), `CoverageDecision` (`status`, `targetScopes`, `relevantEntryIds`, `reason`) | §14.5 | MAY |
| R-092 | Write a `ContextReceipt` for every autonomous resolution with `id`, `requestId`, `trigger`, `resolverVersion`, `resolverConfigHash`, `sourceSnapshotHash`, `actor`, `createdAt`, `sourceQueries`, `considered`, `selected`, `rejected`, `conflicts`, `stale`, `outputHash` | §7.9, §14.6 | MUST |
| R-093 | Carry optional receipt links `previousReceiptId`, `manifestId`, `manifestRevision`, `deltaId`, `repositoryRevision`, `workspaceRevision`, `coverageDecision`, `autonomyDecision`, `decisionNeed`, `resolvedNeedId` | §14.6 | MAY |
| R-094 | Store only identifiers, reasons, hashes, and concise snapshots in receipts — never large sensitive source contents | §14.6 | MUST |
| R-095 | Implement `SessionContextState` with `sessionId`, `repository`, `workspaceRevision`, `manifest`, `receiptChain`, `scopeFrontier`, `observedEntities`, `coverage`, `activeEntryIds`, `staleEntryIds`, `conflicts`, `resolvedNeeds`, `pendingAssumptions`, `mutationAttempts`, `stopRecoveries`, `sourceSnapshotHash`, `createdAt`, `updatedAt`, optional `taskId`, `branch`, `baseRevision` | §14.7 | MUST |
| R-096 | Persist active session state outside model context in the Ledger store or a session-state store with transactional updates and per-session locking | §14.7 | MUST |
| R-097 | Implement `StopRecoveryState` with `decisionKey`, `attempts`, `lastManifestRevision`, `lastSourceSnapshotHash`, `updatedAt` | §14.7 | MUST |
| R-098 | Define `OperationKind` as `read`, `search`, `edit`, `create`, `delete`, `execute`, `migrate`, `deploy`, `query`, `serialize`, `unknown` | §14.8 | MUST |
| R-099 | Implement `ContextCoverage` with `id`, `scope`, `operationKinds`, `manifestRevision`, `sourceSnapshotHash`, `workspaceRevision`, `relevantEntryIds`, `conflictIds`, `degradedSourceIds`, `status` (`covered`, `covered_with_warning`, `blocked_by_conflict`, `degraded`, `invalidated`), `resolvedAt`, optional `repositoryRevision`, `expiresAt`, `invalidationConditions` | §14.8 | MUST |
| R-100 | Derive coverage validity from scope, operation, active source snapshot, repository state, and unresolved conflicts, and never treat read coverage as mutation coverage | §14.8 | MUST |
| R-101 | Invalidate coverage records when relevant repository state, source versions, scope, or operation changes | §7.30 | MUST |
| R-102 | Resolve newly discovered scopes before consequential mutation when the coverage gate is enforced | §7.22 | MUST |
| R-103 | Implement `MutationTarget` with `toolName`, `operationKind`, `scopes`, optional `paths`, `symbols`, `resources` | §14.9 | MUST |
| R-104 | Implement `MutationAttemptState` with `fingerprint`, `hydrationRevision`, `attempts`, `lastDecision` (`allowed`, `denied_for_hydration`, `denied_for_conflict`, `degraded`), `updatedAt` | §14.9 | MUST |
| R-105 | Compute the mutation fingerprint from normalized tool name, mutation target, operation kind, material input hash, source snapshot, and current manifest revision | §14.9 | MUST |
| R-106 | Bound hook loops with mutation-attempt fingerprints and attempt counters so no hook can loop indefinitely | §7.31 | MUST |
| R-107 | Define `DecisionNeedType` as `implementation_choice`, `business_semantics`, `data_derivation`, `architecture`, `dependency_selection`, `compatibility`, `security`, `schema`, `product_behavior`, `operational_action`, `unknown` | §14.10 | MUST |
| R-108 | Implement `DecisionNeed` with `decisionKey`, `type`, `subject`, `scopes`, `constraints`, `risk`, `intent` (`apply_established`, `choose_new`, `change_established`, `verify_fact`), optional `operation`, `proposedOptions`, `originalQuestion` | §14.10 | MUST |
| R-109 | Implement `ResolvedNeed` with `id`, `decisionKey`, `resolution`, `sourceEntryIds`, `authority`, `scope`, `risk`, `intent`, `resolutionMode` (`canon`, `memory_kit`, `ledger`, `current_task_answer`, `human_answer`, `approved_inference`), `manifestRevision`, `sourceSnapshotHash`, `resolvedAt`, optional `normalizedOption`, `expiresAt`, `invalidationConditions` | §14.10 | MUST |
| R-110 | Derive `decisionKey` from normalized type, subject, operation, scope, and material constraints — not raw question text — so it stays stable across paraphrases | §14.10, §7.24 | MUST |
| R-111 | Converge semantically equivalent questions on the same `decisionKey` | §7.24 | MUST |
| R-112 | Query the complete authorized backing stores and current-task caches before any user-facing implementation clarification | §7.23 | MUST |
| R-113 | Suppress re-asking a question already answered for the current task unless its scope, evidence, or constraints materially changed | §7.25 | MUST |
| R-114 | Give the Stop hook one bounded conservative opportunity to resolve a plain-text blocking clarification | §7.26 | MUST |
| R-115 | Give subagents only the context applicable to their assigned work plus repository-wide hard policy | §7.27 | MUST |
| R-116 | Separate autonomy from tool permission — Ledger may know the preferred action while Claude Code permissions still require user approval | §7.17 | MUST |
| R-117 | Allow the resolver to enforce an existing approved invariant at a higher risk level than it may invent a new choice (`apply_established` vs `choose_new`) | §7.28 | MUST |
| R-118 | Use separate failure policies for hard enforcement and advisory context | §7.15 | MUST |
| R-119 | Adapt the logical structures to the existing persistence layer rather than forcing the spec's exact table names | §12 | SHOULD |
| R-120 | Expose `SourceHealth` via adapter `health()` and surface degraded sources in `degradedSources` | §13, §14.4 | MUST |
