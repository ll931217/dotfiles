#!/usr/bin/env python3
"""The user-perspective workflow diagram: what happens to a ticket, and where YOU are
needed. Deliberately contains no hook names or file paths — that is the mechanism map
(gen_mechanism.py), a different diagram for a different question.

Edit the two lists below and re-run. Rendering lives in diagram_lib.py.
"""
import diagram_lib as D

LANES = ["You", "Claude Code", "Jira / beads", "GitLab"]

NODES = [
    ('want', 0, 0, 'You want something built', 'start'),
    ('brain', 1, 1, 'Search gbrain + memory\n+ preference ledger', 'box'),
    ('ledgerq', 1, 2, 'Already decided\nsomething like this?', 'dia'),
    ('grill', 1, 3, '/grilling — asks you\nquestions until aligned', 'box'),
    ('specok', 0, 4, 'Spec right?', 'dia'),
    ('record', 1, 5, 'Record the pick:\nchose / over / why', 'box'),
    ('tospec', 1, 6, '/to-spec — writes spec', 'box'),
    ('totick', 1, 7, '/to-tickets', 'box'),
    ('jtick', 2, 7, 'Task/subtask under H1/H2 or\nmaintenance epic + beads\n.claude/jira_issues', 'box'),
    ('airdy', 1, 8, 'AI_READY?\n(/jira-autopilot)', 'dia'),
    ('wt', 1, 9, 'wt creates worktree;\na worker session starts in it\n(opus · high). You orchestrate', 'box'),
    ('dod', 1, 10, 'Worker spawns 5 agents —\nthey write the DoD', 'box'),
    ('step0', 1, 11, 'Step 0: file >300 LOC?\nstrip dead code,\ncommit on its own', 'box'),
    ('phase', 1, 12, 'Implement one phase\n(max 5 files)', 'box'),
    ('chk', 1, 13, 'tsc --noEmit + eslint\n+ browser check', 'box'),
    ('verify', 1, 14, 'Checks green?', 'dia'),
    ('dodok', 1, 15, '5 agents verify,\norchestrator approves?', 'dia'),
    ('commit', 1, 16, 'Commit + one-line\nstatus to you', 'box'),
    ('jstat', 2, 16, 'Status updated\n(never drifts)', 'box'),
    ('bug', 1, 17, 'Found unrelated bug?', 'dia'),
    ('bead', 2, 17, 'beads issue + Jira subtask,\nkeep scope', 'box'),
    ('more', 1, 18, 'More unblocked tasks?', 'dia'),
    ('blocked', 1, 19, 'Any blocked tasks\nleft?', 'dia'),
    ('recheck', 1, 20, 'Re-check each blocker:\ndep merged? answer arrived?\naccess granted?', 'box'),
    ('nowfree', 1, 21, 'Unblocked now?', 'dia'),
    ('clearlog', 1, 22, 'Log the clear:\nwho unblocked it,\nhow long it sat', 'box'),
    ('jblock', 2, 22, 'Mark blocked + reason,\nlink the bd dependency,\nlog the blocker event', 'box'),
    ('blockrep', 0, 22, 'Blocker list: what is stuck,\nwhat only you can clear', 'box'),
    ('mr', 1, 23, 'Push + open MR\n(ship what is done)', 'box'),
    ('pipe', 3, 23, 'Pipeline runs', 'box'),
    ('green', 3, 24, 'Pipeline green?', 'dia'),
    ('review', 3, 25, 'Reviewer comments', 'box'),
    ('rework', 1, 25, 'Rework + reply threads\n(glab-watch-mr.sh)', 'box'),
    ('merge', 0, 26, 'You merge', 'dia'),
    ('done', 2, 27, 'Mark done; watcher reaps\nworktree + tmux window', 'box'),
    ('reflect', 1, 28, '/reflect: memory +\nledger records +\ncanon draft', 'box'),
    ('canon', 0, 29, 'You merge canon\n(human gate)', 'start'),
    ('report', 1, 30, 'Implementation report\n+ blockers by class\n(2+ hits = fix the process)', 'box'),
]

# src, dst, label, back?
EDGES = [
    ('want', 'brain', '', 0),
    ('brain', 'ledgerq', '', 0),
    ('ledgerq', 'tospec', "Yes — decide, state the assumption, don't ask", 2),
    ('ledgerq', 'grill', 'No', 0),
    ('grill', 'specok', '', 0),
    ('specok', 'grill', 'No', 1),
    ('specok', 'record', 'Yes', 0),
    ('record', 'tospec', '', 0),
    ('tospec', 'totick', '', 0),
    ('totick', 'jtick', '', 0),
    ('totick', 'airdy', '', 0),
    ('airdy', 'grill', 'No — go ask', 1),
    ('airdy', 'wt', 'Yes', 0),
    ('wt', 'dod', '', 0),
    ('dod', 'step0', '', 0),
    ('step0', 'phase', '', 0),
    ('phase', 'chk', '', 0),
    ('chk', 'verify', '', 0),
    ('verify', 'phase', 'No — fix', 1),
    ('verify', 'dodok', 'Yes', 0),
    ('dodok', 'phase', 'No — keep fixing', 1),
    ('dodok', 'commit', 'Yes', 0),
    ('commit', 'jstat', '', 0),
    ('commit', 'bug', '', 0),
    ('bug', 'bead', 'Yes', 0),
    ('bug', 'more', 'No', 0),
    ('more', 'phase', 'Yes', 1),
    ('more', 'blocked', 'No', 0),
    ('blocked', 'mr', 'No — nothing parked', 2),
    ('blocked', 'recheck', 'Yes', 0),
    ('recheck', 'nowfree', '', 0),
    ('nowfree', 'clearlog', 'Yes', 0),
    ('clearlog', 'phase', 'pick it up', 1),
    ('nowfree', 'jblock', 'No', 0),
    ('nowfree', 'blockrep', 'No', 0),
    ('blockrep', 'mr', '', 0),
    ('mr', 'pipe', '', 0),
    ('pipe', 'green', '', 0),
    ('green', 'rework', 'No — fix', 1),
    ('green', 'review', 'Yes', 0),
    ('review', 'rework', '', 0),
    ('rework', 'mr', 'push again', 1),
    ('review', 'merge', 'clean', 0),
    ('merge', 'done', '', 0),
    ('done', 'reflect', '', 0),
    ('reflect', 'canon', '', 0),
    ('reflect', 'report', '', 0),
]

# ── page 2: the same ticket, without agent-discipline ──────────────────────────────────────
# Derived from page 1 so the two never drift: nodes the plugin adds are dropped or reworded,
# and the edges that met at them are rewired. Everything else is identical, on purpose — the
# demo is "same flow, these boxes are what the plugin changes".
DROP = {"ledgerq", "record", "clearlog"}
REWORD = {
    "brain":    "Search gbrain + memory\n(no preference ledger)",
    "grill":    "/grilling — asks you\nthe same questions again",
    "wt":       "wt creates worktree;\nmain session implements,\nworktree Claude sits idle",
    "dod":      "5 agents write the DoD —\nif the rule is remembered",
    "dodok":    "5 agents verify:\nmeets DoD?",
    "jtick":    "Task/subtask + beads,\nkept in sync by hand",
    "jstat":    "Status updated by hand\n(drifts when forgotten)",
    "bead":     "beads issue\n(Jira mirror if remembered)",
    "jblock":   "Mark blocked + reason\n(no blocker event logged)",
    "blockrep": "You find out what is stuck\nwhen you ask",
    "rework":   "Rework + reply threads\n(you refresh the MR page)",
    "done":     "Mark done by hand;\nworktree + tmux window\nstay until noticed",
    "reflect":  "/reflect: memory +\ncanon draft",
    "report":   "Implementation report\n(blockers uncounted)",
}
REWIRE = [  # (src, dst) pairs to add, with label and back flag, replacing edges through DROP
    ("brain", "grill", "", 0),
    ("specok", "tospec", "Yes", 0),
    ("nowfree", "phase", "Yes — pick it up", 1),
]

def without_plugin(nodes, edges):
    kept = [(i, l, r, REWORD.get(i, t), sh) for i, l, r, t, sh in nodes if i not in DROP]
    rows = sorted({r for _, _, r, _, _ in kept})
    remap = {r: k for k, r in enumerate(rows)}          # close the gaps the dropped rows leave
    kept = [(i, l, remap[r], t, sh) for i, l, r, t, sh in kept]
    ids = {i for i, *_ in kept}
    es = [e for e in edges if e[0] in ids and e[1] in ids] + REWIRE
    return kept, es

NODES_WITHOUT, EDGES_WITHOUT = without_plugin(NODES, EDGES)

# On the with-plugin page, highlight every node the plugin adds (DROP) or changes (REWORD),
# plus a legend in the empty top-right cell — so the difference is visible without flipping.
CHANGED = DROP | set(REWORD)
NODES_WITH = [(i, l, r, t, sh + ("!" if i in CHANGED else "")) for i, l, r, t, sh in NODES]
NODES_WITH.append(("legend", 3, 0, "Highlighted = added or\nchanged by agent-discipline", "box!"))

if __name__ == "__main__":
    # before/after order for the demo: the bare .svg stays the with-plugin page
    D.write_pages("ai_agent_dev_workflow_v2", [
        ("Without the plugin", LANES, NODES_WITHOUT, EDGES_WITHOUT, dict(D.FILL), dict(D.STROKE),
         "ai_agent_dev_workflow_v2-without-the-plugin.svg"),
        ("With agent-discipline", LANES, NODES_WITH, EDGES, dict(D.FILL), dict(D.STROKE),
         "ai_agent_dev_workflow_v2.svg"),
    ])
