---
title: Metrics — what the agent dashboard measures, and what it refuses to claim
code_refs:
  - scripts/agent-dashboard.py
  - scripts/blocker-log.py
  - hooks/pref-checkpoint.py
  - commands/ledger.md
  - commands/blockers.md
---

# Metrics

One command:

```bash
python3 scripts/agent-dashboard.py --days 30      # the report        (/ledger)
python3 scripts/agent-dashboard.py --json         # the same numbers, machine-readable
python3 scripts/agent-dashboard.py --selftest     # does the detector have teeth?
```

`--json` prints the dict `collect()` returns, and the panels render from that same dict, so a
number on screen and a number scraped by a script cannot disagree.

## /ledger shows the panels, it does not summarise them

The panels are the deliverable. Each one is built to name the number that makes it look bad, and
a summary is exactly where those annotations get dropped — so `/ledger` runs the script at
command expansion (`` !`python3 …` `` with `allowed-tools: Bash(python3:*)`) and instructs the
model to reprint the output **verbatim in one fenced block, before any words of its own**. At
most three lines of interpretation go underneath.

Bold is therefore terminal-only: `ANSI` is off unless stdout is a TTY (`NO_COLOR` also disables
it), because a raw `\x1b[1m` reprinted into a chat message renders as a literal `ESC[1m` in the
heading. `tests/test_metrics.py` asserts both halves — no escapes in piped output, and the
command file still runs the script and still forbids a summary.

## What is counted, and where it comes from

| Number | Source | Written by |
| --- | --- | --- |
| preference records | `topics/pref-*.md` in the memory dir | you, via `/prefs` |
| questions the ledger spoke to | `pref_events.tsv` kinds `inform` + `deny` | `hooks/pref-checkpoint.py` |
| questions no record matched | `pref_events.tsv` kind `uncovered` | same hook |
| re-issued anyway | kind `reissued` | same hook, deny mode only |
| your corrections | `rule_effect_log.tsv` event `human-correction` | session-end capture |
| blockers, by class | `blocker_log.tsv` | `scripts/blocker-log.py`, `/blockers` |
| stale / unbound docs | `scripts/docs-drift.py --json` | git, against `code_refs` |
| urgent-lane debt | `bd list --label urgent-lane-debt` in the current repo | `orchestrate.py dispatch --urgent` |

## The three rules these numbers obey

**Every count carries its denominator.** `uncovered` exists only for this. Before it, the
dashboard could say "the ledger spoke to 24 questions" — a number that looks identical whether
24 of 30 or 24 of 300 questions were asked. Coverage is now a share, and each uncovered
question is reported as *a record you have not written yet*.

**`inform` is never summed with `deny`.** In inform mode (`LCG_ASK_DENY=0`, the default) the
records are injected and the question still reaches you, so nothing was prevented. Adding it to
`deny` would report asks that never stopped happening.

**A record matches on phrases, not on loose tokens.** A `triggers:` entry is comma-separated,
so `mr description` is ONE phrase and matches only when both words appear in order. Tokenizing it
made every record with a common word in a trigger match everything, which inflates `inform` and
`deny` with hits that were never about that record. `trigger_terms()` in
`hooks/pref-checkpoint.py` splits on commas and keeps multi-word entries whole.

**Automated traffic is excluded from the human-facing effect.** `--selftest` drives the real
hook and writes real rows; the report drops rows whose session starts with `selftest-`, so
running the dashboard cannot raise its own coverage. The rows are still written — the hook has
one code path, and the filter lives in the reader.

## Each panel names the number that makes it look bad

A green with no path to red is not a measurement:

- **panel 1** — `re-issued anyway` rises when records are too broad, and `your corrections`
  rises when the ledger decides *wrong*.
- **panel 2** — an empty blocker log is reported as *nothing was logged*, never as *nothing
  stalled*.
- **panel 3** — the ledger-addressable share (`decision` / `premise`) should fall over time. If
  it is flat while `access` and `external` move, the ledger is not doing its job.
- **panel 5** — `oldest unpaid debt`, in days. Open count and age both rising means the urgent
  lane became the default and its deferred review became a write-off. An unused lane prints
  *has not been used*, annotated as **not** a pass.
- **zero uncovered questions** is annotated as *nothing unmatched was logged*, not as perfect
  coverage.

## Urgent-lane debt

`dispatch --urgent` ships a fix with one lens (`dod-tests`) and no approval round. What keeps
that from being a write-off is a bead, labelled `urgent-lane-debt`, created **at dispatch** —
before any code exists — naming the lenses that were skipped. A worker that dies mid-incident
therefore cannot take the only record of the skip with it.

Panel 5 reads those beads directly. There is no second store, because a second store is one
more thing to drift out of agreement with the first. It reads the repo you run it from.

With no `bd`, or a repo with no `.beads`, the panel reports **UNAVAILABLE** rather than zero.
"Nothing is owed" and "nobody can see what is owed" are opposite facts, and a dashboard that
prints them the same way is worse than one that prints nothing.

## Blockers

`scripts/blocker-log.py` is linked to `~/.scripts/blocker-log.py` by the installer, because the
always-load rules call it by that exact path. When the link is missing the failure is silent:
the rule fires, the path does not exist, nothing is logged, and panels 2 and 3 quietly report
nothing. `tests/test_install_links.sh` drives every linked entry point through its symlink for
that reason.

```bash
blocker-log.py block --task DE-461 --title "retry wrapper on fetchQuote" \
                     --class decision --reason "waiting on which retry policy"
blocker-log.py clear --task DE-461 --by user
```

Classes: `access`, `decision`, `dependency`, `premise`, `external`, `flake`, `other`. Only
`decision` and `premise` are the ledger's job — a class with 2+ hits is a process fix, not a
ticket fix.
