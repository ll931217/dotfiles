---
title: Human-facing output — what the user sees, and what it costs to always show it
code_refs:
  - skills/show-me/SKILL.md
  - rules/ux-obviousness.md
  - hooks/always-load-budget-warn.py
---

# Human-facing output

Three pieces, one subject: the surface a human actually reads.

## `/show-me` — explain the topic visually

The skill picks the smallest view that makes the point: pseudocode for an algorithm, a call
tree for control flow, a shaped diff, a Mermaid graph, or a focused HTML artifact. It also
owns **MR and PR descriptions**, where one shaped diff tells a reviewer what changed faster
than a paragraph. Triggers on "show me / diagram / sketch / MR description" in either
language.

An MR body it writes must carry a `## Proof` section holding an artifact the change actually
produced — a fenced test run, a screenshot, a tmux capture — not a claim that it works.
`hooks/mr-proof-gate.py` denies `glab mr create` without one; see
`docs/gates-deny-while-evidence-is-free.md`.

## `rules/ux-obviousness.md` — the standard the output must meet

Always-load rule: if understanding a human-driven surface requires opening the source, the
feature is not done. Names say the effect, every failure names the offending thing and the
next action, every action confirms what changed and where. The rule also demands **one runnable
E2E per surface** that asserts the user-visible text, not just the exit code — an exit 0 with
an empty screen is exactly what it exists to catch.

## `hooks/always-load-budget-warn.py` — what showing it forever costs

Everything under `~/.claude/rules/` is injected in full into every session, so the tier grows
one reasonable-looking addition at a time until sessions feel heavy and nobody can say when it
happened. This `SessionStart` hook prints the ledger, loudest file first, so the next addition
is a decision instead of a drift. Budget: `ALWAYS_LOAD_BUDGET_TOKENS` in
`~/.claude/memory-kit.conf`, default 9000.
