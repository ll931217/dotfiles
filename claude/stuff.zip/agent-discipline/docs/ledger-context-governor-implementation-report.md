---
code_refs:
  - scripts/ledger-calibration.py
  - scripts/ledger-readiness.py
---

# Ledger Context Governor — implementation report

Against `docs/ledger-context-governor-implementation-spec.md` v0.2.0.
Session of 2026-09-03. Baseline `23290c1` → head `7f12ceb`.

## Summary

**Phase 0 is complete and its exit criteria are met. Phases 1 through 4 are not started.**

Phase 0 turned out to be the load-bearing phase. The spec is written for a service with a
database, migrations, repositories and adapters; this repository is a Claude Code plugin of
standalone scripts whose ledger is **markdown files in the user's memory directory, outside this
repository and shared with memory-kit**. Discovering that before writing a typed schema is the
difference between an additive migration and one that damages user data.

One conflict needs the user's decision before Phase 4 can land. It is stated in full under
"Decision required".

## Completed requirements

| # | Requirement | Evidence |
|---|---|---|
| 0.1 | Gap analysis document | `docs/ledger-context-governor-gap-analysis.md`, 321 lines: the ten §2 audit items, a requirement matrix for phases 0-4, three conflicts, seven risks |
| 0.2 | Characterization tests for existing ledger and hook behavior | `tests/test_characterization_ledger.py`, 14 tests |
| 0.3 | Installed Claude Code version and supported-event matrix | gap analysis §3. Claude Code 2.1.259 |
| 0.5 | Feature flags with conservative defaults | `config.py`, 11 flags, all new behaviour off |
| 0.6 | Existing tests pass unchanged | 9 shell suites + `tests/test_gates.py`, green before and after |

**Exit criteria**

- *Existing tests pass unchanged* — yes. No existing test was edited for this work.
- *Current behavior is documented* — yes, and pinned executably rather than only in prose.
- *Migration and compatibility risks identified* — yes, R1-R7 with severities and mitigations.

### The characterization tests have a proven path to red

A characterization suite that cannot fail records nothing. Three mutations were applied to
`hooks/pref-checkpoint.py` and reverted:

| Mutation | Tests that failed |
|---|---|
| `permissionDecision: deny` → `allow` | 3 |
| remove the re-issue escape hatch (`if key in seen` → `if False`) | 2 |
| `MIN_SCORE = 2` → `0` | 1 |

Green again after restore, and `git diff` on the hook is empty.

## Deferred requirements

| Phase | Status | Why |
|---|---|---|
| 0.4 architecture diagram refresh | deferred | cosmetic; `docs/gen_mechanism.py` is the place, and it is cheap once phases 1-2 change the shape |
| 1 typed ledger, projection, migration, receipts | **not started** | blocked on nothing technical, but see "Decision required"; the migration writes to a user-owned store shared with memory-kit and must not begin before the flag semantics are agreed |
| 2 resolver, `M0`, external session state | not started | depends on Phase 1's entry type |
| 3 discovery, manifest deltas, coverage | not started | depends on Phase 2's manifest |
| 4 shadow `AskUserQuestion`, `Stop` resolution | not started | depends on the C1 decision below |

Nothing from phases 1-4 was partially implemented. The repository sits on a clean phase boundary
rather than mid-refactor, which is the state the spec's phase gates are designed to preserve.

## Decision taken — conflict C1 (resolved 2026-09-03)

**The user chose B.** `LCG_ASK_DENY` defaults to `0`: the ledger's records are injected and the
question still reaches the user. The legacy deny-once path is available at `LCG_ASK_DENY=1` and
remains covered by tests, so the change is one flag wide in either direction.

What changed as a result:

| File | Change |
|---|---|
| `config.py` | `LCG_ASK_DENY` default `1` → `0`, with the reason recorded inline |
| `hooks/pref-checkpoint.py` | added the inform path: `permissionDecision: "allow"` with the records in `additionalContext`; a new `inform` event kind; a broken config fails toward informing, never toward denying |
| `scripts/agent-dashboard.py` | counts `inform` beside `deny` without summing them, and says plainly that inform mode has no "asks you never saw" number to report |
| `tests/test_characterization_ledger.py` | 14 → 19 tests: the new default pinned, the legacy path kept under the flag |

**A consequence worth stating.** In inform mode the ledger cannot prevent an ask, so the
dashboard's headline "asks you never saw" is structurally zero. The metric changes meaning from
*prevention* to *coverage* — how often the ledger had something relevant to say. The dashboard
now says so on screen rather than showing a silent 0.

The self-test's positive control asserted the literal string `deny`, so it failed the moment the
default changed and reported a broken detector when the detector was fine. It now asserts that
the ledger fired, whichever shape that takes.

## Original analysis — conflict C1

The spec's Phase 4 exit criterion is **"No question is suppressed."** Today
`hooks/pref-checkpoint.py` **denies** the first occurrence of a matching question, then allows a
re-issue. Independently, the user's own ledger record `pref-hooks-inform-never-block`
(confidence: `stated`) says to add only hooks that inject context or log, and to leave out any
hook that denies — the goal being unattended execution.

So the spec and a standing user preference agree with each other, and both disagree with the code
that exists.

Provisionally resolved as: **keep today's deny byte-for-byte behind `LCG_ASK_DENY`, default 1.**
Reasoning: §2 forbids silently reinterpreting existing behaviour, and the instruction for this
work constrains *new* autonomy — it does not authorise removing an existing gate unasked.

The alternative, and the one both the spec and the standing preference point at, is
`LCG_ASK_DENY=0`: the hook injects the matching records and never denies. That is a one-flag
change, already tested in both positions.

**Checked in the spec after this was first drafted, and it is more one-sided than it looked.**
§18.9 — the `PreToolUse[AskUserQuestion]` interception — emits only
`"permissionDecision": "allow"` with an `updatedInput`, in every mode including the most
autonomous. **It never denies.** The only hook in the design that emits `"deny"` is the §18.8
mutation coverage gate, and even that "may record what it would have blocked without denying" in
observe or shadow mode.

**A: keep the deny (today's behaviour, current default).
B: flip to inform-only (`LCG_ASK_DENY=0`).**

I would go **B**. Three independent sources now agree this hook should not block: the spec's
mechanism for it, the spec's Phase 4 exit criterion, and the user's own recorded preference. It
stays the user's call only because it visibly changes a gate they rely on.

## Changed files

| File | Change |
|---|---|
| `docs/ledger-context-governor-gap-analysis.md` | new — the §2 required audit |
| `docs/ledger-context-governor-implementation-report.md` | new — this file |
| `config.py` | new — feature flags, 3.12-compatible on purpose |
| `tests/test_characterization_ledger.py` | new — 14 characterization tests |
| `pyproject.toml` | additive `[tool.pytest.ini_options]` |
| `.claude/skills/verify-changes/SKILL.md` | regenerated; three learned facts recorded |
| `scripts/testing-handbook.py` | fixed a false-green (see compatibility findings) |
| `tests/test_testing_handbook.sh` | regression tests for that fix |

No existing hook, script, skill or command was modified. `hooks/pref-checkpoint.py` is
byte-identical to the baseline.

## Migrations

**None ran, and none exist.** The repository has no migration mechanism — the ledger is markdown
files in the user's memory directory. `LCG_MIGRATE_ENTRIES` defaults to `0`, meaning a future
Phase 1 migration is dry-run until deliberately enabled. That default exists because the store is
not owned by this repository.

## Commands run

```
uv run pytest                          # 14 passed
python3 tests/test_gates.py            # ok — gate assertions passed
for t in tests/*.sh; do bash "$t"; done  # 9 suites, all green
python3 config.py                      # flag surface, all conservative
uv run pytest --collect-only -q        # 14 collected (was: 0)
python3 -c "json.load(...)" x3         # plugin.json, marketplace.json, hooks.json valid
ast.parse over 16 python files         # all parse on the hook interpreter, 3.12.3
claude --version                       # 2.1.259
```

Every registered hook handler was checked to exist and be executable.

## Compatibility findings

1. **Claude Code 2.1.259.** `PostToolUseFailure`, `SubagentStart`, `SubagentStop` and
   `PostToolBatch` are all real and available — `PostToolBatch` is registered by a published
   plugin in the local catalog cache. **`PreCompact` is unverified**; §18.13 rehydration should
   be driven from `SessionStart` instead.
2. **Hooks do not run in the uv environment.** They execute as `#!/usr/bin/env python3`, which is
   3.12.3 here, while `pyproject.toml` declares `requires-python = ">=3.14"`. Any shared module a
   hook imports must parse on 3.12. `config.py` is pinned to that interpreter by a test.
3. **`src/agent_discipline/` is an empty skeleton.** It contains a `main()` that prints a
   greeting. No script or hook imports it. Phase 1 is the first work that would justify it.
4. **The frontmatter keys `description` and `triggers` are a contract with memory-kit's recall
   hook**, which this repository does not own. A typed entry may add keys; it may not rename these.
5. **`pref_events.tsv` columns are read by `scripts/agent-dashboard.py`.** Append only.
6. **`UserPromptSubmit` is already occupied** by `pref-capture-nudge.py`. Phase 2's `M0` injection
   shares that event, and two handlers injecting context compete for the same budget.
7. **`updatedInput` replaces the whole tool input** (§18.9). Any field not echoed is dropped.
8. **The resolver core may not depend on Claude Code hook payload types** (§7.16). No hook here
   has that separation today; Phase 2 is where it has to appear.
9. **A false green was found and fixed in this session's earlier work.** `uv run pytest`
   collected zero tests, and the generated verification handbook had recorded it as the way to
   verify a change — a command that exits 0 having run nothing. The generator now probes the unit
   runner with `--collect-only` and rejects one that discovers nothing.

## Known risks

| ID | Risk | Severity |
|---|---|---|
| R1 | Hook interpreter (3.12) differs from the declared runtime (3.14) | high |
| R2 | Phase 1 migration writes to a user-owned store shared with memory-kit | high |
| R3 | `pref_events.tsv` schema is read by the dashboard | medium |
| R4 | `PreCompact` unverified | medium |
| R5 | Two handlers on `UserPromptSubmit` competing for context budget | medium |
| R6 | No property or replay test framework yet; `pytest` only began collecting in this phase | medium |
| R7 | Spec is 36 sections and 9 phases against a 2,540-line codebase | high |

**A limitation of what was built:** the verification handbook's "Learned here" section is
append-only and has no supersession. One line written earlier in this session became false within
the hour and had to be removed by hand. If workers write to it routinely, `--learn` needs a way to
retire a line.

## Suggested next step

Answer C1, then Phase 1 in this order: entry type and its parser beside the existing one
(`LCG_TYPED_LEDGER=0` keeps the current reader), a dry-run migration report over the real
memory directory, the active projection, then receipts. The characterization tests already pin
what must not change while that happens.
