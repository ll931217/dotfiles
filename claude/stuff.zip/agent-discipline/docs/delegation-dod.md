---
title: Delegation state — one definition of done per task
code_refs:
  - scripts/delegate.py
  - scripts/orchestrate.py
  - skills/delegate-to-worktree/SKILL.md
  - skills/orchestrate/SKILL.md
  - prompts/worker.md
  - commands/delegate.md
  - commands/orchestrate.md
  - scripts/agent-orchestrator.sh
  - scripts/agent-worker.sh
  - scripts/agent-config.sh
  - hooks/orchestrator-hands-off.py
---

# One DoD per task

The orchestrator writes a definition of done before any code exists; the worker checks itself
against it; the orchestrator reviews against it and nothing else. That file has to be readable
by both and writable by the worker.

It used to be `<worktree>/.claude/DOD.md` — one fixed name. The file is tracked, so with two
worktrees off one repo, worker A committed its DoD at that path and worker B's rebase refused
to overwrite its own. **B then ran against a DoD it could not write.** Two concurrent workers is
the normal case here, so a single fixed name was a collision waiting for a second worker.

## Eight lanes, one DoD file

The DoD is always written; what changes per lane is how many lenses fill it, how many rounds it
gets, and who approves. A lane is a **price**, never a mood — each one names the part of the full
price it refuses to pay. `--lane <name>`; `--small` and `--urgent` remain as shorthands.

| lane | lenses | rounds | approval | MR | also needs |
| --- | --- | --- | --- | --- | --- |
| full (default) | 4 core + 1-3 domain | 3 | yes | after approval | — |
| small | intent, tests | 1 | yes | after approval | `--touches P …`, at most 3 paths |
| urgent | tests | 1 | no | worker opens it | `--why "<what is broken>"` |
| risky | full set | 3 | yes, **and the plan before any code** | after approval | — |
| mechanical | intent, tests | 1 | yes | after approval | `--touches P …`, any number of paths |
| spike | none | 0 | no | none — the deliverable is a written answer | `--why "<the question>"` |
| revert | none | 0 | yes | after approval | `--revert-of <sha>` |
| repay | the lenses an urgent fire skipped | 3 | yes | after approval | `--key <debt-bead>` |

The discounts are not the same discount:

- **small** — the risk is genuinely low, so the gate is mechanical and reads the paths: at most
  3, none matching CI, migration, infra or secret files. It refuses before creating a worktree,
  because a rejected lane must leave nothing behind.
- **mechanical** — a rename or a sweep: same two lenses, same path gate, but **no cap on how
  many paths**, because a 40-file rename is not 40 risks.
- **urgent** — the risk is unchanged and only the schedule moved, so there is no path gate at
  all: a broken production auth path is exactly the file the small gate refuses.
- **risky** — the one lane you can fall **into**. Nobody reaches for more review under deadline,
  so a `full` dispatch whose `--touches` hits a CI / migration / infra / secret path is upgraded
  to `risky` automatically, and the upgrade is printed.

What stops urgent becoming a write-off is that the skipped review is booked as a bead
(`urgent-lane-debt`) at dispatch, before any code exists — so a worker that dies mid-incident
cannot take the record with it. The **repay** lane is how that bead is closed: it reads the
skipped lenses back off the bead and runs them over the merged diff. `/ledger` panel 5 reports
the open count and the age of the oldest unpaid one. With no `bd`, dispatch and TASK.md both say
the skip is UNRECORDED rather than dropping it.

Two lane flags at once are refused, and so is a lane missing its required argument. Neither gate
is ever widened to fit a task — a refusal is the signal the task does not belong on that lane.

## The path now

```
<worktree>/.claude/dod/<key>.md        # key = the bead or Jira key
<worktree>/.claude/dod/<branch>.md     # no key given: the branch, unique by construction
<worktree>/.claude/DOD.md              # still read if it already exists
```

Decided in **one** place — `dod_path()` in `scripts/delegate.py` — and published in **one**
place: `orchestrate.py dispatch` writes a `DoD file:` line into `<worktree>/.claude/TASK.md`,
so the worker, the orchestrator and `delegate.py` cannot disagree about where it is. After
`delegate.py start`, the path is stored in `delegate.json` as `dod_path`, so later rounds read
it from state rather than re-deriving it.

`orchestrate.py status` prints it per worktree under `file`.

## Two rules this keeps

- **A legacy `DOD.md` on disk keeps being used.** A delegation started before this change does
  not lose its file mid-flight; only new ones get the per-task path.
- **`delegate.py` must be importable.** `orchestrate.py` imports `dod_path` from it so the two
  cannot drift. Its argument parser therefore lives inside `main()`; at module level it ran on
  import and turned that import into `orchestrate.py: error: invalid choice: 'dispatch'`.

Covered in `tests/test_orchestrate.sh`: the per-task file is written, the shared `DOD.md` is
not created, `status` names the file, and an existing legacy `DOD.md` is still honoured.

## The bookkeeping is ignored, in two places

`TASK.md`, `delegate.json`, the DoD file and `mr-body.md` (the MR description the worker
writes with the `show-me` skill, passed to `glab mr create --description "$(cat …)"`; it must
carry a `## Proof` section with a real artifact, or `hooks/mr-proof-gate.py` denies the command)
are bookkeeping
for one task on one machine. Both obvious choices are wrong on their own:

- **tracked** — two workers on one repo collide on a committed copy (that is the bug above)
- **untracked and un-ignored** — every delegated worktree is permanently dirty, and
  `worktree-reap.py` refuses to remove a dirty worktree. The bookkeeping silently blocked its
  own cleanup.

So `ensure_ignored()` (in `scripts/delegate.py`, called by `orchestrate.py dispatch` and by
`delegate.py start`) writes the same five entries to **two** files, because each covers what
the other cannot:

| File | Reaches | Cost |
| --- | --- | --- |
| `<main checkout>/.gitignore` | teammates and CI | tracked — only reaches a worktree once someone commits it |
| `<common git dir>/info/exclude` | the main checkout **and every worktree, immediately** | machine-local, never shared |

```
.claude/TASK.md
.claude/delegate.json
.claude/dod/
.claude/DOD.md
.claude/mr-body.md
```

Two details that are easy to get wrong:

- It writes to the **main checkout's** `.gitignore`, not the worktree's. That file is tracked
  with a separate working copy per worktree, so appending to the worktree's copy dirties the
  worktree — the exact state being avoided. The main checkout is `git worktree list`'s first
  entry.
- `info/exclude` lives in the **common** git dir, which every worktree shares, so it applies
  inside worktrees created later with nothing to commit.

Idempotent twice over: a marked block already present is not written again, and a `.gitignore`
that already lists the entries by hand is left untouched.
