---
title: Testing handbook — each repo's verification detected once, not re-guessed per task
code_refs:
  - scripts/testing-handbook.py
  - commands/testing-handbook.md
  - skills/testing-handbook/SKILL.md
---

# Testing handbook

Every repo answers the same questions differently: what runs the tests, what drives a browser,
whether a property or mutation tool is even installed. A worker that re-derives that per task
guesses. So it is detected **once per repo** from the manifests, each command is verified to
actually resolve, and the result is written as a project skill the worker loads before it
reports anything finished: `<repo>/.claude/skills/verify-changes/SKILL.md`.

```bash
python3 scripts/testing-handbook.py --check            # what was detected; with a handbook present, the DRIFT
python3 scripts/testing-handbook.py                    # write the skill (refuses to clobber hand edits)
python3 scripts/testing-handbook.py --force            # re-detect
python3 scripts/testing-handbook.py --learn "<line>"   # a worker records what it learned, dated
```

`/testing-handbook` runs the skill. Run `--check` first and read the rows: a wrong row becomes a
wrong instruction for every future worker in this repo.

## Missing is recorded, never omitted

A technique whose tool is absent is written as **MISSING**, with the command to install it. A
handbook listing only what happens to be installed reads as if the rest were done.

## Two halves, one generated

The file has a marker (`<!-- learned:begin … -->`). Everything above it is re-detected on every
`--force`; everything below is written by workers and never overwritten. A generator that
promised to keep hand edits and then replaced the whole file would be worse than one that never
promised — so the promise is enforced by the marker, not by intent.
