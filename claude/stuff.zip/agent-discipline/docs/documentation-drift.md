---
title: Documentation drift — binding docs to code, and catching the drift at the edit
code_refs:
  - scripts/docs-drift.py
  - hooks/docs-drift-nudge.py
  - commands/docs.md
---

# Documentation drift

A document that describes code it is not bound to is worse than no document: it is confidently
wrong, and nothing tells you when it stopped being true. So the binding is declared in the
document itself and checked against git.

## The binding

```yaml
---
title: Metrics
code_refs:
  - scripts/agent-dashboard.py
  - hooks/pref-checkpoint.py
---
```

A ref is a path, a directory, or a glob. Several refs on one doc is the normal case — one
document per **feature**, not per file.

What counts as code: files under `hooks/ scripts/ ledger/ commands/ skills/ rules/ prompts/
engine/ src/ lib/ app/` that exist, plus **top-level modules** in the repo root. Root `.md` is excluded
on purpose — `README.md` and `CLAUDE.md` are prose, not a feature awaiting a document.
`docs/`, `tests/`, `__pycache__`, `node_modules` and `.venv` are skipped, and so is any FILE
named `test_*` / `test-*`: a repo that keeps `scripts/test-recall-cue.sh` beside its real
scripts would otherwise have every test reported as an undocumented feature, burying the real
ones.

`engine/` is there for repos that keep their deployed code under one tree — memory-kit installs
by copying `engine/scripts` and `engine/hooks` into `~/.claude`. Without it the report saw 42 of
that repo's files and none of its actual engine.

## The three states

| State | Meaning | What to do |
| --- | --- | --- |
| **stale** | a bound file has a newer commit than the doc, or is modified in the working tree while the doc is not | update the doc |
| **broken ref** | the ref matches no file — renamed or deleted | repoint or drop the ref |
| **unbound** | no doc claims this code file | write or extend a doc, then add the ref |

A brand-new file has no commit, which counts as newer than any doc: undocumented by
definition.

## Where it fires

**At the edit.** `hooks/docs-drift-nudge.py` runs on `PostToolUse[Edit|Write|MultiEdit]` and
names the doc the change just made stale, or says no doc claims the file. It informs and never
blocks, and it goes quiet once per session per file, and entirely once the doc itself is
edited. That moment is chosen deliberately: the file is in hand and the reason for the change
is still in context. A `Stop` hook arrives after the session has moved on; a pre-commit gate
would have to block, and a gate people bypass on every WIP commit measures nothing.

**On demand.**

```bash
python3 scripts/docs-drift.py             # the whole repo
python3 scripts/docs-drift.py --changed   # only docs bound to what is uncommitted now
python3 scripts/docs-drift.py --unbound   # code no doc claims
python3 scripts/docs-drift.py --for hooks/pref-checkpoint.py
python3 scripts/docs-drift.py --json      # the dashboard reads this
python3 scripts/docs-drift.py --strict    # exit 1 when stale — for CI, off by default
```

`/docs` drives the same two commands and does the writing.

## What it will not claim

With no `code_refs` anywhere, **nothing is checked** — and the report says exactly that rather
than printing a clean bill of health. Zero stale docs out of zero bindings is not a pass, and
the dashboard reports the docs panel as *unavailable* rather than as zero drift when the script
or index is missing.

## Where it over-reports

A file bound to two documents makes **both** stale when either subject changes:
`scripts/orchestrate.py` is bound to `optional-tools.md` (its `wt`/`bd` fallbacks) and to
`delegation-dod.md` (the DoD path and the ignore block), so a change to one flags the other.
Bindings are per FILE, with no line ranges.

That is the intended trade: the alternative is line ranges, which rot on every edit and go
stale silently — the failure this whole mechanism exists to prevent. When the flag is a false
positive, say so in the reply and move on; the report is advice, and only `--strict` gates.
