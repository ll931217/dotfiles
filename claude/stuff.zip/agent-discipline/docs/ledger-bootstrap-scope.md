---
title: Bootstrapping a preference ledger from memory that already exists
code_refs:
  - scripts/ledger-bootstrap.py
  - skills/preference-ledger/SKILL.md
  - skills/preference-ledger/procedure.md
  - hooks/pref-capture-nudge.py
  - hooks/pref-preload-on-skill.py
  - rules/answer-shape.md
---

# Ledger bootstrap — scope

**Built.** `scripts/ledger-bootstrap.py`, to the shape below. Two things changed while
building it — both recorded in "What the extractor learned" at the end.

## The problem

Every reader of the ledger requires two things of a file: the name matches `pref-*.md`, and the
body contains `**Preference:**` (`hooks/pref-checkpoint.py:114,118`,
`hooks/pref-preload-on-skill.py:80,84`, `ledger/compat.py:138`). A teammate who has run
memory-kit for months therefore starts at **zero records**: their `topics/` holds
`komodo-skill.md`, `user_profile.md`, project findings — none of it visible. `/ledger` reads as
broken on day one, and the hook that is supposed to answer preference questions has nothing to
say until they hand-write records for decisions they already made.

## What it must produce

A `pref-*.md` record's value is not the outcome — it is **the rejected option and the reason**.
Existing memory almost never states the rejected option, so a bootstrap that fabricates one is
worse than no record: it feeds `pref-checkpoint` a confident answer nobody gave. The scope is
therefore *candidate extraction with a human gate*, never direct writes.

```
ledger-bootstrap.py                 # DRY RUN: what it found, grouped by confidence
ledger-bootstrap.py --write-drafts  # write candidates to topics/drafts/, NOT to topics/
ledger-bootstrap.py --promote <id>  # one candidate -> a real pref-*.md, after you edited it
```

`topics/drafts/` is deliberately a subdirectory: the recall hook only scans the flat `topics/`,
so a draft can never be injected as if it were a decision.

## Sources, best first

| Source | Why it is good | What it cannot give |
| --- | --- | --- |
| `rule_effect_log.tsv`, `event=human-correction` | every row IS an override — the strongest signal that a preference exists | the reason; the summary is ≤80 chars |
| `topics/*.md` with imperative or preference language ("always", "never", "使用者要求", "prefer", "don't") | states the outcome | the rejected option |
| daily logs (`daily/*.md`) | carries the surrounding reasoning | noisy; one day per file |
| `pref_events.tsv` `uncovered` rows | the questions that reached the user with no record — a to-write list keyed to real asks | nothing about the answer |

The last one is the highest-value and cheapest: it needs no NLP at all, only a group-by.

## Confidence, and what each tier is allowed to do

| Tier | Evidence | Action |
| --- | --- | --- |
| `derived-strong` | a correction row AND a topic file agreeing on the same subject | draft with both quoted, marked for review |
| `derived-weak` | one imperative sentence in one topic file | draft with `**Over:** UNKNOWN — fill in or delete` |
| `uncovered-only` | repeated asks, no memory | a stub naming the question, with no answer invented |

No tier writes into `topics/` and none sets `confidence: stated` — only the user saying it does
that.

## Acceptance

1. On a memory dir with zero `pref-*.md`, produces ≥1 candidate per correction row, and
   `pref-checkpoint` still injects **nothing** until a promotion happens.
2. A candidate with no rejected option carries the literal `UNKNOWN` marker; promoting it while
   that marker is present is refused with the offending line named.
3. Re-running is idempotent: an already-promoted subject is reported as `already in the ledger`,
   not drafted twice.
4. `--promote` on a subject that collides with an existing record reports the conflict and the
   winner instead of overwriting.
5. Runs against a memory dir with no `rule_effect_log.tsv` and no daily logs without failing —
   reporting *what it could not read*, never a clean bill of health.

## Open question for the reviewer

Whether the drafts should carry the source quote inline (bigger files, self-contained per rule
AS1) or a `source:` pointer to the daily log line. Inline is assumed here.

## Effort

Roughly one phase: one script, one test file, no new dependencies. The extraction is
line-oriented pattern matching over markdown and TSV — no model call, so it is reviewable and
runs offline.
