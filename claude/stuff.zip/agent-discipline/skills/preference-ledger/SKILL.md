---
name: preference-ledger
description: Record and reuse WHY the user chose what they chose — every option pick, override, rejected alternative, and the reasoning (stated or derived). Use when the user picks between options you offered, overrides your approach, says "I'd rather", "no, do X instead", "that's the kind of response I want to avoid", or explains why they want something. Also use BEFORE asking the user a preference-type question, to check whether a past decision already answers it. Triggers on /prefs, "learn from this", "remember why", "how would I want this handled".
user_invocable: true
trigger: /prefs
---

# Preference Ledger

Corrections are already captured (`rule_effect_log.tsv`, `human-correction`). That log records
**that** the user pushed back. This skill records **why**, plus the option they did NOT take —
which is what makes a future decision derivable instead of guessable.

**BLOCKING — Read `${CLAUDE_PLUGIN_ROOT}/skills/preference-ledger/procedure.md` and follow
it exactly.** It holds the record schema, the derive-vs-state rules (including when NOT to infer),
the confidence ladder, and the retrieval contract used at decision time.

Two modes:
- **Capture** (after a pick/override) — write or sharpen one record.
- **Consult** (before a preference-type question, per rule `AS2` in `~/.claude/rules/answer-shape.md`)
  — retrieve, decide, state the assumption, do not interrupt.
