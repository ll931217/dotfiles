# Preference Ledger — procedure

Records live in the `topics/` directory of YOUR global memory dir, as `pref-*.md`. Resolve the
path — never type someone else's:

```bash
python3 -c "import sys;sys.path.insert(0,'${CLAUDE_PLUGIN_ROOT}');from agent_discipline_paths import topics_dir;print(topics_dir())"
```

It resolves to `~/.claude/projects/<$HOME with / . _ replaced by ->/memory/topics`, the same
directory memory-kit writes, and honours `AGENT_DISCIPLINE_MEMORY_DIR` when memory lives
elsewhere.
One decision per file. They are surfaced by the existing memory recall hook, so the
`description:` / `triggers:` cues ARE the retrieval mechanism — write them for the situation
the preference should fire in, not for what it contains.

## MODE A — Capture

Fires when the user: picks one of your options, overrides your approach, reverses an omission
you made, states a reason for wanting something, or rejects the shape of an answer.

Do NOT capture: pure task instructions ("now do the frontend"), one-off factual answers,
or anything already in `~/.claude/rules/` or canon.

### Schema

```markdown
---
name: pref-<slug>
description: "<when this should fire, bilingual zh+en — a future prompt may arrive in either>"
triggers: "<comma-separated, zh+en, ascii terms must be single tokens>"
metadata:
  node_type: preference
  status: provisional | settled
  confidence: stated | derived-strong | derived-weak
  observations: <n>
  type: user
  originSessionId: <sid>
  modified: <iso8601>
---

**Preference:** <one line, imperative — what to do next time>

**Chose:** <the option taken>
**Over:** <the option rejected — this field is the whole point, never omit it>

**Why:** <the reason. If the user stated it, quote them. If derived, mark it `(derived)` and
say from what.>

**Generalizes to:** <the class of future decisions this should settle — be specific enough to
be actionable, narrow enough to not overreach>

**Does NOT apply when:** <the boundary. A preference with no stated limit becomes cargo-cult.>
```

### Confidence ladder

| Level | Meaning | Autonomy it grants |
|---|---|---|
| `stated` | user gave the reason in their own words | act on it silently |
| `derived-strong` | ≥2 consistent observations, no counterexample | act, and state the assumption in one clause |
| `derived-weak` | 1 observation, reason inferred | act only on low-cost/reversible calls; otherwise ask |

Promote on repeat: bump `observations`, raise confidence, flip `status: settled` at 3 consistent
observations. On a counterexample, do NOT delete — add `Does NOT apply when:` and drop confidence
one level. The boundary is more valuable than the rule.

### Derivation limits

Derive from what the user did and said. Never invent a motive to make a tidy story. If you cannot
name the observation a reason came from, it is `derived-weak` at best — or not a record at all.
When a pick has no discernible reason, capture the pick with `Why: not stated` rather than
fabricating one; the counterfactual (`Over:`) still carries signal.

## MODE B — Consult

Before asking any preference-type question (rule `AS2`):

1. `rg -l` over `topics/ (pref-*.md)` for the decision class; read matches.
2. Match found at `stated` or `derived-strong` → act on it. Say what you assumed, in one clause,
   inline (rule `AS1` — carry the reasoning, not just the filename).
3. Match at `derived-weak`, or conflicting records → act if cheap and reversible; otherwise ask,
   and include what the past record says so the user is confirming, not re-deriving.
4. No match → ask, then immediately capture the answer as a new record (Mode A).

A question the ledger could have answered is a defect. After answering one, ask why it was not
already a record, and write it.

## Write discipline

Follow CLAUDE.md strict write discipline: write file → verify it exists → add/refresh the index
line in the global `MEMORY.md`. Check the tier lock (`state.json.lock`) before multi-file writes.
Universal + sanitizable preferences about *how to work* (not about this user specifically) are
canon candidates — flag them, never auto-merge.
