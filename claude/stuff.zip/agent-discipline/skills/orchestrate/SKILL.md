---
name: orchestrate
description: Run a batch of tasks through parallel worker sessions — one worktree and one worker Claude per ready task — while this session only dispatches, reviews and approves. Use when the user hands over several tasks or subtasks, a sprint, a beads epic, or says to orchestrate, fan out, parallelize, delegate the lot, or "run these through workers"; also right after `wt switch --create` when a worker session has appeared and this session is about to implement instead. Triggers on /orchestrate.
user_invocable: true
trigger: /orchestrate
---

# Orchestrate: you dispatch and review, workers implement

Two roles, two models. You are the orchestrator: the smartest model, highest effort, holder of
the conversation. Start this session with `~/.scripts/agent-orchestrator.sh` when you know a
batch is coming — effort cannot be raised from inside. Each worker is the Claude that worktrunk
starts in the worktree, with `prompts/worker.md` as its role (`~/.scripts/agent-worker.sh`, run
by the `wt` post-start hook). Models and efforts for all three roles live in
`~/.config/agent-discipline.env`; `~/.scripts/agent-config.sh --show` prints what is in force.

You never edit code in this flow. Not in the main checkout, not in a worktree.

## 1. Plan — what can run in parallel

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/orchestrate.py" plan
```

`bd ready` is the parallel set: open issues with no open blockers. No beads → dispatch by hand
from the user's list. Dependencies between tasks are beads `dep` edges, not your memory.

## 2. Dispatch — one worker per task

Find your own session name first: `ListAgents` prints it on the first line. Then, per task:

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/orchestrate.py" dispatch \
  --key <bead-id> --branch <type>/<slug> --task "<one sentence, what done means>" \
  --orchestrator <your session name>
```

That creates the worktree (branched off `staging` when it exists), and writes
`<worktree>/.claude/TASK.md`: task, your name, constraints, and the ledger records whose cue
overlaps the task — the worker reads preferences from the file, not from you.

Then `ListAgents`: the worker appears as `worker:<branch>` (measured: the launcher's `--name` is what the list shows). `SendMessage` it:
"Read .claude/TASK.md and begin." **Not listed after a minute → it did not start.** Say so and
start it (`cd <worktree> && ~/.scripts/agent-worker.sh` in a tmux window). Never wait on a
session that is not in the list.

Dispatch every ready task before reviewing any. Workers run concurrently; you do not.

## 3. Wait — the worker owns the DoD

The worker spawns 5 DoD teammates (intent, tests, UX, discipline, prefs), writes
`.claude/DOD.md`, implements, has the teammates verify, and messages you **only when all five
pass** — or when it hits the 3-round cap with a lens still failing. Until then:

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/orchestrate.py" status
```

Every row ends with `next: …`. `REVIEW` is the only one that needs you.

## 4. Review — against DOD.md, issues not fixes

Read `<worktree>/.claude/DOD.md` and the diff (`git -C <worktree> diff <base>...HEAD`). Run the
check the worker named. Then one of:

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/orchestrate.py" approve --worktree <path>
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/orchestrate.py" reject  --worktree <path> --issue "<what fails which DoD item>"
```

Each prints the message to `SendMessage` the worker. A rejection names the symptom and the
item, never the patch. Approve → the worker pushes and opens the MR into `staging`.

## 5. After the MR

The push hook starts `glab-watch-mr.sh`, and the same hook hands the worker the one command that
wakes it when the MR ends — the worker owns its MR until then. On merge the watcher reaps the
worktree, branch and tmux window. Simple MRs (docs / chore / style / test, docs-like paths only)
go through `/automerge`; every other MR is the user's to merge. Nothing is reaped before merge.

`orchestrate.py status` shows each MR and its pipeline, so you can see a red one without asking
the worker. A worker that reported "MR opened" and then went quiet through a merge or a red
pipeline did not arm its wake-up: send it the outcome, and say so — that is a mechanism failure,
not a worker to nag every time.

## Boundaries

- One task, one worktree already in hand, no batch → `/delegate` is enough.
- A worker escalates (`escalated` in status) → stop, bring the user the DoD and the rounds, and
  the question: is the DoD wrong or the approach?
- A worker session is gone mid-task → say so; do not take the work back silently.
