---
name: orchestrate
description: Run a batch of tasks through parallel worker sessions — one worktree and one worker Claude per ready task — while this session only dispatches, reviews and approves. Use when the user hands over several tasks or subtasks, a sprint, a beads epic, or says to orchestrate, fan out, parallelize, delegate the lot, or "run these through workers"; also right after `wt switch --create` when a worker session has appeared and this session is about to implement instead. Triggers on /orchestrate.
user_invocable: true
trigger: /orchestrate
---

# Orchestrate: you dispatch and review, workers implement

Two roles, two models. You are the orchestrator: the smartest model, highest effort, holder of
the conversation. Start this session with `~/.scripts/agent-orchestrator.sh` when you know a
batch is coming — effort cannot be raised from inside. Each worker is the Claude that worktrunk
starts in the worktree, with `prompts/worker.md` as its role (`~/.scripts/agent-worker.sh`, run
by the `wt` post-start hook). Models and efforts for all three roles live in
`~/.config/agent-discipline.env`; `~/.scripts/agent-config.sh --show` prints what is in force.

You never edit code in this flow. Not in the main checkout, not in a worktree.

## 1. Plan — what can run in parallel

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/orchestrate.py" plan
```

`bd ready` is the parallel set: open issues with no open blockers. No beads → dispatch by hand
from the user's list. Dependencies between tasks are beads `dep` edges, not your memory.

## 2. Dispatch — one worker per task

Find your own session name first: `ListAgents` prints it on the first line. Then, per task:

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/orchestrate.py" dispatch \
  --key <bead-id> --branch <type>/<slug> --task "<one sentence, what done means>" \
  --orchestrator <your session name>
```

Every lane is the full ceremony minus a named price. `dispatch --help` prints the table; pick
with `--lane <name>` (`--small` and `--urgent` still work as aliases). Two lane flags at once is
a refusal, never a precedence rule.

| lane | what it stops paying for | gate |
|---|---|---|
| `full` (default) | nothing — 4 core + 1-3 domain lenses, 3 rounds | — |
| `small` | 2 lenses, 1 round, checks scoped to the paths | ≤3 paths, none CI/migration/infra/secret |
| `mechanical` | 2 lenses, 1 round, the SHAPE reviewed once instead of per file | any number of paths, same risky-path refusal |
| `urgent` | 1 lens, no approval, worker opens the MR itself | needs `--why`; books a debt bead |
| `risky` | nothing — it ADDS a plan-approval gate before the first edit | falls in automatically on risky paths |
| `spike` | no lenses, no MR — the deliverable is a written answer | needs `--why` (the question) |
| `revert` | no lenses — the only check is the diff being the exact inverse | needs `--revert-of <sha>` |
| `repay` | nothing — runs the lenses an urgent fire skipped, over the merged diff | needs `--key <debt bead>` |

**Never widen a gate to fit a task** — a refusal is the signal the task is not on that lane. The
refusal names the path or flag that failed, and no worktree is created.

Two lanes deserve a word beyond the table:

`--lane risky` is the only lane you fall INTO: pass `--touches` on an ordinary dispatch and a
migration, infra or secret path upgrades it automatically, because nobody reaches for more
review under deadline. The worker writes its DoD and a plan, runs `delegate.py plan-ready`, and
stops. `orchestrate.py status` shows `REVIEW THE PLAN` — approving there means "start", not
"open the MR", and `approve` knows the difference.

`--lane repay` is the return path for the urgent lane's debt. Urgent dispatch books the bead
before any code exists; repay reads the skipped lenses back off it, runs them over the already
merged diff, and the worker closes the bead. A debt bead nobody repays is a write-off with extra
steps — the bead body carries the exact repay command.

When a task dies rather than lands, record it: `orchestrate.py abandon --worktree <p> --why
"<the dead end>"`. It writes into `.git/` (so the worktree stays clean and reapable) and the
next `dispatch --key <same key>` quotes the reason in TASK.md. Otherwise the only record of a
dead end is the transcript of the session that hit it.

That creates the worktree (branched off `staging` when it exists), and writes
`<worktree>/.claude/TASK.md`: task, your name, constraints, and the ledger records whose cue
overlaps the task — the worker reads preferences from the file, not from you.

Then `ListAgents`: the worker appears as `worker:<branch>` (measured: the launcher's `--name` is what the list shows). `SendMessage` it:
"Read .claude/TASK.md and begin." **Not listed after a minute → it did not start.** Say so and
start it (`cd <worktree> && ~/.scripts/agent-worker.sh` in a tmux window). Never wait on a
session that is not in the list.

Dispatch every ready task before reviewing any. Workers run concurrently; you do not.

## 3. Wait — the worker owns the DoD

The worker spawns 4 core DoD teammates (intent, tests, discipline, prefs) plus 1-3 domain
lenses picked from the agent pool for what the task touches (UX, security, SQL, ...) — or, on
the small lane, just intent and tests — writes
its own `.claude/dod/<key>.md` (TASK.md names it), generates or reads the repo's
`verify-changes` handbook (`/testing-handbook`)
so its tests match how this repo is actually verified, implements, has the teammates verify, and
messages you **only when every lens passes** — or when it hits the round cap (3, or 1 on the reduced lanes) with a lens still failing. Until then:

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/orchestrate.py" status
```

Every row ends with `next: …`. `REVIEW` is the only one that needs you — except `REVIEW THE PLAN`, which is the risky lane's
gate and comes before any code exists.

## 4. Review — against the task's DoD file, issues not fixes

Read the DoD file `orchestrate.py status` prints under `file` and the diff (`git -C <worktree> diff <base>...HEAD`). Run the
check the worker named. A report carrying `NOT RUN: <technique> — <tool> not installed` is not a
failure — that is the handbook being honest. Judge whether the change really needed it; if it did
and the tool is worth having, that is a bead, not a rejection. Then one of:

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/orchestrate.py" approve --worktree <path>
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/orchestrate.py" reject  --worktree <path> --issue "<what fails which DoD item>"
```

Each prints the message to `SendMessage` the worker. A rejection names the symptom and the
item, never the patch. Approve → the worker pushes and opens the MR into `staging`, writing the
description with the `show-me` skill: one visual of the change's shape plus the check that
proves it, never `--fill` on work a human has to review.

## 5. After the MR

The push hook starts `glab-watch-mr.sh`, and the same hook hands the worker the one command that
wakes it when the MR ends — the worker owns its MR until then. On merge the watcher reaps the
worktree, branch and tmux window. Simple MRs (docs / chore / style / test, docs-like paths only)
go through `/automerge`; every other MR is the user's to merge. Nothing is reaped before merge.

`orchestrate.py status` shows each MR and its pipeline, so you can see a red one without asking
the worker. A worker that reported "MR opened" and then went quiet through a merge or a red
pipeline did not arm its wake-up: send it the outcome, and say so — that is a mechanism failure,
not a worker to nag every time.

## Boundaries

- One task, one worktree already in hand, no batch → `/delegate` is enough.
- A worker escalates (`escalated` in status) → stop, bring the user the DoD and the rounds, and
  the question: is the DoD wrong or the approach? If the answer is "drop it", do not just reap:
  `orchestrate.py abandon --worktree <p> --why "<the dead end>"` first, or the next attempt pays
  for it again.
- A worker session is gone mid-task → say so; do not take the work back silently.
