---
name: mr-automerge
description: Merge the MRs that are boring enough not to need the user — docs, chores, style, tests — after reviewing each, then reap the worktree and branch. Use when the user asks to clear, tidy, sweep or "get through" open MRs; when a batch of doc or chore work has just been pushed; when they ask what is waiting to be merged or why an MR is still open; or when finishing a task that opened a docs/chore MR. Also use before handing the user a list of MRs to review, to filter out the ones they should not have to look at. Triggers on /automerge, "merge the simple ones", "clean up open MRs", "anything mergeable".
user_invocable: true
trigger: /automerge
---

# Auto-merge the boring MRs

Two steps, in this order, always.

**1. List. This merges nothing.**

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/mr-automerge.py" --all
```

Every MR comes back ELIGIBLE or HOLD, and HOLD prints every reason it failed.

**2. For each ELIGIBLE MR only** — read the real diff
(`glab api "projects/:id/merge_requests/<iid>/changes"`), review it in a subagent (model: `REVIEWER_MODEL` from `~/.scripts/agent-config.sh --show`)
asking for a verdict and a reason rather than a summary, and reject on: anything factually wrong, a doc that
now contradicts the code, a "chore" that changes behaviour, or a title that undersells the diff.
Merge what passes:

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/mr-automerge.py" --repo <path> --merge <iid> --yes
```

Eligibility is re-checked at merge time; reaping is automatic unless `--no-reap`.

## The rule that matters

**The eligibility gate is the safety, not the review.** An agent approving a diff another agent
wrote is a second opinion, not an independent one. The gate refuses anything touching CI,
migrations, dependency manifests, container builds, infrastructure or secret-shaped paths, and
treats a missing pipeline as a failure rather than a pass.

If you want to widen the gate to fit one particular MR, that MR is not simple — leave it for the
user. Report per MR: merged, or held with the reason. Never a bare count.
