---
name: testing-handbook
description: Give a repo its own verification handbook — the exact unit, E2E, property-based and mutation commands that work HERE, plus which of them a given change actually requires. Use the first time you implement in a repo, when a definition-of-done item asks what proves a behaviour, when deciding whether a diff needs more than a unit test, when the test tooling changes, or when someone asks how this project is verified. Triggers on /testing-handbook.
user_invocable: true
trigger: /testing-handbook
---

# Give this repo a verification handbook

Every repo answers the same questions differently — what runs the tests, what drives a browser,
whether a property library or a mutation tool is even installed. A worker that re-derives those
per task guesses, and a guess that looks like a command is worse than no answer.

This detects them once, from the manifests, and writes
`<repo>/.claude/skills/verify-changes/SKILL.md`. **Every repo gets one** — this is not specific
to any project.

## 1. Look before writing

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/testing-handbook.py" --check
```

Prints the detected stack and, per technique, either the command or `MISSING` with the reason.
Read it. A wrong row here becomes a wrong instruction every future worker follows.

With a handbook already present, `--check` prints **drift** instead — what the tooling does now
that the file does not say. `NOW AVAILABLE` is the one that matters: a previous change added a
tool, and until you regenerate the handbook keeps telling every worker that technique is
impossible.

## 2. Write it

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/testing-handbook.py"          # refuses to clobber
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/testing-handbook.py" --force  # re-detect
```

It refuses to overwrite a hand-written file, and re-detecting a generated one needs `--force`.

## 3. Two halves, and only one is generated

Everything above the `learned:begin` marker is re-detected on every `--force`. Everything below
is written by workers and **never** overwritten. So detection being wrong is not permanent, and a
fact a worker paid for is not lost the next time the tooling changes.

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/testing-handbook.py" --learn "test needs the DB up: pnpm db:up first"
```

Dated, deduplicated, appended. Worth recording: a command that needs a service first, a seed
step, a flaky test and its workaround, a tool a change just added. Not worth recording: anything
about one task's code.

Detection reads manifests; it cannot know that `pnpm run test` needs a database up. Correct that
with `--learn`, not by editing the generated half — an edit up there is lost on the next
`--force`, and the file says so.

## What the handbook decides

It carries a routing table, because running all four techniques on every change makes workers
grind and teaches nothing:

| The change touches | It needs |
|---|---|
| any logic | a unit test that fails without the change |
| a human-facing surface | one E2E asserting what the user sees |
| roundtrip / parser / validator / comparator / numeric | a property-based test |
| money, auth, or a shared library others call | mutation testing scoped to the changed files |
| only docs or formatting | nothing beyond the existing suite |

## The rule that matters

**A missing tool is reported, never skipped.** Most repos here have no mutation tool and no
property library. The handbook records those as MISSING with the one command that adds them, and
a worker that needed one says so in its report and in the merge request:

```
NOT RUN: mutation testing — mutmut not installed here (add: uv add --dev mutmut)
```

Silently dropping the technique makes an unverified change read as a verified one. That is the
failure this whole flow exists to prevent.
