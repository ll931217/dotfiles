---
name: show-me
description: Explain the current topic visually — concise diagrams, code-shape sketches, call trees, shaped diffs, and focused HTML artifacts. Use when the user asks to see, picture, sketch, map or diagram something, and when WRITING AN MR OR PR DESCRIPTION, where one shaped diff or Mermaid graph tells a reviewer what changed faster than a paragraph.
triggers: show me, visualize, diagram, sketch, mermaid, call tree, MR description, PR description, merge request body, 圖, 畫個圖, 視覺化, MR 描述
user_invocable: true
trigger: /show-me
---

Help the user understand the current topic of conversation visually. Skip the preamble and keep prose brief. Pick the smallest view that makes the key point clear.

- Show logic or an algorithm as pseudocode:

```text
on(save)
  if content is unchanged
    return cached result
  write new content
  return fresh result
```

- Show runtime control flow as a call tree:

```text
submitForm
  createSession
    persistPrompt
    launchAgent
  navigateToSession
```

- Show UI structure as a component tree, including state and module boundaries that matter:

```tsx
<SessionPage> (apps/example/src/routes/session.tsx)
  useSessionEvents()
  <SessionToolbar>
    <RunSkillButton> (packages/ui)
```

- Show file responsibility or a broad refactor as a shallow file tree:

```text
src/
├── commands/       # parses user actions
├── sessions/       # owns session state
└── transport/      # sends API requests
```

- Show component interaction, control flow, or data flow with Mermaid:

```mermaid
sequenceDiagram
    participant User
    participant UI
    participant Daemon
    User->>UI: choose command
    UI->>Daemon: send expanded prompt
    Daemon-->>UI: stream result
```

- Use `diff` when the point is what changes and the surrounding shape already exists. Match the diff shape to the topic.

For a component change:

```diff
 <SessionPage>
   useSessionEvents()
   <SessionToolbar>
+    <RunSkillButton />
   <SessionTimeline>
+    <SkillResultCard />
```

For a file-layout change:

```diff
 src/
 ├── commands/
+│   └── show-me.ts       # expands the slash command
 ├── sessions/
-└── transport.ts
+└── transport/
+    ├── client.ts
+    └── stream.ts
```

For a call-tree or call-stack change:

```diff
 submitForm
   createSession
     persistPrompt
+    expandSkillMention
     launchAgent
-  navigateToSession
+  navigateToSession
+    subscribeToEvents
```

For a state or control-flow change:

```diff
 on(save)
-  write content
+  if content is unchanged
+    return cached result
+  write new content
+  invalidate cache
```

- Show the whole block when most of it is new, when omitted context would hide ownership or order, or when the user needs a copyable target shape:

```ts
function expandSkill(command: string): string {
  const skillName = command.slice(1)
  return `use the ${skillName} skill`
}
```

- For a visual UI, layout, state comparison, or concept too dense for Mermaid, write one focused HTML file — a diagram, an infographic, or a short slide deck, whichever fits the point. Match the product's colors, type, spacing, and components; use real labels and data; support desktop and mobile. Then open it for the user:

```
Bash(open path/to/show-me-{description}.html)
```

### guidance

Place each visual next to the short text it supports. Keep only the calls, files, props, states, and boundaries needed to answer the user's current question or the options to resolve the current discussion point.

You may use one of these, you may use several, it is unlikely you will use all of them. Use your judgement and don't overwhelm the user.

### In an MR description

An MR description has one reader with one question: *what changed, and what do I have to check?*
A shaped diff or a Mermaid graph answers that in the time a paragraph takes to skim, so the
default MR body is **one visual plus the short text it supports** — usually the shaped diff,
because "what changed" is literally the question.

Two constraints the general guidance above does not carry:

- **GitLab renders Markdown and Mermaid in a description; it does not render an HTML file.** The
  HTML artifact option is for a live conversation, not an MR body. If the point genuinely needs
  one, attach the file to the MR and keep a Mermaid or diff summary inline — a link nobody opens
  is not an explanation.
- **The visual is not the diff.** The reviewer already has the real diff, one click away. Show
  the SHAPE — which files gained responsibility, which call path is new, which branch of the
  state machine changed — not the lines they can read themselves.

One visual, not four. Pick by what the change is:

| the change is | show |
|---|---|
| files moved, split, or gained responsibility | shaped file-tree diff |
| a new step in an existing flow | call-tree diff |
| a behaviour or state rule changed | pseudocode diff of the old vs new branch |
| a new interaction between components/services | Mermaid sequence diagram |
| one self-contained new function or type | the block itself |

Write the body to a file and hand it to `glab`, so the visual survives the shell:

~~~bash
cat > /tmp/mr-body.md <<'BODY'
Splits transport into a client and a stream so the retry policy has one owner.

```diff
 src/
 ├── commands/
-└── transport.ts
+└── transport/
+    ├── client.ts     # owns retries
+    └── stream.ts
```

Check: the retry test in `tests/test_transport.py` covers the new owner.

## Proof
```
$ uv run pytest tests/test_transport.py -q
....                                                          [100%]
4 passed in 0.31s
```
BODY
glab mr create --target-branch staging --description "$(cat /tmp/mr-body.md)" \
  --title "<type>(<scope>): <subject>" --remove-source-branch --yes
~~~

The `## Proof` section is not optional and not prose: an artifact — a fenced run, a screenshot,
a `tmux capture-pane` tail. The visual says what the code looks like; the proof says it ran. The
`mr-proof-gate` hook denies `glab mr create` when either is a claim instead of an artifact.

`--fill` takes the body from the commits instead, which is fine for a chore and wrong for
anything a human has to review — the commit message says why it was done, the visual says what
it now looks like.
