---
name: delegate-to-worktree
description: Hand the implementation to the Claude session running in the new worktree instead of doing it yourself, then review its work against a written definition of done. Use immediately after `wt switch --create` or any worktree creation that spawns a tmux window with claude in it; when the user says to delegate, hand off, assign, or "let the other agent do it"; or whenever you are about to implement in a worktree that already has its own session. You are the orchestrator and reviewer because you hold the context — the worker has the fresh context window and does the typing.
user_invocable: true
trigger: /delegate
---

# Delegate to the worktree's own session

You are **A**: you hold the conversation, the spec and the review. **B** is the session
worktrunk started in the new tmux window. B has a clean context window and the worktree; you
have the reasons. Do not implement in your own checkout and do not implement through B by
dictating patches.

## 1. Write the DoD before anything moves

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/delegate.py" start \
  --worktree <path> --task "<one sentence>" \
  --dod "<checkable item>" --dod "<checkable item>"
```

Writes `<worktree>/.claude/DOD.md`. **This is the point of the whole flow**: B cannot self-check
against a DoD it cannot read, and you cannot review consistently against one you are holding in
your head. Every item must be checkable by someone who was not in this conversation.

## 2. Find B and confirm it is alive

`ListAgents` — B appears with its tmux pane, e.g.
`feat-netbox-site-options-e7 [66c1b3] · tmux atlas:@45.%66 · started 20m ago`. Match on the
branch or worktree name.

**If B is not listed, stop.** A spawned session has failed silently before on this machine
(`CLAUDE_CODE_TEAMMATE_COMMAND` with an unexpanded `~`, exit 127, while the task list still
said "running"). Waiting on an agent that never started looks exactly like an agent thinking.

## 3. Assign

`SendMessage` to B: the task, `read .claude/DOD.md first`, and the constraints it cannot infer
(the phase rule, Step 0 for files over 300 LOC, which checks must pass). Send **what done looks
like, not how to get there**.

## 4. Review loop — issues, never solutions

When B reports finished:

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/delegate.py" round --worktree <path>
```

Verify **against DOD.md and nothing else** — read the diff, run the checks yourself. Then:

- Meets it → `delegate.py accept --worktree <path>`, then carry on (MR, reap).
- Does not →
  ```bash
  python3 "${CLAUDE_PLUGIN_ROOT}/scripts/delegate.py" reject --worktree <path> \
    --issue "<what is wrong and which DoD item it fails>"
  ```
  then send B that issue. **Name the symptom and the failed item. Do not name the fix.** If you
  hand B the patch you have paid for two context windows and used one. The script warns when a
  rejection reads like a solution.

## 5. The cap is not advisory

Three rounds. At the cap the script refuses to issue another and tells you to escalate:

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/delegate.py" escalate --worktree <path> --task-key <KEY>
```

That logs a `decision`-class blocker and prints what to tell the user: the task, every round and
its issue, and the actual question — **is the DoD wrong, or is the approach wrong?** Three failed
rounds means the two of you disagree about something neither of you can see. A fourth will not
find it.

## Boundaries

- No worktree session (small edit, no `wt`) → just do the work. This is for delegation, not ceremony.
- B is idle or gone mid-flight → say so and stop; do not silently take the work back.
- Squad, or any second orchestrator, is not needed: `ListAgents` + `SendMessage` already reach
  the session worktrunk started, and a second thing creating worktrees is how checkouts drift.
