---
name: delegate-to-worktree
description: Hand the implementation to the Claude session running in the new worktree instead of doing it yourself, then review its work against a written definition of done. Use immediately after `wt switch --create` or any worktree creation that spawns a tmux window with claude in it; when the user says to delegate, hand off, assign, or "let the other agent do it"; or whenever you are about to implement in a worktree that already has its own session. You are the orchestrator and reviewer because you hold the context — the worker has the fresh context window and does the typing.
user_invocable: true
trigger: /delegate
---

# Delegate to the worktree's own session

You are **A**: you hold the conversation, the spec and the review. **B** is the session
worktrunk started in the new tmux window. B has a clean context window and the worktree; you
have the reasons. Do not implement in your own checkout and do not implement through B by
dictating patches.

## 1. Write the task file before anything moves

`orchestrate.py dispatch` does this when it creates the worktree. Made the worktree by hand?
Write `<worktree>/.claude/TASK.md` yourself: the task in one sentence, your session name (first
line of `ListAgents`), the constraints B cannot infer, and the ledger records that apply.

**B writes the DoD, not you.** Its role prompt has it spawn 4 core DoD teammates (intent, tests,
discipline, prefs) and write the DoD file named in TASK.md (`.claude/dod/<key>.md`, one
per task — a shared `.claude/DOD.md` is tracked and two workers collided on it) before any
code. You review against that file —
one both of you can read — never against a list in your head.

## 2. Find B and confirm it is alive

`ListAgents` — B appears as `worker:<branch>` with its tmux pane, e.g.
`worker:feat/netbox-site-options [66c1b3] · tmux atlas:@45.%66 · started 20m ago`.

**If B is not listed, stop.** A spawned session has failed silently before on this machine
(`CLAUDE_CODE_TEAMMATE_COMMAND` with an unexpanded `~`, exit 127, while the task list still
said "running"). Waiting on an agent that never started looks exactly like an agent thinking.

## 3. Assign

`SendMessage` to B: "Read .claude/TASK.md and begin." Everything else is in the file. If you
find yourself typing how to get there, it belongs in TASK.md as a constraint, or nowhere.

## 4. Review loop — issues, never solutions

B reports only when every one of its DoD teammates passes (its `delegate.py report`). Then:

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/delegate.py" round --worktree <path>
```

Verify **against that DoD file and nothing else** — read the diff, run the checks yourself. Then:

- Meets it → `delegate.py accept --worktree <path>`, then carry on (MR, reap).
- Does not →
  ```bash
  python3 "${CLAUDE_PLUGIN_ROOT}/scripts/delegate.py" reject --worktree <path> \
    --issue "<what is wrong and which DoD item it fails>"
  ```
  then send B that issue. **Name the symptom and the failed item. Do not name the fix.** If you
  hand B the patch you have paid for two context windows and used one. The script warns when a
  rejection reads like a solution.

## 5. The cap is not advisory

Three rounds. At the cap the script refuses to issue another and tells you to escalate:

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/delegate.py" escalate --worktree <path> --task-key <KEY>
```

That logs a `decision`-class blocker and prints what to tell the user: the task, every round and
its issue, and the actual question — **is the DoD wrong, or is the approach wrong?** Three failed
rounds means the two of you disagree about something neither of you can see. A fourth will not
find it.

## Boundaries

- No worktree session (small edit, no `wt`) → just do the work. This is for delegation, not ceremony.
- B is idle or gone mid-flight → say so and stop; do not silently take the work back.
- Squad, or any second orchestrator, is not needed: `ListAgents` + `SendMessage` already reach
  the session worktrunk started, and a second thing creating worktrees is how checkouts drift.
