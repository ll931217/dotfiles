# UX Obviousness — if you had to read the source, the UX failed

**Rule:** when building or changing anything a human drives — a CLI, a command, a hook's output,
a form, a screen — the feature must explain itself at the moment of use. If understanding it
requires opening the source, the docs, or asking, the feature is not done; the UX is.

The test is mechanical, run it on your own work before shipping:

> Show the feature to someone who has never seen the code. Can they say what it does and what
> to do next, from the screen alone? No → fix the feature, not the docs.

## What this forbids

- A flag / button / field whose effect is only knowable from the implementation.
- An error that states what failed but not what to do (`invalid config` — which key, what value,
  fix how).
- A prompt or option list where picking correctly requires knowing internals.
- "It's in the README" as the answer to "how would anyone know?". Docs are a backup, not the
  interface.
- Silent success or silent no-op: the user cannot tell whether it ran.

## What this requires

- Names say the effect (`--dry-run`, not `--mode=2`).
- Every failure names the offending thing and the next action.
- Every action confirms its outcome in the same breath: what changed, where.
- Defaults are the safe, common choice, so doing nothing is right.
- The affordance is visible without hovering or guessing.

## When it doesn't apply

Internal APIs, library functions, and code read only by developers — there, reading the source
IS the interface. This rule governs surfaces a human operates, not ones a program calls.

## The check: an E2E that asserts the UX, not just the result

A UX claim is not landed until something runnable fails when the obviousness breaks. "I looked at
it and it seemed clear" is a claim, not evidence — and a unit test that asserts the return value
passes happily while the screen says nothing.

So every human-facing change leaves ONE E2E behind, driving the real surface (CLI process,
browser page, hook output), asserting what the user SEES:

| Requirement above | What the E2E asserts |
|---|---|
| failure names the next action | run the broken input; stderr contains the offending key AND a fix verb |
| action confirms its outcome | run it; stdout names what changed and where — not just exit 0 |
| no silent no-op | run it twice; the second run says "already done", not nothing |
| affordance is visible | the label / flag appears in `--help` or in the rendered page without hover |

Rules:

- Assert the **user-visible text and the exit code**, never only the exit code. An exit 0 with an
  empty screen is exactly the failure this rule exists to catch.
- Drive the surface end to end. Calling the internal function skips the layer where UX lives.
- One check per surface, not per branch. Smallest thing that fails if the obviousness regresses —
  a `test_*.py` subprocess run, a Playwright/`agent-browser` page assertion, no fixtures.
- No E2E possible (interactive TTY, real hardware)? Say so explicitly in the MR and paste the
  manual transcript. Silence is not a pass.
