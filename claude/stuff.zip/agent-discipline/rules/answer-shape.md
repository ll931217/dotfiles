# Answer Shape — self-contained references, and who owns a blocked premise

Two always-on rules. Both exist to keep the user's context-switch cost near zero.

## AS1: A reference is not an answer — inline what it says

**Rule:** never hand the user a bare identifier as the payload. Ticket key, file path, bead id,
page slug, MR number, log line number, canon rule key — if the user would have to go open it to
understand the sentence, the sentence is unfinished. Name it AND carry its relevant content inline.

- ✗ "Also affected: DE-455, DE-457."
- ✓ "Two sibling tickets rest on the same wrong assumption: DE-455 (adds a retry wrapper around
  `fetchQuote`, which this change deletes) and DE-457 (its acceptance test asserts the old
  column name)."
- ✗ "See `topics/vdi-no-hover-no-alpha.md`." ✓ "Past finding: you work over VDI, so hover-only
  affordances are invisible — `topics/vdi-no-hover-no-alpha.md`."

The id stays (it is how the user acts on it); it just never travels alone. Cite the source
*after* the substance, not instead of it.

## AS2: Classify a blocked premise before interrupting

When work stalls because an assumption broke, split it first:

| Premise type | Who settles it | Action |
|---|---|---|
| **Preference** — which option would the user pick, what style, how much scope | memory | search `topics/ (pref-*.md)` + memory + gbrain, decide, state the assumption inline, keep going |
| **Project fact** — what was decided here before, why this is built this way | memory / gbrain | same: retrieve, cite the content (per AS1), keep going |
| **World state** — does this column/endpoint/flag actually exist, what does the code do | the source | go read the source. Never ask the user, and never answer from memory (canon `evidence-first`) |
| **Intent / trade-off** — the goal itself is wrong or two real options diverge in cost | the human | STOP and ask, in the shape below |

Only the last row earns an interrupt. Asking the user something the first three rows cover is a
defect, not caution.

**Interrupt shape** (when the last row does apply):

```
Assumed:   <what the plan took as given>
Actually:  <what is true, with file:line or quoted evidence>
Also hits: <other work resting on the same premise, WITH its content per AS1>
A: <option>  B: <option>   I'd go <X> because <reason>
```

Everything above the decision must be readable without opening anything. The user's job is to
pick a letter, not to reconstruct the problem.

## AS3: Every pick the user makes becomes a record

When the user chooses one of your options, overrides your approach, reverses an omission, or
gives a reason for wanting something — write it to the ledger (`/prefs`, records under
`memory/topics/ (pref-*.md)`) before the topic closes. Capture the rejected option and the reason,
not just the outcome; without the counterfactual nothing is derivable later.

The `AskUserQuestion` PreToolUse hook (`pref-checkpoint.py`, shipped by the agent-discipline
plugin) enforces the
consult side of AS2 mechanically. Capture has no such enforcement — it is on you, here.
