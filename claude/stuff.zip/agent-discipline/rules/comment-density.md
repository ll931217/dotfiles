# Comment Density — a comment is one line the code cannot say itself

**Rule:** comments explain what the code cannot. That is almost always a single line, and almost
never a paragraph. A block of prose in front of the code hides the code, and it rots on the next
edit because nobody rewrites a paragraph to change a flag.

**Cap: 5 consecutive lines of comment prose**, anywhere — header or mid-function. Enforced by
`hooks/comment-bloat-gate.py` on every `Write` / `Edit` to a code file.

It counts paragraphs of flush prose, not whole blocks. A lone `#` ends one, and an indented line
(`#   tool.sh --flag`) is not counted at all — a usage listing, an option table or an exit-code
list is reference a reader looks things up in, and a long one of those is a good header. The wall
of narration is the problem, and both live in the same block.

## What to keep

The thing a reader cannot recover by reading the next line:

- a constraint that is not visible locally — a unit, a bound, an ordering requirement
- a gotcha with a cost — why the obvious version is wrong here
- a deliberate simplification and its ceiling (`ponytail:` comments)

## What to delete

- restating the line below it (`# loop over the rows` above a `for` loop)
- history: what it used to be, what broke, which incident, what date
- alternatives considered, and the argument for the one chosen
- background on the system for a reader who has never seen it

Those are not worthless — they are just not comments. A real explanation goes in `docs/`, bound
to the code with `code_refs` so `scripts/docs-drift.py` notices when it stops being true, and the
comment shrinks to one line naming the doc.

## When it doesn't apply

Prose files (`.md`, config, fixtures) — the gate skips them. A generated file, or a licence
header a tool requires, is not a comment anybody chose to write.
