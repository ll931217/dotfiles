#!/usr/bin/env python3
"""Seed a preference ledger from memory that already exists — as DRAFTS a human promotes.

Every ledger reader wants `topics/pref-*.md` with a `**Preference:**` line
(`hooks/pref-checkpoint.py`, `hooks/pref-preload-on-skill.py`, `ledger/compat.py`). Someone who
has run memory-kit for months therefore starts with zero records, and `/ledger` reads as broken
while the hook has nothing to say.

What a record is worth is the option NOT taken and the reason. Existing memory almost never
states the rejected option, so this NEVER writes a record: it writes candidates to
`topics/drafts/`, which the recall hook does not scan, and refuses to promote one that still
admits it does not know what was rejected.

  ledger-bootstrap.py                    # DRY RUN: what it found, by confidence
  ledger-bootstrap.py --write-drafts      # write them to topics/drafts/
  ledger-bootstrap.py --promote <slug>    # after you edited it: drafts/ -> topics/pref-<slug>.md
  ledger-bootstrap.py --list              # drafts waiting, and which are promotable

Design notes and acceptance criteria: docs/ledger-bootstrap-scope.md
"""
import argparse
import csv
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
from agent_discipline_paths import memory_dir, topics_dir, mem_file  # noqa: E402

UNKNOWN = "UNKNOWN — fill this in or delete the draft"
# An imperative aimed at how work should be done. Deliberately narrow: a wrong candidate costs
# a human a read, and a flood of them costs the whole mechanism its credibility.
IMPERATIVE = re.compile(
    r"(使用者要求|使用者說|不要|務必|一律|改用|"
    r"\balways\b|\bnever\b|\bdon't\b|\bdo not\b|\bprefer\b|\buse .* instead\b|"
    r"\bmust\b|\bshould\b)", re.I)
STOP_LINE = re.compile(r"^\s*(#|<!--|\||-{3,}|```)")
# A metadata KEY at the start of the line (`description:`, `triggers:`) — not any early colon.
# Rejecting every colon in the first 20 chars also threw away real prose like
# `User correction: "don't ever compile on this machine"`, which is exactly the target.
META_KEY = re.compile(r"^[a-z][a-z_-]{2,20}:\s")


def read_tsv(path, has_header):
    if not os.path.exists(path):
        return []
    with open(path, newline="") as f:
        rows = list(csv.reader(f, delimiter="\t"))
    return rows[1:] if (has_header and rows) else rows


def slugify(text, limit=60):
    s = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return (s[:limit].rstrip("-") or "candidate")


def existing_subjects(tdir):
    """Slugs already in the ledger, so a re-run reports 'already in the ledger' rather than
    drafting the same thing twice."""
    out = set()
    if os.path.isdir(tdir):
        for fn in os.listdir(tdir):
            if fn.startswith("pref-") and fn.endswith(".md"):
                out.add(fn[len("pref-"):-len(".md")])
    return out


# ── sources, best first ──────────────────────────────────────────────────────────
def from_corrections(mem):
    """rule_effect_log.tsv `human-correction` rows. Every one IS an override, which is the
    strongest evidence a preference exists — but the summary is capped at 80 chars, so it
    carries the outcome and not the reason."""
    out = []
    for row in read_tsv(os.path.join(mem, "rule_effect_log.tsv"), has_header=False):
        if len(row) < 5 or row[2] != "human-correction":
            continue
        summary = row[4].strip()
        if not summary:
            continue
        out.append({"subject": summary, "source": f"rule_effect_log.tsv ({row[0][:10]})",
                    "quote": summary, "kind": "correction"})
    return out


def strip_frontmatter(body):
    """Frontmatter is metadata, not a preference. Without this the top candidate for most files
    was its own `description:` line, which reads like a rule and is really a retrieval cue."""
    if not body.startswith("---"):
        return body
    end = body.find("\n---", 3)
    return body[end + 4:] if end > 0 else body


def sentence_start(t):
    """A whole clause, not the tail of a wrapped line. Markdown wraps mid-sentence, so a line
    beginning lowercase mid-thought produced candidates like 'copy and answers ... silently'."""
    if not t:
        return False
    first = t[0]
    return first.isupper() or ord(first) > 0x2E80 or first in "`\"'"


def from_topics(tdir):
    """Imperative sentences in non-pref topic files: the outcome is stated, the rejected option
    is not. Deliberately at most one per file — the rest is detail for whoever reviews it."""
    out = []
    if not os.path.isdir(tdir):
        return out
    for fn in sorted(os.listdir(tdir)):
        if not fn.endswith(".md") or fn.startswith("pref-"):
            continue
        try:
            body = strip_frontmatter(open(os.path.join(tdir, fn), errors="replace").read())
        except OSError:
            continue
        for ln in body.splitlines():
            t = ln.strip(" -*\t")
            if (len(t) < 30 or STOP_LINE.match(ln) or not IMPERATIVE.search(t)
                    or not sentence_start(t) or META_KEY.match(t)):
                continue
            out.append({"subject": t[:110], "source": f"topics/{fn}", "quote": t,
                        "kind": "topic"})
            break
    return out


def from_uncovered(mem):
    """`uncovered` rows in pref_events.tsv: questions that reached the user with no record.
    No NLP at all — a group-by — and it is keyed to asks that really happened."""
    counts = {}
    for row in read_tsv(os.path.join(mem, "pref_events.tsv"), has_header=True):
        if len(row) < 5 or row[1] != "uncovered":
            continue
        q = row[4].strip()
        if q:
            counts[q] = counts.get(q, 0) + 1
    return [{"subject": q[:110], "source": f"pref_events.tsv (asked {n}x)", "quote": q,
             "kind": "uncovered", "asks": n}
            for q, n in sorted(counts.items(), key=lambda kv: -kv[1])]


# ── candidates ───────────────────────────────────────────────────────────────────
def build(mem, tdir):
    corrections = from_corrections(mem)
    topics = from_topics(tdir)
    uncovered = from_uncovered(mem)
    corr_words = {}
    for c in corrections:
        for w in slugify(c["subject"]).split("-"):
            if len(w) > 4:
                corr_words.setdefault(w, []).append(c)

    cands, seen = [], set()
    for c in corrections + topics + uncovered:
        c["slug"] = slugify(c["subject"], 50)
        if c["slug"] in seen:
            continue
        seen.add(c["slug"])
        if c["kind"] == "topic":
            # a topic line whose words also appear in a correction: two independent sources
            hits = {w for w in slugify(c["subject"]).split("-") if len(w) > 4} & set(corr_words)
            c["tier"] = "derived-strong" if len(hits) >= 2 else "derived-weak"
            c["agrees_with"] = sorted(hits)[:3]
        elif c["kind"] == "correction":
            c["tier"] = "derived-weak"
            c["agrees_with"] = []
        else:
            c["tier"] = "uncovered-only"
            c["agrees_with"] = []
        cands.append(c)
    return cands


def draft_text(c):
    known = c["kind"] != "uncovered"
    return "\n".join([
        "---",
        f"description: DRAFT from {c['source']} — {c['subject'][:90]}",
        "triggers: ",
        f"confidence: {c['tier']}",
        "type: user",
        "---",
        "",
        "<!-- DRAFT. Not in the ledger: the recall hook does not scan topics/drafts/.",
        f"     Edit, then: ledger-bootstrap.py --promote {c['slug']} -->",
        "",
        f"**Preference:** {c['subject'] if known else UNKNOWN}",
        "",
        f"**Chose:** {c['subject'][:90] if known else UNKNOWN}",
        "",
        f"**Over:** {UNKNOWN}",
        "",
        f"**Why:** (derived) from {c['source']}: \"{c['quote'][:200]}\"",
        "",
        "**Generalizes to:** " + UNKNOWN,
        "",
        "**Does NOT apply when:** " + UNKNOWN,
        "",
        f"<!-- evidence: {c['source']}"
        + (f"; agrees with correction terms: {', '.join(c['agrees_with'])}" if c.get("agrees_with") else "")
        + " -->",
        ""])


def promotable(path):
    """(ok, reason). A draft still admitting it does not know the rejected option must not
    enter the ledger: pref-checkpoint would inject it as a settled decision."""
    body = open(path, errors="replace").read()
    if UNKNOWN.split("—")[0].strip() in body:
        bad = [i + 1 for i, ln in enumerate(body.splitlines()) if "UNKNOWN" in ln]
        return False, f"still has UNKNOWN on line(s) {', '.join(map(str, bad))}"
    if "**Preference:**" not in body:
        return False, "no **Preference:** line — every reader keys on it"
    if "**Over:**" not in body:
        return False, "no **Over:** line — without the rejected option nothing is derivable"
    return True, ""


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--write-drafts", action="store_true")
    ap.add_argument("--promote", metavar="SLUG")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--limit", type=int, default=25,
                    help="how many candidates to draft, strongest first (default 25). A flood "
                         "of weak drafts costs the mechanism its credibility.")
    a = ap.parse_args(argv)

    mem, tdir = memory_dir(), topics_dir()
    ddir = os.path.join(tdir, "drafts")

    if a.promote:
        src = os.path.join(ddir, f"{a.promote}.md")
        if not os.path.isfile(src):
            print(f"no draft {a.promote} in {ddir}")
            return 1
        ok, why = promotable(src)
        if not ok:
            print(f"REFUSED: {a.promote} — {why}")
            print("A record the hook injects as settled must not say it does not know what was")
            print("rejected. Edit the draft, then promote it.")
            return 1
        dst = os.path.join(tdir, f"pref-{a.promote}.md")
        if os.path.exists(dst):
            print(f"REFUSED: {os.path.basename(dst)} already exists — merge by hand")
            return 1
        body = open(src).read().replace(
            "<!-- DRAFT. Not in the ledger: the recall hook does not scan topics/drafts/.", "<!--")
        open(dst, "w").write(body)
        os.remove(src)
        print(f"promoted -> {dst}")
        print("Write real `triggers:` in both languages, or the recall hook will rarely fire it.")
        return 0

    if a.list:
        drafts = sorted(f for f in os.listdir(ddir)) if os.path.isdir(ddir) else []
        if not drafts:
            print(f"no drafts in {ddir} — run --write-drafts first")
            return 0
        print(f"{len(drafts)} draft(s) in {ddir}\n")
        for fn in drafts:
            ok, why = promotable(os.path.join(ddir, fn))
            print(f"  {'READY  ' if ok else 'needs edit'} {fn[:-3]}"
                  + ("" if ok else f"   ({why})"))
        return 0

    cands = build(mem, tdir)
    have = existing_subjects(tdir)
    fresh = [c for c in cands if c["slug"] not in have]
    already = len(cands) - len(fresh)

    ORDER = {"derived-strong": 0, "derived-weak": 1, "uncovered-only": 2}
    fresh.sort(key=lambda c: (ORDER[c["tier"]], -c.get("asks", 0)))
    over = max(0, len(fresh) - a.limit)
    fresh = fresh[:a.limit]
    by_tier = {}
    for c in fresh:
        by_tier.setdefault(c["tier"], []).append(c)

    print(f"\nledger bootstrap — memory: {mem.replace(os.path.expanduser('~'), '~')}")
    print(f"  existing records          {len(have)}")
    print(f"  candidates                {len(fresh)}"
          + (f"   ({already} already in the ledger, skipped)" if already else "")
          + (f"   [+{over} beyond --limit {a.limit}]" if over else ""))
    for t in ("derived-strong", "derived-weak", "uncovered-only"):
        rows = by_tier.get(t, [])
        print(f"    {t:16} {len(rows)}")
        for c in rows[:5]:
            print(f"      {c['subject'][:88]}")
            print(f"        {c['source']}")
        if len(rows) > 5:
            print(f"      … {len(rows) - 5} more")
    if not fresh:
        print("\n  nothing to draft. That is not the same as 'you need no records': it means")
        print("  these sources hold no imperative this tool recognises.")
        return 0
    if not a.write_drafts:
        print(f"\nDRY RUN — nothing written. --write-drafts puts these in {ddir}")
        print("(a subdirectory ON PURPOSE: the recall hook scans only the flat topics/, so a")
        print(" draft can never be injected as if it were a decision you made.)")
        return 0

    os.makedirs(ddir, exist_ok=True)
    n = 0
    for c in fresh:
        path = os.path.join(ddir, f"{c['slug']}.md")
        if os.path.exists(path):
            continue
        open(path, "w").write(draft_text(c))
        n += 1
    print(f"\nwrote {n} draft(s) to {ddir}")
    print("Each one needs the REJECTED option and the reason before it can be promoted:")
    print("  ledger-bootstrap.py --list                # what is ready")
    print("  ledger-bootstrap.py --promote <slug>      # after editing")
    return 0


if __name__ == "__main__":
    sys.exit(main())
