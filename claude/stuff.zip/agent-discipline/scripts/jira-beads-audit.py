#!/usr/bin/env python3
"""Audit the Jira <-> beads link for drift. Read-only unless --fix.

The invariant (see CLAUDE.md "THE LINK IS DIRECTIONAL"):
  every key in <repo>/.claude/jira_issues MUST have a bead labelled jira:<key>;
  the reverse does NOT hold — a bead with no jira: label is complete on its own.

Checks, and whether a machine may fix them:
  C1 orphan-key       key in file, no bead mirrors it        -> human (create mirror or drop key)
  C2 stale-key        key in file, Jira already Done/Closed  -> FIXABLE (drop from file)
  C3 body-missing     mirrored bead never names its parent   -> FIXABLE (write the Jira: line)
  C4 body-mismatch    body names a different key than label  -> human (copy-paste error)
  C5 status-drift     bead closed but Jira still open, etc.  -> human (level 3 derives this)

  jira-beads-audit.py [--repo PATH | --all] [--json] [--fix] [--selftest]
Exit 1 when findings exist, so a pre-push hook or CI step can gate on it.
"""
import argparse, glob, json, os, re, shutil, subprocess, sys, tempfile

JIRA = os.path.expanduser(
    "~/Projects/llm_library/plugins/data-skills/skills/jira/scripts/jira.py")
SEARCH_ROOTS = ["~/Projects", "~/GitLab", "~/Services"]
DONE = {"done", "closed", "resolved", "cancelled", "canceled", "won't do", "wont do"}
KEY_RE = re.compile(r"^[A-Z][A-Z0-9]+-\d+$")
BODY_RE = re.compile(r"^\s*Jira:\s*([A-Z][A-Z0-9]+-\d+)", re.M)


def sh(cmd, cwd=None):
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    return r.returncode, r.stdout, r.stderr


def find_repos():
    out = []
    for root in SEARCH_ROOTS:
        out += glob.glob(os.path.join(os.path.expanduser(root), "*", ".claude", "jira_issues"))
    return sorted(os.path.dirname(os.path.dirname(p)) for p in out)


def read_keys(repo):
    p = os.path.join(repo, ".claude", "jira_issues")
    if not os.path.exists(p):
        return []
    keys = []
    for line in open(p):
        line = line.split("#", 1)[0].strip()
        if KEY_RE.match(line):
            keys.append(line)
    return keys


def read_beads(repo):
    """Returns [] when beads is simply not in use here, None only on a real failure.

    Beads is OPTIONAL. A repo tracked in Jira alone is a valid setup, not a defect — so
    "no bd" degrades to Jira-only checks instead of raising a finding.
    """
    if not shutil.which("bd"):
        return []
    rc, out, _ = sh(["bd", "list", "--json"], cwd=repo)
    if rc != 0 or not out.strip():
        return []                        # no beads DB in this repo -> Jira-only mode
    try:
        d = json.loads(out)
    except json.JSONDecodeError:
        return None
    return d if isinstance(d, list) else d.get("issues", d.get("data", []))


def jira_get(keys):
    if not keys:
        return {}
    rc, out, err = sh([sys.executable, JIRA, "get", *keys])
    if rc != 0:
        return {"__error__": err.strip()[:200]}
    try:
        d = json.loads(out)
    except json.JSONDecodeError:
        return {"__error__": "jira.py returned non-JSON"}
    recs = d if isinstance(d, list) else [d]
    return {r["key"]: r for r in recs if isinstance(r, dict) and r.get("key")}


def audit(repo, do_fix=False):
    findings = []
    keys = read_keys(repo)
    beads = read_beads(repo)
    jira_only = not beads
    mirror = {}
    for b in beads:
        for lab in (b.get("labels") or []):
            if str(lab).startswith("jira:"):
                mirror.setdefault(str(lab)[5:], []).append(b)
    jira = jira_get(keys)
    jerr = jira.pop("__error__", None)

    for k in keys:
        st_now = (jira.get(k, {}).get("status") or "").lower()
        if jira_only:
            if st_now in DONE:
                findings.append({"check": "C2 stale-key", "repo": repo, "key": k, "fixable": True,
                                 "mode": "jira-only",
                                 "detail": f'Jira says {jira[k]["status"]} — '
                                           f'"{jira[k].get("summary","")[:60]}"; drop from .claude/jira_issues'})
            continue
        # A Done key with no mirror is not an orphan needing a mirror — it is just stale.
        # Reporting both makes the list twice as long and hides the real orphans.
        if k not in mirror and st_now not in DONE:
            j = jira.get(k, {})
            findings.append({"check": "C1 orphan-key", "repo": repo, "key": k, "fixable": False,
                             "detail": f'no bead labelled jira:{k} — "{j.get("summary","?")[:70]}" '
                                       f'({j.get("status","status unknown")}) will never be updated'})
        st = (jira.get(k, {}).get("status") or "").lower()
        if st in DONE:
            findings.append({"check": "C2 stale-key", "repo": repo, "key": k, "fixable": True,
                             "detail": f'Jira says {jira[k]["status"]} — "{jira[k].get("summary","")[:60]}"; '
                                       f"drop from .claude/jira_issues"})

    if jira_only:
        if jerr:
            findings.append({"check": "jira-unreachable", "repo": repo, "fixable": False,
                             "detail": f"{jerr} — checks SKIPPED, not passed"})
        return findings

    for k, bs in mirror.items():
        j = jira.get(k)
        title = (j or {}).get("summary", "")
        for b in bs:
            body = b.get("description") or ""
            m = BODY_RE.search(body)
            if not m:
                findings.append({"check": "C3 body-missing", "repo": repo, "key": k,
                                 "bead": b.get("id"), "fixable": True,
                                 "detail": f'bead {b.get("id")} "{(b.get("title") or "")[:50]}" '
                                           f"never names its parent in the body"})
            elif m.group(1) != k:
                findings.append({"check": "C4 body-mismatch", "repo": repo, "key": k,
                                 "bead": b.get("id"), "fixable": False,
                                 "detail": f'label says {k} but body says {m.group(1)} — copy-paste error'})
            bst = (b.get("status") or "").lower()
            jst = ((j or {}).get("status") or "").lower()
            if j and bst in {"closed", "done"} and jst not in DONE:
                findings.append({"check": "C5 status-drift", "repo": repo, "key": k,
                                 "bead": b.get("id"), "fixable": False,
                                 "detail": f'bead is {b.get("status")} but Jira is {j.get("status")} — '
                                           f'"{title[:50]}"'})
    if jerr:
        findings.append({"check": "jira-unreachable", "repo": repo, "fixable": False,
                         "detail": f"{jerr} — key status checks were SKIPPED, not passed"})

    if do_fix:
        _apply_fixes(repo, findings, jira, mirror)
    return findings


def _apply_fixes(repo, findings, jira, mirror):
    drop = {f["key"] for f in findings if f["check"].startswith("C2")}
    if drop:
        p = os.path.join(repo, ".claude", "jira_issues")
        lines = open(p).read().splitlines(True)
        kept = [l for l in lines if l.split("#", 1)[0].strip() not in drop]
        open(p, "w").writelines(kept)
        print(f"  fixed: dropped {len(drop)} closed key(s) from {p}")
    for f in [x for x in findings if x["check"].startswith("C3")]:
        k, bid = f["key"], f["bead"]
        title = jira.get(k, {}).get("summary", "")
        if not title:
            print(f"  skipped {bid}: no Jira title available, a bare key would just move the lookup")
            continue
        b = next((x for x in mirror[k] if x.get("id") == bid), None)
        body = (b.get("description") or "") if b else ""
        new = f"Jira: {k} — {title}\n\n{body}".rstrip() + "\n"
        rc, _, err = sh(["bd", "update", bid, "--description", new], cwd=repo)
        print(f"  fixed: {bid} body line" if rc == 0 else f"  FAILED {bid}: {err.strip()[:80]}")


def selftest():
    """Prove each check can FIRE and can stay SILENT on a clean fixture (canon EF10)."""
    print("selftest: synthetic repo, bd/Jira stubbed out\n")
    ok = True
    with tempfile.TemporaryDirectory() as d:
        os.makedirs(os.path.join(d, ".claude"))
        open(os.path.join(d, ".claude", "jira_issues"), "w").write("# hdr\nDE-1\nDE-2\n")
        beads = [{"id": "b-1", "title": "mirror of DE-1", "status": "open",
                  "labels": ["jira:DE-1"], "description": "Jira: DE-1 — parent title\n\nbody"}]
        jira = {"DE-1": {"key": "DE-1", "summary": "parent title", "status": "In Progress"},
                "DE-2": {"key": "DE-2", "summary": "unmirrored", "status": "To Do"}}
        g = globals()
        g["read_beads"], g["jira_get"] = (lambda r: beads), (lambda ks: dict(jira))
        found = {f["check"].split()[0] for f in audit(d)}
        print("  DE-2 has no mirror -> C1 fires:", "PASS" if "C1" in found else "FAIL")
        ok &= "C1" in found
        print("  DE-1 fully correct  -> stays silent:",
              "PASS" if not any(f.startswith(("C3", "C4", "C5")) for f in found) else "FAIL")
        ok &= not any(f.startswith(("C3", "C4", "C5")) for f in found)

        beads[0]["description"] = "body with no parent reference"
        ok2 = "C3" in {f["check"].split()[0] for f in audit(d)}
        print("  body line removed   -> C3 fires:", "PASS" if ok2 else "FAIL"); ok &= ok2

        beads[0]["description"] = "Jira: DE-999 — wrong parent"
        ok3 = "C4" in {f["check"].split()[0] for f in audit(d)}
        print("  body names DE-999   -> C4 fires:", "PASS" if ok3 else "FAIL"); ok &= ok3

        jira["DE-1"]["status"] = "Done"
        ok4 = "C2" in {f["check"].split()[0] for f in audit(d)}
        print("  Jira says Done      -> C2 fires:", "PASS" if ok4 else "FAIL"); ok &= ok4
    print("\nverdict:", "all checks have teeth" if ok else "BROKEN — audit results are meaningless")
    return ok


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--repo", default=None)
    p.add_argument("--all", action="store_true")
    p.add_argument("--json", action="store_true")
    p.add_argument("--fix", action="store_true", help="apply ONLY the machine-safe fixes (C2, C3)")
    p.add_argument("--selftest", action="store_true")
    a = p.parse_args()
    if a.selftest:
        return 0 if selftest() else 1

    repos = find_repos() if a.all else [os.path.abspath(a.repo or os.getcwd())]
    all_f = []
    for r in repos:
        if not os.path.exists(os.path.join(r, ".claude", "jira_issues")):
            continue
        all_f += audit(r, do_fix=a.fix)

    if a.json:
        print(json.dumps(all_f, indent=2))
        return 1 if all_f else 0
    if not all_f:
        print(f"jira<->beads: no drift across {len(repos)} repo(s)")
        return 0
    by_repo = {}
    for f in all_f:
        by_repo.setdefault(f["repo"], []).append(f)
    for repo, fs in by_repo.items():
        print(f"\n{repo.replace(os.path.expanduser('~'), '~')}")
        for f in sorted(fs, key=lambda x: x["check"]):
            mark = "fixable" if f.get("fixable") else "needs you"
            print(f"  [{mark:9}] {f['check']:18} {f.get('key','')}  {f['detail']}")
    n_fix = sum(1 for f in all_f if f.get("fixable"))
    print(f"\n{len(all_f)} finding(s), {n_fix} machine-fixable (--fix). Run --selftest to confirm the checks fire.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
