#!/usr/bin/env bash
# Level 1: scheduled detection. Turns silent drift into a dated, readable list.
# Detection only — never fixes. Fixing on a schedule would hide the trend.
set -uo pipefail
LOG="$HOME/.claude/logs/jira-drift.log"
mkdir -p "$(dirname "$LOG")"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUT=$(timeout 900 python3 "$HERE/jira-beads-audit.py" --all 2>&1)
# Surface merge candidates too — LIST only. Unattended merging is not a thing this does:
# the review step needs an agent in the loop, and the gate is not a substitute for it.
MERGEABLE=$(timeout 600 python3 "$HERE/mr-automerge.py" --all 2>&1 | grep -c ELIGIBLE || true)
{
  echo "=== $(date -Iseconds)"
  echo "$OUT"
  [ "${MERGEABLE:-0}" -gt 0 ] && echo "--- $MERGEABLE MR(s) eligible for auto-merge: run /automerge"
  echo
} >> "$LOG"
# keep the log readable: last 60 days of runs
tail -n 4000 "$LOG" > "$LOG.tmp" && mv "$LOG.tmp" "$LOG"
