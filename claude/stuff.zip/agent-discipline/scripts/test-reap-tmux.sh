#!/usr/bin/env bash
# Does the reaper close the tmux window its own removal orphaned?
#
# Three arms, over a stubbed `tmux list-panes`:
#   1. `wt remove` trash path, directory gone -> orphan  (the miss: the filter demanded
#      ".worktrees", and wt MOVES the worktree to .git/wt/trash/…)
#   2. that same window is THIS session's pane      -> kept, and it says why
#   3. the directory still exists                   -> not an orphan (negative control)
#
#   ./test-reap-tmux.sh
set -uo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
fails=0

mkdir -p "$TMP/bin"
# The stub answers list-panes from a file the arms rewrite, and records kill-window calls.
cat > "$TMP/bin/tmux" <<STUB
#!/usr/bin/env bash
case "\$1" in
  list-panes) cat "$TMP/panes" ;;
  kill-window) echo "\$3" >> "$TMP/killed" ;;
esac
STUB
chmod +x "$TMP/bin/tmux"

orphans() {  # -> "target|name" lines, plus whatever the detector printed
  PATH="$TMP/bin:$PATH" python3 - "$HERE" <<'PY'
import importlib.util, sys
spec = importlib.util.spec_from_file_location("reap", f"{sys.argv[1]}/worktree-reap.py")
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
for tgt, name, _ in m.orphan_tmux_windows():
    print(f"ORPHAN {tgt}|{name}")
PY
}

check() {  # label, haystack, needle
  if grep -qF -- "$3" <<<"$2"; then echo "  ok   $1"; else
    echo "  FAIL $1 — expected: $3"; echo "$2" | sed 's/^/       | /'; fails=$((fails+1)); fi
}
check_absent() {
  if grep -qF -- "$3" <<<"$2"; then
    echo "  FAIL $1 — should NOT contain: $3"; fails=$((fails+1)); else echo "  ok   $1"; fi
}

gone="/home/nobody/Projects/x/.git/wt/trash/feat-foo-1788249884"
live="$TMP"

echo "arm 1: wt trash path, directory gone"
printf 'atlas\t3\tfeat/foo\t%s\t%%9\n' "$gone" > "$TMP/panes"
out="$(unset TMUX_PANE; orphans)"
check "detected as an orphan" "$out" "ORPHAN atlas:3|feat/foo"

echo "arm 2: same window is this session's own pane"
out="$(TMUX_PANE=%9 orphans)"
check_absent "not offered for killing" "$out" "ORPHAN atlas:3"
check "says whose window it is" "$out" "is THIS session's own"
check "names the command to close it" "$out" "tmux kill-window -t atlas:3"

echo "arm 3: directory still exists (negative control)"
printf 'atlas\t4\tfeat/bar\t%s\t%%11\n' "$live" > "$TMP/panes"
out="$(unset TMUX_PANE; orphans)"
check_absent "live window is not an orphan" "$out" "ORPHAN"

echo
[[ $fails -eq 0 ]] && { echo "PASS"; exit 0; } || { echo "$fails check(s) FAILED"; exit 1; }
