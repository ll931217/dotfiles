#!/usr/bin/env bash
# E2E: an unhealthy install must exit 1 and print the offending thing AND a fix command.
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
out=$(HOME="$tmp" AGENT_DISCIPLINE_NO_CRON=1 bash "$ROOT/scripts/doctor.sh" 2>&1); rc=$?
fail=0
[ "$rc" = 1 ] || { echo "FAIL: empty HOME should exit 1, got $rc"; fail=1; }
grep -q 'no .*settings.json' <<<"$out" || { echo "FAIL: does not name the missing settings.json"; fail=1; }
grep -q 'fix: ./install.sh' <<<"$out"  || { echo "FAIL: no fix command offered"; fail=1; }
grep -q 'UNHEALTHY' <<<"$out"          || { echo "FAIL: no verdict line"; fail=1; }
out2=$(bash "$ROOT/scripts/doctor.sh" --quiet 2>&1)
grep -q '✓' <<<"$out2" && { echo "FAIL: --quiet printed passing checks"; fail=1; }
[ "$fail" = 0 ] && echo "ok: doctor reports, names, and fixes" || exit 1
