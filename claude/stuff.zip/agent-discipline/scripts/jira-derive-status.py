#!/usr/bin/env python3
"""Level 3: derive Jira status from MR state instead of maintaining it by hand.

Levels 1 and 2 POLICE drift. This removes a class of it: when status is derived, there is no
second copy of the truth to fall out of sync.

  MR open / draft   -> In Progress
  MR ready, not draft, has reviewers or is non-draft open  -> Verifying   (this board's review state)
  MR merged         -> Done
  MR closed         -> left alone (abandoned work is a human call)

Key discovery: source branch (feat/DE-1788-x), MR title, or MR description.

WRITES TO JIRA. Dry-run is the default; --apply is required to transition anything.
What it CANNOT see: tickets with no MR — investigation, blocked, abandoned work. Those still
drift, which is why the level 1 / level 2 audit stays.

  jira-derive-status.py [--repo PATH | --all] [--apply]
"""
import argparse, glob, json, os, re, subprocess, sys
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.realpath(__file__))))
from agent_tools import gl_api, ToolError  # noqa: E402

JIRA = os.path.expanduser(
    "~/Projects/llm_library/plugins/data-skills/skills/jira/scripts/jira.py")
SEARCH_ROOTS = ["~/Projects", "~/GitLab", "~/Services"]
KEY_RE = re.compile(r"\b([A-Z][A-Z0-9]+-\d+)\b")
TERMINAL = {"done", "closed", "resolved", "cancelled", "won't do", "wont do"}

def sh(cmd, cwd=None, timeout=120):
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
    return r.returncode, r.stdout, r.stderr

def repos(all_):
    if not all_:
        return [os.getcwd()]
    out = []
    for root in SEARCH_ROOTS:
        out += glob.glob(os.path.join(os.path.expanduser(root), "*", ".claude", "jira_issues"))
    return sorted(os.path.dirname(os.path.dirname(p)) for p in out)

def mrs(repo):
    try:
        return gl_api("projects/:id/merge_requests?state=all&per_page=50", cwd=repo), None
    except ToolError as e:
        return None, str(e)[:160]

def desired(mr):
    """MR state -> the status this board should show. None = do not touch."""
    st = mr.get("state")
    if st == "merged":
        return "Done"
    if st == "opened":
        return "In Progress" if mr.get("draft") else "Verifying"
    return None                      # closed: abandoned work is a human decision

def keys_for(mr):
    text = " ".join([mr.get("source_branch") or "", mr.get("title") or "",
                     (mr.get("description") or "")[:400]])
    return sorted(set(KEY_RE.findall(text)))

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--repo"); p.add_argument("--all", action="store_true")
    p.add_argument("--apply", action="store_true", help="actually transition Jira (default: dry-run)")
    a = p.parse_args()
    targets = [os.path.abspath(a.repo)] if a.repo else repos(a.all)

    planned, skipped = [], []
    for repo in targets:
        if not os.path.exists(os.path.join(repo, ".git")):
            continue
        ms, err = mrs(repo)
        if ms is None:
            skipped.append((repo, err)); continue
        want = {}
        for mr in ms:
            d = desired(mr)
            if not d:
                continue
            for k in keys_for(mr):
                # merged beats open: a key on several MRs is Done only once all merged
                if want.get(k, ("", None))[0] != "In Progress":
                    want[k] = (d, mr)
        if not want:
            continue
        rc, out, _ = sh([sys.executable, JIRA, "get", *sorted(want)], timeout=180)
        try:
            recs = json.loads(out) if rc == 0 else []
        except json.JSONDecodeError:
            recs = []
        cur = {r["key"]: r for r in (recs if isinstance(recs, list) else [recs]) if r.get("key")}
        for k, (d, mr) in sorted(want.items()):
            now = cur.get(k, {}).get("status", "?")
            if now.lower() == d.lower() or now.lower() in TERMINAL and d != "Done":
                continue
            if now == "?":
                continue
            planned.append({"repo": repo, "key": k, "from": now, "to": d,
                            "mr": f'!{mr.get("iid")} {mr.get("state")} — {(mr.get("title") or "")[:60]}',
                            "summary": cur.get(k, {}).get("summary", "")[:60]})

    if skipped:
        print("could not read MRs (reported, NOT treated as clean):")
        for r, e in skipped:
            print(f"  {r.replace(os.path.expanduser('~'),'~')}: {e}")
        print()
    if not planned:
        print("no status to derive — every mirrored key already matches its MR state")
        return 0
    print(f"{'APPLYING' if a.apply else 'DRY RUN — nothing written'} · {len(planned)} transition(s)\n")
    for t in planned:
        print(f"  {t['key']}  {t['from']:>12} -> {t['to']:<12} {t['summary']}")
        print(f"      driven by {t['mr']}")
    if not a.apply:
        print("\nRe-run with --apply to write these to Jira. Review the list first: a wrong")
        print("transition is visible to the whole team and has to be undone by hand.")
        return 0
    for t in planned:
        rc, _, err = sh([sys.executable, JIRA, "transition", t["key"], "--to", t["to"],
                         "--comment", f"Status derived from {t['mr']}"], timeout=120)
        print(f"  {'ok  ' if rc == 0 else 'FAIL'} {t['key']} -> {t['to']}"
              + ("" if rc == 0 else f"  {err.strip()[:80]}"))
    return 0

if __name__ == "__main__":
    sys.exit(main())
