#!/usr/bin/env bash
# Watch a GitLab MR + its pipeline. Notifies on every state change,
# then again when the MR merges or closes, then exits.
#
# Usage:
#   glab-watch-mr.sh            # watch MR for current branch
#   glab-watch-mr.sh 9          # watch MR !9
#   glab-watch-mr.sh feat/foo   # watch MR for branch feat/foo
#   glab-watch-mr.sh --once     # print status once and exit (no loop)
#   INTERVAL=60 glab-watch-mr.sh
#   NO_REAP=1 glab-watch-mr.sh   # do not clean up when it merges
#
# Exit codes: 0 merged/closed/--once, 1 no MR found, 2 pipeline failed or canceled,
# 3 merge conflict (cannot_be_merged twice in a row).
#
# On merge it reaps: worktree, local branch and MR-watch cron entry. The reaper fails closed
# (merged + clean + nothing unpushed, or it keeps and reports), so this is safe unattended.
# Watching a merge and then leaving the worktree behind is what left 4,741 stale watcher logs.
set -euo pipefail

INTERVAL="${INTERVAL:-30}"
# Resolved through symlinks: this script is normally invoked as ~/.scripts/glab-watch-mr.sh,
# a symlink into the plugin. Taking dirname of the LINK put the reaper in ~/.scripts, where it
# does not exist -- so `-x "$REAP"` was false and the auto-reap below was skipped in SILENCE on
# every real invocation. That is why a merged MR still left its worktree behind.
SELF="$(readlink -f "${BASH_SOURCE[0]}")"
REAP="$(dirname "$SELF")/worktree-reap.py"

# group/repo, e.g. st-dev/rom — without it a notification from one of eight open
# worktrees is unattributable, which is the whole reason for watching in the first place.
PROJECT="$(glab api projects/:id 2>/dev/null | jq -r '.path_with_namespace // empty')"
[[ -z "$PROJECT" ]] && PROJECT="$(basename "$(git rev-parse --show-toplevel 2>/dev/null || pwd)")"

notify() {  # title, body
  echo "[$(date +%H:%M:%S)] $1 — $2"
  command -v notify-send >/dev/null 2>&1 && notify-send "$1" "$2" || true
}

resolve_iid() {  # arg -> MR iid
  local arg="${1:-}"
  [[ "$arg" =~ ^[0-9]+$ ]] && { echo "$arg"; return; }
  local branch="${arg:-$(git branch --show-current)}"
  glab api "projects/:id/merge_requests?source_branch=${branch}&state=opened" \
    | jq -r 'sort_by(.iid) | last | .iid // empty'
}

once="false"
[[ "${1:-}" == "--once" ]] && { once="true"; shift; }

iid="$(resolve_iid "${1:-}")"
[[ -z "$iid" ]] && { echo "No open MR found for that branch." >&2; exit 1; }

echo "Watching ${PROJECT} !${iid} (poll ${INTERVAL}s)…"
last=""
while true; do
  read -r state pipe merge_status web pipe_web < <(
    glab api "projects/:id/merge_requests/${iid}" \
      | jq -r '[.state, (.head_pipeline.status // "none"), .merge_status, .web_url, (.head_pipeline.web_url // "-")] | @tsv'
  )
  # Terminal states get their own notification below, with the URL you would actually
  # click. Announcing the change too fired two notifications back to back for one event.
  terminal="false"
  case "$state" in merged|closed) terminal="true" ;; esac
  case "$pipe" in failed|canceled) terminal="true" ;; esac

  now="${state}/${pipe}/${merge_status}"
  if [[ "$now" != "$last" && "$terminal" == "false" ]]; then
    notify "${PROJECT} !${iid}: ${state}" "pipeline=${pipe} merge=${merge_status}  ${pipe_web}"
    last="$now"
  fi

  # A red pipeline or a conflict is terminal for an unattended watch: nothing
  # changes until a human pushes again, so keep polling and the watcher just
  # burns until its timeout with the failure buried mid-log. Exit non-zero so
  # the caller sees it.
  case "$pipe" in
    failed|canceled)
      notify "${PROJECT} !${iid} PIPELINE ${pipe^^} ❌" "$pipe_web"
      exit 2 ;;
  esac

  # merge_status flaps through checking/unchecked while GitLab recomputes the
  # merge ref, so one bad reading is not a conflict. Two in a row is.
  if [[ "$merge_status" == "cannot_be_merged" ]]; then
    conflict_hits=$(( ${conflict_hits:-0} + 1 ))
    if (( conflict_hits >= 2 )); then
      notify "${PROJECT} !${iid} MERGE CONFLICT ⚠" "$web"
      exit 3
    fi
  else
    conflict_hits=0
  fi

  case "$state" in
    merged)
      notify "${PROJECT} !${iid} MERGED ✅" "$web"
      # The merge starts a pipeline on the TARGET branch, and nobody is watching it:
      # this watcher exits here, and no local command ran, so the PostToolUse hook
      # never fires either. That is how a red post-merge pipeline stayed unnoticed
      # until someone opened the web UI. Hand off before reaping — the reap moves
      # this shell out of the worktree.
      target="$(glab api "projects/:id/merge_requests/${iid}" | jq -r '.target_branch // empty')"
      watcher="$(dirname "$SELF")/glab-watch-pipeline.sh"
      if [[ -n "$target" && -x "$watcher" ]]; then
        log="$HOME/.cache/glab-watch/merged-$(printf '%s' "$target" | tr / _).log"
        mkdir -p "$(dirname "$log")"
        # sleep: GitLab needs a moment to create the pipeline for the merge commit,
        # and resolve_id on an empty list exits 1 as "no pipeline found".
        ( cd "$PWD" && sleep 20 && "$watcher" "$target" ) >>"$log" 2>&1 &
        disown 2>/dev/null || true
        echo "--- now watching the ${target} pipeline in the background: $log"
      fi
      if [[ "${NO_REAP:-0}" == "1" ]]; then
        echo "--- NO_REAP=1: leaving the worktree, branch and cron entry in place"
      elif [[ ! -x "$REAP" ]]; then
        # Loud, not silent: a missing reaper used to mean the cleanup simply never happened
        # and nothing said so.
        echo "!!! reaper not found at $REAP — worktree NOT cleaned up. Fix the install." >&2
      else
        echo "--- cleaning up after the merge (NO_REAP=1 to skip)"
        # From the MAIN checkout, and with the shell's cwd out of the worktree first: this
        # script often runs INSIDE the worktree it is about to remove, and `git worktree
        # remove` cannot delete the directory a process is sitting in.
        main="$(git worktree list --porcelain | sed -n '''1s/^worktree //p''')"
        cd "${main:-$(git rev-parse --show-toplevel)}"
        python3 "$REAP" --repo . --reap || \
          echo "reap failed — run it by hand: python3 $REAP --repo ${main:-.} --reap" >&2
        # Not "worktree gone": the reaper keeps anything it cannot prove is finished,
        # and claiming a removal it declined to make is how a stale worktree goes unnoticed.
        echo "--- cleanup done; this shell now sits in $PWD"
      fi
      exit 0 ;;
    closed) notify "${PROJECT} !${iid} CLOSED ❌" "$web"; exit 0 ;;
  esac
  [[ "$once" == "true" ]] && exit 0
  sleep "$INTERVAL"
done
