#!/usr/bin/env bash
# Watch a GitLab MR + its pipeline. Notifies on every state change,
# then again when the MR merges or closes, then exits.
#
# Usage:
#   glab-watch-mr.sh            # watch MR for current branch
#   glab-watch-mr.sh 9          # watch MR !9
#   glab-watch-mr.sh feat/foo   # watch MR for branch feat/foo
#   glab-watch-mr.sh --once     # print status once and exit (no loop)
#   INTERVAL=60 glab-watch-mr.sh
#   NO_REAP=1 glab-watch-mr.sh   # do not clean up when it merges
#
# On merge it reaps: worktree, local branch and MR-watch cron entry. The reaper fails closed
# (merged + clean + nothing unpushed, or it keeps and reports), so this is safe unattended.
# Watching a merge and then leaving the worktree behind is what left 4,741 stale watcher logs.
set -euo pipefail

INTERVAL="${INTERVAL:-30}"
REAP="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/worktree-reap.py"

# group/repo, e.g. st-dev/rom — without it a notification from one of eight open
# worktrees is unattributable, which is the whole reason for watching in the first place.
PROJECT="$(glab api projects/:id 2>/dev/null | jq -r '.path_with_namespace // empty')"
[[ -z "$PROJECT" ]] && PROJECT="$(basename "$(git rev-parse --show-toplevel 2>/dev/null || pwd)")"

notify() {  # title, body
  echo "[$(date +%H:%M:%S)] $1 — $2"
  command -v notify-send >/dev/null 2>&1 && notify-send "$1" "$2" || true
}

resolve_iid() {  # arg -> MR iid
  local arg="${1:-}"
  [[ "$arg" =~ ^[0-9]+$ ]] && { echo "$arg"; return; }
  local branch="${arg:-$(git branch --show-current)}"
  glab api "projects/:id/merge_requests?source_branch=${branch}&state=opened" \
    | jq -r 'sort_by(.iid) | last | .iid // empty'
}

once="false"
[[ "${1:-}" == "--once" ]] && { once="true"; shift; }

iid="$(resolve_iid "${1:-}")"
[[ -z "$iid" ]] && { echo "No open MR found for that branch." >&2; exit 1; }

echo "Watching ${PROJECT} !${iid} (poll ${INTERVAL}s)…"
last=""
while true; do
  read -r state pipe merge_status web pipe_web < <(
    glab api "projects/:id/merge_requests/${iid}" \
      | jq -r '[.state, (.head_pipeline.status // "none"), .merge_status, .web_url, (.head_pipeline.web_url // "-")] | @tsv'
  )
  now="${state}/${pipe}/${merge_status}"
  if [[ "$now" != "$last" ]]; then
    notify "${PROJECT} !${iid}: ${state}" "pipeline=${pipe} merge=${merge_status}  ${pipe_web}"
    last="$now"
  fi

  case "$state" in
    merged)
      notify "${PROJECT} !${iid} MERGED ✅" "$web"
      if [[ "${NO_REAP:-0}" != "1" && -x "$REAP" ]]; then
        echo "--- cleaning up after the merge (NO_REAP=1 to skip)"
        python3 "$REAP" --repo "$(git rev-parse --show-toplevel)" --reap || \
          echo "reap failed — run it by hand: python3 $REAP --repo . "
      fi
      exit 0 ;;
    closed) notify "${PROJECT} !${iid} CLOSED ❌" "$web"; exit 0 ;;
  esac
  [[ "$once" == "true" ]] && exit 0
  sleep "$INTERVAL"
done
