#!/usr/bin/env python3
"""Why did that context appear? The receipt explainer — the `/ledger:why` surface.

  ledger-why.py                # the most recent receipts
  ledger-why.py <receipt_id>   # everything considered, selected and rejected, and why
  ledger-why.py --last         # the newest receipt in full

A receipt is written before the context it explains is used, so it can never describe a
resolution that did not happen.
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
from agent_discipline_paths import mem_file          # noqa: E402
from ledger.events import ReceiptStore                # noqa: E402

STATE = {"selected": "used", "rejected": "left out", "conflicts": "conflict",
         "considered": "considered", "stale": "stale"}


def show(rec):
    print(f"{rec['receipt_id']}   manifest {rec['manifest_id']} rev {rec['revision']}")
    print(f"  generated {rec['generated_at']}   trigger {rec['trigger'] or '-'}")
    if rec.get("degraded_sources"):
        print(f"  DEGRADED: {', '.join(rec['degraded_sources'])}"
              f"   <- the context was thinner than it looks")
    groups = {}
    for it in rec["items"]:
        groups.setdefault(it["state"], []).append(it)
    for state in ("selected", "rejected", "conflicts", "stale", "considered"):
        items = groups.get(state)
        if not items:
            continue
        print(f"\n  {STATE.get(state, state)} ({len(items)}):")
        for it in items:
            extra = f" — {it['why']}" if it.get("why") else ""
            auth = f"  [{it['authority']}]" if it.get("authority") else ""
            print(f"    {it['id']}{auth}{extra}")


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("receipt_id", nargs="?")
    ap.add_argument("--last", action="store_true")
    ap.add_argument("--path", default=None)
    a = ap.parse_args()

    path = a.path or mem_file("lcg_receipts.jsonl")
    store = ReceiptStore(path)
    all_recs = list(store.read_all())
    if not all_recs:
        print(f"no receipts at {path}")
        print("Receipts are written when LCG_RECEIPTS=1 and the resolver runs "
              "(LCG_RESOLVER=1). Both are off by default — see `python3 config.py`.")
        return 1
    if a.receipt_id:
        rec = store.get(a.receipt_id)
        if not rec:
            print(f"no receipt {a.receipt_id!r}. The newest are:")
            for r in all_recs[-5:]:
                print(f"  {r['receipt_id']}  {r['generated_at']}")
            return 1
        show(rec)
        return 0
    if a.last:
        show(all_recs[-1])
        return 0
    print(f"{len(all_recs)} receipt(s) in {path}. Newest last:\n")
    for r in all_recs[-10:]:
        sel = sum(1 for i in r["items"] if i["state"] == "selected")
        rej = sum(1 for i in r["items"] if i["state"] == "rejected")
        deg = " DEGRADED" if r.get("degraded_sources") else ""
        print(f"  {r['receipt_id']}  {r['generated_at']}  {r['manifest_id']}"
              f"  {sel} used, {rej} left out{deg}")
    print("\nOne in full: ledger-why.py <receipt_id>")
    return 0


if __name__ == "__main__":
    sys.exit(main())
