#!/usr/bin/env python3
"""Orchestrator side of the worker flow: one worktree + one worker Claude per ready task.

  orchestrate.py plan     [--repo P]                       # which tasks can run in parallel now (bd ready)
  orchestrate.py dispatch --branch B --task "..." --orchestrator NAME [--key ID] [--base BR]
                          [--lane full|small|urgent|risky|mechanical|spike|revert|repay]
                          # each lane says which part of the full price it refuses to pay (LANES below)
                                                           # worktree + .claude/TASK.md, says how to start the worker
  orchestrate.py status   [--repo P] [--no-mr]             # every worker: DoD, round, report, MR — and what to do next
  orchestrate.py approve  --worktree P                     # record it; prints the message to send the worker
  orchestrate.py reject   --worktree P --issue "..."       # record it; prints the message to send the worker
  orchestrate.py abandon  --worktree P --why "..."         # record the dead end where the next attempt reads it

The orchestrator never edits code. It dispatches, reviews against the task's DoD file, approves or
rejects. The worker (prompts/worker.md) does everything else and opens the MR after approve.
"""
import argparse, glob, json, os, re, shutil, subprocess, sys

HERE = os.path.dirname(os.path.realpath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from agent_discipline_paths import topics_dir  # noqa: E402
from agent_tools import gl_api, ToolError, worktree_add, tasks_ready  # noqa: E402

DELEGATE = os.path.join(HERE, "delegate.py")
# wt is preferred but not required: worktree_add() falls back to `git worktree`, which cannot
# run worktrunk's post-start hook — so no worker session starts and dispatch says so below.


def sh(cmd, cwd=None, timeout=120):
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
    return r.returncode, r.stdout.strip(), r.stderr.strip()


def repo_root(p):
    rc, out, _ = sh(["git", "rev-parse", "--show-toplevel"], cwd=p)
    return out if rc == 0 else sys.exit(f"not a git checkout: {p}")


def worktrees(root):
    rc, out, _ = sh(["git", "worktree", "list", "--porcelain"], cwd=root)
    items, cur = [], {}
    for ln in out.splitlines() + [""]:
        if not ln:
            if cur: items.append(cur); cur = {}
        elif ln.startswith("worktree "): cur["path"] = ln[9:]
        elif ln.startswith("branch "): cur["branch"] = ln[7:].replace("refs/heads/", "")
    return [w for w in items if os.path.realpath(w["path"]) != os.path.realpath(root)]


def matching_prefs(task, limit=5):
    """Ledger records whose cue overlaps the task text; carries the Preference line (AS1)."""
    words = {w for w in re.findall(r"[a-z][a-z0-9-]{3,}", task.lower())}
    hits = []
    for f in sorted(glob.glob(os.path.join(topics_dir(), "pref-*.md"))):
        s = open(f, encoding="utf-8", errors="replace").read()
        cue = " ".join(re.findall(r"^(?:description|triggers):(.*)$", s, re.M)).lower()
        score = sum(2 for w in words if w in cue) + sum(1 for w in words if w in s.lower())
        m = re.search(r"\*\*Preference:\*\*\s*(.+?)(?:\n\n|\n\*\*)", s, re.S)
        if score and m:
            hits.append((score, os.path.basename(f), " ".join(m.group(1).split())))
    hits.sort(reverse=True)
    return hits[:limit]


# ── the lanes ─────────────────────────────────────────────────────────────────────
# Full ceremony (4 core + 1-3 domain lenses, 3 rounds, whole suite) is priced for a change
# that can hurt. Every other lane says which part of that price it refuses to pay, and why —
# a lane is a PRICE, never a mood. Where a lane can be gated mechanically it is gated on the
# PATHS, because "this feels small" is exactly the judgement that widens under deadline.
SMALL_MAX_PATHS = 3
RISKY_PATH = re.compile(
    r"(^|/)(\.gitlab-ci\.yml|\.github/|Jenkinsfile|Dockerfile|docker-compose"
    r"|migrations?/|alembic/|terraform/|\.tf$|helm/|charts?/|k8s/|kubernetes/"
    r"|secrets?/|\.env|credentials?)", re.I)

CORE_LENSES = ["dod-intent", "dod-tests", "dod-discipline", "dod-prefs"]
URGENT_SKIPPED_LENSES = ["dod-intent", "dod-discipline", "dod-prefs", "domain lenses"]

# lens=None means "the full set the worker picks"; [] means no lenses at all.
LANES = {
    "full":       dict(lenses=None, rounds=3, approval=True,  mr=True,  plan_gate=False,
                       cost="4 core + 1-3 domain lenses, 3 rounds, whole suite"),
    "small":      dict(lenses=["dod-intent", "dod-tests"], rounds=1, approval=True, mr=True,
                       plan_gate=False, cost="2 lenses (intent, tests), 1 round"),
    "urgent":     dict(lenses=["dod-tests"], rounds=1, approval=False, mr=True, plan_gate=False,
                       cost="1 lens (tests), no approval round, worker opens the MR itself"),
    "risky":      dict(lenses=None, rounds=3, approval=True, mr=True, plan_gate=True,
                       cost="full lenses, 3 rounds, AND the plan is approved before any code"),
    "mechanical": dict(lenses=["dod-intent", "dod-tests"], rounds=1, approval=True, mr=True,
                       plan_gate=False, cost="2 lenses (intent, tests), 1 round, reviewed once"),
    "spike":      dict(lenses=[], rounds=0, approval=False, mr=False, plan_gate=False,
                       cost="no lenses, no MR — the deliverable is a written answer"),
    "revert":     dict(lenses=[], rounds=0, approval=True, mr=True, plan_gate=False,
                       cost="no lenses — the only check is that the diff is the exact inverse"),
    "repay":      dict(lenses=None, rounds=3, approval=True, mr=True, plan_gate=False,
                       cost="the lenses an urgent fire skipped, run over the merged diff"),
}


def path_gate(touches, max_paths=None):
    """Reason these paths may NOT take a reduced lane, or None. Shared by small and mechanical
    so the two can never drift into disagreeing about what a risky path is."""
    if not touches:
        return ("this lane needs --touches <path> [...]: the gate reads the paths the change "
                "touches, so it cannot be satisfied by judgement alone")
    if max_paths and len(touches) > max_paths:
        return (f"{len(touches)} paths, and this lane allows at most {max_paths}: "
                + ", ".join(touches))
    bad = [t for t in touches if RISKY_PATH.search(t)]
    if bad:
        return ("CI / migration / infra / secret path(s), which always get the full lane: "
                + ", ".join(bad))
    return None


def small_lane_reject(touches):
    """Reason this task may NOT take the small lane, or None if it may."""
    why = path_gate(touches, SMALL_MAX_PATHS)
    return why.replace("this lane needs", "--small needs") if why else None


def pick_lane(a):
    """(lane, reason-it-was-refused, note). Flags collapse to ONE lane here so the rest of
    dispatch never has to reason about combinations — and so a second lane flag is a refusal
    rather than a silent precedence rule nobody remembers."""
    named = [n for n in ("small", "urgent") if getattr(a, n, False)]
    if a.lane and named:
        return None, f"--lane {a.lane} and --{named[0]} say different things. Pick one.", None
    if len(named) > 1:
        return None, ("--small and --urgent are different problems: small = low risk, urgent = "
                      "risk unchanged but waiting costs more. Pick one."), None
    lane = a.lane or (named[0] if named else "full")
    note = None
    # The risky lane is the one lane you can fall INTO. Nobody reaches for more review under
    # deadline, so the paths that earn it are read, not volunteered.
    if lane == "full" and a.touches and any(RISKY_PATH.search(t) for t in a.touches):
        bad = ", ".join(t for t in a.touches if RISKY_PATH.search(t))
        lane, note = "risky", f"upgraded to the risky lane by its paths: {bad}"
    return lane, None, note


def lane_flag(lane, a):
    """The flag the user actually typed, so a refusal names what to remove."""
    return "--small" if a.small else "--urgent" if a.urgent else f"--lane {lane}"


def lane_reject(lane, a):
    """Reason this dispatch may not run on the lane it asked for, or None."""
    if lane in ("small", "mechanical"):
        why = path_gate(a.touches, SMALL_MAX_PATHS if lane == "small" else None)
        return why.replace("this lane needs", f"{lane_flag(lane, a)} needs") if why else None
    if lane == "urgent" and not (a.why or "").strip():
        return (f'{lane_flag(lane, a)} needs --why "<what is broken in production>": it is what the debt '
                "bead and the MR say, and what stops the lane becoming the default.")
    if lane == "revert" and not (a.revert_of or "").strip():
        return ("--lane revert needs --revert-of <sha>: the lane buys its way out of review by "
                "targeting a commit that was already reviewed, so it must name it.")
    if lane == "repay" and not (a.key or "").strip():
        return ("--lane repay needs --key <debt-bead>: the lane exists to close one booked debt, "
                "and the bead is where the skipped lenses are written down.")
    if lane == "spike" and not (a.why or "").strip():
        return ('--lane spike needs --why "<the question this answers>": a spike with no question '
                "is just unreviewed code.")
    return None


# ── the urgent lane ───────────────────────────────────────────────────────────────
# NOT the small lane with a different name. Small = the risk is low, so buy less review.
# Urgent = the risk is UNCHANGED, but waiting costs more than reviewing — so the review is
# deferred, never cancelled. Hence no path gate (a broken prod auth path is exactly the file
# the small gate refuses) and a debt bead created at dispatch, before any code exists.


def debt_bead(root, branch, why, key=None):
    """Open the follow-up that makes the skipped review a debt, not a write-off.

    Returns (bead_id, error). Created at DISPATCH, not at merge: a worker that dies mid-fire
    would otherwise take the only record of the skipped lenses with it.
    """
    if not (shutil.which("bd") and os.path.isdir(os.path.join(root, ".beads"))):
        return None, "no bd in this repo — the skipped review is UNRECORDED; open it by hand"
    title = f"[urgent-lane] review {branch} with the lenses the fire skipped"
    desc = ("Why: an urgent fix shipped with only the dod-tests lens, so the rest of the DoD "
            f"never ran.\nWhat: re-review the merged change on {branch} through "
            + ", ".join(URGENT_SKIPPED_LENSES)
            + f".\nWhere: this repo, branch {branch}"
            + (f" (task {key})" if key else "")
            + f".\nWhen: shipped under this incident — {why}\n"
            "How: read the merged diff, run the lenses, fix or accept each finding.\n"
            f"Repay: orchestrate.py dispatch --lane repay --key <this bead> --branch "
            f"repay/{branch.replace('/', '-')} --task \"repay the review {branch} skipped\"")
    rc, out, err = sh(["bd", "create", "--title", title, "--description", desc,
                       "--type", "task", "--priority", "1", "--label", "urgent-lane-debt"],
                      cwd=root)
    if rc != 0:
        return None, f"bd create failed: {err or out}"
    m = re.search(r"[a-z0-9][a-z0-9-]*-[a-z0-9]+", out)
    return (m.group(0) if m else out.strip()), None


def debt_detail(root, key):
    """What an urgent fire skipped, read back off its debt bead. The repay lane must run the
    lenses that were actually skipped, and the bead is the only record of them."""
    if not shutil.which("bd"):
        return None, None, "no bd on PATH — cannot read the debt bead"
    rc, out, err = sh(["bd", "show", key], cwd=root)
    if rc != 0:
        return None, None, f"bd show {key} failed: {err or out}"
    lenses = [l for l in URGENT_SKIPPED_LENSES if l in out] or URGENT_SKIPPED_LENSES
    m = re.search(r"review ([^\s]+) with the lenses", out)
    return lenses, (m.group(1) if m else None), None


# ── abandoned attempts ────────────────────────────────────────────────────────────
# Kept inside .git/, not in the tree: it must survive the worktree it describes being reaped,
# and it must never dirty a checkout (a dirty worktree is what blocks reaping).
def abandon_dir(root):
    return os.path.join(root, ".git", "agent-discipline", "abandoned")


def abandon_note(root, key):
    f = os.path.join(abandon_dir(root), f"{re.sub(r'[^A-Za-z0-9._-]+', '-', str(key))}.md")
    return f if os.path.exists(f) else None


def cmd_plan(a):
    root = repo_root(a.repo)
    try:
        backend, items, note = tasks_ready(root)
    except ToolError as e:
        print(f"nothing to plan from: {e}")
        print("Dispatch by hand:")
        print('  orchestrate.py dispatch --branch <b> --task "<one sentence>" --orchestrator <your session name>')
        return 0
    if not items:
        print(f"{backend}: nothing is ready"
              + (" (all open issues are blocked, in progress or deferred)" if backend == "bd" else ""))
        if note:
            print(f"  NOTE: {note}")
        return 0
    print(f"{len(items)} task(s) ready now — no open blockers, so they can run in parallel, "
          f"one worker each:   [source: {backend}]")
    for it in items:
        print(f"  {str(it['id']):<14} {(it.get('title') or '')[:90]}")
    if note:
        # The fallback answers a NARROWER question. Printing the list without this would pass
        # "assigned and not done" off as "has no blockers".
        print(f"\n  NOTE: {note}")
    print("\nnext: for each, orchestrate.py dispatch --key <id> --branch <b> --task \"<title>\" --orchestrator <you>")
    return 0


def cmd_dispatch(a):
    root = repo_root(a.repo)
    if os.path.realpath(root) != os.path.realpath(repo_root(os.path.join(root, "."))) or "/.worktrees/" in root:
        sys.exit("run dispatch from the MAIN checkout, not from inside a worktree")
    # Before creating anything: a rejected lane must leave no worktree behind.
    lane, clash, upgrade = pick_lane(a)
    if clash:
        sys.exit(clash)
    why_no = lane_reject(lane, a)
    if why_no:
        flag = lane_flag(lane, a)
        sys.exit(f"{flag} refused: {why_no}\n"
                 f"re-run without {flag} — this task gets the full lane.")
    spec = LANES[lane]
    base = a.base
    if not base:
        rc, _, _ = sh(["git", "rev-parse", "--verify", "-q", "origin/staging"], cwd=root)
        base = "staging" if rc == 0 else None
    backend, _path, err = worktree_add(root, a.branch, base=base)
    if err:
        sys.exit(f"{backend} failed to create the worktree:\n{err}\nfix that, then re-run dispatch")
    wt = next((w["path"] for w in worktrees(root) if w.get("branch") == a.branch), None)
    if not wt:
        sys.exit(f"{backend} reported success but no worktree has branch {a.branch} "
                 f"— check `git worktree list`")

    # The DoD path is decided HERE and written into TASK.md, so the worker, the orchestrator
    # and delegate.py cannot disagree about it. One file per task: a shared .claude/DOD.md is
    # tracked, so two workers on one repo collided on it in git.
    sys.path.insert(0, HERE)
    import importlib
    _dm = importlib.import_module("delegate")          # safe: its parser lives in main()
    dod_rel = os.path.relpath(_dm.dod_path(wt, a.key or a.branch), wt)
    # Before writing any of it: make it invisible to git. An un-ignored TASK.md leaves the
    # worktree permanently dirty, and worktree-reap refuses to remove a dirty worktree — so
    # the bookkeeping silently blocked its own cleanup.
    ignored = _dm.ensure_ignored(wt)

    bead, bead_err = debt_bead(root, a.branch, a.why, a.key) if lane == "urgent" else (None, None)
    repay_lenses = repay_branch = repay_err = None
    if lane == "repay":
        repay_lenses, repay_branch, repay_err = debt_detail(root, a.key)
    prior = abandon_note(root, a.key) if a.key else None

    prefs = matching_prefs(a.task)
    lines = ["# Task", "", a.task, "",
             f"Key: {a.key or '-'}",
             f"DoD file: {dod_rel}   (yours alone — never .claude/DOD.md, which is shared)",
             f"Orchestrator: {a.orchestrator}   (SendMessage to this name; it reviews, you implement)",
             f"Base branch: {base or 'repo default'}   MR target: staging (never main)", "",
             "## Constraints", "",
             "- phases of ≤5 files; run the project's checks and commit after each",
             "- push the branch when green; open the MR only after the orchestrator approves",
             "- anything you notice next to the task: `bd create`, do not fix in-band", "",
             "## Preferences that apply (from the ledger)", ""]
    lines += [f"- {p} — `{f}`" for _, f, p in prefs] or ["- none matched the task text; still read pref-*.md for the dod-prefs lens"]
    if prior:
        lines += ["", "## A previous attempt at this task was abandoned", "",
                  "Read it before you plan — it is the record of a dead end someone already paid",
                  f"for: `{prior}`", ""]
        lines += ["> " + l for l in open(prior).read().strip().splitlines()]
    if lane == "urgent":
        lines += ["", "## Lane: URGENT", "",
                  f"Production is broken: {a.why}",
                  "",
                  "Speed is bought here, not safety. Spawn ONLY `dod-tests` — a runnable check",
                  "that proves the fix works and fails when it breaks. Skip "
                  + ", ".join(URGENT_SKIPPED_LENSES) + ".",
                  "Verification cap is 1 round. When that lens passes, open the MR IMMEDIATELY —",
                  "do not wait for the orchestrator to approve. Say in the MR body which lenses",
                  "were skipped and why.",
                  "",
                  (f"The skipped review is already booked as `{bead}` — say that bead id in the MR"
                   if bead else
                   f"!! The follow-up review could NOT be booked ({bead_err}). Say so to the"
                   " orchestrator in your first message — an unbooked skip is a write-off."),
                  "",
                  "You still do not skip: the fix actually working, the check that proves it, and",
                  "a truthful report. A lane that ships an unverified change is not fast, it is a",
                  "second outage."]
    if lane == "small":
        lines += ["", "## Lane: SMALL", "",
                  "This task passed the small-lane gate on its paths: "
                  + ", ".join(a.touches) + ".",
                  "Reduced ceremony — spawn ONLY `dod-intent` and `dod-tests`, no domain lenses,",
                  "no dod-discipline, no dod-prefs. Verification cap is 1 round, not 3. Run the",
                  "checks that cover the paths above, not the whole suite; the pipeline is the",
                  "full gate.",
                  "",
                  "Grow past those paths, or find the change needs a CI / migration / infra /",
                  "secret file, and the lane is void: say so to the orchestrator and switch to the",
                  "full procedure. Do not stretch the lane to fit."]
    if lane == "risky":
        lines += ["", "## Lane: RISKY", "",
                  (upgrade or "The orchestrator asked for this lane.")
                  + " A wrong approach here costs data, not tokens.",
                  "",
                  "Full lenses and 3 rounds, as usual — plus one gate BEFORE the first edit:",
                  "spawn the DoD teammates, write your DoD file, then write a short plan (what you",
                  "will change, in which files, and what you deliberately will NOT touch) and run",
                  "",
                  "    python3 \"$AGENT_DISCIPLINE_ROOT/scripts/delegate.py\" plan-ready --worktree . \\",
                  "        --plan \"<the plan, one paragraph>\"",
                  "",
                  "then message the orchestrator and WAIT. Write no code until it approves the",
                  "plan. A rejected plan is cheap; a rejected migration is not.",
                  "",
                  "Include `security-reviewer` (or the domain lens matching what makes this risky)",
                  "among your domain lenses — the paths that earned this lane are the ones to aim",
                  "the lens at."]
    if lane == "mechanical":
        lines += ["", "## Lane: MECHANICAL", "",
                  "This is one repeated change across many files: " + ", ".join(a.touches) + ".",
                  "Spawn ONLY `dod-intent` and `dod-tests`, 1 round. Review the SHAPE once, not",
                  "each file — that is what the lane buys.",
                  "",
                  "Before you report, check your own diff is actually uniform:",
                  "`git diff <base>...HEAD` must be the same edit repeated. The moment one file",
                  "needs a hand-written exception, the lane is void — say so to the orchestrator",
                  "and switch to the full procedure. The exception is where the bug will be."]
    if lane == "spike":
        lines += ["", "## Lane: SPIKE", "",
                  f"The question: {a.why}",
                  "",
                  "This code is not going to be merged, so it is not going to be reviewed: spawn",
                  "NO DoD lenses and open NO MR. Build the smallest thing that answers the",
                  "question, then report the ANSWER — what you found, what you ran, and what you",
                  "would do next if we took it seriously.",
                  "",
                  "Leave the branch unpushed for reference. If the answer is 'yes, do it', the",
                  "real work is a new task on a real lane — never grow this one into it."]
    if lane == "revert":
        lines += ["", "## Lane: REVERT", "",
                  f"Undo `{a.revert_of}`. That commit's replacement was already reviewed once —",
                  "going back to it is why this lane buys no lenses.",
                  "",
                  "    git revert --no-edit " + a.revert_of,
                  "",
                  "The ONE check: your diff is the exact inverse of that commit and nothing else.",
                  "",
                  "    git diff <base>...HEAD          # compare against: git show " + a.revert_of,
                  "",
                  "Anything extra — a fix you noticed, a test you improved — voids the lane. Say",
                  "so and dispatch it separately. A revert that also changes something is not a",
                  "revert, and it is the change nobody reviewed."]
    if lane == "repay":
        lines += ["", "## Lane: REPAY", "",
                  f"Debt bead: `{a.key}`"
                  + (f" — it covers the merged branch `{repay_branch}`." if repay_branch else "."),
                  "",
                  (("Run exactly the lenses the fire skipped: " + ", ".join(repay_lenses) + ".")
                   if repay_lenses else
                   f"!! Could not read the bead ({repay_err}) — read it yourself and say so."),
                  "",
                  "Review the ALREADY MERGED diff, not new work. Each finding is either fixed here",
                  "(small, obvious) or filed as its own bead (anything bigger) — say which for",
                  "each. When every skipped lens has an answer, close the debt bead and say so in",
                  "the MR; a repayment that leaves the bead open has repaid nothing."]
    lines += ["", "## Procedure", "",
              "You are the worker. Follow your role prompt: spawn the DoD teammates first (4 core",
              f"lenses + the domain lenses the task shape calls for), write `{dod_rel}`, implement,",
              "have them verify, report here only when every lens passes."]
    if lane != "full":
        lines += ["", f"The Lane: {lane.upper()} block above overrides the procedure where they "
                      "disagree:", f"  {spec['cost']}."]
    os.makedirs(os.path.join(wt, ".claude"), exist_ok=True)
    task_md = os.path.join(wt, ".claude", "TASK.md")
    open(task_md, "w").write("\n".join(lines) + "\n")

    for note in ignored:
        print(f"ignored  : delegation bookkeeping in {note}")
    print(f"worktree : {wt}   [created with {backend}]")
    print(f"task file: {task_md}  ({len(prefs)} ledger record(s) carried in)")
    print(f"lane     : {lane.upper()} — {spec['cost']}")
    if upgrade:
        print(f"           !! {upgrade} — nobody asked for this lane, the paths did")
    if prior:
        print(f"prior    : this task was abandoned before; the note is quoted in TASK.md ({prior})")
    if lane == "urgent":
        print(f"debt     : {bead} — the skipped lenses, booked as a follow-up" if bead
              else f"debt     : !! NOT BOOKED — {bead_err}")
    if lane == "repay":
        print(f"repaying : {a.key} — " + (", ".join(repay_lenses) if repay_lenses
                                          else f"!! bead unreadable: {repay_err}"))
    if backend != "wt":
        # Only worktrunk's post-start hook starts a worker. Printing the ListAgents line below
        # without saying this would send the orchestrator waiting for a session that is never
        # coming.
        print("!! created with git worktree (wt not installed), so NO worker session was started.")
        print(f"     start one yourself: (cd {wt} && ~/.scripts/agent-worker.sh)")
    # worktrunk's post-start hook opens a window in the CURRENT tmux session; with no $TMUX it
    # tries `tmux new`, which needs a terminal this process does not have — so no worker.
    elif not os.environ.get("TMUX"):
        print("!! no tmux — worktrunk's post-start hook did not start a worker. Start it yourself:")
        print(f"     (cd {wt} && ~/.scripts/agent-worker.sh)")
    if backend == "wt" and os.environ.get("TMUX"):
        print(f"next     : ListAgents — the worker appears as `worker:{a.branch}`. When it does,")
        print(f"           SendMessage it: \"Read .claude/TASK.md and begin.\"  Not listed after a minute → it")
        print(f"           did not start; say so, do not wait on it.")
    else:
        # Telling the orchestrator to wait for a worker that was never started is the
        # contradiction this branch exists to avoid: nothing will ever appear in ListAgents.
        print(f"next     : start the worker with the command above, then ListAgents.")
        print(f"           It appears as `worker:{a.branch}` — and not before you start it.")
    return 0


def mr_state(root, branch):
    try:
        mr = gl_api(f"projects/:id/merge_requests?source_branch={branch}&state=all&per_page=1",
                    cwd=root)[0]
    except (ToolError, IndexError, TypeError):
        return "-", "-"
    return f"!{mr['iid']} {mr['state']}", (mr.get("head_pipeline") or {}).get("status") or "-"


def cmd_status(a):
    root = repo_root(a.repo)
    wts = worktrees(root)
    if not wts:
        print("no worktrees — nothing dispatched. `orchestrate.py plan` to see what is ready.")
        return 0
    for w in wts:
        p, b = w["path"], w.get("branch", "?")
        st = {}
        try:
            st = json.load(open(os.path.join(p, ".claude", "delegate.json")))
        except Exception:
            pass
        has_task = os.path.exists(os.path.join(p, ".claude", "TASK.md"))
        mr, pipe = ("skipped", "-") if a.no_mr else mr_state(root, b)
        status = st.get("status", "no DoD yet" if has_task else "no task file")
        rnd = f"{st.get('round', 0)}/{st.get('max', 3)}" if st else "-"
        dodf = st.get("dod_path", "-")
        nxt = {
            "no task file": "dispatch wrote nothing here — not a worker worktree, or made by hand",
            "no DoD yet": "waiting: worker is spawning its DoD teammates",
            "assigned": "waiting: worker implementing",
            "rejected": "waiting: worker fixing the last issue",
            "plan-ready": "REVIEW THE PLAN: no code exists yet — approve the approach or reject it",
            "reported": "REVIEW: read the DoD named below + the diff, then approve or reject",
            "abandoned": "abandoned — the reason is on the task; reap this worktree",
            "accepted": "worker opens the MR; watcher reaps after merge",
            "escalated": "ASK THE USER: DoD wrong, or approach wrong?",
        }.get(status, status)
        if mr.endswith("merged"):
            nxt = "merged — reap runs from the watcher (or /reap)"
        print(f"{b}\n  path {p}\n  dod {status:<10} round {rnd:<5} mr {mr:<14} pipeline {pipe}"
              f"\n  file {dodf}\n  next {nxt}")
    return 0


def delegate_status(wt):
    try:
        return json.load(open(os.path.join(wt, ".claude", "delegate.json"))).get("status")
    except Exception:
        return None


def cmd_approve(a):
    # A plan-ready worker has written no code. Sending it the MR command there would ask it to
    # push an empty branch — the approval it is waiting for is permission to START.
    if delegate_status(a.worktree) == "plan-ready":
        rc = subprocess.call([sys.executable, DELEGATE, "plan-approve", "--worktree", a.worktree])
        if rc: return rc
        print("\nsend the worker:")
        print("  Plan approved. Implement it. Report again when every lens passes.")
        return 0
    rc = subprocess.call([sys.executable, DELEGATE, "accept", "--worktree", a.worktree])
    if rc: return rc
    print("\nsend the worker:")
    print("  Approved. Write .claude/mr-body.md with the show-me skill — one visual of the "
          "change's shape plus the command that checks it — then: git push -u origin HEAD && "
          "glab mr create --target-branch staging "
          "--description \"$(cat .claude/mr-body.md)\" "
          "--title \"<type>(<scope>): <subject>\" --remove-source-branch --yes. Report the MR URL.")
    return 0


def cmd_abandon(a):
    """Record WHY an attempt died, where the next dispatch of the same task will read it.

    Without this the only record of a dead end is the transcript of the session that hit it,
    and the next worker pays for it again."""
    root = repo_root(a.repo)
    key = a.key
    if not key:
        st = {}
        try:
            st = json.load(open(os.path.join(a.worktree, ".claude", "delegate.json")))
        except Exception:
            pass
        key = st.get("key") or os.path.basename(os.path.abspath(a.worktree))
    d = abandon_dir(root)
    os.makedirs(d, exist_ok=True)
    f = os.path.join(d, f"{re.sub(r'[^A-Za-z0-9._-]+', '-', str(key))}.md")
    rounds = "-"
    try:
        st = json.load(open(os.path.join(a.worktree, ".claude", "delegate.json")))
        rounds = f"{st.get('round', 0)}/{st.get('max', 3)}"
        failing = "; ".join(h["issue"][:120] for h in st.get("history", [])[-3:]) or "-"
    except Exception:
        failing = "-"
    body = (f"# Abandoned attempt at {key}\n\n"
            f"- when: {__import__('datetime').datetime.now().astimezone().isoformat(timespec='seconds')}\n"
            f"- branch: {a.branch or '-'}\n"
            f"- rounds spent: {rounds}\n"
            f"- why it stopped: {a.why}\n"
            f"- issues raised in review: {failing}\n")
    open(f, "w").write(body)
    print(f"recorded : {f}")
    print("           the next dispatch --key "
          f"{key} quotes this in TASK.md, so nobody pays for this dead end twice")
    if shutil.which("bd") and os.path.isdir(os.path.join(root, ".beads")):
        rc, out, err = sh(["bd", "update", key, "--notes", f"abandoned: {a.why}"], cwd=root)
        print(f"bead     : {key} annotated" if rc == 0
              else f"bead     : !! not annotated ({err or out}) — the note above is the only record")
    else:
        print("bead     : no bd here — the note above is the only record")
    return 0


def cmd_reject(a):
    rc = subprocess.call([sys.executable, DELEGATE, "reject", "--worktree", a.worktree, "--issue", a.issue])
    if rc: return rc
    print("\nsend the worker:")
    print(f"  Rejected: {a.issue}  Fix it, re-verify with your DoD teammates, report again.")
    return 0


p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
sub = p.add_subparsers(dest="cmd", required=True)
s = sub.add_parser("plan"); s.add_argument("--repo", default="."); s.set_defaults(fn=cmd_plan)
s = sub.add_parser("dispatch"); s.add_argument("--repo", default="."); s.add_argument("--branch", required=True)
s.add_argument("--task", required=True); s.add_argument("--orchestrator", required=True, help="your session name from ListAgents")
s.add_argument("--key", help="bead or Jira key"); s.add_argument("--base", help="base branch (default: staging if it exists)")
s.add_argument("--lane", choices=sorted(LANES), help="; ".join(f"{k}: {v['cost']}" for k, v in LANES.items()))
s.add_argument("--small", action="store_true", help=f"= --lane small. Needs --touches; refused for >{SMALL_MAX_PATHS} paths or any CI/migration/infra/secret path")
s.add_argument("--touches", nargs="+", default=[], help="the paths this change touches — what the small and mechanical gates read, and what upgrades a full dispatch to the risky lane")
s.add_argument("--urgent", action="store_true", help="= --lane urgent. Needs --why; books the skipped review as a bead")
s.add_argument("--why", help="what is broken in production (--lane urgent), or the question a spike answers")
s.add_argument("--revert-of", dest="revert_of", help="the commit being undone — required with --lane revert")
s.set_defaults(fn=cmd_dispatch)
s = sub.add_parser("status"); s.add_argument("--repo", default="."); s.add_argument("--no-mr", action="store_true"); s.set_defaults(fn=cmd_status)
s = sub.add_parser("approve"); s.add_argument("--worktree", required=True); s.set_defaults(fn=cmd_approve)
s = sub.add_parser("abandon"); s.add_argument("--repo", default="."); s.add_argument("--worktree", required=True)
s.add_argument("--why", required=True, help="what stopped it — the dead end the next attempt must not repeat")
s.add_argument("--key", help="task key (default: the one dispatch recorded)"); s.add_argument("--branch")
s.set_defaults(fn=cmd_abandon)
s = sub.add_parser("reject"); s.add_argument("--worktree", required=True); s.add_argument("--issue", required=True); s.set_defaults(fn=cmd_reject)
a = p.parse_args(); sys.exit(a.fn(a) or 0)
