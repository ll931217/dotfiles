#!/usr/bin/env python3
"""Orchestrator side of the worker flow: one worktree + one worker Claude per ready task.

  orchestrate.py plan     [--repo P]                       # which tasks can run in parallel now (bd ready)
  orchestrate.py dispatch --branch B --task "..." --orchestrator NAME [--key ID] [--base BR]
                                                           # worktree + .claude/TASK.md, says how to start the worker
  orchestrate.py status   [--repo P] [--no-mr]             # every worker: DoD, round, report, MR — and what to do next
  orchestrate.py approve  --worktree P                     # record it; prints the message to send the worker
  orchestrate.py reject   --worktree P --issue "..."       # record it; prints the message to send the worker

The orchestrator never edits code. It dispatches, reviews against .claude/DOD.md, approves or
rejects. The worker (prompts/worker.md) does everything else and opens the MR after approve.
"""
import argparse, glob, json, os, re, shutil, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from agent_discipline_paths import topics_dir  # noqa: E402

DELEGATE = os.path.join(HERE, "delegate.py")
WT = next((p for p in (shutil.which("wt"), os.path.expanduser("~/.cargo/bin/wt")) if p and os.path.exists(p)), None)


def sh(cmd, cwd=None, timeout=120):
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
    return r.returncode, r.stdout.strip(), r.stderr.strip()


def repo_root(p):
    rc, out, _ = sh(["git", "rev-parse", "--show-toplevel"], cwd=p)
    return out if rc == 0 else sys.exit(f"not a git checkout: {p}")


def worktrees(root):
    rc, out, _ = sh(["git", "worktree", "list", "--porcelain"], cwd=root)
    items, cur = [], {}
    for ln in out.splitlines() + [""]:
        if not ln:
            if cur: items.append(cur); cur = {}
        elif ln.startswith("worktree "): cur["path"] = ln[9:]
        elif ln.startswith("branch "): cur["branch"] = ln[7:].replace("refs/heads/", "")
    return [w for w in items if os.path.realpath(w["path"]) != os.path.realpath(root)]


def matching_prefs(task, limit=5):
    """Ledger records whose cue overlaps the task text; carries the Preference line (AS1)."""
    words = {w for w in re.findall(r"[a-z][a-z0-9-]{3,}", task.lower())}
    hits = []
    for f in sorted(glob.glob(os.path.join(topics_dir(), "pref-*.md"))):
        s = open(f, encoding="utf-8", errors="replace").read()
        cue = " ".join(re.findall(r"^(?:description|triggers):(.*)$", s, re.M)).lower()
        score = sum(2 for w in words if w in cue) + sum(1 for w in words if w in s.lower())
        m = re.search(r"\*\*Preference:\*\*\s*(.+?)(?:\n\n|\n\*\*)", s, re.S)
        if score and m:
            hits.append((score, os.path.basename(f), " ".join(m.group(1).split())))
    hits.sort(reverse=True)
    return hits[:limit]


def cmd_plan(a):
    root = repo_root(a.repo)
    if not shutil.which("bd") or not os.path.isdir(os.path.join(root, ".beads")):
        print("no beads here — nothing to plan from. Dispatch by hand:")
        print('  orchestrate.py dispatch --branch <b> --task "<one sentence>" --orchestrator <your session name>')
        return 0
    rc, out, err = sh(["bd", "ready", "--json"], cwd=root)
    if rc != 0:
        sys.exit(f"bd ready failed: {err or out}")
    items = json.loads(out or "[]")
    if not items:
        print("bd ready: nothing is ready (all open issues are blocked, in progress or deferred)")
        return 0
    print(f"{len(items)} task(s) ready now — no open blockers, so they can run in parallel, one worker each:")
    for it in items:
        print(f"  {it['id']:<14} {it.get('title','')[:90]}")
    print("\nnext: for each, orchestrate.py dispatch --key <id> --branch <b> --task \"<title>\" --orchestrator <you>")
    return 0


def cmd_dispatch(a):
    root = repo_root(a.repo)
    if os.path.realpath(root) != os.path.realpath(repo_root(os.path.join(root, "."))) or "/.worktrees/" in root:
        sys.exit("run dispatch from the MAIN checkout, not from inside a worktree")
    if not WT:
        sys.exit("wt (worktrunk) not found — install it or create the worktree yourself, then re-run with --worktree")
    base = a.base
    if not base:
        rc, _, _ = sh(["git", "rev-parse", "--verify", "-q", "origin/staging"], cwd=root)
        base = "staging" if rc == 0 else None
    cmd = [WT, "switch", "--create", a.branch, "--yes"] + (["--base", base] if base else [])
    rc, out, err = sh(cmd, cwd=root, timeout=300)
    if rc != 0:
        sys.exit(f"wt switch --create failed:\n{err or out}\nfix that, then re-run dispatch")
    wt = next((w["path"] for w in worktrees(root) if w.get("branch") == a.branch), None)
    if not wt:
        sys.exit(f"wt reported success but no worktree has branch {a.branch} — check `git worktree list`")

    prefs = matching_prefs(a.task)
    lines = ["# Task", "", a.task, "",
             f"Key: {a.key or '-'}",
             f"Orchestrator: {a.orchestrator}   (SendMessage to this name; it reviews, you implement)",
             f"Base branch: {base or 'repo default'}   MR target: staging (never main)", "",
             "## Constraints", "",
             "- phases of ≤5 files; run the project's checks and commit after each",
             "- push the branch when green; open the MR only after the orchestrator approves",
             "- anything you notice next to the task: `bd create`, do not fix in-band", "",
             "## Preferences that apply (from the ledger)", ""]
    lines += [f"- {p} — `{f}`" for _, f, p in prefs] or ["- none matched the task text; still read pref-*.md for the dod-prefs lens"]
    lines += ["", "## Procedure", "",
              "You are the worker. Follow your role prompt: spawn the 5 DoD teammates first, write",
              "`.claude/DOD.md`, implement, have them verify, report here only when all five pass."]
    os.makedirs(os.path.join(wt, ".claude"), exist_ok=True)
    task_md = os.path.join(wt, ".claude", "TASK.md")
    open(task_md, "w").write("\n".join(lines) + "\n")

    print(f"worktree : {wt}")
    print(f"task file: {task_md}  ({len(prefs)} ledger record(s) carried in)")
    # worktrunk's post-start hook opens a window in the CURRENT tmux session; with no $TMUX it
    # tries `tmux new`, which needs a terminal this process does not have — so no worker.
    if not os.environ.get("TMUX"):
        print("!! no tmux — worktrunk's post-start hook did not start a worker. Start it yourself:")
        print(f"     (cd {wt} && ~/.scripts/agent-worker.sh)")
    print(f"next     : ListAgents — the worker appears as `worker:{a.branch}`. When it does,")
    print(f"           SendMessage it: \"Read .claude/TASK.md and begin.\"  Not listed after a minute → it")
    print(f"           did not start; say so, do not wait on it.")
    return 0


def mr_state(root, branch):
    rc, out, _ = sh(["glab", "api", f"projects/:id/merge_requests?source_branch={branch}&state=all&per_page=1"],
                    cwd=root, timeout=30)
    try:
        mr = json.loads(out)[0]
    except Exception:
        return "-", "-"
    return f"!{mr['iid']} {mr['state']}", (mr.get("head_pipeline") or {}).get("status") or "-"


def cmd_status(a):
    root = repo_root(a.repo)
    wts = worktrees(root)
    if not wts:
        print("no worktrees — nothing dispatched. `orchestrate.py plan` to see what is ready.")
        return 0
    for w in wts:
        p, b = w["path"], w.get("branch", "?")
        st = {}
        try:
            st = json.load(open(os.path.join(p, ".claude", "delegate.json")))
        except Exception:
            pass
        has_task = os.path.exists(os.path.join(p, ".claude", "TASK.md"))
        mr, pipe = ("skipped", "-") if a.no_mr else mr_state(root, b)
        status = st.get("status", "no DoD yet" if has_task else "no task file")
        rnd = f"{st.get('round', 0)}/{st.get('max', 3)}" if st else "-"
        nxt = {
            "no task file": "dispatch wrote nothing here — not a worker worktree, or made by hand",
            "no DoD yet": "waiting: worker is spawning its DoD teammates",
            "assigned": "waiting: worker implementing",
            "rejected": "waiting: worker fixing the last issue",
            "reported": "REVIEW: read .claude/DOD.md + the diff, then approve or reject",
            "accepted": "worker opens the MR; watcher reaps after merge",
            "escalated": "ASK THE USER: DoD wrong, or approach wrong?",
        }.get(status, status)
        if mr.endswith("merged"):
            nxt = "merged — reap runs from the watcher (or /reap)"
        print(f"{b}\n  path {p}\n  dod {status:<10} round {rnd:<5} mr {mr:<14} pipeline {pipe}\n  next {nxt}")
    return 0


def cmd_approve(a):
    rc = subprocess.call([sys.executable, DELEGATE, "accept", "--worktree", a.worktree])
    if rc: return rc
    print("\nsend the worker:")
    print("  Approved. Open the MR into staging: git push -u origin HEAD && glab mr create "
          "--target-branch staging --fill --remove-source-branch --yes — then report the MR URL.")
    return 0


def cmd_reject(a):
    rc = subprocess.call([sys.executable, DELEGATE, "reject", "--worktree", a.worktree, "--issue", a.issue])
    if rc: return rc
    print("\nsend the worker:")
    print(f"  Rejected: {a.issue}  Fix it, re-verify with your DoD teammates, report again.")
    return 0


p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
sub = p.add_subparsers(dest="cmd", required=True)
s = sub.add_parser("plan"); s.add_argument("--repo", default="."); s.set_defaults(fn=cmd_plan)
s = sub.add_parser("dispatch"); s.add_argument("--repo", default="."); s.add_argument("--branch", required=True)
s.add_argument("--task", required=True); s.add_argument("--orchestrator", required=True, help="your session name from ListAgents")
s.add_argument("--key", help="bead or Jira key"); s.add_argument("--base", help="base branch (default: staging if it exists)")
s.set_defaults(fn=cmd_dispatch)
s = sub.add_parser("status"); s.add_argument("--repo", default="."); s.add_argument("--no-mr", action="store_true"); s.set_defaults(fn=cmd_status)
s = sub.add_parser("approve"); s.add_argument("--worktree", required=True); s.set_defaults(fn=cmd_approve)
s = sub.add_parser("reject"); s.add_argument("--worktree", required=True); s.add_argument("--issue", required=True); s.set_defaults(fn=cmd_reject)
a = p.parse_args(); sys.exit(a.fn(a) or 0)
