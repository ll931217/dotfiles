#!/usr/bin/env python3
"""What the typed ledger makes of your existing records. Reads only — never writes.

  ledger-inspect.py                 # the compatibility report over your real memory dir
  ledger-inspect.py --entries       # one line per entry: authority, autonomy, decision key
  ledger-inspect.py --key <key>     # exact decision-key lookup against the active projection
  ledger-inspect.py --conflicts     # subjects where two records disagree, and who wins

Migration status: there is nothing to migrate. The typed ledger reads the existing markdown as a
compatibility projection, so your files are untouched and memory-kit keeps reading them.
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
from agent_discipline_paths import topics_dir            # noqa: E402
from ledger.compat import report                          # noqa: E402
from ledger.projection import ActiveProjection            # noqa: E402
from ledger.types import decision_key                     # noqa: E402


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--topics", default=None, help="override the ledger directory")
    ap.add_argument("--entries", action="store_true")
    ap.add_argument("--conflicts", action="store_true")
    ap.add_argument("--key")
    a = ap.parse_args()

    src = a.topics or topics_dir()
    r = report(src)
    proj = ActiveProjection(r["entries"])

    if a.key:
        hits = proj.by_decision_key(a.key)
        if not hits:
            print(f"no entry with decision key {a.key!r}")
            print("Keys are exact. List them with --entries.")
            return 1
        for e in proj.rank(hits):
            print(f"{e.id}\n  authority {e.authority}   autonomy {e.autonomy}\n  {e.statement}")
        return 0

    if a.entries:
        for e in proj.rank(proj.active):
            print(f"{e.authority:28} {e.autonomy:20} {decision_key(e.id)}")
        return 0

    if a.conflicts:
        cs = proj.conflicts(proj.active)
        if not cs:
            print("no two active records state different things about the same subject.")
            print("With every record unscoped and none in conflict, precedence has nothing to do")
            print("yet — that changes as soon as entries carry scope.")
            return 0
        for c in cs:
            print(f"{c['subject']}\n  wins  {c['winner'].id} ({c['winner'].authority}), "
                  f"by {c['decided_by']}")
            for l in c["losers"]:
                print(f"  over  {l.id} ({l.authority})")
        return 0

    print(f"ledger: {src}")
    print(f"  readable as typed entries   {r['readable']}")
    print(f"  unscoped                    {r['unscoped']}  "
          f"(no dimension declared = not constrained, NOT global authority)")
    print("\n  authority (from `confidence:`)")
    for k, v in sorted(r["by_authority"].items(), key=lambda x: -x[1]):
        print(f"    {k:30} {v}")
    print("\n  autonomy (from the confidence ladder)")
    for k, v in sorted(r["by_autonomy"].items(), key=lambda x: -x[1]):
        print(f"    {k:30} {v}")
    if r["skipped"]:
        print(f"\n  !! {len(r['skipped'])} file(s) named pref-* that the ledger CANNOT read.")
        print("     They are invisible to retrieval — today's hook skips them silently too.")
        for fn, why in r["skipped"]:
            print(f"     {fn}\n       {why}")
    print(f"\n  would write: nothing. This is a compatibility projection, not a migration —")
    print(f"  your files stay exactly as they are and memory-kit keeps reading them.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
