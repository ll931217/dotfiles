#!/usr/bin/env bash
# The whole suite, both halves, under one coverage number.
#
#   ./scripts/run-tests.sh            run everything, enforce the coverage floor
#   ./scripts/run-tests.sh --no-cov   just run the tests
#
# Half this repo's tests are shell scripts that drive the CLI scripts as `python3 ...`
# subprocesses. Plain `coverage run -m pytest` cannot see into those, so those files report 0%
# while being the best-tested part of the repo. Two things make them count:
#   * tests/coverage-subprocess/sitecustomize.py on PYTHONPATH, so every python3 subprocess
#     starts recording;
#   * a shim dir holding ONLY python3/python, rather than the whole .venv/bin on PATH — putting
#     the venv's bin dir first makes `mutmut` visible to the tool detection in
#     scripts/testing-handbook.py, and its test asserts that tool is absent.
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
COV=1; [ "${1:-}" = --no-cov ] && COV=0

PY=python3
COVBIN=""
if [ -x "$ROOT/.venv/bin/python" ]; then PY="$ROOT/.venv/bin/python"; fi
if [ -x "$ROOT/.venv/bin/coverage" ]; then COVBIN="$ROOT/.venv/bin/coverage"
elif command -v coverage >/dev/null; then COVBIN=coverage
elif "$PY" -c 'import coverage' 2>/dev/null; then COVBIN="$PY -m coverage"
else COV=0; fi

WORK="${TMPDIR:-/tmp}/agent-discipline-tests.$$"
mkdir -p "$WORK/bin"
# a wrapper, NOT a symlink: a symlink from outside the venv loses the venv (python resolves
# pyvenv.cfg from the link's own directory), and with it the coverage module the subprocesses need
printf '#!/bin/sh\nexec "%s" "$@"\n' "$PY" > "$WORK/bin/python3"
cp "$WORK/bin/python3" "$WORK/bin/python"
chmod +x "$WORK/bin/python3" "$WORK/bin/python"
export PATH="$WORK/bin:$PATH"
trap 'rm -rf "$WORK"' EXIT

if [ "$COV" = 1 ]; then
  # absolute and outside the repo: subprocesses run with cwd inside temp git worktrees, and a
  # .coverage.* file landing there trips the dirty-tree assertions in tests/*.sh
  export COVERAGE_FILE="$WORK/data"
  # subprocesses resolve a RELATIVE `source =` against their own cwd, which is a temp worktree —
  # so pyproject's source list matches nothing there and the run records no data at all. This
  # config says the same thing in absolute paths.
  cat > "$WORK/coveragerc" <<RC
[run]
parallel = True
source =
    $ROOT
omit =
    $ROOT/.venv/*
    $ROOT/tests/*
    $ROOT/.worktrees/*
    $ROOT/scripts/test-*
    */__pycache__/*
RC
  export COVERAGE_PROCESS_START="$WORK/coveragerc"
  export PYTHONPATH="$ROOT/tests/coverage-subprocess${PYTHONPATH:+:$PYTHONPATH}"
  $COVBIN erase
  RUN=($COVBIN run --rcfile="$WORK/coveragerc" --parallel-mode -m pytest)
else
  RUN=("$PY" -m pytest)
fi

rc=0
echo "── pytest ──────────────────────────────────────────────"
"${RUN[@]}" || rc=1

echo "── shell tests ─────────────────────────────────────────"
for t in tests/*.sh scripts/test-*.sh; do
  [ -f "$t" ] || continue
  # needs a live tmux server; reported as skipped, never silently passed
  if [ "$(basename "$t")" = test-reap-tmux.sh ] && ! tmux -V >/dev/null 2>&1; then
    printf '  SKIP %s (no tmux)\n' "$t"; continue
  fi
  if bash "$t" >"$WORK/out" 2>&1; then printf '  ok   %s\n' "$t"
  else rc=1; printf '  FAIL %s\n' "$t"; sed 's/^/       /' "$WORK/out" | tail -25; fi
done

[ "$COV" = 1 ] || { echo; echo "coverage: NOT measured (--no-cov, or coverage is not installed)"; exit $rc; }

echo "── coverage ────────────────────────────────────────────"
$COVBIN combine -q
$COVBIN xml -q -o "$ROOT/coverage.xml"
# the combined data survives the run, so `coverage html` / `coverage report -m` work afterwards
cp "$COVERAGE_FILE" "$ROOT/.coverage"
# fail_under lives in pyproject.toml; COVERAGE_FAIL_UNDER overrides it for a one-off check
if ! $COVBIN report ${COVERAGE_FAIL_UNDER:+--fail-under="$COVERAGE_FAIL_UNDER"}; then
  rc=1
  echo
  echo "coverage is BELOW the floor — the pipeline fails here."
  echo "  see which lines: coverage report -m   (or: coverage html && open htmlcov/index.html)"
fi
exit $rc
