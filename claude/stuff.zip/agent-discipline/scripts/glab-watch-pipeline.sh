#!/usr/bin/env bash
# Watch a GitLab pipeline. Notifies on every status change and on each job that
# finishes, then exits when the pipeline reaches a terminal state.
#
# Usage:
#   glab-watch-pipeline.sh              # latest pipeline on current branch
#   glab-watch-pipeline.sh 12345        # pipeline #12345
#   glab-watch-pipeline.sh feat/foo     # latest pipeline on branch feat/foo
#   glab-watch-pipeline.sh --once       # print status once and exit (no loop; any position)
#   INTERVAL=60 glab-watch-pipeline.sh
#   NO_TRACE=1 glab-watch-pipeline.sh   # do not print the failing job's log tail
#
# Exit codes: 0 success (or --once), 1 no pipeline found, 2 failed, 3 canceled.
#
# On failure it prints the failed job names AND the last lines of the first failure's
# log, because "pipeline failed" with a URL you must open is a status, not an answer.
set -euo pipefail

SELF="$(readlink -f "${BASH_SOURCE[0]}")"
# glab when installed, GitLab REST v4 when not (gl_api).
. "$(dirname "$SELF")/agent-tools.sh"

INTERVAL="${INTERVAL:-30}"
TRACE_LINES="${TRACE_LINES:-30}"

# `|| true`: under `set -e -o pipefail` this line was the whole script's exit path when the
# API could not be reached -- gl_api failed, jq got empty input and failed too, and the script
# died HERE, printing nothing at all. The basename fallback below could never run, and the
# real error (no token) was suppressed by the 2>/dev/null.
PROJECT="$(gl_api projects/:id 2>/dev/null | jq -r '.path_with_namespace // empty' 2>/dev/null || true)"
[[ -z "$PROJECT" ]] && PROJECT="$(basename "$(git rev-parse --show-toplevel 2>/dev/null || pwd)")"

notify() {  # title, body
  echo "[$(date +%H:%M:%S)] $1 — $2"
  command -v notify-send >/dev/null 2>&1 && notify-send "$1" "$2" || true
}

resolve_id() {  # arg -> pipeline id
  local arg="${1:-}"
  [[ "$arg" =~ ^[0-9]+$ ]] && { echo "$arg"; return; }
  local branch="${arg:-$(git branch --show-current)}"
  gl_api "projects/:id/pipelines?ref=${branch}&per_page=1" | jq -r '.[0].id // empty'
}

# --once is accepted in ANY position: as a trailing flag it used to be read as the ref,
# so `... feat/x --once` silently looped forever instead of printing once.
once="false"; target=""
for arg in "$@"; do
  case "$arg" in
    --once) once="true" ;;
    -h|--help) sed -n '2,14p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    -*) echo "unknown option: $arg (try --help)" >&2; exit 1 ;;
    *) target="$arg" ;;
  esac
done

id="$(resolve_id "$target")"
[[ -z "$id" ]] && { echo "No pipeline found for that ref. Push first, or pass a pipeline id." >&2; exit 1; }

echo "Watching ${PROJECT} pipeline #${id} (poll ${INTERVAL}s)…"
last=""
declare -A seen   # job id -> last reported status, so each job is announced once per transition

report_jobs() {
  local jobs; jobs="$(gl_api "projects/:id/pipelines/${id}/jobs?per_page=100" 2>/dev/null || echo '[]')"
  while IFS=$'\t' read -r jid jname jstatus jstage; do
    [[ -z "$jid" ]] && continue
    # Only finished jobs are worth a line; running/pending flap and would spam the log.
    case "$jstatus" in created|pending|running|manual|skipped) continue ;; esac
    if [[ "${seen[$jid]:-}" != "$jstatus" ]]; then
      seen[$jid]="$jstatus"
      echo "    ${jstage}/${jname}: ${jstatus}"
    fi
  done < <(jq -r '.[] | [.id, .name, .status, .stage] | @tsv' <<<"$jobs")
}

failed_detail() {
  local jobs; jobs="$(gl_api "projects/:id/pipelines/${id}/jobs?scope=failed&per_page=100" 2>/dev/null || echo '[]')"
  local names; names="$(jq -r '[.[] | .stage + "/" + .name] | join(", ")' <<<"$jobs")"
  [[ -n "$names" && "$names" != "" ]] && echo "failed jobs: $names"
  [[ "${NO_TRACE:-0}" == "1" ]] && return
  local first; first="$(jq -r '.[0].id // empty' <<<"$jobs")"
  [[ -z "$first" ]] && return
  echo "--- last ${TRACE_LINES} lines of job ${first}:"
  # A trace can be absent (expired artifacts, job never started) — say so instead of
  # printing nothing, which reads as "the log was empty".
  gl_api "projects/:id/jobs/${first}/trace" 2>/dev/null | tail -n "$TRACE_LINES" \
    || echo "    (no trace available for job ${first})"
  echo "--- full log: $(gl_hint "projects/:id/jobs/${first}/trace")"
}

# A failed BRIDGE holds its failure in another project's pipeline, and that pipeline's
# jobs are invisible to /jobs on this one — so the block above prints "failed jobs:"
# with nothing after it. Follow the bridge or the answer is a URL to go open.
failed_bridges_detail() {
  local bridges; bridges="$(gl_api "projects/:id/pipelines/${id}/bridges?per_page=100" 2>/dev/null || echo '[]')"
  while IFS=$'\t' read -r bname dpid dproj dweb; do
    [[ -z "$dpid" || "$dpid" == "null" ]] && continue
    echo "--- bridge ${bname} failed downstream: ${dweb}"
    local djobs; djobs="$(gl_api "projects/${dproj}/pipelines/${dpid}/jobs?scope=failed&per_page=100" 2>/dev/null || echo '[]')"
    echo "    failed jobs: $(jq -r '[.[] | .stage + "/" + .name] | join(", ")' <<<"$djobs")"
    [[ "${NO_TRACE:-0}" == "1" ]] && continue
    local dfirst; dfirst="$(jq -r '.[0].id // empty' <<<"$djobs")"
    [[ -z "$dfirst" ]] && continue
    echo "--- last ${TRACE_LINES} lines of downstream job ${dfirst}:"
    gl_api "projects/${dproj}/jobs/${dfirst}/trace" 2>/dev/null | tail -n "$TRACE_LINES" \
      || echo "    (no trace available for job ${dfirst})"
  done < <(jq -r '.[] | select(.status == "failed") | [.name, (.downstream_pipeline.id // ""), (.downstream_pipeline.project_id // ""), (.downstream_pipeline.web_url // "-")] | @tsv' <<<"$bridges")
}

while true; do
  read -r status ref sha web < <(
    gl_api "projects/:id/pipelines/${id}" \
      | jq -r '[.status, .ref, (.sha[0:8]), .web_url] | @tsv'
  )
  if [[ "$status" != "$last" ]]; then
    notify "${PROJECT} #${id} ${status}" "${ref} @${sha}  ${web}"
    last="$status"
  fi
  report_jobs

  case "$status" in
    success)
      notify "${PROJECT} #${id} PASSED ✅" "${ref}  ${web}"
      exit 0 ;;
    failed)
      notify "${PROJECT} #${id} FAILED ❌" "${ref}  ${web}"
      failed_detail
      failed_bridges_detail
      exit 2 ;;
    canceled)
      notify "${PROJECT} #${id} CANCELED ⚠" "${ref}  ${web}"
      exit 3 ;;
  esac
  [[ "$once" == "true" ]] && exit 0
  sleep "$INTERVAL"
done
