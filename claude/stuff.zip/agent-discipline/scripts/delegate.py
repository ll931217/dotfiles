#!/usr/bin/env python3
"""State for an orchestrator (A) delegating a worktree task to a worker session (B).

A holds the context and does the reviewing; B does the work in its own worktree and its own
context window. The parts that must survive A's turns — the definition of done, which round
we are on, what was rejected and why — live on disk here, not in A's head.

  delegate.py start    --worktree P --task "..." --dod "- item" --dod "- item" [--key ID]
  delegate.py round    --worktree P                 # next round, or refuses past the cap
  delegate.py reject   --worktree P --issue "..."   # record an issue (NOT a fix) and advance
  delegate.py report   --worktree P                 # worker: all DoD teammates passed, awaiting review
  delegate.py accept   --worktree P
  delegate.py plan-ready --worktree P --plan "..."   # risky lane: stop before code, wait for approval
  delegate.py status   --worktree P
  delegate.py escalate --worktree P --task-key KEY  # give up, log a blocker, tell the human
"""
import argparse, datetime, json, os, re, subprocess, sys

MAX_ROUNDS = 3
BLOCKER = os.path.join(os.path.dirname(os.path.realpath(__file__)), "blocker-log.py")

LEGACY_DOD = os.path.join(".claude", "DOD.md")

# What the delegation tooling writes into a worktree. None of it is source: it is bookkeeping
# for one task, on one machine.
BOOKKEEPING = (".claude/TASK.md", ".claude/delegate.json", ".claude/dod/", ".claude/DOD.md",
               ".claude/mr-body.md")
IGNORE_MARK = "# agent-discipline: delegation bookkeeping"
IGNORE_BLOCK = "\n".join([
    IGNORE_MARK,
    "# Written into a worktree by the delegation tooling, one file per task.",
    "# TRACKED is wrong: two workers on one repo collide on a committed copy.",
    "# UNTRACKED and un-ignored is worse: every delegated worktree is permanently dirty, and",
    "# that is what silently stopped worktree-reap from ever cleaning one up.",
    *BOOKKEEPING,
])


def git_dirs(repo):
    """(main_checkout, common_git_dir).

    The MAIN checkout, not `repo`: .gitignore is a tracked file with a separate working copy
    per worktree, so appending to the worktree's copy dirties the worktree — the exact state
    that stops worktree-reap. The main checkout is `git worktree list`'s first entry.

    The common dir is shared by every worktree, which is why info/exclude written there applies
    inside all of them with nothing to commit.
    """
    def g(*args):
        r = subprocess.run(["git", *args], cwd=repo, capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 else ""
    common = g("rev-parse", "--path-format=absolute", "--git-common-dir") or ""
    listing = g("worktree", "list", "--porcelain")
    main = ""
    for ln in listing.splitlines():
        if ln.startswith("worktree "):
            main = ln[9:].strip()
            break
    if not main:
        main = g("rev-parse", "--show-toplevel") or os.path.abspath(repo)
    return main, common


def ensure_ignored(repo):
    """Make the bookkeeping invisible to git in `repo`. Returns a list of what changed.

    Writes BOTH, because each covers what the other cannot:
      .gitignore          teammates and CI get it — but it is tracked, so it only reaches a
                          worktree once someone commits it
      .git/info/exclude   lives in the common git dir, so it applies in the main checkout AND
                          in every worktree immediately, with nothing to commit and nothing
                          left dirty
    Idempotent: a marked block that is already present is not written again.
    """
    main, common = git_dirs(repo)
    if not main:
        return []
    done = []
    for path, note in ((os.path.join(main, ".gitignore"),
                        f"{os.path.join(main, '.gitignore')} (commit it so teammates get it)"),
                       (os.path.join(common, "info", "exclude") if common else "", "info/exclude (already in effect)")):
        if not path:
            continue
        try:
            body = open(path).read() if os.path.exists(path) else ""
            if IGNORE_MARK in body:
                continue
            missing = [e for e in BOOKKEEPING
                       if not re.search(rf"^{re.escape(e)}\s*$", body, re.M)]
            if not missing:
                continue          # already ignored by hand — leave the file alone
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "a") as f:
                f.write(("" if body.endswith("\n") or not body else "\n") + "\n" + IGNORE_BLOCK + "\n")
            done.append(note)
        except OSError:
            continue
    return done



def slug(text):
    return re.sub(r"[^A-Za-z0-9._-]+", "-", str(text)).strip("-")[:80] or "task"


def dod_path(wt, key=None):
    """One DoD file per TASK, not one per repo.

    Every worker used to write `.claude/DOD.md`, which is tracked: worker A committed its DoD
    there and worker B's rebase refused to overwrite its own, so B ran against a DoD it could
    not write. Two concurrent worktrees off one repo is the normal case, so the path carries
    the task key (falling back to the branch, which is unique by construction).

    A legacy `.claude/DOD.md` already on disk keeps being used, so a delegation started before
    this change does not lose its file mid-flight.
    """
    legacy = os.path.join(wt, LEGACY_DOD)
    if not key:
        rc = subprocess.run(["git", "branch", "--show-current"], cwd=wt,
                            capture_output=True, text=True)
        key = rc.stdout.strip() or os.path.basename(wt)
    per_task = os.path.join(wt, ".claude", "dod", f"{slug(key)}.md")
    if os.path.exists(legacy) and not os.path.exists(per_task):
        return legacy
    return per_task


def paths(wt, key=None):
    """(worktree, dod, state). The state file is per-worktree and never contended; only the
    DoD was. Once a delegation exists, its dod path comes from the state file, so later
    commands cannot disagree with `start` about where it is."""
    wt = os.path.abspath(os.path.expanduser(wt))
    state = os.path.join(wt, ".claude", "delegate.json")
    d = load(state)
    if d and d.get("dod_path"):
        return wt, os.path.join(wt, d["dod_path"]), state
    return wt, dod_path(wt, key), state

def load(state):
    try:
        return json.load(open(state))
    except Exception:
        return None

def save(state, d):
    os.makedirs(os.path.dirname(state), exist_ok=True)
    json.dump(d, open(state, "w"), indent=2)

def now():
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")

def cmd_start(a):
    wt, dod, state = paths(a.worktree, getattr(a, "key", None))
    if not os.path.isdir(wt):
        sys.exit(f"no such worktree: {wt}")
    for note in ensure_ignored(wt):
        print(f"ignored delegation bookkeeping in {note}")
    if not a.dod:
        sys.exit("--dod is required: a worker cannot self-check against a DoD it cannot read")
    body = ["# Definition of done", "",
            "Written by the orchestrator before any work starts. The worker checks itself",
            "against this before reporting; the orchestrator verifies against this and nothing",
            "else. If it is not on this list it is not required — say so rather than adding it",
            "silently in review.", "", f"## Task", "", a.task, "", "## Done means", ""]
    body += [f"- [ ] {d}" for d in a.dod]
    body += ["", "## Rounds", "", "_(the orchestrator appends each rejection here)_", ""]
    os.makedirs(os.path.dirname(dod), exist_ok=True)
    open(dod, "w").write("\n".join(body) + "\n")
    rel = os.path.relpath(dod, wt)
    save(state, {"task": a.task, "dod": a.dod, "round": 0, "max": MAX_ROUNDS,
                 "history": [], "started": now(), "status": "assigned",
                 "dod_path": rel, "key": getattr(a, "key", None)})
    print(f"DoD written: {dod}")
    print(f"round 0/{MAX_ROUNDS} — send B the task and point it at {rel}")

def cmd_round(a):
    wt, dod, state = paths(a.worktree)
    d = load(state) or sys.exit("no delegation here — run `start` first")
    if d["round"] >= d["max"]:
        print(f"ROUND CAP REACHED ({d['max']}). Do not send another round.")
        print("Escalate: delegate.py escalate --worktree <p> --task-key <KEY>")
        return 1
    d["round"] += 1
    save(state, d)
    print(f"round {d['round']}/{d['max']}")
    return 0

def cmd_reject(a):
    wt, dod, state = paths(a.worktree)
    d = load(state) or sys.exit("no delegation here — run `start` first")
    if any(w in a.issue.lower() for w in ("you should", "change it to", "replace with", "use this instead")):
        print("WARNING: that reads like a solution, not an issue. Say what is wrong and which")
        print("DoD item it fails; let B choose the fix. Sending it anyway.")
    d["history"].append({"round": d["round"], "at": now(), "issue": a.issue})
    d["status"] = "rejected"
    save(state, d)
    with open(dod, "a") as f:
        f.write(f"\n### Round {d['round']} — rejected {now()}\n\n{a.issue}\n")
    print(f"recorded against round {d['round']}; appended to {dod}")

def cmd_report(a):
    wt, dod, state = paths(a.worktree)
    d = load(state) or sys.exit("no delegation here — run `start` first")
    d["status"] = "reported"; d["reported_at"] = now()
    save(state, d)
    print(f"reported after {d['round']} verify round(s) — now message the orchestrator and wait")
    print(f"  DoD: {os.path.relpath(dod, wt)}")

def cmd_accept(a):
    wt, dod, state = paths(a.worktree)
    d = load(state) or sys.exit("no delegation here")
    d["status"] = "accepted"; d["accepted_at"] = now()
    save(state, d)
    print(f"accepted after {d['round']} round(s) of review")

def cmd_plan_ready(a):
    """The risky lane's gate: the worker stops here, BEFORE any code, and waits.

    A rejected plan costs one message; a rejected migration costs a restore."""
    wt, dod, state = paths(a.worktree)
    d = load(state) or sys.exit("no delegation here — run `start` first")
    d["status"] = "plan-ready"; d["plan"] = a.plan; d["plan_at"] = now()
    save(state, d)
    with open(dod, "a") as f:
        f.write(f"\n### Plan submitted {now()}\n\n{a.plan}\n")
    print(f"plan recorded in {os.path.relpath(dod, wt)} — message the orchestrator and WAIT.")
    print("Write no code until it approves the plan.")


def cmd_plan_approve(a):
    wt, dod, state = paths(a.worktree)
    d = load(state) or sys.exit("no delegation here")
    if d.get("status") != "plan-ready":
        sys.exit(f"nothing is waiting on a plan here (status: {d.get('status')})")
    d["status"] = "assigned"; d["plan_approved_at"] = now()
    save(state, d)
    print("plan approved — the worker may implement now")


def cmd_status(a):
    wt, dod, state = paths(a.worktree)
    d = load(state)
    if not d:
        print("no delegation in this worktree")
        return
    print(f"task    : {d['task']}")
    print(f"dod     : {os.path.relpath(dod, wt)}")
    print(f"status  : {d['status']}   round {d['round']}/{d['max']}")
    for h in d["history"]:
        print(f"  round {h['round']}: {h['issue'][:100]}")

def cmd_escalate(a):
    wt, dod, state = paths(a.worktree)
    d = load(state) or sys.exit("no delegation here")
    d["status"] = "escalated"; save(state, d)
    title = d["task"][:60]
    subprocess.run([sys.executable, BLOCKER, "block", "--task", a.task_key, "--title", title,
                    "--class", "decision", "--reason",
                    f"delegation hit the {d['max']}-round cap; last issue: "
                    f"{(d['history'][-1]['issue'][:80] if d['history'] else 'n/a')}"],
                   cwd=wt)
    print(f"\nESCALATED after {d['round']} rounds. Tell the user:")
    print(f"  task    : {d['task']}")
    print(f"  tried   : {len(d['history'])} round(s) of review")
    for h in d["history"]:
        print(f"    round {h['round']}: {h['issue'][:90]}")
    print("  what to decide: whether the DoD is wrong, or the approach is.")

def main(argv=None):
    """Parser built INSIDE main(), not at import time. orchestrate.py imports dod_path() from
    here so the two cannot disagree about where a DoD lives, and a module-level parser turned
    that import into `orchestrate.py: error: invalid choice: 'dispatch'`."""
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("start"); s.add_argument("--worktree", required=True)
    s.add_argument("--task", required=True)
    s.add_argument("--dod", action="append", help="repeatable; one checkable item each")
    s.add_argument("--key", help="bead or Jira key — names the DoD file so concurrent workers "
                                 "on one repo never contend (default: the branch)")
    s.set_defaults(fn=cmd_start)
    for name, fn in (("round", cmd_round), ("report", cmd_report), ("accept", cmd_accept),
                     ("status", cmd_status)):
        q = sub.add_parser(name); q.add_argument("--worktree", required=True)
        q.set_defaults(fn=fn)
    q = sub.add_parser("plan-ready"); q.add_argument("--worktree", required=True)
    q.add_argument("--plan", required=True, help="what you will change, where, and what you will not touch")
    q.set_defaults(fn=cmd_plan_ready)
    q = sub.add_parser("plan-approve"); q.add_argument("--worktree", required=True)
    q.set_defaults(fn=cmd_plan_approve)
    r = sub.add_parser("reject"); r.add_argument("--worktree", required=True)
    r.add_argument("--issue", required=True); r.set_defaults(fn=cmd_reject)
    e = sub.add_parser("escalate"); e.add_argument("--worktree", required=True)
    e.add_argument("--task-key", required=True); e.set_defaults(fn=cmd_escalate)
    a = p.parse_args(argv)
    return a.fn(a) or 0


if __name__ == "__main__":
    sys.exit(main())
