#!/usr/bin/env python3
"""State for an orchestrator (A) delegating a worktree task to a worker session (B).

A holds the context and does the reviewing; B does the work in its own worktree and its own
context window. The parts that must survive A's turns — the definition of done, which round
we are on, what was rejected and why — live on disk here, not in A's head.

  delegate.py start    --worktree P --task "..." --dod "- item" --dod "- item"
  delegate.py round    --worktree P                 # next round, or refuses past the cap
  delegate.py reject   --worktree P --issue "..."   # record an issue (NOT a fix) and advance
  delegate.py report   --worktree P                 # worker: all DoD teammates passed, awaiting review
  delegate.py accept   --worktree P
  delegate.py status   --worktree P
  delegate.py escalate --worktree P --task-key KEY  # give up, log a blocker, tell the human
"""
import argparse, datetime, json, os, subprocess, sys

MAX_ROUNDS = 3
BLOCKER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "blocker-log.py")

def paths(wt):
    wt = os.path.abspath(os.path.expanduser(wt))
    return wt, os.path.join(wt, ".claude", "DOD.md"), os.path.join(wt, ".claude", "delegate.json")

def load(state):
    try:
        return json.load(open(state))
    except Exception:
        return None

def save(state, d):
    os.makedirs(os.path.dirname(state), exist_ok=True)
    json.dump(d, open(state, "w"), indent=2)

def now():
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")

def cmd_start(a):
    wt, dod, state = paths(a.worktree)
    if not os.path.isdir(wt):
        sys.exit(f"no such worktree: {wt}")
    if not a.dod:
        sys.exit("--dod is required: a worker cannot self-check against a DoD it cannot read")
    body = ["# Definition of done", "",
            "Written by the orchestrator before any work starts. The worker checks itself",
            "against this before reporting; the orchestrator verifies against this and nothing",
            "else. If it is not on this list it is not required — say so rather than adding it",
            "silently in review.", "", f"## Task", "", a.task, "", "## Done means", ""]
    body += [f"- [ ] {d}" for d in a.dod]
    body += ["", "## Rounds", "", "_(the orchestrator appends each rejection here)_", ""]
    open(dod, "w").write("\n".join(body) + "\n")
    save(state, {"task": a.task, "dod": a.dod, "round": 0, "max": MAX_ROUNDS,
                 "history": [], "started": now(), "status": "assigned"})
    print(f"DoD written: {dod}")
    print(f"round 0/{MAX_ROUNDS} — send B the task and point it at .claude/DOD.md")

def cmd_round(a):
    wt, dod, state = paths(a.worktree)
    d = load(state) or sys.exit("no delegation here — run `start` first")
    if d["round"] >= d["max"]:
        print(f"ROUND CAP REACHED ({d['max']}). Do not send another round.")
        print("Escalate: delegate.py escalate --worktree <p> --task-key <KEY>")
        return 1
    d["round"] += 1
    save(state, d)
    print(f"round {d['round']}/{d['max']}")
    return 0

def cmd_reject(a):
    wt, dod, state = paths(a.worktree)
    d = load(state) or sys.exit("no delegation here — run `start` first")
    if any(w in a.issue.lower() for w in ("you should", "change it to", "replace with", "use this instead")):
        print("WARNING: that reads like a solution, not an issue. Say what is wrong and which")
        print("DoD item it fails; let B choose the fix. Sending it anyway.")
    d["history"].append({"round": d["round"], "at": now(), "issue": a.issue})
    d["status"] = "rejected"
    save(state, d)
    with open(dod, "a") as f:
        f.write(f"\n### Round {d['round']} — rejected {now()}\n\n{a.issue}\n")
    print(f"recorded against round {d['round']}; appended to {dod}")

def cmd_report(a):
    wt, dod, state = paths(a.worktree)
    d = load(state) or sys.exit("no delegation here — run `start` first")
    d["status"] = "reported"; d["reported_at"] = now()
    save(state, d)
    print(f"reported after {d['round']} verify round(s) — now message the orchestrator and wait")

def cmd_accept(a):
    wt, dod, state = paths(a.worktree)
    d = load(state) or sys.exit("no delegation here")
    d["status"] = "accepted"; d["accepted_at"] = now()
    save(state, d)
    print(f"accepted after {d['round']} round(s) of review")

def cmd_status(a):
    wt, dod, state = paths(a.worktree)
    d = load(state)
    if not d:
        print("no delegation in this worktree")
        return
    print(f"task    : {d['task']}")
    print(f"status  : {d['status']}   round {d['round']}/{d['max']}")
    for h in d["history"]:
        print(f"  round {h['round']}: {h['issue'][:100]}")

def cmd_escalate(a):
    wt, dod, state = paths(a.worktree)
    d = load(state) or sys.exit("no delegation here")
    d["status"] = "escalated"; save(state, d)
    title = d["task"][:60]
    subprocess.run([sys.executable, BLOCKER, "block", "--task", a.task_key, "--title", title,
                    "--class", "decision", "--reason",
                    f"delegation hit the {d['max']}-round cap; last issue: "
                    f"{(d['history'][-1]['issue'][:80] if d['history'] else 'n/a')}"],
                   cwd=wt)
    print(f"\nESCALATED after {d['round']} rounds. Tell the user:")
    print(f"  task    : {d['task']}")
    print(f"  tried   : {len(d['history'])} round(s) of review")
    for h in d["history"]:
        print(f"    round {h['round']}: {h['issue'][:90]}")
    print("  what to decide: whether the DoD is wrong, or the approach is.")

p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
sub = p.add_subparsers(dest="cmd", required=True)
s = sub.add_parser("start"); s.add_argument("--worktree", required=True); s.add_argument("--task", required=True)
s.add_argument("--dod", action="append", help="repeatable; one checkable item each"); s.set_defaults(fn=cmd_start)
for name, fn in (("round", cmd_round), ("report", cmd_report), ("accept", cmd_accept), ("status", cmd_status)):
    q = sub.add_parser(name); q.add_argument("--worktree", required=True); q.set_defaults(fn=fn)
r = sub.add_parser("reject"); r.add_argument("--worktree", required=True); r.add_argument("--issue", required=True); r.set_defaults(fn=cmd_reject)
e = sub.add_parser("escalate"); e.add_argument("--worktree", required=True); e.add_argument("--task-key", required=True); e.set_defaults(fn=cmd_escalate)
a = p.parse_args(); sys.exit(a.fn(a) or 0)
