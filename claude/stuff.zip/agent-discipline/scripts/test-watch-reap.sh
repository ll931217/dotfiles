#!/usr/bin/env bash
# Does watching a MERGED MR actually reap? Two arms, because the bug this covers was silence:
# the reaper path was resolved from the symlink's directory, `-x` was false, and the cleanup
# was skipped with nothing printed. A test that only ran the script direct would have passed.
#
#   arm 1: invoked THROUGH A SYMLINK (how it is really invoked) -> reaper runs
#   arm 2: reaper missing                                       -> says so on stderr, loudly
#
#   ./test-watch-reap.sh
set -uo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
fails=0

# A repo for the watcher to sit in, and a fake glab that says "!7, merged".
repo="$TMP/repo"; mkdir -p "$repo"; git -C "$repo" init -q
git -C "$repo" -c user.email=t@t -c user.name=t commit -q --allow-empty -m init
mkdir -p "$TMP/bin"
cat > "$TMP/bin/glab" <<'STUB'
#!/usr/bin/env bash
case "$*" in
  *"merge_requests?source_branch"*) echo '[{"iid":7,"state":"merged"}]' ;;
  *"merge_requests/7"*) echo '{"state":"merged","head_pipeline":{"status":"success","web_url":"p"},"merge_status":"can_be_merged","web_url":"w"}' ;;
  *"projects/:id"*) echo '{"path_with_namespace":"grp/repo"}' ;;
  *) echo '{}' ;;
esac
STUB
chmod +x "$TMP/bin/glab"

run_arm() {  # dir-holding-the-symlink -> stdout+stderr of the watcher
  ( cd "$repo" && PATH="$TMP/bin:$PATH" timeout 30 bash "$1/glab-watch-mr.sh" 7 2>&1 )
}

check() {  # label, haystack, needle
  if grep -qF -- "$3" <<<"$2"; then echo "  ok   $1"; else
    echo "  FAIL $1 — expected to see: $3"; echo "$2" | sed 's/^/       | /'; fails=$((fails+1)); fi
}

# ── arm 1: through a symlink -> the REAL reaper in the plugin dir runs ─────────
# The stub trick does not work here, and that is the point: readlink -f resolves the link to
# the plugin directory, so the reaper found is the plugin's own. The assertion is therefore
# that a line only the real reaper prints appears in the output.
a1="$TMP/arm1"; mkdir -p "$a1"
ln -s "$HERE/glab-watch-mr.sh" "$a1/glab-watch-mr.sh"
echo "arm 1: invoked through a symlink"
out="$(run_arm "$a1")"
check "reports the merge" "$out" "MERGED"
check "runs the cleanup" "$out" "cleaning up after the merge"
check "the REAPER itself ran (its own verdict line)" "$out" "no worktree has a fully merged MR"
check "does not claim a removal it did not make" "$out" "cleanup done"

# ── arm 2: reaper absent -> must SAY so, not skip in silence ───────────────────
# A COPY, not a symlink: resolution lands in a directory with no reaper beside it.
a2="$TMP/arm2"; mkdir -p "$a2"
cp "$HERE/glab-watch-mr.sh" "$a2/glab-watch-mr.sh"
echo "arm 2: reaper missing"
out="$(run_arm "$a2")"
check "names the missing reaper" "$out" "reaper not found"
check "says the worktree was not cleaned" "$out" "NOT cleaned up"

echo
[[ $fails -eq 0 ]] && { echo "PASS"; exit 0; } || { echo "$fails check(s) FAILED"; exit 1; }
