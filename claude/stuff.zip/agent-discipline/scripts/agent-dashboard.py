#!/usr/bin/env python3
"""One terminal dashboard for the agent's self-improvement loop.

Three questions, three panels:
  1. GRILLING CONTEXT  — is the ledger loaded before the agent interviews you, and does it
                         stop questions you should never have seen?
  2. BLOCKERS          — where does work stall, and which classes recur?
  3. LEDGER -> UNBLOCK — of the blockers that a recorded decision *could* have prevented
                         (class decision/premise), is that share shrinking?

Every panel obeys three canon rules (evidence-first):
  EF10  a green with no path to red is a structural guarantee -> --selftest, and each panel
        names the number that makes it look BAD
  EF5   automated traffic is reported apart from human-facing effect, never summed
  EF7   no count is shown without its denominator or a control band

  agent-dashboard.py [--days 30] [--selftest]
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from agent_discipline_paths import memory_dir, topics_dir, mem_file  # noqa: E402
import argparse, csv, datetime, json, os, subprocess, sys, collections

MEM = memory_dir()
EVENTS, EFFECT, RECALL = f"{MEM}/pref_events.tsv", f"{MEM}/rule_effect_log.tsv", f"{MEM}/recall_log.tsv"
BLOCKERS, TOPICS = f"{MEM}/blocker_log.tsv", f"{MEM}/topics"
# Resolve the hook inside THIS plugin. Pointing at ~/.claude/hooks/ broke the moment
# those copies were retired — and the self-test reported "DETECTOR BROKEN", which
# reads like a matcher bug rather than a missing file.
HOOK = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                    "hooks", "pref-checkpoint.py")
LEDGER_ADDRESSABLE = {"decision", "premise"}   # a recorded decision could have pre-answered these
W = 78

def rule(t=""):
    print(f"\n\033[1m{t}\033[0m" if t else "")
    print("─" * W)

def bar(n, total, width=28):
    if not total:
        return "·" * width
    f = int(round(width * n / total))
    return "█" * f + "·" * (width - f)

def read_tsv_positional(p):
    """rule_effect_log.tsv has NO header row — DictReader would eat row 1 as column names
    and silently report zero. Columns: ts, session, event, rule_key, summary, evidence."""
    if not os.path.exists(p):
        return []
    out = []
    with open(p, newline="") as f:
        for row in csv.reader(f, delimiter="\t"):
            if len(row) >= 5:
                out.append({"ts": row[0], "session": row[1], "event": row[2],
                            "rule_key": row[3], "summary": row[4]})
    return out

def read_tsv(p):
    if not os.path.exists(p):
        return []
    with open(p, newline="") as f:
        return list(csv.DictReader(f, delimiter="\t"))

def in_window(row, cut, key="ts"):
    try:
        return datetime.datetime.fromisoformat(row.get(key, "")) >= cut
    except Exception:
        return False

def selftest():
    """Positive AND negative control. A detector that cannot stay silent is not a detector."""
    import uuid
    def ask(q):
        ev = {"tool_name": "AskUserQuestion", "session_id": "selftest-" + uuid.uuid4().hex[:8],
              "tool_input": {"questions": [{"question": q, "header": "T", "options": [
                  {"label": "a", "description": "x"}, {"label": "b", "description": "y"}]}]}}
        r = subprocess.run([sys.executable, HOOK], input=json.dumps(ev),
                           capture_output=True, text=True)
        return "deny" in r.stdout
    pos = ask("should this be an HTML dashboard or a plain terminal script for the metrics?")
    neg = ask("which cloud region should the new Kafka cluster live in?")
    rule("DETECTOR SELF-TEST")
    print(f"  positive control (ledger covers it)   deny   {'PASS' if pos else 'FAIL'}")
    print(f"  negative control (unrelated)          allow  {'PASS' if not neg else 'FAIL'}")
    ok = pos and not neg
    print(f"\n  verdict: {'detector has teeth' if ok else 'BROKEN — every number below is meaningless'}")
    return ok

def main(days):
    cut = datetime.datetime.now().astimezone() - datetime.timedelta(days=days)
    ev = collections.Counter()
    per_skill = collections.Counter()
    per_record = collections.Counter()
    for r in read_tsv(EVENTS):
        if not in_window(r, cut):
            continue
        ev[r["kind"]] += 1
        if r["kind"] == "preload":
            per_skill[r["detail"]] += 1
        elif r["kind"] in ("deny", "reissued"):
            per_record[r["detail"]] += 1

    corr_rows = [r for r in read_tsv_positional(EFFECT) if r["event"] == "human-correction"]
    corrections = sum(1 for r in corr_rows if in_window(r, cut))
    corr_all = len(corr_rows)
    n_rec = len([f for f in os.listdir(TOPICS) if f.startswith("pref-")]) if os.path.isdir(TOPICS) else 0
    settled, reissued = ev["deny"] - ev["reissued"], ev["reissued"]

    print(f"\n\033[1magent dashboard\033[0m — last {days}d · {n_rec} preference records")

    # ── 1 ────────────────────────────────────────────────────────────────────
    rule("1. GRILLING CONTEXT — does the agent arrive already knowing?")
    if ev["preload"]:
        print(f"  ledger preloaded into {ev['preload']} interviewing-skill run(s):")
        for s, n in per_skill.most_common(5):
            print(f"     {n:3}x  {s}")
    else:
        print("  ledger preloaded into 0 interviewing-skill runs")
        print("     └─ no /grilling or /to-spec run in this window; nothing to conclude")
    print(f"\n  questions intercepted        {ev['deny']:4}")
    if ev["deny"]:
        print(f"    settled from the ledger    {settled:4}  {bar(settled, ev['deny'])}  asks you never saw")
        print(f"    re-issued anyway           {reissued:4}  {bar(reissued, ev['deny'])}  ← records too broad")
    print(f"  your corrections in window   {corrections:4}   ← rises if the ledger decides WRONG"
          f"   ({corr_all} all-time)")
    if per_record:
        print("\n  which record did the work:")
        for rec, n in per_record.most_common(5):
            print(f"     {n:3}x  {rec.replace('pref-','').replace('.md','')}")

    # ── 2 ────────────────────────────────────────────────────────────────────
    rule("2. BLOCKERS — where work actually stalls")
    rows = [r for r in read_tsv(BLOCKERS) if in_window(r, cut)]
    if not rows:
        print("  no blocker events logged in this window")
        print("     └─ NOT a good score: it means nothing was logged, not that nothing stalled")
    else:
        per = collections.defaultdict(lambda: {"n": 0, "open": 0, "wait": 0.0, "items": []})
        for r in rows:
            c = per[r["class"] or "other"]
            if r["event"] == "block":
                c["n"] += 1; c["open"] += 1
                c["items"].append(f'{r["task"]} — {r["title"]}')
            else:
                c["open"] -= 1; c["wait"] += float(r["waited_h"] or 0)
        tot = sum(c["n"] for c in per.values())
        print(f"  {'class':12} {'hits':>4} {'open':>5} {'waited':>9}")
        for cls, c in sorted(per.items(), key=lambda kv: -kv[1]["n"]):
            print(f"  {cls:12} {c['n']:4} {c['open']:5} {c['wait']:8.1f}h  {bar(c['n'], tot, 18)}")
        hot = [(k, v) for k, v in per.items() if v["n"] >= 2]
        if hot:
            print("\n  recurring (2+) — fix the cause, not the ticket:")
            for cls, c in sorted(hot, key=lambda kv: -kv[1]["n"]):
                print(f"     {cls}: {c['n']}x, {c['wait']:.1f}h lost")
                for it in c["items"][:3]:
                    print(f"         {it}")

    # ── 3 ────────────────────────────────────────────────────────────────────
    rule("3. LEDGER → UNBLOCKING — is the preventable share shrinking?")
    blocks = [r for r in rows if r["event"] == "block"]
    if not blocks:
        print("  no blocks logged — this panel needs blocker data before it can say anything")
    else:
        addr = [r for r in blocks if r["class"] in LEDGER_ADDRESSABLE]
        pct = 100 * len(addr) / len(blocks)
        print(f"  ledger-addressable (decision/premise)  {len(addr)}/{len(blocks)}  ({pct:.0f}%)")
        print(f"    {bar(len(addr), len(blocks))}")
        print("\n  A working ledger should push this DOWN over time: fewer tasks parked waiting")
        print("  on a decision, because the decision was already recorded. Access / external /")
        print("  dependency blocks are NOT its job — they should stay flat.")
        half = datetime.datetime.now().astimezone() - datetime.timedelta(days=days // 2)
        recent = [r for r in blocks if in_window(r, half)]
        older = [r for r in blocks if not in_window(r, half)]
        def share(g):
            return (100 * len([r for r in g if r["class"] in LEDGER_ADDRESSABLE]) / len(g)) if g else None
        a, b = share(older), share(recent)
        if a is not None and b is not None:
            arrow = "improving" if b < a else ("worse" if b > a else "flat")
            print(f"\n  first half {a:.0f}%  →  second half {b:.0f}%   ({arrow})")
        else:
            print("\n  trend needs blocks in both halves of the window — not enough data yet")

    rule()
    print("Run --selftest before trusting any of the above.")
    print("Log blockers with the plugin's blocker-log.py (or /blockers) so panels 2 and 3 have input.")
    return 0

p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
p.add_argument("--days", type=int, default=30)
p.add_argument("--selftest", action="store_true")
a = p.parse_args()
if a.selftest:
    sys.exit(0 if selftest() else 1)
sys.exit(main(a.days))
