#!/usr/bin/env python3
"""One terminal dashboard for the agent's self-improvement loop.

Three questions, three panels:
  1. GRILLING CONTEXT  — is the ledger loaded before the agent interviews you, and does it
                         stop questions you should never have seen?
  2. BLOCKERS          — where does work stall, and which classes recur?
  3. LEDGER -> UNBLOCK — of the blockers that a recorded decision *could* have prevented
                         (class decision/premise), is that share shrinking?
  5. URGENT-LANE DEBT  — the reviews an urgent fix skipped are booked as beads. Are they
                         ever paid, or does the lane quietly become a write-off?

Every panel obeys three canon rules (evidence-first):
  EF10  a green with no path to red is a structural guarantee -> --selftest, and each panel
        names the number that makes it look BAD
  EF5   automated traffic is reported apart from human-facing effect, never summed
  EF7   no count is shown without its denominator or a control band

  agent-dashboard.py [--days 30] [--selftest] [--json]
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
from agent_discipline_paths import memory_dir, topics_dir, mem_file  # noqa: E402
import argparse, csv, datetime, json, os, shutil, subprocess, sys, collections

MEM = memory_dir()
EVENTS, EFFECT, RECALL = f"{MEM}/pref_events.tsv", f"{MEM}/rule_effect_log.tsv", f"{MEM}/recall_log.tsv"
BLOCKERS, TOPICS = f"{MEM}/blocker_log.tsv", f"{MEM}/topics"
# Resolve the hook inside THIS plugin. Pointing at ~/.claude/hooks/ broke the moment
# those copies were retired — and the self-test reported "DETECTOR BROKEN", which
# reads like a matcher bug rather than a missing file.
HOOK = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))),
                    "hooks", "pref-checkpoint.py")
LEDGER_ADDRESSABLE = {"decision", "premise"}   # a recorded decision could have pre-answered these
W = 78

# Bold only on a terminal: /ledger pipes this into a chat message, where a raw escape shows as
# literal "ESC[1m" in the panel heading.
ANSI = sys.stdout.isatty() and not os.environ.get("NO_COLOR")

def bold(t):
    return f"\033[1m{t}\033[0m" if ANSI else t

def rule(t=""):
    print(f"\n{bold(t)}" if t else "")
    print("─" * W)

def bar(n, total, width=28):
    if not total:
        return "·" * width
    f = int(round(width * n / total))
    return "█" * f + "·" * (width - f)

def read_tsv_positional(p):
    """rule_effect_log.tsv has NO header row — DictReader would eat row 1 as column names
    and silently report zero. Columns: ts, session, event, rule_key, summary, evidence."""
    if not os.path.exists(p):
        return []
    out = []
    with open(p, newline="") as f:
        for row in csv.reader(f, delimiter="\t"):
            if len(row) >= 5:
                out.append({"ts": row[0], "session": row[1], "event": row[2],
                            "rule_key": row[3], "summary": row[4]})
    return out

def read_tsv(p):
    if not os.path.exists(p):
        return []
    with open(p, newline="") as f:
        return list(csv.DictReader(f, delimiter="\t"))

def in_window(row, cut, key="ts"):
    try:
        return datetime.datetime.fromisoformat(row.get(key, "")) >= cut
    except Exception:
        return False

def selftest():
    """Positive AND negative control. A detector that cannot stay silent is not a detector."""
    import uuid
    def ask(q):
        ev = {"tool_name": "AskUserQuestion", "session_id": "selftest-" + uuid.uuid4().hex[:8],
              "tool_input": {"questions": [{"question": q, "header": "T", "options": [
                  {"label": "a", "description": "x"}, {"label": "b", "description": "y"}]}]}}
        r = subprocess.run([sys.executable, HOOK], input=json.dumps(ev),
                           capture_output=True, text=True)
        # The hook informs by default and denies only under LCG_ASK_DENY=1. What the control
        # asserts is that the ledger FIRED, whichever shape that takes — pinning "deny" here made
        # the self-test fail the moment the default changed, reporting a broken detector when the
        # detector was fine.
        return "pref-checkpoint" in r.stdout
    pos = ask("should this be an HTML dashboard or a plain terminal script for the metrics?")
    neg = ask("which cloud region should the new Kafka cluster live in?")
    rule("DETECTOR SELF-TEST")
    print(f"  positive control (ledger covers it)   fires   {'PASS' if pos else 'FAIL'}")
    print(f"  negative control (unrelated)          silent  {'PASS' if not neg else 'FAIL'}")
    ok = pos and not neg
    print(f"\n  verdict: {'detector has teeth' if ok else 'BROKEN — every number below is meaningless'}")
    return ok

def collect(days):
    """Every number the dashboard reports, in one dict. --json prints this verbatim, so a
    number shown on screen and a number scraped by a script can never disagree."""
    cut = datetime.datetime.now().astimezone() - datetime.timedelta(days=days)
    ev = collections.Counter()
    per_skill = collections.Counter()
    per_record = collections.Counter()
    for r in read_tsv(EVENTS):
        if not in_window(r, cut):
            continue
        # --selftest drives the real hook, which writes real rows. Counting them would let the
        # dashboard raise its own coverage by being run (canon EF5: automated traffic is never
        # summed into the human-facing effect).
        if str(r.get("session", "")).startswith("selftest-"):
            continue
        ev[r["kind"]] += 1
        if r["kind"] == "preload":
            per_skill[r["detail"]] += 1
        elif r["kind"] in ("deny", "inform", "reissued"):
            per_record[r["detail"]] += 1

    corr_rows = [r for r in read_tsv_positional(EFFECT) if r["event"] == "human-correction"]
    corrections = sum(1 for r in corr_rows if in_window(r, cut))
    corr_all = len(corr_rows)
    n_rec = len([f for f in os.listdir(TOPICS) if f.startswith("pref-")]) if os.path.isdir(TOPICS) else 0
    # `inform` and `deny` are NOT summed into one "intercepted" number. In inform mode the
    # question still reached the user, so counting it as prevented would report asks that never
    # stopped happening (canon EF5: automated injection and a forced decision are different).
    fired = ev["deny"] + ev["inform"]
    settled, reissued = ev["deny"] - ev["reissued"], ev["reissued"]
    # The denominator (EF7). `uncovered` is one row per AskUserQuestion the ledger had NOTHING
    # to say about, so "spoke to 8" finally divides by something. Rows before the hook started
    # logging it are absent, not zero -- asks_seen says how many the hook actually saw.
    asks_seen = fired + ev["uncovered"]

    blk = blockers(days)
    docs = docs_drift()
    debt = urgent_debt()
    M = {"days": days, "records": n_rec,
         "asks": {"seen": asks_seen, "ledger_spoke_to": fired, "uncovered": ev["uncovered"],
                  "informed": ev["inform"], "settled": settled, "reissued": reissued,
                  "coverage_pct": round(100 * fired / asks_seen, 1) if asks_seen else None},
         "preloads": ev["preload"], "corrections": {"window": corrections, "all_time": corr_all},
         "blockers": blk["totals"], "docs": docs, "urgent_debt": debt}
    return M, dict(ev=ev, per_skill=per_skill, per_record=per_record, cut=cut, days=days,
                   n_rec=n_rec, fired=fired, settled=settled, reissued=reissued,
                   asks_seen=asks_seen, corrections=corrections, corr_all=corr_all,
                   blk=blk, docs=docs, urgent_debt=debt, M=M)


def blockers(days):
    """Blocker rows in window, grouped by class. Separated out so --json can report the same
    grouping the panel prints."""
    cut = datetime.datetime.now().astimezone() - datetime.timedelta(days=days)
    rows = [r for r in read_tsv(BLOCKERS) if in_window(r, cut)]
    per = collections.defaultdict(lambda: {"n": 0, "open": 0, "wait": 0.0, "items": []})
    for r in rows:
        c = per[r["class"] or "other"]
        if r["event"] == "block":
            c["n"] += 1; c["open"] += 1
            c["items"].append(f'{r["task"]} — {r["title"]}')
        else:
            c["open"] -= 1; c["wait"] += float(r["waited_h"] or 0)
    blocks = [r for r in rows if r["event"] == "block"]
    addr = [r for r in blocks if r["class"] in LEDGER_ADDRESSABLE]
    return {"rows": rows, "per": per, "blocks": blocks,
            "totals": {"events": len(rows), "blocks": len(blocks),
                       "needs_user": len(addr),
                       "needs_user_pct": round(100 * len(addr) / len(blocks), 1) if blocks else None,
                       "hours_waited": round(sum(c["wait"] for c in per.values()), 1),
                       "by_class": {k: v["n"] for k, v in per.items()}}}


def docs_drift():
    """How many code-bound docs are stale right now. Empty dict when the docs index does not
    exist -- reported as unavailable, never as zero drift."""
    script = os.path.join(os.path.dirname(os.path.realpath(__file__)), "docs-drift.py")
    if not os.path.exists(script):
        return {"available": False}
    try:
        # -C os.getcwd(): the drift report is about the repo you are WORKING in, not about the
        # plugin checkout the script happens to live in.
        r = subprocess.run([sys.executable, script, "--json", "-C", os.getcwd()],
                           capture_output=True, text=True, timeout=30)
        d = json.loads(r.stdout)
        return {"available": True, "bound": d.get("bound"), "stale": d.get("stale"),
                "unbound_code": d.get("unbound_code")}
    except Exception as e:
        return {"available": False, "error": str(e)[:80]}


DEBT_LABEL = "urgent-lane-debt"


def urgent_debt(repo="."):
    """Open/closed `urgent-lane-debt` beads and the age of the oldest unpaid one.

    Reads beads directly — the lane already books the debt there, so a second store would only
    be one more thing to drift. No bd, or no .beads in this repo -> unavailable, never zero:
    "0 open debt" and "we cannot see the debt" are opposite facts.
    """
    if not (shutil.which("bd") and os.path.isdir(os.path.join(repo, ".beads"))):
        return {"available": False, "why": "no bd, or this repo has no .beads"}
    out = {}
    for st in ("open", "closed"):
        r = subprocess.run(["bd", "list", "--label", DEBT_LABEL, "--status", st, "--json"],
                           cwd=repo, capture_output=True, text=True, timeout=30)
        if r.returncode != 0:
            return {"available": False, "why": f"bd list failed: {(r.stderr or r.stdout)[:60]}"}
        try:
            out[st] = json.loads(r.stdout or "[]")
        except json.JSONDecodeError:
            return {"available": False, "why": "bd list did not return JSON"}
    now = datetime.datetime.now().astimezone()
    ages = []
    for b in out["open"]:
        try:
            ages.append(((now - datetime.datetime.fromisoformat(
                b["created_at"].replace("Z", "+00:00"))).total_seconds() / 86400, b))
        except (KeyError, ValueError, TypeError):
            continue
    ages.sort(reverse=True)
    return {"available": True, "open": len(out["open"]), "closed": len(out["closed"]),
            "oldest_days": round(ages[0][0], 1) if ages else None,
            "oldest": [(round(d, 1), b.get("id"), (b.get("title") or "")[:60]) for d, b in ages[:3]]}


def main(days, as_json=False):
    M, C = collect(days)
    if as_json:
        print(json.dumps(M, indent=2, default=str))
        return 0
    ev, per_skill, per_record = C["ev"], C["per_skill"], C["per_record"]
    n_rec, fired, settled, reissued = C["n_rec"], C["fired"], C["settled"], C["reissued"]
    asks_seen, corrections, corr_all = C["asks_seen"], C["corrections"], C["corr_all"]

    head = bold("agent dashboard")
    print(f"\n{head} — last {days}d · {n_rec} preference records")

    # ── 1 ────────────────────────────────────────────────────────────────────
    rule("1. GRILLING CONTEXT — does the agent arrive already knowing?")
    if ev["preload"]:
        print(f"  ledger preloaded into {ev['preload']} interviewing-skill run(s):")
        for s, n in per_skill.most_common(5):
            print(f"     {n:3}x  {s}")
    else:
        print("  ledger preloaded into 0 interviewing-skill runs")
        print("     └─ no /grilling or /to-spec run in this window; nothing to conclude")
    print(f"\n  questions the ledger spoke to {fired:4}  of {asks_seen} the hook saw"
          + (f"   ({100 * fired / asks_seen:.0f}% coverage)" if asks_seen else ""))
    if ev["uncovered"]:
        print(f"    no record matched          {ev['uncovered']:4}  {bar(ev['uncovered'], asks_seen)}"
              f"  ← each one is a ledger record you have not written")
    elif fired:
        print("    └─ 0 uncovered questions. Read this as 'no unmatched ask was LOGGED', not as")
        print("       perfect coverage: rows predate the uncovered counter until this window is")
        print("       fully inside it.")
    if not asks_seen:
        print("    └─ the hook logged no questions at all in this window. That is NOT full")
        print("       coverage — it means nothing asked, or the hook is not registered.")
    if ev["inform"]:
        print(f"    informed, not blocked      {ev['inform']:4}  {bar(ev['inform'], fired)}  you were still asked")
    if ev["deny"]:
        print(f"    settled from the ledger    {settled:4}  {bar(settled, ev['deny'])}  asks you never saw")
        print(f"    re-issued anyway           {reissued:4}  {bar(reissued, ev['deny'])}  ← records too broad")
    if ev["inform"] and not ev["deny"]:
        print("    └─ inform mode (LCG_ASK_DENY=0): the ledger cannot prevent an ask, so there is")
        print("       no 'asks you never saw' number to report. This measures COVERAGE — how often")
        print("       the ledger had something to say — not prevention.")
    print(f"  your corrections in window   {corrections:4}   ← rises if the ledger decides WRONG"
          f"   ({corr_all} all-time)")
    if per_record:
        print("\n  which record did the work:")
        for rec, n in per_record.most_common(5):
            print(f"     {n:3}x  {rec.replace('pref-','').replace('.md','')}")

    # ── 2 ────────────────────────────────────────────────────────────────────
    rule("2. BLOCKERS — where work actually stalls")
    rows, per = C["blk"]["rows"], C["blk"]["per"]
    if not rows:
        print("  no blocker events logged in this window")
        print("     └─ NOT a good score: it means nothing was logged, not that nothing stalled")
    else:
        tot = sum(c["n"] for c in per.values())
        print(f"  {'class':12} {'hits':>4} {'open':>5} {'waited':>9}")
        for cls, c in sorted(per.items(), key=lambda kv: -kv[1]["n"]):
            print(f"  {cls:12} {c['n']:4} {c['open']:5} {c['wait']:8.1f}h  {bar(c['n'], tot, 18)}")
        hot = [(k, v) for k, v in per.items() if v["n"] >= 2]
        if hot:
            print("\n  recurring (2+) — fix the cause, not the ticket:")
            for cls, c in sorted(hot, key=lambda kv: -kv[1]["n"]):
                print(f"     {cls}: {c['n']}x, {c['wait']:.1f}h lost")
                for it in c["items"][:3]:
                    print(f"         {it}")

    # ── 3 ────────────────────────────────────────────────────────────────────
    rule("3. LEDGER → UNBLOCKING — is the preventable share shrinking?")
    blocks = C["blk"]["blocks"]
    if not blocks:
        print("  no blocks logged — this panel needs blocker data before it can say anything")
    else:
        addr = [r for r in blocks if r["class"] in LEDGER_ADDRESSABLE]
        pct = 100 * len(addr) / len(blocks)
        print(f"  ledger-addressable (decision/premise)  {len(addr)}/{len(blocks)}  ({pct:.0f}%)")
        print(f"    {bar(len(addr), len(blocks))}")
        print("\n  A working ledger should push this DOWN over time: fewer tasks parked waiting")
        print("  on a decision, because the decision was already recorded. Access / external /")
        print("  dependency blocks are NOT its job — they should stay flat.")
        half = datetime.datetime.now().astimezone() - datetime.timedelta(days=days // 2)
        recent = [r for r in blocks if in_window(r, half)]
        older = [r for r in blocks if not in_window(r, half)]
        def share(g):
            return (100 * len([r for r in g if r["class"] in LEDGER_ADDRESSABLE]) / len(g)) if g else None
        a, b = share(older), share(recent)
        if a is not None and b is not None:
            arrow = "improving" if b < a else ("worse" if b > a else "flat")
            print(f"\n  first half {a:.0f}%  →  second half {b:.0f}%   ({arrow})")
        else:
            print("\n  trend needs blocks in both halves of the window — not enough data yet")

    # ── 4 ────────────────────────────────────────────────────────────────────
    rule("4. DOCUMENTATION — is any doc still describing code that moved on?")
    d = C["docs"]
    if not d.get("available"):
        why = d.get("error") or "scripts/docs-drift.py not found"
        print(f"  unavailable ({why})")
        print("     └─ reported as UNAVAILABLE, not as zero drift")
    elif not d.get("bound"):
        print("  no doc declares code_refs in this repo, so nothing is checked")
        print("     └─ NOT a pass: 0 stale out of 0 bindings measures nothing")
    else:
        print(f"  code files bound to a doc   {d['bound']:4}")
        print(f"  stale docs                  {d['stale']:4}"
              + ("   ← code moved on after the doc" if d["stale"] else ""))
        print(f"  unbound code                {d['unbound_code']:4}"
              + ("   ← features with no document" if d["unbound_code"] else ""))
        print("\n  docs-drift.py --changed names the doc your uncommitted work made stale;")
        print("  /docs updates it.")

    # ── 5 ────────────────────────────────────────────────────────────────────
    rule("5. URGENT-LANE DEBT — is the review an urgent fix skipped ever paid back?")
    u = C["urgent_debt"]
    if not u.get("available"):
        print(f"  unavailable ({u.get('why')})")
        print("     └─ reported as UNAVAILABLE, not as zero debt. They are opposite facts:")
        print("        one means nothing is owed, the other means nobody can see what is.")
    elif not (u["open"] or u["closed"]):
        print("  the urgent lane has not been used in this repo — no debt to report")
        print("     └─ a clean panel here means the lane was never taken, NOT that it is safe")
    else:
        paid = u["closed"]; total = u["open"] + paid
        print(f"  urgent fixes shipped        {total:4}   (each skipped intent/discipline/prefs"
              " + domain lenses)")
        print(f"  review paid back            {paid:4}  {bar(paid, total)}")
        print(f"  still owed                  {u['open']:4}"
              + ("   ← unreviewed code in production" if u["open"] else ""))
        if u["oldest_days"] is not None:
            print(f"\n  oldest unpaid debt        {u['oldest_days']:6.1f}d"
                  "   ← THE number that makes this panel look bad")
            for d, bid, title in u["oldest"]:
                print(f"     {d:6.1f}d  {bid}  {title}")
        print("\n  Rising open count or an ageing oldest = the lane became the default and the")
        print("  deferred review became a write-off. `bd list --label urgent-lane-debt` to work them.")

    rule()
    print("Run --selftest before trusting any of the above.")
    print("Log blockers with the plugin's blocker-log.py (or /blockers) so panels 2 and 3 have input.")
    return 0

p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
p.add_argument("--days", type=int, default=30)
p.add_argument("--selftest", action="store_true")
p.add_argument("--json", action="store_true", help="machine-readable metrics, same numbers")
a = p.parse_args()
if a.selftest:
    sys.exit(0 if selftest() else 1)
sys.exit(main(a.days, a.json))
