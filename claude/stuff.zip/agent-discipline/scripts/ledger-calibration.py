#!/usr/bin/env python3
"""Shadow calibration: could this system be trusted to answer anything itself?

Grouped, never a single headline number (P4-21). An abstention is counted separately from a
wrong answer — conflating them makes a system that wisely says nothing look identical to one that
guesses badly, and telling those apart is the entire purpose of shadow mode.

  ledger-calibration.py            # the report
  ledger-calibration.py --stop     # plain-text Stop candidates and their false-positive rate
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
from agent_discipline_paths import mem_file            # noqa: E402
from ledger.prediction import JsonlStore, calibrate     # noqa: E402


def bar(n, total, width=20):
    if not total:
        return ""
    filled = int(round(width * n / total))
    return "█" * filled + "·" * (width - filled)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--stop", action="store_true")
    a = ap.parse_args()

    if a.stop:
        rows = list(JsonlStore(mem_file("lcg_stop_candidates.jsonl")).read_all())
        if not rows:
            print("no Stop observations yet. Enable LCG_STOP_DETECT=1 and work normally.")
            return 1
        hits = [r for r in rows if r.get("candidate")]
        print(f"Stop observations: {len(rows)}   flagged as a question for you: {len(hits)}")
        print("Every stop is logged, not just the hits — a hit rate with no denominator is not a"
              " measurement.\n")
        reasons = {}
        for r in rows:
            if not r.get("candidate"):
                reasons[r["reason"]] = reasons.get(r["reason"], 0) + 1
        for why, n in sorted(reasons.items(), key=lambda x: -x[1]):
            print(f"  not a candidate: {why:36} {n}")
        print("\nRead the excerpts and mark the wrong ones — false positives are the number that"
              " decides whether this is ever safe to act on:")
        for r in hits[-5:]:
            print(f"\n  --- {r['session_id']}\n  {r['excerpt'][-220:]}")
        return 0

    preds = list(JsonlStore(mem_file("lcg_predictions.jsonl")).read_all())
    outs = list(JsonlStore(mem_file("lcg_outcomes.jsonl")).read_all())
    if not preds:
        print("no predictions yet. Enable LCG_SHADOW_ASK=1 and work normally; the ledger will"
              " predict silently while you answer.")
        return 1

    c = calibrate(preds, outs)
    print(f"shadow calibration — {len(preds)} prediction(s), {c['total']} answered\n")
    if not c["total"]:
        print("  predictions exist but none has an outcome yet: no question has been answered")
        print("  since shadow mode was enabled. Nothing can be concluded.")
        return 0
    print(f"  abstained          {c['abstained']:4}  {bar(c['abstained'], c['total'])}"
          f"  said nothing, correctly or not")
    print(f"  predicted          {c['predicted']:4}  {bar(c['predicted'], c['total'])}")
    if c["predicted"]:
        print(f"    agreed with you  {c['agreed']:4}  {bar(c['agreed'], c['predicted'])}"
              f"  precision {c['precision']:.0%}")
    else:
        print("    never ventured an answer, so precision is undefined — not 0%, undefined.")

    for group, buckets in c["groups"].items():
        print(f"\n  by {group}:")
        for name, b in sorted(buckets.items(), key=lambda x: -x[1]["n"]):
            prec = f"{b['agreed'] / b['predicted']:.0%}" if b["predicted"] else "  —"
            print(f"    {name:22} n={b['n']:3}  predicted={b['predicted']:3}  precision {prec}")
    print("\n  A high precision over a handful of low-risk predictions is not evidence of much.")
    print("  The mandatory_human group must show predicted=0 always — it is a correctness check,")
    print("  not a performance one.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
