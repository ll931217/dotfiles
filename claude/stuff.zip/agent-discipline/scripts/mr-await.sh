#!/usr/bin/env bash
# Block until an MR reaches a terminal state, by asking GitLab — not by tailing a watcher's log.
#
#   mr-await.sh 128              # wait for MR !128 in the current repo
#   mr-await.sh 128 --timeout 3600 --interval 30
#   mr-await.sh --once 128       # print the current state and exit
#
# Exit codes: 0 merged · 1 closed · 2 pipeline failed or canceled · 3 merge conflict
#             4 cannot query GitLab · 5 TIMEOUT (state still open)
#
# Why this exists: the wake-up used to be an until-loop over glab-watch-mr.sh's log file. The
# watcher died at 11:16:35, the MR merged at 11:46:52, and the loop waited forever — a dead
# producer's silence is indistinguishable from "still running", so a human had to carry the
# news in. Polling the API has no producer to die, and the timeout means silence always ends
# in a message.
set -uo pipefail

SELF="$(readlink -f "${BASH_SOURCE[0]}")"
. "$(dirname "$SELF")/agent-tools.sh"

TIMEOUT="${MR_AWAIT_TIMEOUT:-7200}"
INTERVAL="${MR_AWAIT_INTERVAL:-60}"
once=false
iid=""
while [ $# -gt 0 ]; do
  case "$1" in
    --once)     once=true; shift ;;
    --timeout)  TIMEOUT="$2"; shift 2 ;;
    --interval) INTERVAL="$2"; shift 2 ;;
    -h|--help)  sed -n '2,16p' "$SELF"; exit 0 ;;
    *)          iid="$1"; shift ;;
  esac
done

if [ -z "$iid" ]; then
  echo "mr-await.sh: which MR? pass its iid, e.g. mr-await.sh 128" >&2
  exit 4
fi

state_of() {  # -> "<state>\t<pipeline>\t<url>\t<merge_status>" or non-zero
  local body row
  body="$(gl_api "projects/:id/merge_requests/${iid}")" || return 1
  # An empty or state-less body is NOT an open MR. Treating it as one printed "!7  · pipeline"
  # and then waited out the whole timeout on a reply that never said anything -- the same
  # silence-reads-as-running bug this script exists to remove.
  [ -n "$body" ] || return 1
  row="$(printf '%s' "$body" \
    | jq -r '[.state, (.head_pipeline.status // "none"), (.web_url // "-"), (.merge_status // "-")] | @tsv' \
    2>/dev/null)" || return 1
  case "$row" in ""|$'\t'*) return 1 ;; esac
  printf '%s' "$row"
}

report() {   # state pipeline url merge_status
  printf '!%s %s · pipeline %s · %s\n' "$iid" "$1" "$2" "$3"
}

verdict() {  # state pipeline merge_status -> exit code, or 9 to keep waiting
  case "$1" in
    merged) return 0 ;;
    closed) return 1 ;;
    locked|opened)
      case "$2" in failed|canceled) return 2 ;; esac
      [ "$3" = "cannot_be_merged" ] && return 3
      return 9 ;;
    *) return 9 ;;
  esac
}

deadline=$(( $(date +%s) + TIMEOUT ))
last=""
while :; do
  if ! row="$(state_of)"; then
    echo "!$iid — cannot query GitLab (see the error above). This is NOT a verdict on the MR." >&2
    exit 4
  fi
  IFS=$'\t' read -r state pipeline url mstatus <<< "$row"
  # Print only on CHANGE, so a two-hour wait does not bury the terminal line in 120 identical
  # ones — but always print the first observation, or a wake-up that ends immediately says
  # nothing at all.
  if [ "$state|$pipeline|$mstatus" != "$last" ]; then
    report "$state" "$pipeline" "$url"
    last="$state|$pipeline|$mstatus"
  fi
  verdict "$state" "$pipeline" "$mstatus"; rc=$?
  if [ "$rc" != 9 ]; then
    case "$rc" in
      0) echo "MERGED — the worktree is reaped by the watcher; say so and stop." ;;
      1) echo "CLOSED without merging." ;;
      2) echo "PIPELINE $pipeline — fix it and push again." ;;
      3) echo "MERGE CONFLICT — rebase onto the target and push again." ;;
    esac
    exit "$rc"
  fi
  $once && exit 0
  if [ "$(date +%s)" -ge "$deadline" ]; then
    echo "TIMEOUT after ${TIMEOUT}s — !$iid is still ${state} (pipeline ${pipeline}). Nothing"
    echo "failed and nothing merged: check it yourself at ${url}, or re-arm with a longer"
    echo "--timeout. This message exists so the wait can never end in silence."
    exit 5
  fi
  sleep "$INTERVAL"
done
