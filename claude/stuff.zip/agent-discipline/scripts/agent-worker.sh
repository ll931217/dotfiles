#!/usr/bin/env bash
# Start the WORKER Claude for a worktree. worktrunk's post-start hook runs this instead of bare
# `claude`, so the worktree session gets the worker model, effort and role prompt while the
# session that created the worktree stays the orchestrator.
#
# Usage:
#   agent-worker.sh                      # in a worktree: start the worker
#   agent-worker.sh --show               # print what would run, start nothing
#   WORKER_MODEL=sonnet WORKER_EFFORT=medium agent-worker.sh
#
# Model / effort come from agent-config.sh: env var > ~/.config/agent-discipline.env > default
# (opus / high). REVIEWER_MODEL is rendered into the role prompt so the worker spawns its DoD
# teammates on the configured model. Anything after the options is passed to claude.
set -euo pipefail

SELF="$(readlink -f "${BASH_SOURCE[0]}")"
ROOT="$(dirname "$(dirname "$SELF")")"
PROMPT_SRC="$ROOT/prompts/worker.md"
source "$ROOT/scripts/agent-config.sh"
MODEL="$WORKER_MODEL"
EFFORT="$WORKER_EFFORT"

[[ -f "$PROMPT_SRC" ]] || { echo "worker role prompt missing: $PROMPT_SRC — reinstall the plugin" >&2; exit 1; }
PROMPT="$(mktemp -t worker-prompt.XXXXXX.md)"
sed "s/{{REVIEWER_MODEL}}/${REVIEWER_MODEL}/g" "$PROMPT_SRC" > "$PROMPT"
branch="$(git branch --show-current 2>/dev/null || echo unknown)"
task=""
[[ -f .claude/TASK.md ]] && task=" task=.claude/TASK.md (present)" || task=" task=none yet (orchestrator will message you)"

echo "worker: branch=${branch} model=${MODEL} effort=${EFFORT} reviewers=${REVIEWER_MODEL} role=${PROMPT_SRC}${task}"
echo "        (change these in ${AGENT_DISCIPLINE_CONFIG}, or WORKER_MODEL= / WORKER_EFFORT= / REVIEWER_MODEL= in the env)"
if [[ "${1:-}" == "--show" ]]; then exit 0; fi

export AGENT_DISCIPLINE_ROOT="$ROOT"
exec claude --model "$MODEL" --effort "$EFFORT" --name "worker:${branch}" \
  --append-system-prompt-file "$PROMPT" "$@"
