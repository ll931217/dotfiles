#!/usr/bin/env bash
# One place for which model runs which role. Sourced by agent-worker.sh and
# agent-orchestrator.sh; skills tell the agent to run `--show` before spawning reviewers.
#
#   agent-config.sh --show    # effective values and where each came from
#   agent-config.sh --init    # write a commented template to the config file if none exists
#
# Precedence: environment variable > ~/.config/agent-discipline.env > built-in default.
# Keys: ORCHESTRATOR_MODEL ORCHESTRATOR_EFFORT WORKER_MODEL WORKER_EFFORT REVIEWER_MODEL
AGENT_DISCIPLINE_CONFIG="${AGENT_DISCIPLINE_CONFIG:-$HOME/.config/agent-discipline.env}"

declare -A _AD_DEFAULT=(
  [ORCHESTRATOR_MODEL]=""        # empty = whatever `claude` defaults to (your settings.json)
  [ORCHESTRATOR_EFFORT]="xhigh"
  [WORKER_MODEL]="opus"
  [WORKER_EFFORT]="high"
  [REVIEWER_MODEL]="sonnet"      # the 5 DoD teammates and the automerge review subagent
)
declare -A _AD_SOURCE=()

_ad_load() {
  local k v
  for k in "${!_AD_DEFAULT[@]}"; do
    if [[ -n "${!k+x}" ]]; then _AD_SOURCE[$k]="env"; fi
  done
  if [[ -f "$AGENT_DISCIPLINE_CONFIG" ]]; then
    while IFS='=' read -r k v; do
      [[ "$k" =~ ^[A-Z_]+$ && -n "${_AD_DEFAULT[$k]+x}" ]] || continue
      v="${v%%#*}"; v="${v//\"/}"; v="${v// /}"
      if [[ -z "${_AD_SOURCE[$k]:-}" ]]; then export "$k=$v"; _AD_SOURCE[$k]="$AGENT_DISCIPLINE_CONFIG"; fi
    done < "$AGENT_DISCIPLINE_CONFIG"
  fi
  for k in "${!_AD_DEFAULT[@]}"; do
    if [[ -z "${_AD_SOURCE[$k]:-}" ]]; then export "$k=${_AD_DEFAULT[$k]}"; _AD_SOURCE[$k]="default"; fi
  done
}

ad_show() {
  local k
  echo "agent-discipline roles  (config: $AGENT_DISCIPLINE_CONFIG$( [[ -f "$AGENT_DISCIPLINE_CONFIG" ]] || echo ' — not present, run agent-config.sh --init'))"
  for k in ORCHESTRATOR_MODEL ORCHESTRATOR_EFFORT WORKER_MODEL WORKER_EFFORT REVIEWER_MODEL; do
    printf '  %-20s %-10s from %s\n' "$k" "${!k:-(claude default)}" "${_AD_SOURCE[$k]}"
  done
  echo "  precedence: env var > config file > default"
}

ad_init() {
  if [[ -f "$AGENT_DISCIPLINE_CONFIG" ]]; then echo "already exists: $AGENT_DISCIPLINE_CONFIG (edit it)"; return 0; fi
  mkdir -p "$(dirname "$AGENT_DISCIPLINE_CONFIG")"
  cat > "$AGENT_DISCIPLINE_CONFIG" <<'T'
# agent-discipline: which model runs which role. KEY=value, one per line.
# An environment variable of the same name overrides a line here.
# Models: an alias (opus, sonnet, haiku) or a full id (claude-fable-5-1). Effort: low|medium|high|xhigh|max.

# The session you talk to. Plans, dispatches, reviews, approves. Empty model = your claude default.
ORCHESTRATOR_MODEL=
ORCHESTRATOR_EFFORT=xhigh

# The Claude worktrunk starts in each worktree. Writes the DoD (via its 5 teammates), implements.
WORKER_MODEL=opus
WORKER_EFFORT=high

# The 5 DoD teammates the worker spawns, and the automerge review subagent.
REVIEWER_MODEL=sonnet
T
  echo "wrote $AGENT_DISCIPLINE_CONFIG — edit it, changes apply to the next worker or orchestrator you start"
}

_ad_load
# only act on arguments when run directly — when sourced, $1 belongs to the launcher
if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
  case "${1:-}" in
    --show) ad_show ;;
    --init) ad_init ;;
    *) echo "usage: agent-config.sh --show | --init   (config: $AGENT_DISCIPLINE_CONFIG)"; exit 1 ;;
  esac
fi
