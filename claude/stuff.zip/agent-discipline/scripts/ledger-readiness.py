#!/usr/bin/env python3
"""Is the ledger anywhere near being allowed to answer for you?

Measures the Phase 7 prerequisites from real data. Nothing here is a checkbox: every line is
computed from the prediction, outcome and Stop stores, and anything unmeasurable counts as unmet.

  ledger-readiness.py                    # the prerequisite table
  ledger-readiness.py --kill             # engage the kill switch
  ledger-readiness.py --unkill           # release it
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
from agent_discipline_paths import mem_file                                  # noqa: E402
from ledger.autonomy import KILL_SWITCH_PATH, kill_switch_engaged, readiness  # noqa: E402
from ledger.prediction import JsonlStore                                      # noqa: E402


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--kill", action="store_true")
    ap.add_argument("--unkill", action="store_true")
    a = ap.parse_args()

    if a.kill:
        os.makedirs(os.path.dirname(KILL_SWITCH_PATH), exist_ok=True)
        open(KILL_SWITCH_PATH, "w").write("engaged\n")
        print(f"kill switch ENGAGED: {KILL_SWITCH_PATH}")
        print("Every autonomous path refuses while this file exists, before any other check.")
        return 0
    if a.unkill:
        try:
            os.unlink(KILL_SWITCH_PATH)
            print("kill switch released")
        except OSError:
            print("kill switch was not engaged")
        return 0

    r = readiness(
        predictions=JsonlStore(mem_file("lcg_predictions.jsonl")).read_all(),
        outcomes=JsonlStore(mem_file("lcg_outcomes.jsonl")).read_all(),
        stop_rows=JsonlStore(mem_file("lcg_stop_candidates.jsonl")).read_all(),
    )
    print(r.render())
    if kill_switch_engaged():
        print(f"\nKILL SWITCH IS ENGAGED ({KILL_SWITCH_PATH}) — everything refuses regardless.")
    if not r.ready:
        print("\nThe way forward is measurement, not configuration:")
        print("  1. LCG_SHADOW_ASK=1 and work normally — predictions accumulate silently.")
        print("  2. python3 scripts/ledger-calibration.py — precision, grouped.")
        print("  3. Review the Stop candidates and mark the wrong ones.")
        print("  4. A security review, by a person, recorded.")
    return 0 if r.ready else 1


if __name__ == "__main__":
    sys.exit(main())
