#!/usr/bin/env bash
# Start the ORCHESTRATOR session for a batch of tasks: the model and effort from
# agent-config.sh (default: your claude default model, effort xhigh — effort cannot be raised
# from inside a running session, which is why this launcher exists).
#
#   agent-orchestrator.sh            # in the repo's main checkout
#   agent-orchestrator.sh --show     # print what would run, start nothing
set -euo pipefail
SELF="$(readlink -f "${BASH_SOURCE[0]}")"
ROOT="$(dirname "$(dirname "$SELF")")"
source "$ROOT/scripts/agent-config.sh"

if git rev-parse --show-toplevel >/dev/null 2>&1 && [[ "$(git rev-parse --show-toplevel)" == *"/.worktrees/"* ]]; then
  echo "you are inside a worktree — the orchestrator runs from the MAIN checkout (workers live here)" >&2
  exit 1
fi
repo="$(basename "$(git rev-parse --show-toplevel 2>/dev/null || pwd)")"
args=(--effort "$ORCHESTRATOR_EFFORT" --name "orch:${repo}")
[[ -n "$ORCHESTRATOR_MODEL" ]] && args=(--model "$ORCHESTRATOR_MODEL" "${args[@]}")

echo "orchestrator: repo=${repo} model=${ORCHESTRATOR_MODEL:-(claude default)} effort=${ORCHESTRATOR_EFFORT} workers=${WORKER_MODEL}/${WORKER_EFFORT} reviewers=${REVIEWER_MODEL}"
echo "              (change these in ${AGENT_DISCIPLINE_CONFIG}; then /orchestrate)"
[[ "${1:-}" == "--show" ]] && exit 0
exec claude "${args[@]}" "$@"
