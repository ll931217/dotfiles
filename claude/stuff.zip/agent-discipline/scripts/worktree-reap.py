#!/usr/bin/env python3
"""Remove worktrees, local branches and MR-watch cron entries left behind by merged MRs.

Refuses to touch anything it cannot prove is finished. A worktree is reapable ONLY when:
  * every MR from its branch is merged (an open or missing MR means keep), AND
  * the working tree is clean, AND
  * it has no commits absent from the merged remote branch.

Dry run by default. Deleting a worktree with unpushed work is unrecoverable, so the checks
fail closed: anything unverifiable is kept and reported, never reaped.

  worktree-reap.py [--repo PATH | --all] [--reap]
"""
import argparse, glob, json, os, re, shutil, subprocess, sys, urllib.parse

SEARCH_ROOTS = ["~/Projects", "~/GitLab", "~/Services"]
PROTECTED = {"main", "master", "dev", "develop", "staging", "production"}

def sh(cmd, cwd=None, timeout=90):
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
    return r.returncode, r.stdout.strip(), r.stderr.strip()

def repos(all_):
    if not all_:
        return [os.getcwd()]
    out = set()
    for root in SEARCH_ROOTS:
        for p in glob.glob(os.path.join(os.path.expanduser(root), "*", ".git")):
            out.add(os.path.dirname(p))
    return sorted(out)

def worktrees(repo):
    rc, out, _ = sh(["git", "worktree", "list", "--porcelain"], cwd=repo)
    if rc != 0:
        return []
    items, cur = [], {}
    for line in out.splitlines():
        if line.startswith("worktree "):
            if cur:
                items.append(cur)
            cur = {"path": line[9:]}
        elif line.startswith("branch "):
            cur["branch"] = line[7:].replace("refs/heads/", "")
    if cur:
        items.append(cur)
    return [w for w in items[1:] if w.get("branch")]      # [0] is the main checkout

def mr_states(repo, branch):
    q = urllib.parse.quote(branch, safe="")
    rc, out, _ = sh(["glab", "api", f"projects/:id/merge_requests?source_branch={q}&state=all"], cwd=repo)
    if rc != 0:
        return None
    try:
        return [(m["iid"], m["state"]) for m in json.loads(out)]
    except Exception:
        return None

def verdict(repo, wt):
    """(reapable, reason). Fails closed — 'unknown' is never reapable."""
    br, path = wt["branch"], wt["path"]
    if br in PROTECTED:
        return False, f"protected branch {br}"
    mrs = mr_states(repo, br)
    if mrs is None:
        return False, "could not query MRs — UNKNOWN, not reaped"
    if not mrs:
        return False, "no MR for this branch — work may be unshared"
    open_ = [f"!{i}" for i, s in mrs if s == "opened"]
    if open_:
        return False, f"MR still open ({', '.join(open_)})"
    if not any(s == "merged" for _, s in mrs):
        return False, f"MR closed without merging ({', '.join(f'!{i}' for i, _ in mrs)}) — human call"
    rc, dirty, _ = sh(["git", "status", "--porcelain"], cwd=path)
    if rc != 0:
        return False, "cannot read worktree status"
    if dirty:
        return False, f"uncommitted changes ({len(dirty.splitlines())} file(s))"
    rc, ahead, _ = sh(["git", "log", "--oneline", f"origin/{br}..HEAD"], cwd=path)
    if rc == 0 and ahead:
        return False, f"{len(ahead.splitlines())} commit(s) not on origin/{br}"
    merged = ", ".join(f"!{i}" for i, s in mrs if s == "merged")
    return True, f"MR {merged} merged, clean, nothing unpushed"

def orphan_tmux_windows():
    """tmux windows whose pane sits in a directory that no longer exists.

    worktrunk's post-start hook opens a window per worktree and starts claude in it. Removing
    the worktree leaves the window behind, pointing at a deleted path, with an idle agent in it.
    Only windows whose cwd is genuinely gone are touched — a live window is never a candidate.
    """
    # Per PANE, not per window: list-windows reports only the active pane's path, so a
    # multi-pane window was judged on one pane. A window is orphaned only when EVERY pane
    # sits in a deleted worktree — one live pane and the user still has something there.
    rc, out, _ = sh(["tmux", "list-panes", "-a", "-F",
                     "#{session_name}\t#{window_index}\t#{window_name}\t#{pane_current_path}"])
    if rc != 0:
        return []
    windows = {}
    for line in out.splitlines():
        parts = line.split("\t")
        if len(parts) != 4:
            continue
        sess, idx, name, path = parts
        path = path.replace(" (deleted)", "")
        w = windows.setdefault(f"{sess}:{idx}", {"name": name, "paths": []})
        w["paths"].append(path)
    orphans = []
    for tgt, w in windows.items():
        ps = w["paths"]
        if ps and all(p and ".worktrees" in p and not os.path.isdir(p) for p in ps):
            orphans.append((tgt, w["name"], ps[0] + (f"  ({len(ps)} panes)" if len(ps) > 1 else "")))
    return orphans


def stale_cron(branches):
    """MR-watch cron entries for branches whose MRs have merged — they poll forever otherwise."""
    rc, out, _ = sh(["crontab", "-l"])
    if rc != 0:
        return []
    hits = []
    for line in out.splitlines():
        if "autopilot-mr-watch" in line and not line.lstrip().startswith("#"):
            for b in branches:
                if b in line:
                    hits.append((b, line))
    return hits

WATCH_LOGS = os.path.expanduser("~/.claude/scheduled")
LOG_AGE_DAYS = 30


def stale_watch_logs():
    """MR-watch leaves one log file per poll. A watcher left running against a merged MR
    produced 4,741 files / 19MB here. Age-based so it can never delete a live run's output."""
    import time
    cutoff = time.time() - LOG_AGE_DAYS * 86400
    if not os.path.isdir(WATCH_LOGS):
        return []
    return [os.path.join(WATCH_LOGS, f) for f in os.listdir(WATCH_LOGS)
            if ".mrwatch." in f and f.endswith(".log")
            and os.path.getmtime(os.path.join(WATCH_LOGS, f)) < cutoff]


def _kill_tmux(orphans):
    for tgt, name, _ in orphans:
        rc, _, err = sh(["tmux", "kill-window", "-t", tgt])
        print(f"  closed tmux window {tgt} ({name})" if rc == 0
              else f"  could not close {tgt}: {err[:70]}")


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--repo"); p.add_argument("--all", action="store_true")
    p.add_argument("--reap", action="store_true", help="actually remove (default: dry run)")
    a = p.parse_args()

    reapable, kept = [], []
    for repo in ([os.path.abspath(a.repo)] if a.repo else repos(a.all)):
        for wt in worktrees(repo):
            ok, why = verdict(repo, wt)
            (reapable if ok else kept).append((repo, wt, why))

    if kept:
        print("KEPT\n")
        for repo, wt, why in kept:
            print(f"  {os.path.basename(repo):10} {wt['branch']:44} {why}")
        print()
    tmux_orphans = orphan_tmux_windows()
    if tmux_orphans:
        print(f"{len(tmux_orphans)} orphaned tmux window(s) — pane cwd no longer exists:")
        for tgt, name, path in tmux_orphans:
            print(f"  {tgt:14} {name:38} {path.replace(os.path.expanduser('~'), '~')}")
        print()

    logs = stale_watch_logs()
    if logs:
        mb = sum(os.path.getsize(f) for f in logs) / 1e6
        print(f"{len(logs)} MR-watch log file(s) older than {LOG_AGE_DAYS}d ({mb:.1f} MB)\n")

    if not reapable:
        print("no worktree has a fully merged MR with clean, pushed state")
        if a.reap:
            _kill_tmux(tmux_orphans)
            for f in logs:
                try:
                    os.remove(f)
                except OSError:
                    pass
            if logs:
                print(f"removed {len(logs)} aged MR-watch log file(s)")
        elif logs or tmux_orphans:
            print("re-run with --reap to remove the aged watcher logs and orphaned tmux windows")
        return 0
    print(f"{'REAPING' if a.reap else 'REAPABLE (dry run — nothing removed)'}\n")
    for repo, wt, why in reapable:
        print(f"  {os.path.basename(repo):10} {wt['branch']:44} {why}")
        print(f"      {wt['path'].replace(os.path.expanduser('~'), '~')}")

    crons = stale_cron([wt["branch"] for _, wt, _ in reapable])
    if crons:
        print("\n  stale MR-watch cron entries (still polling a merged MR):")
        for b, line in crons:
            print(f"      {line[:100]}")

    if not a.reap:
        print("\nRe-run with --reap to remove these worktrees, their local branches, the cron"
              "\nentries and the aged watcher logs.")
        return 0
    for f in logs:
        try:
            os.remove(f)
        except OSError:
            pass
    if logs:
        print(f"  removed {len(logs)} aged MR-watch log file(s)")

    for repo, wt, _ in reapable:
        # Prefer `wt remove`: it runs the user's own pre-remove hooks, which close the tmux
        # window rooted in the worktree and delete the branch when merged. Calling
        # `git worktree remove` skipped all of that and left windows open on deleted paths.
        used_wt = False
        if shutil.which("wt"):
            # -y: no prompt (there is no TTY here). --foreground: removal is BACKGROUND by
            # default, and reporting "removed" from a command that returned early is claiming
            # a target-end fact we have not observed. -D: our checks already proved the MR
            # merged, and a squash merge past wt's walk cap needs it.
            base = ["wt", "remove", "-y", "--foreground", "-D"]
            rc, _, err = sh(base + [wt["branch"]], cwd=repo, timeout=300)
            if rc != 0:
                rc, _, err = sh(base + [wt["path"]], cwd=repo, timeout=300)
            used_wt = rc == 0
        if not used_wt:
            rc, _, err = sh(["git", "worktree", "remove", wt["path"]], cwd=repo)
            if rc != 0:
                print(f"  FAILED worktree {wt['branch']}: {err[:90]}")
                continue
            print("  (used git worktree remove — wt unavailable, so pre-remove hooks did NOT run)")
        print(f"  removed worktree {wt['path'].replace(os.path.expanduser('~'), '~')}"
              + ("  via wt (pre-remove hooks ran)" if used_wt else ""))
        rc, _, err = sh(["git", "branch", "-d", wt["branch"]], cwd=repo)
        if rc == 0:
            print(f"  removed branch   {wt['branch']}")
        elif "not fully merged" in err:
            # Squash merge: the MR merged, but the local commits are not ancestors of the
            # target, so -d refuses. Force is safe HERE and only here — verdict() already
            # proved the MR merged, the tree is clean, and nothing is missing from origin.
            rc2, _, err2 = sh(["git", "branch", "-D", wt["branch"]], cwd=repo)
            print(f"  removed branch   {wt['branch']} (squash-merged, forced after checks)"
                  if rc2 == 0 else f"  branch kept      {wt['branch']}: {err2[:70]}")
        else:
            print(f"  branch kept      {wt['branch']}: {err[:70]}")
    if crons:
        rc, out, _ = sh(["crontab", "-l"])
        drop = {line for _, line in crons}
        stage = os.path.expanduser("~/ct.new")        # short path: crontab truncates long ones
        with open(stage, "w") as f:
            f.write("\n".join(l for l in out.splitlines() if l not in drop) + "\n")
        rc, _, err = sh(["crontab", stage])
        os.remove(stage)
        print(f"  removed {len(drop)} stale cron entr(ies)" if rc == 0 else f"  cron update FAILED: {err[:80]}")
    return 0

if __name__ == "__main__":
    sys.exit(main())
