#!/usr/bin/env python3
"""Blocker event log — where the process leaks, grouped so recurring causes surface.

Preferences say how you like to work; this says where work stalls. Different shape, different
lifetime, so it lives in its own TSV rather than polluting the ledger.

  blocker-log.py block  --task DE-461 --title "retry wrapper on fetchQuote" \
                        --class access --reason "no staging DB credential" [--project atlas]
  blocker-log.py clear  --task DE-461 [--by user] [--note "granted via gopass"]
  blocker-log.py report [--days 90]

Classes: access | decision | dependency | premise | external | flake | other
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from agent_discipline_paths import memory_dir, topics_dir, mem_file  # noqa: E402
import argparse, csv, datetime, os, sys, collections

LOG = mem_file("blocker_log.tsv")
COLS = ["ts", "event", "project", "task", "title", "class", "reason", "by", "note", "waited_h"]
CLASSES = ["access", "decision", "dependency", "premise", "external", "flake", "other"]

def now():
    return datetime.datetime.now().astimezone()

def rows():
    if not os.path.exists(LOG):
        return []
    with open(LOG, newline="") as f:
        return list(csv.DictReader(f, delimiter="\t"))

def append(rec):
    new = not os.path.exists(LOG)
    os.makedirs(os.path.dirname(LOG), exist_ok=True)
    with open(LOG, "a", newline="") as f:
        w = csv.DictWriter(f, COLS, delimiter="\t", extrasaction="ignore")
        if new:
            w.writeheader()
        w.writerow(rec)

def cmd_block(a):
    if a.klass not in CLASSES:
        sys.exit(f"--class must be one of: {', '.join(CLASSES)}")
    if not a.title:
        sys.exit("--title is required: a bare task key makes the report unreadable")
    append({"ts": now().isoformat(timespec="seconds"), "event": "block", "project": a.project,
            "task": a.task, "title": a.title, "class": a.klass, "reason": a.reason})
    print(f"blocked {a.task} ({a.klass}): {a.reason}")

def cmd_clear(a):
    open_block = None
    for r in rows():
        if r["task"] == a.task and r["event"] == "block":
            open_block = r
        elif r["task"] == a.task and r["event"] == "clear":
            open_block = None
    if not open_block:
        sys.exit(f"no open block for {a.task} — nothing to clear")
    t0 = datetime.datetime.fromisoformat(open_block["ts"])
    waited = round((now() - t0).total_seconds() / 3600, 1)
    append({"ts": now().isoformat(timespec="seconds"), "event": "clear", "project": open_block["project"],
            "task": a.task, "title": open_block["title"], "class": open_block["class"],
            "reason": open_block["reason"], "by": a.by, "note": a.note, "waited_h": waited})
    print(f"cleared {a.task} after {waited}h ({open_block['class']}, by {a.by})")

def cmd_report(a):
    cutoff = now() - datetime.timedelta(days=a.days)
    per = collections.defaultdict(lambda: {"n": 0, "wait": 0.0, "open": 0, "items": []})
    for r in rows():
        try:
            if datetime.datetime.fromisoformat(r["ts"]) < cutoff:
                continue
        except Exception:
            continue
        c = per[r["class"] or "other"]
        if r["event"] == "block":
            c["n"] += 1
            c["open"] += 1
            c["items"].append(f'{r["task"]} {r["title"]}')
        else:
            c["open"] -= 1
            c["wait"] += float(r["waited_h"] or 0)
    if not per:
        print(f"no blocker events in the last {a.days}d")
        return
    print(f"blockers, last {a.days}d\n")
    print(f"{'class':12} {'hits':>5} {'still open':>11} {'total wait':>11}")
    for cls, c in sorted(per.items(), key=lambda kv: -kv[1]["n"]):
        print(f"{cls:12} {c['n']:5} {c['open']:11} {c['wait']:10.1f}h")
    print("\nrecurring (2+ hits) — fix the cause, not the ticket:")
    hot = [(cls, c) for cls, c in per.items() if c["n"] >= 2]
    for cls, c in sorted(hot, key=lambda kv: -kv[1]["n"]):
        print(f"  {cls}: {c['n']}x, {c['wait']:.1f}h lost")
        for it in c["items"][:4]:
            print(f"      {it}")
    if not hot:
        print("  (none yet)")

p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
sub = p.add_subparsers(dest="cmd", required=True)
b = sub.add_parser("block"); b.add_argument("--task", required=True); b.add_argument("--title", required=True)
b.add_argument("--class", dest="klass", required=True); b.add_argument("--reason", required=True)
b.add_argument("--project", default=os.path.basename(os.getcwd())); b.set_defaults(fn=cmd_block)
c = sub.add_parser("clear"); c.add_argument("--task", required=True)
c.add_argument("--by", default="user"); c.add_argument("--note", default=""); c.set_defaults(fn=cmd_clear)
r = sub.add_parser("report"); r.add_argument("--days", type=int, default=90); r.set_defaults(fn=cmd_report)
a = p.parse_args(); a.fn(a)
