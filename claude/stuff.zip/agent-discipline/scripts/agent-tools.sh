#!/usr/bin/env bash
# Shell half of the optional-tool adapters (python half: agent_tools.py). Sourced, not run.
#
#   . "$(dirname "$0")/agent-tools.sh"
#   gl_api "projects/:id/merge_requests?state=opened" | jq -r '.[].iid'
#
# gl_api is glab's `glab api <path>` when glab is installed, and a direct GitLab REST v4 call
# when it is not. Same argument, same JSON on stdout, so a call site needs no branch.
# Non-zero exit with a message on stderr naming what to fix — never an empty body that reads
# like "no results".

# shellcheck disable=SC2034
AGENT_TOOLS_SH=1

_at_have() { command -v "$1" >/dev/null 2>&1; }

# group/repo from the origin remote, URL-encoded. glab resolves :id itself; REST must be told.
gl_project() {
  local url path
  url="$(git remote get-url origin 2>/dev/null)" || return 1
  case "$url" in
    *://*) path="${url#*://}"; path="${path#*@}"; path="${path#*/}" ;;
    *@*:*) path="${url#*:}" ;;
    *)     path="$url" ;;
  esac
  path="${path%.git}"; path="${path#/}"
  printf '%s' "${path//\//%2F}"
}

gl_host() {
  local url host
  if [ -n "${GITLAB_HOST:-}" ]; then
    host="${GITLAB_HOST%/}"
    case "$host" in *://*) printf '%s' "$host" ;; *) printf 'https://%s' "$host" ;; esac
    return 0
  fi
  url="$(git remote get-url origin 2>/dev/null)" || return 1
  case "$url" in
    # scheme kept as-is (the internal GitLab is plain http), and any `user:token@` stripped:
    # a CI checkout's origin carries the job token, and echoing it into a host string put a
    # live credential into every log line built from gl_host.
    http://*|https://*)
       host="${url#*://}"; host="${host#*@}"; host="${host%%/*}"
       printf '%s://%s' "${url%%://*}" "$host" ;;
    *) host="${url#*://}"; host="${host#*@}"; host="${host%%/*}"; host="${host%%:*}"
       printf 'https://%s' "$host" ;;
  esac
}

gl_token() {
  local slot="${GITLAB_TOKEN_GOPASS:-vici/gitlab/api_token}"
  for v in "${GITLAB_TOKEN:-}" "${GLAB_TOKEN:-}" "${CI_JOB_TOKEN:-}"; do
    [ -n "$v" ] && { printf '%s' "$v"; return 0; }
  done
  if _at_have gopass; then gopass show -o "$slot" 2>/dev/null && return 0; fi
  return 1
}

gl_api() {
  local path="$1"; shift || true
  if _at_have glab; then
    glab api "$path" "$@"
    return $?
  fi
  local proj host token url
  proj="$(gl_project)" || { echo "gl_api: no origin remote, cannot resolve the project" >&2; return 1; }
  host="$(gl_host)"    || { echo "gl_api: cannot derive the GitLab host; set GITLAB_HOST" >&2; return 1; }
  token="$(gl_token)"  || { echo "gl_api: glab is not installed and no token: set GITLAB_TOKEN, or store one at 'gopass insert ${GITLAB_TOKEN_GOPASS:-vici/gitlab/api_token}'" >&2; return 1; }
  url="$host/api/v4/${path#/}"
  url="${url//projects\/:id/projects/$proj}"
  curl -sS --fail-with-body -H "PRIVATE-TOKEN: $token" "$@" "$url"
}

# Which backend a caller is about to get. For status lines, so a degraded run says so.
gl_backend() { _at_have glab && printf 'glab' || printf 'REST v4'; }

# The command a HUMAN should run to see this themselves. Printing "glab api ..." to someone
# who has no glab is advice that cannot be followed.
gl_hint() {
  local path="$1"
  if _at_have glab; then printf 'glab api %s' "$path"
  else printf 'curl -H "PRIVATE-TOKEN: $GITLAB_TOKEN" %s/api/v4/%s' "$(gl_host)" "${path//projects\/:id/projects/$(gl_project)}"
  fi
}
