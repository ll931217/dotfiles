#!/usr/bin/env python3
"""Merge only the MRs that are boring enough to merge without you — then reap.

The safety here is the ELIGIBILITY GATE, not the review. An agent approving a diff it just
wrote is weak evidence; a deny-list that refuses to touch CI, migrations, dependencies or
secrets is not. Review is an extra gate on top, never a substitute.

Eligible ONLY when all hold:
  * open, not draft, no conflicts, merge status can_be_merged
  * pipeline succeeded (a missing pipeline is NOT a pass)
  * every blocking discussion resolved
  * title starts with docs:/chore:/style:/test:  AND every changed path is docs-like
    (a title is a claim, the paths are the evidence — a chore: that edits source is not simple)
  * nothing in the deny-list is touched
  * diff within --max-files / --max-lines

  mr-automerge.py [--repo P | --all] [--list] [--merge IID] [--yes] [--no-reap]

--list is the default and writes nothing. --merge needs --yes.
"""
import argparse, glob, json, os, re, subprocess, sys
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.realpath(__file__))))
from agent_tools import gl_api, ToolError  # noqa: E402

SEARCH_ROOTS = ["~/Projects", "~/GitLab", "~/Services"]
REAP = os.path.join(os.path.dirname(os.path.realpath(__file__)), "worktree-reap.py")

SAFE_TITLE = re.compile(r"^(docs|chore|style|test)(\([^)]*\))?!?:", re.I)
DOCS_LIKE = re.compile(r"(\.md$|\.mdx$|\.txt$|\.rst$|^docs/|^README|LICENSE|\.gitignore$)", re.I)
# Touch any of these and it is not a simple MR, whatever the title says.
DENY = [
    (re.compile(r"(^|/)\.gitlab-ci\.yml$|(^|/)\.github/|(^|/)Jenkinsfile$"), "CI configuration"),
    (re.compile(r"(^|/)(migrations?|alembic)/"), "database migration"),
    (re.compile(r"(package(-lock)?\.json|pnpm-lock\.yaml|yarn\.lock|poetry\.lock|uv\.lock|requirements.*\.txt|pyproject\.toml|go\.(mod|sum)|Cargo\.(toml|lock))$"), "dependency manifest"),
    (re.compile(r"(^|/)(Dockerfile|docker-compose[^/]*\.ya?ml)$"), "container build"),
    (re.compile(r"(^|/)(terraform|helm|k8s|kustomize)/|\.tf$"), "infrastructure"),
    (re.compile(r"(secret|credential|\.env|\.pem$|\.key$)", re.I), "possible secret"),
]

def sh(cmd, cwd=None, timeout=120):
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
    return r.returncode, r.stdout.strip(), r.stderr.strip()

def api(repo, path):
    try:
        return gl_api(path, cwd=repo)
    except ToolError:
        return None

def repos(all_):
    if not all_:
        return [os.getcwd()]
    out = set()
    for root in SEARCH_ROOTS:
        for p in glob.glob(os.path.join(os.path.expanduser(root), "*", ".git")):
            out.add(os.path.dirname(p))
    return sorted(out)

def assess(repo, mr, max_files, max_lines):
    """(eligible, reasons) — every reason a human would want to see, not just the first."""
    no = []
    if mr.get("draft") or mr.get("work_in_progress"):
        no.append("draft")
    if mr.get("has_conflicts"):
        no.append("has conflicts")
    if not mr.get("blocking_discussions_resolved", False):
        no.append("unresolved discussions")
    dms = mr.get("detailed_merge_status")
    if dms not in ("mergeable", "can_be_merged"):
        no.append(f"merge status {dms}")
    pipe = (mr.get("head_pipeline") or {}).get("status")
    if pipe != "success":
        no.append(f"pipeline {pipe or 'missing'} — absent is not a pass")
    labels = [l.lower() for l in (mr.get("labels") or [])]
    for bad in ("do-not-merge", "wip", "needs-review", "blocked"):
        if bad in labels:
            no.append(f"label {bad}")

    ch = api(repo, f"projects/:id/merge_requests/{mr['iid']}/changes") or {}
    changes = ch.get("changes", [])
    paths = [c.get("new_path") or c.get("old_path") or "" for c in changes]
    for rx, why in DENY:
        hit = [p for p in paths if rx.search(p)]
        if hit:
            no.append(f"touches {why}: {hit[0]}")
    if len(paths) > max_files:
        no.append(f"{len(paths)} files > {max_files}")
    added = sum(len(re.findall(r"^\+(?!\+\+)", c.get("diff", ""), re.M)) for c in changes)
    removed = sum(len(re.findall(r"^-(?!--)", c.get("diff", ""), re.M)) for c in changes)
    if added + removed > max_lines:
        no.append(f"{added + removed} changed lines > {max_lines}")

    if not SAFE_TITLE.match(mr.get("title", "")):
        no.append("title is not docs:/chore:/style:/test:")
    non_docs = [p for p in paths if not DOCS_LIKE.search(p)]
    if not paths or non_docs:
        no.append(f"changes non-docs path: {non_docs[0]}" if non_docs else "no changed paths")
    return (not no), no, paths, added, removed

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--repo"); p.add_argument("--all", action="store_true")
    p.add_argument("--list", action="store_true")
    p.add_argument("--merge", type=int, metavar="IID")
    p.add_argument("--yes", action="store_true", help="required for --merge")
    p.add_argument("--no-reap", action="store_true")
    p.add_argument("--max-files", type=int, default=10)
    p.add_argument("--max-lines", type=int, default=200)
    a = p.parse_args()
    targets = [os.path.abspath(a.repo)] if a.repo else repos(a.all)

    if a.merge is not None:
        repo = targets[0]
        if not a.yes:
            print("--merge requires --yes. This merges into a shared branch and is visible to the team.")
            return 1
        mr = api(repo, f"projects/:id/merge_requests/{a.merge}")
        if not mr:
            print(f"could not read !{a.merge}")
            return 1
        ok, why, *_ = assess(repo, mr, a.max_files, a.max_lines)
        if not ok:
            print(f"!{a.merge} is NOT eligible — refusing:")
            for w in why:
                print(f"  - {w}")
            return 1
        try:
            gl_api(f"projects/:id/merge_requests/{a.merge}/merge", method="PUT",
                   fields={"squash": "true", "should_remove_source_branch": "true"}, cwd=repo)
        except ToolError as e:
            print(f"merge FAILED: {str(e)[:200]}")
            return 1
        print(f"merged !{a.merge}")
        if not a.no_reap:
            sh([sys.executable, REAP, "--repo", repo, "--reap"], cwd=repo, timeout=300)
            print("reaped worktree / branch / cron")
        return 0

    total_ok = 0
    for repo in targets:
        mrs = api(repo, "projects/:id/merge_requests?state=opened&per_page=30")
        if not mrs:
            continue
        for mr in mrs:
            ok, why, paths, add, rem = assess(repo, mr, a.max_files, a.max_lines)
            name = os.path.basename(repo)
            head = f"  {name} !{mr['iid']} {mr['title'][:58]}"
            if ok:
                total_ok += 1
                print(f"\033[32mELIGIBLE\033[0m{head}")
                print(f"      {len(paths)} file(s), +{add}/-{rem}: {', '.join(paths[:4])}")
                print(f"      merge with: mr-automerge.py --repo {repo} --merge {mr['iid']} --yes")
            else:
                print(f"HOLD    {head}")
                for w in why:
                    print(f"      - {w}")
    print(f"\n{total_ok} eligible. Nothing was merged — --merge <iid> --yes does that, one at a time.")
    print("Eligibility is the safety, not the review. Widen the gate deliberately, never by accident.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
