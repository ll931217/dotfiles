#!/usr/bin/env bash
# agent-discipline doctor. Read-only: reports what is broken and how to fix it, writes nothing.
#
#   ./scripts/doctor.sh          full report
#   ./scripts/doctor.sh --quiet  only problems (what install.sh uses)
#
# Exit 0 = healthy, 1 = at least one FAIL. Warnings alone do not fail.
set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CLAUDE="$HOME/.claude"
SETTINGS="$CLAUDE/settings.json"
RULES_DIR="$CLAUDE/rules"
NAME="agent-discipline"
SCRIPT_LINKS=(agent-worker.sh agent-orchestrator.sh agent-config.sh
              glab-watch-mr.sh glab-watch-pipeline.sh blocker-log.py
              mr-await.sh agent-tools.sh)
QUIET=0; [ "${1:-}" = --quiet ] && QUIET=1
FAILED=0

sec()  { [ "$QUIET" = 1 ] || { echo; echo "$*"; }; }
say()  { [ "$QUIET" = 1 ] || printf '  %s\n' "$*"; }
ok()   { [ "$QUIET" = 1 ] || printf '  \033[32m✓\033[0m %s\n' "$*"; }
warn() { printf '  \033[33m!\033[0m %s\n' "$*"; }
bad()  { FAILED=1; printf '  \033[31m✗\033[0m %s\n' "$*"; }
fix()  { printf '      fix: %s\n' "$*"; }

[ -f "$ROOT/.claude-plugin/plugin.json" ] || { echo "not an agent-discipline checkout: $ROOT"; exit 1; }
[ "$QUIET" = 1 ] || echo "agent-discipline doctor · $ROOT"

# 1. plugin registration — a marketplace pointing at a DIFFERENT checkout is the silent killer:
#    your edits here never load, and nothing says so.
sec "plugin registration"
reg=$(ROOT="$ROOT" SETTINGS="$SETTINGS" python3 - <<'PY'
import json, os
name = "agent-discipline"
p, root = os.environ["SETTINGS"], os.environ["ROOT"]
if not os.path.exists(p): print("nosettings"); raise SystemExit
d = json.load(open(p))
mk = d.get("extraKnownMarketplaces", {}).get(name)
if not mk: print("unregistered"); raise SystemExit
path = mk.get("source", {}).get("path", "")
if os.path.realpath(path) != os.path.realpath(root): print("otherpath\t" + path); raise SystemExit
print("ok" if d.get("enabledPlugins", {}).get(f"{name}@{name}") else "disabled")
PY
)
case "${reg%%$'\t'*}" in
  ok)           ok "registered and enabled from this checkout" ;;
  nosettings)   bad "no $SETTINGS"; fix "./install.sh" ;;
  unregistered) bad "marketplace not registered — no hooks, skills or commands load"; fix "./install.sh" ;;
  disabled)     bad "registered but plugin disabled"; fix "./install.sh" ;;
  otherpath)    bad "marketplace points at ${reg#*$'\t'} — edits in THIS checkout never load"; fix "./install.sh (from this checkout)" ;;
esac

# 2. always-load rules — a plugin cannot write ~/.claude/rules, so each rules/*.md must be a symlink
sec "always-load rules (~/.claude/rules)"
for src in "$ROOT"/rules/*.md; do
  n="$(basename "$src")"; t="$RULES_DIR/$n"
  if [ -L "$t" ] && [ "$(readlink -f "$t")" = "$src" ]; then ok "$n"
  elif [ -L "$t" ]; then bad "$n -> $(readlink -f "$t") (another checkout)"; fix "./install.sh"
  elif [ -e "$t" ]; then bad "$n is a real file, not a link to this checkout"; fix "./install.sh (backs it up to ~/.claude/rules-backup/)"
  else bad "$n not loaded at all"; fix "./install.sh"; fi
done
# a stray backup left inside rules/ is injected in full every session — pure token cost
stray=$(ls "$RULES_DIR"/*.pre-plugin "$RULES_DIR"/*.bak 2>/dev/null | wc -l)
[ "$stray" -gt 0 ] && { warn "$stray backup file(s) sitting in rules/ — injected every session"; fix "mv $RULES_DIR/*.pre-plugin $CLAUDE/rules-backup/"; }

# 3. ~/.scripts entry points — the rules call these by short path; a missing one fails SILENTLY
sec "~/.scripts entry points"
for n in "${SCRIPT_LINKS[@]}"; do
  t="$HOME/.scripts/$n"
  if [ -L "$t" ] && [ "$(readlink -f "$t")" = "$ROOT/scripts/$n" ]; then
    [ -x "$ROOT/scripts/$n" ] && ok "$n" || bad "$n linked but not executable"
  elif [ -e "$t" ] || [ -L "$t" ]; then bad "$n exists but is not this checkout's — rules may call the wrong version"; fix "./install.sh"
  else bad "$n missing — rules that call ~/.scripts/$n do nothing, with no error"; fix "./install.sh"; fi
done

# 4. roles config
sec "roles config"
CFG="${AGENT_DISCIPLINE_CONFIG:-$HOME/.config/agent-discipline.env}"
[ -f "$CFG" ] && ok "$CFG" || { warn "no roles config — orchestrator/worker models fall back to defaults"; fix "bash $ROOT/scripts/agent-config.sh --init"; }

# 5. cron — a commented-out entry looks installed and never fires
sec "cron (Jira<->beads drift scan)"
if [ "${AGENT_DISCIPLINE_NO_CRON:-0}" = "1" ]; then say "skipped (AGENT_DISCIPLINE_NO_CRON=1)"
else
  line=$(crontab -l 2>/dev/null | grep -E '^(#*\s*)(([0-9*/,-]+\s+){5}).*jira-drift-nightly\.sh' | head -1)
  if [ -z "$line" ]; then warn "not scheduled — drift is only detected when you ask"; fix "./install.sh --cron"
  elif [[ "$line" =~ ^[[:space:]]*# ]]; then bad "entry is commented out — looks installed, never fires"; fix "./install.sh --cron"
  elif [[ "$line" != *"$ROOT"* ]]; then bad "entry runs another checkout: ${line##* }"; fix "./install.sh --cron"
  else ok "weekday scan active"; fi
fi

# 6. dependencies — every one OPTIONAL with a fallback, so these are warnings, never failures
sec "dependencies (all optional, all have fallbacks)"
[ "$QUIET" = 1 ] || python3 "$ROOT/agent_tools.py" || true
JIRA_PY_DEFAULT="$HOME/Projects/llm_library/plugins/data-skills/skills/jira/scripts/jira.py"
[ -f "${JIRA_PY:-$JIRA_PY_DEFAULT}" ] && ok "jira.py — Jira status checks available" \
  || { warn "jira.py not found — audits report Jira checks as SKIPPED, never as passed"; fix "export JIRA_PY=/path/to/jira.py"; }
command -v bd >/dev/null && ok "bd — Jira<->beads mirror checks available" \
  || warn "bd absent — mirror checks cannot run; key-level checks still do"

# 7. portability — scan every channel a teammate consumes, not just the executable ones
sec "portability"
SCAN=("$ROOT/hooks" "$ROOT/scripts" "$ROOT/ledger" "$ROOT/skills" "$ROOT/prompts" "$ROOT/rules" "$ROOT/commands")
PAT='projects/-(home|Users)-[a-z]|/(home|Users)/[a-z][a-z.]+/'
GREPOPT=(-rlE --include='*.md' --include='*.py' --include='*.sh'
         --exclude-dir=__pycache__ --exclude='test-*' --exclude='test_*' --exclude='doctor.sh')
hits=$(grep "${GREPOPT[@]}" "$PAT" "${SCAN[@]}" 2>/dev/null | wc -l)
if [ "$hits" -gt 0 ]; then
  bad "$hits file(s) hardcode one user's home — they will find no data on another machine"
  grep "${GREPOPT[@]}" "$PAT" "${SCAN[@]}" 2>/dev/null | sed 's#^#      #'
  fix "replace the literal path with agent_discipline_paths.memory_dir()"
else
  MEMDIR=$(python3 -c "import sys;sys.path.insert(0,'$ROOT');from agent_discipline_paths import memory_dir;print(memory_dir())")
  ok "paths resolve at runtime"
  SHORT=$(printf '%s' "$MEMDIR" | sed "s#^$HOME#~#")
  [ -d "$MEMDIR" ] && say "memory dir: $SHORT" \
    || { say "memory dir not created yet: $SHORT (harmless — made on first write)"; }
fi

echo
if [ "$FAILED" = 1 ]; then printf '  \033[31mUNHEALTHY\033[0m — fix the ✗ lines above, then re-run: %s\n' "$ROOT/scripts/doctor.sh"; exit 1; fi
[ "$QUIET" = 1 ] || printf '  \033[32mhealthy\033[0m — nothing to fix\n'
exit 0
