#!/usr/bin/env python3
"""Which documents no longer describe the code they are bound to.

A doc declares what it documents in its own frontmatter:

    ---
    code_refs:
      - hooks/pref-checkpoint.py
      - scripts/agent-dashboard.py
    ---

The binding is then checked against git, not against a promise: a doc is STALE when a file it
claims to document has a newer commit than the doc itself, or is modified in the working tree
while the doc is not. Files under the code roots that no doc claims are UNBOUND -- a feature
with no document, which is how drift starts.

  docs-drift.py                 # the report
  docs-drift.py --json          # same numbers, machine-readable (the dashboard reads this)
  docs-drift.py --changed       # only docs bound to what is uncommitted right now
  docs-drift.py --for <path>... # which docs are bound to these files
  docs-drift.py --unbound       # code with no doc, longest-unbound first

Exit code is 0 unless --strict is given: this reports, it does not gate.
"""
import argparse
import fnmatch
import json
import os
import subprocess
import sys

DOC_GLOBS = ("docs/**/*.md", "docs/*.md", "*.md")
# Where "a feature" lives. Only roots that exist here are scanned, so this stays useful in a
# repo with a different layout.
CODE_ROOTS = ("hooks", "scripts", "ledger", "commands", "skills", "rules", "prompts", "engine",
              "src", "lib", "app")
CODE_EXT = (".py", ".sh", ".ts", ".tsx", ".js", ".md", ".sql")
# Not features: tests, generated output, vendored code, and the docs themselves.
SKIP_PARTS = ("__pycache__", "node_modules", ".venv", "tests", "test", "docs", ".git")
# A test named as a FILE rather than kept in a tests/ directory (memory-kit's
# scripts/test-recall-cue.sh). SKIP_PARTS only prunes directories, so without this every test
# script is reported as a feature awaiting a document -- noise that buries the real ones.
SKIP_FILE_PREFIX = ("test_", "test-")


def git(*args, cwd="."):
    r = subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True)
    return r.stdout.strip() if r.returncode == 0 else ""


def repo_root(start="."):
    return git("rev-parse", "--show-toplevel", cwd=start) or os.path.abspath(start)


def frontmatter(raw):
    """The code_refs list, whatever shape it was written in: a YAML list, or one inline
    comma-separated line. Hand-parsed on purpose -- a hook must not need PyYAML installed."""
    if not raw.startswith("---"):
        return []
    end = raw.find("\n---", 3)
    if end < 0:
        return []
    refs, in_refs = [], False
    for ln in raw[3:end].splitlines():
        if in_refs:
            st = ln.strip()
            if st.startswith("- "):
                refs.append(st[2:].strip().strip("\"'"))
                continue
            if st and not ln.startswith((" ", "\t")):
                in_refs = False
            else:
                continue
        if ln.strip().startswith("code_refs:"):
            rest = ln.split(":", 1)[1].strip().strip("[]")
            if rest:
                refs += [x.strip().strip("\"'") for x in rest.split(",") if x.strip()]
            else:
                in_refs = True
    return [r for r in refs if r]


def iter_docs(root):
    for dirpath, dirnames, filenames in os.walk(root):
        rel = os.path.relpath(dirpath, root)
        parts = set(rel.split(os.sep))
        if parts & {".git", "node_modules", "__pycache__", ".venv"}:
            dirnames[:] = []
            continue
        for fn in filenames:
            if fn.endswith(".md"):
                yield os.path.relpath(os.path.join(dirpath, fn), root)


def iter_code(root):
    # Top-level modules count. Without this a real path like agent_discipline_paths.py is
    # invisible, and a doc that correctly points at it is reported as a BROKEN binding --
    # the checker accusing the doc of the checker's own blind spot. Root .md is excluded:
    # README / CLAUDE / AGENTS are prose, not a feature to be documented.
    for fn in sorted(os.listdir(root)):
        if (fn.endswith(CODE_EXT) and not fn.endswith(".md")
                and os.path.isfile(os.path.join(root, fn))):
            yield fn
    for base in CODE_ROOTS:
        d = os.path.join(root, base)
        if not os.path.isdir(d):
            continue
        for dirpath, dirnames, filenames in os.walk(d):
            rel = os.path.relpath(dirpath, root)
            if set(rel.split(os.sep)) & set(SKIP_PARTS):
                dirnames[:] = []
                continue
            for fn in filenames:
                if fn.endswith(CODE_EXT) and not fn.startswith(SKIP_FILE_PREFIX):
                    yield os.path.relpath(os.path.join(dirpath, fn), root)


def last_commit(path, root):
    """Committer timestamp of the newest commit touching path, as an int. 0 = never committed,
    which counts as newer than any doc (a brand-new file is undocumented by definition)."""
    out = git("log", "-1", "--format=%ct", "--", path, cwd=root)
    return int(out) if out.isdigit() else 0


def dirty(root):
    # --no-renames and a split, NOT a fixed column: git() strips the output, which eats the
    # leading space of " M path" and shifted every path by one character -- the dirty set was
    # full of "cripts/feature.py" and nothing ever matched.
    out = git("status", "--porcelain", "--no-renames", cwd=root)
    files = set()
    for ln in out.splitlines():
        parts = ln.split(None, 1)
        if len(parts) == 2:
            files.add(parts[1].strip().strip('"'))
    return files


def expand(ref, code_files):
    """A code_ref is a path, a directory, or a glob. Returns what it actually matches."""
    if any(c in ref for c in "*?["):
        return sorted(f for f in code_files if fnmatch.fnmatch(f, ref))
    hits = sorted(f for f in code_files if f == ref or f.startswith(ref.rstrip("/") + "/"))
    return hits


def analyse(root):
    code_files = sorted(iter_code(root))
    changed = dirty(root)
    bound, docs = {}, {}
    for doc in iter_docs(root):
        refs = frontmatter(open(os.path.join(root, doc), errors="replace").read())
        if not refs:
            continue
        doc_ct = last_commit(doc, root)
        doc_dirty = doc in changed
        entries, missing = [], []
        for ref in refs:
            hits = expand(ref, code_files)
            if not hits:
                # The ref points at nothing. Silence here is how a doc keeps looking bound
                # after the file it documents was renamed or deleted.
                missing.append(ref)
                continue
            for f in hits:
                bound.setdefault(f, []).append(doc)
                f_ct = last_commit(f, root)
                stale = (f_ct > doc_ct and not doc_dirty) or (f in changed and not doc_dirty)
                entries.append({"file": f, "code_committed": f_ct, "uncommitted": f in changed,
                                "stale": stale})
        docs[doc] = {"refs": refs, "doc_committed": doc_ct, "doc_uncommitted": doc_dirty,
                     "files": entries, "missing_refs": missing,
                     "stale_files": [e["file"] for e in entries if e["stale"]]}
    unbound = [f for f in code_files if f not in bound]
    return {"root": root, "docs": docs, "bound": bound, "unbound": unbound,
            "changed": sorted(changed), "code_files": code_files}


def summary(a):
    stale = {d: v for d, v in a["docs"].items() if v["stale_files"]}
    broken = {d: v["missing_refs"] for d, v in a["docs"].items() if v["missing_refs"]}
    return {"docs_with_bindings": len(a["docs"]), "bound": len(a["bound"]),
            "unbound_code": len(a["unbound"]), "stale": len(stale),
            "broken_refs": sum(len(v) for v in broken.values()),
            "stale_docs": {d: v["stale_files"] for d, v in stale.items()},
            "broken_ref_docs": broken,
            "unbound_files": a["unbound"]}


def docs_for(a, paths):
    out = {}
    for p in paths:
        p = os.path.relpath(os.path.abspath(p), a["root"])
        hit = a["bound"].get(p, [])
        out[p] = hit
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--changed", action="store_true", help="only what is uncommitted right now")
    ap.add_argument("--unbound", action="store_true", help="code no doc claims")
    ap.add_argument("--for", dest="For", nargs="+", metavar="PATH")
    ap.add_argument("--strict", action="store_true", help="exit 1 when anything is stale")
    ap.add_argument("-C", dest="cwd", default=".")
    a = ap.parse_args(argv)

    root = repo_root(a.cwd)
    an = analyse(root)
    s = summary(an)

    if a.For:
        m = docs_for(an, a.For)
        if a.json:
            print(json.dumps(m, indent=2))
        else:
            for p, ds in m.items():
                print(f"{p}: {', '.join(ds) if ds else 'NO DOC — nothing documents this file'}")
        return 0

    if a.json:
        print(json.dumps(s, indent=2))
        return 1 if (a.strict and s["stale"]) else 0

    if a.changed:
        touched = [f for f in an["changed"] if f in an["bound"]]
        print(f"uncommitted files with a doc binding: {len(touched)}")
        for f in touched:
            for d in an["bound"][f]:
                mark = "STALE" if f in an["docs"][d]["stale_files"] else "in sync"
                print(f"  {f}\n     -> {d}  [{mark}]")
        new = [f for f in an["changed"] if f not in an["bound"] and f in set(an["code_files"])]
        if new:
            print(f"\nuncommitted code with NO doc: {len(new)}")
            for f in new:
                print(f"  {f}   <- write or extend a doc, then add {f} to its code_refs")
        return 1 if (a.strict and touched) else 0

    if a.unbound:
        print(f"code files no doc claims: {s['unbound_code']} of {len(an['code_files'])}")
        for f in an["unbound"]:
            print(f"  {f}")
        return 0

    print(f"\ndocumentation drift — {root}")
    print(f"  docs with code_refs      {s['docs_with_bindings']}")
    print(f"  code files bound         {s['bound']} of {len(an['code_files'])}")
    print(f"  stale docs               {s['stale']}"
          + ("   <- code moved on after the doc" if s["stale"] else ""))
    print(f"  broken code_refs         {s['broken_refs']}"
          + ("   <- ref points at nothing; file renamed or deleted" if s["broken_refs"] else ""))
    print(f"  unbound code             {s['unbound_code']}"
          + ("   <- features with no document" if s["unbound_code"] else ""))
    if s["stale_docs"]:
        print("\nstale — update the doc, or say in the doc why the change does not affect it:")
        for d, files in sorted(s["stale_docs"].items()):
            print(f"  {d}")
            for f in files[:6]:
                print(f"     newer: {f}")
    if s["broken_ref_docs"]:
        print("\nbroken bindings — the ref matches no file:")
        for d, refs in sorted(s["broken_ref_docs"].items()):
            print(f"  {d}: {', '.join(refs)}")
    if s["unbound_code"]:
        print(f"\nunbound ({s['unbound_code']}) — run with --unbound for the full list, "
              f"or /docs to write the missing doc")
    if not s["docs_with_bindings"]:
        print("\nNo doc declares code_refs yet, so NOTHING is checked — this is not a pass.")
        print("Add to a doc's frontmatter:\n  ---\n  code_refs:\n    - path/to/file.py\n  ---")
    print()
    return 1 if (a.strict and (s["stale"] or s["broken_refs"])) else 0


if __name__ == "__main__":
    sys.exit(main())
