# agent-discipline

Working rules decay when they rely on being remembered — measured on this setup, the
always-loaded recall channel was acted on **16.4%** of the time. This plugin converts the rules
worth keeping into mechanisms that fire at the moment of action.

## What it does

**Preference ledger.** Records _why_ you chose what you chose — the option taken, the option
rejected, and the reason — then reuses it. A preference-shaped question is intercepted before it
reaches you and answered from the record; re-asking the same question lets it through, so a
genuine question costs one round trip, never a wall.

**Jira ↔ beads drift audit.** Every key in `<repo>/.claude/jira_issues` must have a bead
labelled `jira:<key>`; the reverse does not hold. Finds orphan keys, keys Jira has already
closed, mirrors that never name their parent, and body/label mismatches. **Beads is optional** —
a Jira-only repo runs the key-level checks and says which checks were skipped, never reporting
skipped as passed.

**Derived Jira status.** Reads MR state and derives the ticket status instead of maintaining it
by hand: merged → Done, open → Verifying, draft → In Progress, closed → left alone. Dry-run by
default. Only sees tickets that have an MR, so it shrinks what the audit must catch rather than
replacing it.

**Blocker log.** One row when work parks, one when it frees, grouped by class. A class with 2+
hits is a process fix, not another deferred ticket.

**Always-load budget warning.** `~/.claude/rules/` is injected in full every session forever.
Warns when the total crosses a budget, heaviest file first.

## Commands

| Command     | What                                                                            |
| ----------- | ------------------------------------------------------------------------------- |
| `/ledger`   | dashboard — ledger effect, blockers, whether the preventable share is shrinking |
| `/drift`    | audit this repo's Jira ↔ beads link (read-only; `--fix` for machine-safe rows)  |
| `/blockers` | blockers grouped by class                                                       |

## Every measurement has a path to red

`--selftest` on the dashboard and the audit runs a positive **and** a negative control. A
detector that cannot stay silent is not a detector; a green with no path to red is a structural
guarantee, not a result. Both self-tests caught real bugs on their first run — a matcher that
denied every English sentence containing "should" and "the", and a headerless TSV that reported
0 corrections where there were 75.

Empty panels say "not enough data", never green.

## Install

```sh
glab api "projects/liangshih.lin%2Fagent-discipline/repository/files/bootstrap.sh/raw?ref=master" | sh
```

Uses the auth `glab` already holds. **Plain `curl` does not work** on this instance: the web
`/-/raw/` route redirects an internal project to `sign_in` even with a `PRIVATE-TOKEN` header,
because it wants a browser session. With a token in the environment the API route works over
curl too:

```sh
curl -fsSL -H "PRIVATE-TOKEN: $GITLAB_TOKEN" \
  "https://gitlab.data.vici.corp/api/v4/projects/581/repository/files/bootstrap.sh/raw?ref=master" | sh
```

No `glab` and no token? Clone and run the installer directly — note SSH is on **port 8022**:

```sh
git clone ssh://git@gitlab.data.vici.corp:8022/liangshih.lin/agent-discipline.git ~/GitLab/agent-discipline
~/GitLab/agent-discipline/install.sh
```

Clones to `~/GitLab/agent-discipline` (override with `AGENT_DISCIPLINE_DIR`), then runs
`install.sh`. Re-running fast-forwards and re-installs; a dirty checkout is left alone rather
than overwritten. POSIX `sh` with no prompts — piped into `sh` there is no TTY, so anything
interactive would hang.

Already cloned? Just `./install.sh`.

| Flag          |                                                              |
| ------------- | ------------------------------------------------------------ |
| _(none)_      | register marketplace, enable plugin, link rules, repair cron |
| `--check`     | report what would change, write nothing                      |
| `--cron`      | also schedule the weekday drift scan if it is missing        |
| `--uninstall` | remove everything the installer added (never your data)      |

`AGENT_DISCIPLINE_NO_CRON=1` skips all cron handling, for deliberately disabling the scan.

**What the installer does that matters:**

- Strips inline hook entries from `settings.json` that the plugin now owns — registered in both
  places, every hook fires **twice**.
- Symlinks `rules/answer-shape.md` into `~/.claude/rules/`, because a plugin cannot write the
  always-load channel. Any pre-existing file is backed up to `~/.claude/rules-backup/`, _not_
  left in `rules/` — everything in that directory is injected in full every session, so a
  `.bak` sitting there silently doubles the cost.
- Checks the cron entry on **every** run and repairs it: a commented-out schedule looks
  installed but never fires, and a stale path points at a checkout you may have moved.

## Not yet portable — read before sharing

- **Memory paths are resolved, not derived.** Several scripts hardcode this machine's memory
  directory. They must resolve `$HOME` at runtime before anyone else installs this.
- **The AS1–AS3 rules live outside the plugin**, in `~/.claude/rules/answer-shape.md`, because a
  plugin cannot write to the always-load channel. Porting them means injecting at `SessionStart`.
- **The nightly scan is a crontab entry**, not plugin-managed. A throttled `SessionStart` check
  would be the plugin-native equivalent.
- Data (`topics/pref-*.md`, the TSV logs) stays in your memory directory. The plugin reads and
  writes it; it never owns it.
