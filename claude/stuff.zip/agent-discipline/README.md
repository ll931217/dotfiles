# agent-discipline

Working rules decay when they rely on being remembered — measured on this setup, the
always-loaded recall channel was acted on **16.4%** of the time. This plugin converts the rules
worth keeping into mechanisms that fire at the moment of action.

## What it does

**Preference ledger.** Records _why_ you chose what you chose — the option taken, the option
rejected, and the reason — then reuses it. A preference-shaped question is intercepted before it
reaches you and answered from the record; re-asking the same question lets it through, so a
genuine question costs one round trip, never a wall.

**Jira ↔ beads drift audit.** Every key in `<repo>/.claude/jira_issues` must have a bead
labelled `jira:<key>`; the reverse does not hold. Finds orphan keys, keys Jira has already
closed, mirrors that never name their parent, and body/label mismatches. **Beads is optional** —
a Jira-only repo runs the key-level checks and says which checks were skipped, never reporting
skipped as passed.

**Derived Jira status.** Reads MR state and derives the ticket status instead of maintaining it
by hand: merged → Done, open → Verifying, draft → In Progress, closed → left alone. Dry-run by
default. Only sees tickets that have an MR, so it shrinks what the audit must catch rather than
replacing it.

**Automatic worktree cleanup.** The MR watcher reaps on merge -- worktree, local branch, cron
entry -- with no prompt: the reaper fails closed (merged + clean + nothing unpushed, or it keeps
and reports the reason), so there is nothing for a human to adjudicate. `/reap` remains for
merges nothing was watching. `scripts/test-watch-reap.sh` covers both arms, including the
reaper-missing one, because the failure this had was SILENCE: the reaper path was resolved from
the invoking symlink's directory, `-x` was false, and the cleanup was skipped without a word.
The tmux half is `scripts/test-reap-tmux.sh`: the window is closed AFTER the removal that
orphans it, `wt`'s trash path counts as orphaned, and the window hosting the running session is
never killed -- it is named, with the command to close it.

**Orchestrator / worker split.** `wt switch --create` starts the worktree's Claude through
`~/.scripts/agent-worker.sh`: `opus` at `high`, named `worker:<branch>`, with `prompts/worker.md`
as its role. The session that made the worktree stays the orchestrator (`/orchestrate`): it
dispatches one worker per `bd ready` task, writing `.claude/TASK.md` with the task, its own
session name and the ledger records whose cue matches. The worker spawns 4 core DoD teammates
(intent, tests, UX, discipline, prefs), writes `.claude/DOD.md`, implements, has them verify, and
reports only when every lens passes. The orchestrator reviews against `DOD.md`, approves, and the
worker opens the MR into `staging`. Nothing is reaped before the merge. Editing the main
checkout while workers are active gets a note, never a block. `WORKER_MODEL` / `WORKER_EFFORT`
override the worker defaults.

**Which model runs which role** is one file, `~/.config/agent-discipline.env` (template written
by `install.sh`; `~/.scripts/agent-config.sh --show` prints the effective values and where each
came from — env var beats file beats default):

| Key | Default | Used by |
| --- | --- | --- |
| `ORCHESTRATOR_MODEL` / `ORCHESTRATOR_EFFORT` | your claude default / `xhigh` | `~/.scripts/agent-orchestrator.sh`, the launcher for a batch session |
| `WORKER_MODEL` / `WORKER_EFFORT` | `opus` / `high` | `~/.scripts/agent-worker.sh`, started by the `wt` post-start hook |
| `REVIEWER_MODEL` | `sonnet` | the worker's DoD teammates, and the automerge review subagent |

**A ledger can be seeded from memory you already have.** `scripts/ledger-bootstrap.py` reads
`human-correction` rows, imperative lines in topic files, and repeated `uncovered` asks, and
writes CANDIDATES to `topics/drafts/` — a subdirectory the recall hook does not scan, so a
draft can never be injected as if it were a decision you made. What a record is worth is the
option NOT taken, and memory rarely states it, so every draft carries a literal `UNKNOWN` and
`--promote` refuses while it stands. Dry run by default. Details in
`docs/ledger-bootstrap-scope.md`.

**worktrunk, beads and glab are optional.** Each has a fallback that needs nothing but git,
python and a token: `wt` → `git worktree`, `bd` → `jira.py`, `glab` → GitLab REST v4.
`python3 agent_tools.py` prints which is in use. A fallback that answers a NARROWER question
says so — the jira task list carries "blocked-by relationships were NOT checked", and
`dispatch` without `wt` says no worker session was started instead of telling you to message
one. Details in `docs/optional-tools.md`.

**Docs bound to the code they describe.** A document declares what it documents in its own
frontmatter (`code_refs:`), and the binding is checked against git: a doc whose bound file has
a newer commit is STALE, a ref matching no file is BROKEN, and code no doc claims is UNBOUND —
a feature with no document. `hooks/docs-drift-nudge.py` names the stale doc at the moment of
the edit, informing and never blocking, and goes quiet once the doc is edited too. With no
bindings anywhere the report says *nothing is checked* rather than printing a clean bill of
health. `/docs` does the writing; `scripts/docs-drift.py --strict` is the CI arm, off by
default. Details in `docs/documentation-drift.md`.

**Metrics that carry their denominator.** `/ledger` reports how often the ledger spoke to a
question **out of how many questions it saw** — the hook logs an `uncovered` row when no record
matched, so 24-of-30 and 24-of-300 can no longer look identical, and every uncovered question
is reported as a record you have not written yet. `inform` is never summed with `deny`,
`--selftest` traffic is excluded from the human-facing numbers, and `--json` prints the same
dict the panels render from. A fifth panel tracks **urgent-lane debt**: an urgent fix ships
with one lens, and the reviews it skipped are booked as beads at dispatch — the panel reports
how many are still owed and the age of the oldest unpaid one, which is the number that says the
lane became the default. With no `bd` it reports UNAVAILABLE, because "nothing is owed" and
"nobody can see what is owed" are opposite facts. Details in `docs/metrics.md`.

**Every repo gets a verification handbook.** `/testing-handbook` detects, from the manifests,
what actually verifies a change *here* — the unit runner, the E2E driver, whether a property
library or a mutation tool is even installed — and writes it as a project skill at
`<repo>/.claude/skills/verify-changes/SKILL.md`. The worker generates it the first time it
implements in a repo, so this is not per-project setup. The handbook carries a routing table
(logic → a unit test that fails without the change; a human-facing surface → one E2E asserting
what the user sees; roundtrip / parser / validator / numeric → a property-based test; money,
auth or a shared library → mutation testing scoped to the changed files), because running all
four on every change makes workers grind. **A technique whose tool is missing is recorded as
MISSING with the command that adds it**, and a worker that needed one reports
`NOT RUN: <technique> — <tool> not installed` rather than dropping it — silently skipping is how
an unverified change comes to read as a verified one.

The handbook has two halves and only one is generated. Detected commands are re-detected on every
`--force`; a `Learned here` section below a marker is written by workers (`--learn "<one line>"`,
dated and deduplicated) and never overwritten — so a fact paid for once survives, and a wrong
detection is not permanent. `--check` on a repo that already has a handbook prints the **drift**
instead of rewriting: `NOW AVAILABLE` means a previous change added a tool the handbook still
calls impossible.

**The worker owns its MR until it ends.** A detached watcher notifies the desktop; it cannot
notify the agent session that opened the MR, so "it merged" used to be carried over by hand. The
push hook now hands that session a background command that exits on merge, close, merge conflict
or a red pipeline, and re-invokes it with the outcome. It also fixes the sequence bug behind the
misses: `git push` started a branch-pipeline watch, and the `glab mr create` seconds later hit a
"something is already running" lock and started nothing — the pipeline went green, that watcher
exited, and the MR was watched by nobody. An MR watch now supersedes a pipeline watch.

**Blocker log.** One row when work parks, one when it frees, grouped by class. A class with 2+
hits is a process fix, not another deferred ticket.

**Always-load budget warning.** `~/.claude/rules/` is injected in full every session forever.
Warns when the total crosses a budget, heaviest file first.

## Commands

| Command     | What                                                                            |
| ----------- | ------------------------------------------------------------------------------- |
| `/ledger`   | dashboard — ledger effect, blockers, whether the preventable share is shrinking |
| `/drift`    | audit this repo's Jira ↔ beads link (read-only; `--fix` for machine-safe rows)  |
| `/blockers` | blockers grouped by class                                                       |
| `/orchestrate` | batch of tasks → one opus worker per ready task; this session reviews and approves |
| `/testing-handbook` | detect how THIS repo is verified, write it as a project skill, and show drift when the tooling moves on |
| `/delegate` | one task, one worktree: same handshake for a single worker                      |
| `/automerge` | merge the docs/chore/style/test MRs that pass the gate, reap after               |

## Every measurement has a path to red

`--selftest` on the dashboard and the audit runs a positive **and** a negative control. A
detector that cannot stay silent is not a detector; a green with no path to red is a structural
guarantee, not a result. Both self-tests caught real bugs on their first run — a matcher that
denied every English sentence containing "should" and "the", and a headerless TSV that reported
0 corrections where there were 75.

Empty panels say "not enough data", never green.

## Install

```sh
glab api "projects/liangshih.lin%2Fagent-discipline/repository/files/bootstrap.sh/raw?ref=master" | sh
```

Uses the auth `glab` already holds. **Plain `curl` does not work** on this instance: the web
`/-/raw/` route redirects an internal project to `sign_in` even with a `PRIVATE-TOKEN` header,
because it wants a browser session. With a token in the environment the API route works over
curl too:

```sh
curl -fsSL -H "PRIVATE-TOKEN: $GITLAB_TOKEN" \
  "https://gitlab.data.vici.corp/api/v4/projects/581/repository/files/bootstrap.sh/raw?ref=master" | sh
```

No `glab` and no token? Clone and run the installer directly — note SSH is on **port 8022**:

```sh
git clone ssh://git@gitlab.data.vici.corp:8022/liangshih.lin/agent-discipline.git ~/GitLab/agent-discipline
~/GitLab/agent-discipline/install.sh
```

Clones to `~/GitLab/agent-discipline` (override with `AGENT_DISCIPLINE_DIR`), then runs
`install.sh`. Re-running fast-forwards and re-installs; a dirty checkout is left alone rather
than overwritten. POSIX `sh` with no prompts — piped into `sh` there is no TTY, so anything
interactive would hang.

Already cloned? Just `./install.sh`.

| Flag          |                                                              |
| ------------- | ------------------------------------------------------------ |
| _(none)_      | register marketplace, enable plugin, link rules, repair cron |
| `--check`     | report what would change, write nothing                      |
| `--cron`      | also schedule the weekday drift scan if it is missing        |
| `--uninstall` | remove everything the installer added (never your data)      |

`AGENT_DISCIPLINE_NO_CRON=1` skips all cron handling, for deliberately disabling the scan.

**What the installer does that matters:**

- Writes `~/.config/agent-discipline.env` once (roles config) and never overwrites it.

- Strips inline hook entries from `settings.json` that the plugin now owns — registered in both
  places, every hook fires **twice**.
- Symlinks `scripts/agent-worker.sh` and the two `glab-watch-*.sh` watchers into `~/.scripts/`,
  the short path worktrunk's post-start hook and the shell call.
- Symlinks every `rules/*.md` into `~/.claude/rules/`, because a plugin cannot write the
  always-load channel. Any pre-existing file is backed up to `~/.claude/rules-backup/`, _not_
  left in `rules/` — everything in that directory is injected in full every session, so a
  `.bak` sitting there silently doubles the cost.
- Checks the cron entry on **every** run and repairs it: a commented-out schedule looks
  installed but never fires, and a stale path points at a checkout you may have moved.

## Not yet portable — read before sharing

- **Memory paths are resolved, not derived.** Several scripts hardcode this machine's memory
  directory. They must resolve `$HOME` at runtime before anyone else installs this.
- **The AS1–AS3 rules live outside the plugin**, in `~/.claude/rules/answer-shape.md`, because a
  plugin cannot write to the always-load channel. Porting them means injecting at `SessionStart`.
- **The nightly scan is a crontab entry**, not plugin-managed. A throttled `SessionStart` check
  would be the plugin-native equivalent.
- Data (`topics/pref-*.md`, the TSV logs) stays in your memory directory. The plugin reads and
  writes it; it never owns it.
