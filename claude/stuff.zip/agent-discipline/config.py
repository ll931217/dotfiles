"""Feature flags for the Ledger Context Governor, with conservative defaults.

Every flag here defaults to TODAY'S behaviour. Nothing in this file turns a new behaviour on;
enabling one is a deliberate act by the user, per the spec's rule that new autonomous behaviour
stays behind a flag.

Resolution order, first hit wins:
  1. environment variable of the same name, e.g. LCG_SHADOW_ASK=1
  2. ~/.config/agent-discipline.env  (the roles config, shared with the launchers)
  3. the default below

  python3 config.py            # print every flag, its value, and where it came from
  python3 config.py --json     # same, machine-readable

Runs on Python 3.12 on purpose: Claude Code executes hooks as `#!/usr/bin/env python3`, which is
the system interpreter, NOT the uv environment that pyproject.toml's `requires-python = ">=3.14"`
describes. Anything imported by a hook must not need 3.13+.
"""
import json
import os
import sys

CONFIG_FILE = os.environ.get(
    "AGENT_DISCIPLINE_CONFIG", os.path.expanduser("~/.config/agent-discipline.env"))

# name -> (default, what it gates)
FLAGS = {
    # ---- rollout mode (spec §25). `observe` writes records and changes nothing a user sees.
    "LCG_MODE": ("observe", "observe | shadow | recommend | resolve — the rollout ceiling for "
                            "everything below. Nothing above `shadow` is implemented yet."),

    # ---- Phase 1
    "LCG_TYPED_LEDGER": ("0", "read typed entry fields (kind, authority, scope, lifecycle) when "
                              "present. Off: entries are read exactly as they are today."),
    "LCG_MIGRATE_ENTRIES": ("0", "allow the migration to WRITE to the user's memory directory. "
                                 "Off: migration is dry-run only. The store is user-owned and "
                                 "shared with memory-kit, so writing is opt-in."),

    # ---- Phase 2
    "LCG_RESOLVER": ("0", "compile a Task Context Manifest on UserPromptSubmit."),
    "LCG_INJECT_M0": ("0", "inject the manifest into context. Off: the manifest is written to "
                           "session state and nothing reaches the model."),
    "LCG_RECEIPTS": ("0", "persist a context receipt per resolution."),

    # ---- Phase 3
    "LCG_DISCOVERY": ("0", "extract entities from tool observations and extend the scope frontier."),
    "LCG_INJECT_DELTA": ("0", "inject manifest deltas (M1+). Off: deltas are recorded only."),
    "LCG_COVERAGE": ("0", "record mutation coverage. NON-ENFORCING by construction — there is no "
                          "flag that makes coverage deny a tool call in phases 0-4."),

    # ---- Phase 4
    "LCG_SHADOW_ASK": ("0", "record a prediction for every AskUserQuestion and compare it with the "
                            "human's answer. Measurement only; never changes what the user sees."),
    "LCG_STOP_DETECT": ("0", "detect plain-text clarification requests at Stop and record a shadow "
                             "prediction. Never continues the session."),

    # ---- Phase 5-6
    "LCG_CURATION": ("0", "record answers as candidates, deduplicate them, and expire task "
                          "assumptions. Approval to any authority above the answer's own class "
                          "always needs a human, flag or no flag."),
    "LCG_RECOMMEND": ("0", "show what the ledger WOULD answer, with its source ids, intent and "
                           "risk. Advisory: it never fills an answer."),
    "LCG_SUBAGENT_SCOPE": ("0", "pass inherited mandatory constraints to a subagent instead of "
                                "the parent's whole manifest."),

    # ---- Phase 7. Autonomy additionally requires every prerequisite in ledger/autonomy.py to be
    # MET FROM EVIDENCE. Setting this flag is necessary and nowhere near sufficient.
    "LCG_AUTONOMY": ("0", "allow the ledger to answer a question itself. Requires LCG_MODE=resolve "
                          "AND every readiness prerequisite met AND the kill switch absent. "
                          "`python3 scripts/ledger-readiness.py` shows what is unmet."),
    "LCG_ENFORCE_COVERAGE": ("0", "let the coverage gate deny an uncovered mutation once, to "
                                  "hydrate context. Phase 7; gated on the same readiness check."),
    "LCG_STOP_RECOVERY": ("0", "let a plain-text Stop candidate continue the session. Phase 7; "
                               "same gate."),

    # ---- behaviour that ALREADY EXISTS. Default preserves it exactly (gap analysis C1).
    "LCG_ASK_DENY": ("0", "whether pref-checkpoint DENIES a question the ledger covers. Default 0 "
                          "= inform only: the records are injected and the question still reaches "
                          "the user. Set 1 for the legacy deny-once behaviour. Changed from 1 to 0 "
                          "on 2026-09-03 by the user's decision on gap-analysis conflict C1: the "
                          "spec's own AskUserQuestion hook never denies at any autonomy level "
                          "(§18.9), and hooks here inform rather than block."),
}

# Flags that must never default to on, whatever else changes. Asserted by the test suite: a
# future edit that flips one of these has to delete it from this list first, deliberately.
MUST_DEFAULT_OFF = (
    "LCG_TYPED_LEDGER", "LCG_MIGRATE_ENTRIES", "LCG_RESOLVER", "LCG_INJECT_M0", "LCG_RECEIPTS",
    "LCG_DISCOVERY", "LCG_INJECT_DELTA", "LCG_COVERAGE", "LCG_SHADOW_ASK", "LCG_STOP_DETECT",
    "LCG_CURATION", "LCG_RECOMMEND", "LCG_SUBAGENT_SCOPE",
    # The three that can act on the user's behalf. These are also gated on evidence, not just
    # on the flag — see ledger/autonomy.py.
    "LCG_AUTONOMY", "LCG_ENFORCE_COVERAGE", "LCG_STOP_RECOVERY",
)


def _from_file():
    out = {}
    try:
        with open(CONFIG_FILE) as f:
            for line in f:
                line = line.split("#", 1)[0].strip()
                if "=" not in line:
                    continue
                k, v = line.split("=", 1)
                k, v = k.strip(), v.strip().strip('"').strip("'")
                if k in FLAGS and v != "":
                    out[k] = v
    except OSError:
        pass
    return out


def get(name):
    """Value and where it came from: ('1', 'env') / ('0', <config path>) / ('0', 'default')."""
    if name not in FLAGS:
        raise KeyError(f"unknown flag: {name}")
    if os.environ.get(name):
        return os.environ[name], "env"
    from_file = _from_file()
    if name in from_file:
        return from_file[name], CONFIG_FILE
    return FLAGS[name][0], "default"


def on(name):
    """True only for an explicit truthy value. Anything unset or unparsed is OFF."""
    return get(name)[0].strip().lower() in ("1", "true", "yes", "on")


def mode():
    return get("LCG_MODE")[0].strip().lower()


def main(argv):
    rows = [(n, *get(n), FLAGS[n][1]) for n in FLAGS]
    if "--json" in argv:
        print(json.dumps({n: {"value": v, "source": s, "gates": d} for n, v, s, d in rows}, indent=2))
        return 0
    print(f"Ledger Context Governor flags   (config: {CONFIG_FILE}"
          f"{'' if os.path.exists(CONFIG_FILE) else ' — not present'})")
    print("Every flag defaults to today's behaviour; none of them is on unless you turned it on.\n")
    for n, v, s, d in rows:
        star = " " if s == "default" else "*"
        print(f" {star}{n:22} {v:8} from {s}")
        print(f"    {d}")
    print("\n * = overridden. Order: env var > config file > default.")
    off = [n for n in MUST_DEFAULT_OFF if FLAGS[n][0] != "0"]
    if off:
        print(f"\n!! these must default to 0 and do not: {', '.join(off)}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
