"""Phrase triggers must not fire word by word — "new card" matching bare "new" is what broke
the dashboard's negative control."""
import importlib.util, pathlib

spec = importlib.util.spec_from_file_location(
    "pref_checkpoint", pathlib.Path(__file__).resolve().parent.parent / "hooks" / "pref-checkpoint.py")
hook = importlib.util.module_from_spec(spec)
spec.loader.exec_module(hook)

FM = {"triggers": "FINI, new card, attach, 新卡片", "description": ""}

def test_phrase_trigger_does_not_fire_on_one_word():
    assert hook.score("which cloud region should the new Kafka cluster live in?", FM) == 0

def test_phrase_trigger_fires_on_the_phrase():
    assert hook.score("should this be a new card or a row?", FM) >= 2

def test_single_word_and_cjk_triggers_still_fire():
    assert hook.score("attach it where?", FM) >= 2
    assert hook.score("要不要開新卡片?", FM) >= 2
