#!/usr/bin/env bash
# E2E for scripts/agent-worker.sh: the launcher says what it is about to run, and a missing
# role prompt names the fix. Drives the real script; never starts claude (--show).
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
fail=0
# Test the built-in defaults, not this machine: a real ~/.config/agent-discipline.env would
# otherwise make "effort=high" fail for anyone who set WORKER_EFFORT.
export AGENT_DISCIPLINE_CONFIG="$(mktemp -u)/none.env"
check() { if [[ "$2" == *"$3"* ]]; then echo "ok   $1"; else echo "FAIL $1"; echo "     want: $3"; echo "     got:  $2"; fail=1; fi; }

out="$(cd "$ROOT" && "$ROOT/scripts/agent-worker.sh" --show 2>&1)"; rc=$?
check "--show names model and effort" "$out" "model=opus effort=high"
check "--show says no task yet" "$out" "task=none yet"
[[ $rc -eq 0 ]] && echo "ok   --show exits 0" || { echo "FAIL --show exit $rc"; fail=1; }

out="$(cd "$ROOT" && WORKER_MODEL=sonnet WORKER_EFFORT=medium "$ROOT/scripts/agent-worker.sh" --show 2>&1)"
check "env overrides model and effort" "$out" "model=sonnet effort=medium"

tmp="$(mktemp -d)"; mkdir -p "$tmp/scripts"; cp "$ROOT/scripts/agent-worker.sh" "$ROOT/scripts/agent-config.sh" "$tmp/scripts/"
out="$(cd "$ROOT" && "$tmp/scripts/agent-worker.sh" --show 2>&1)"; rc=$?
check "missing prompt names the file and the fix" "$out" "worker role prompt missing"
check "missing prompt says reinstall" "$out" "reinstall the plugin"
[[ $rc -eq 1 ]] && echo "ok   missing prompt exits 1" || { echo "FAIL missing prompt exit $rc"; fail=1; }
rm -rf "$tmp"

[[ $fail -eq 0 ]] && echo "ok — agent-worker E2E passed" || { echo "FAILED"; exit 1; }
