#!/usr/bin/env bash
# scripts/mr-await.sh: every way the wait can end, driven with a fake GitLab.
#
# The bug it replaces: the wake-up was an until-loop over glab-watch-mr.sh's log. The watcher
# died at 11:16:35, the MR merged at 11:46:52, and the loop waited forever, because a dead
# producer's silence is identical to "still running". So the assertions here are about ENDING:
# every path prints something and exits with a distinct code, including the timeout.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
fail=0
rc=0
ok()  { echo "ok   $1"; }
bad() { echo "FAIL $1"; [ $# -gt 1 ] && echo "     got:  $2"; fail=1; }

# A fake glab whose `api` prints whatever $MR_JSON holds. mr-await.sh goes through gl_api,
# which prefers glab when it is on PATH — so this intercepts the real network.
mkdir -p "$T/bin"
cat > "$T/bin/glab" <<'G'
#!/usr/bin/env bash
[ "${1:-}" = "api" ] || exit 1
printf '%s' "$MR_JSON"
G
chmod +x "$T/bin/glab"
for t in bash sh env git jq python3 grep sed cut tr cat readlink dirname date sleep head printf curl; do
  p="$(command -v "$t")" && ln -sf "$p" "$T/bin/$t"
done

mr() {  # state pipeline merge_status
  printf '{"state":"%s","head_pipeline":{"status":"%s"},"web_url":"http://gl/x/-/merge_requests/7","merge_status":"%s"}' \
    "$1" "$2" "${3:-can_be_merged}"
}

# $rc must survive the command substitution the CALLER wraps this in, so it is written to a
# file rather than a variable: `out="$(await ...)"` runs this in a subshell, and a variable set
# there is gone by the time the caller reads it.
await() {  # MR_JSON, args... -> output on stdout, exit code into $T/rc
  local json="$1"; shift
  local out
  out="$(cd "$ROOT" && MR_JSON="$json" PATH="$T/bin" MR_AWAIT_INTERVAL=1 \
         bash "$ROOT/scripts/mr-await.sh" "$@" 2>&1)"
  printf '%s' "$?" > "$T/rc"
  printf '%s' "$out"
}
rcof() { cat "$T/rc"; }

out="$(await "$(mr merged success)" 7)"
[ "$(rcof)" = 0 ] && ok "merged exits 0" || bad "merged rc=$(rcof)"
[[ "$out" == *"MERGED"* && "$out" == *"!7 merged"* ]] && ok "merged says so and names the MR" || bad "merged text" "$out"

out="$(await "$(mr closed success)" 7)"
[ "$(rcof)" = 1 ] && ok "closed exits 1" || bad "closed rc=$(rcof)"
[[ "$out" == *"CLOSED without merging"* ]] && ok "closed is not confused with merged" || bad "closed text" "$out"

out="$(await "$(mr opened failed)" 7)"
[ "$(rcof)" = 2 ] && ok "red pipeline exits 2" || bad "failed rc=$(rcof)"
[[ "$out" == *"fix it and push again"* ]] && ok "red pipeline says what to do" || bad "failed text" "$out"

out="$(await "$(mr opened canceled)" 7)"
[ "$(rcof)" = 2 ] && ok "canceled counts as red" || bad "canceled rc=$(rcof)"

out="$(await "$(mr opened success cannot_be_merged)" 7)"
[ "$(rcof)" = 3 ] && ok "merge conflict exits 3" || bad "conflict rc=$(rcof)"
[[ "$out" == *"rebase onto the target"* ]] && ok "conflict says what to do" || bad "conflict text" "$out"

# an MR that just sits there: the wait MUST end, with a message
out="$(await "$(mr opened running)" 7 --timeout 2)"
[ "$(rcof)" = 5 ] && ok "an MR that never resolves exits 5, not never" || bad "timeout rc=$(rcof)"
[[ "$out" == *"TIMEOUT after 2s"* ]] && ok "the timeout names how long it waited" || bad "timeout text" "$out"
[[ "$out" == *"Nothing"*"failed and nothing merged"* ]] && ok "the timeout is not reported as a verdict" || bad "timeout verdict" "$out"
[[ "$out" == *"!7 opened"* ]] && ok "the first observation is printed even so" || bad "no first state" "$out"

# --once: report and leave
out="$(await "$(mr opened running)" --once 7)"
[ "$(rcof)" = 0 ] && ok "--once exits 0 without waiting" || bad "once rc=$(rcof)"
[[ "$out" == *"!7 opened · pipeline running"* ]] && ok "--once prints the current state" || bad "once text" "$out"

# cannot reach GitLab: NOT a verdict on the MR. A farm with no glab and no token at all.
mkdir -p "$T/bare"
for t in bash sh env git jq python3 grep sed cut tr cat readlink dirname date sleep head curl; do
  p="$(command -v "$t")" && ln -sf "$p" "$T/bare/$t"
done
out="$(cd "$ROOT" && env -u GITLAB_TOKEN -u GLAB_TOKEN -u CI_JOB_TOKEN \
       GITLAB_TOKEN_GOPASS=nope/definitely-not-here PATH="$T/bare" \
       bash "$ROOT/scripts/mr-await.sh" 7 --timeout 2 2>&1)"; rc=$?
[ "$rc" = 4 ] && ok "unreachable GitLab exits 4" || bad "unreachable rc=$rc" "$out"
[[ "$out" == *"NOT a verdict"* ]] && ok "unreachable says it is not a verdict on the MR" || bad "unreachable text" "$out"
[[ "$out" != *TIMEOUT* ]] && ok "unreachable does not sit through the timeout" || bad "waited anyway" "$out"

# an EMPTY reply is unreachable too, not an open MR that never resolves
out="$(await "" 7 --timeout 2)"
[ "$(rcof)" = 4 ] && ok "an empty API reply exits 4, not a 2s wait" || bad "empty reply rc=$(rcof)" "$out"
[[ "$out" != *"· pipeline  ·"* ]] && ok "no blank state line is printed" || bad "printed a blank state" "$out"

# no iid at all
out="$(cd "$ROOT" && PATH="$T/bin" bash "$ROOT/scripts/mr-await.sh" 2>&1)"; rc=$?
[ "$rc" = 4 ] && [[ "$out" == *"which MR?"* ]] && ok "no iid asks for one" || bad "no iid" "$out (rc=$rc)"

echo; [ $fail -eq 0 ] && echo "mr-await: PASS" || echo "mr-await: FAIL"
exit $fail
