#!/usr/bin/env bash
# E2E for hooks/comment-bloat-gate.py: drives the real hook over stdin and asserts what the
# agent SEES — the deny text has to name the file, the line and the fix, not just exit 0.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
HOOK="$ROOT/hooks/comment-bloat-gate.py"
fail=0
check() { if [[ "$2" == *"$3"* ]]; then echo "ok   $1"; else echo "FAIL $1"; echo "     want: $3"; echo "     got:  $2"; fail=1; fi; }
denied() { [[ "$1" == *'"deny"'* ]]; }

fire() { python3 -c '
import json,sys
print(json.dumps({"tool_input":{"file_path":sys.argv[1],"content":sys.stdin.read()}}))' "$1" | python3 "$HOOK"; }

essay="$(printf '#!/usr/bin/env bash\n'; for i in $(seq 1 20); do echo "# background paragraph line $i"; done; echo 'set -e')"
out="$(printf '%s' "$essay" | fire wat.sh)"
denied "$out" && echo "ok   a 20-line header is denied" || { echo "FAIL essay header allowed"; fail=1; }
check "the deny names the file" "$out" "wat.sh"
check "and where the block starts" "$out" "starting at line 2"
check "and the cap that applies" "$out" "(max 5)"
check "and what to do instead" "$out" "usually WHY, never WHAT"

out="$(printf '#!/usr/bin/env bash\n# one line saying why\nset -e\n' | fire ok.sh)"
[[ -z "$out" ]] && echo "ok   a one-line comment is silent" || { echo "FAIL short comment denied: $out"; fail=1; }

mid="$(printf 'import os\nimport sys\nimport json\nx=1\n'; for i in $(seq 1 6); do echo "# mid-function essay $i"; done; printf 'y=2\n')"
out="$(printf '%s' "$mid" | fire mid.py)"
denied "$out" && echo "ok   6 comment lines inside the code are denied (cap 5)" || { echo "FAIL inline essay allowed"; fail=1; }
check "an inline paragraph is reported the same way" "$out" "6-line comment paragraph"

# A usage listing is reference, not narration: it is indented under a marker, so it must not
# count toward the paragraph cap even when the whole header runs long.
usage="$(printf '#!/usr/bin/env bash\n# What this does, in one line.\n#\n# Usage:\n')"
for i in $(seq 1 12); do usage="$usage$(printf '#   tool.sh --flag-%s\n' "$i")"; done
out="$(printf '%s\nset -e\n' "$usage" | fire usage.sh)"
[[ -z "$out" ]] && echo "ok   an indented usage block does not count as prose" || { echo "FAIL usage block denied: $out"; fail=1; }

out="$(printf '%s' "$essay" | fire notes.md)"
[[ -z "$out" ]] && echo "ok   a prose file is not a code file — skipped" || { echo "FAIL .md denied"; fail=1; }

out="$(python3 -c '
import json
print(json.dumps({"tool_input":{"file_path":"e.py","edits":[{"new_string":"\n".join("# x" for _ in range(12))}]}}))' | python3 "$HOOK")"
denied "$out" && echo "ok   MultiEdit edits are read too" || { echo "FAIL MultiEdit not inspected"; fail=1; }

echo '{"garbage": true}' | python3 "$HOOK" >/dev/null 2>&1 \
  && echo "ok   a malformed event exits 0 without blocking" || { echo "FAIL crashed on bad input"; fail=1; }

[[ $fail -eq 0 ]] && echo "ok — comment-bloat gate E2E passed" || { echo "FAILED"; exit 1; }
