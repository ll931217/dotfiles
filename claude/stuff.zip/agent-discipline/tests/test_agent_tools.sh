#!/usr/bin/env bash
# The optional-tool adapters, with each preferred tool genuinely ABSENT.
#
# Absence is simulated with a symlink farm, not by stripping PATH: glab and curl both live in
# /usr/bin here, so removing that directory removes the fallback's own dependency and the test
# would pass for the wrong reason. The farm holds exactly the tools the fallback may use, and
# the first assertion is that the preferred tool really is gone.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
fail=0
ok()  { echo "ok   $1"; }
bad() { echo "FAIL $1"; [ $# -gt 1 ] && echo "     got:  $2"; fail=1; }

# a PATH with everything the fallbacks need and nothing we are pretending is missing
mkdir -p "$T/bin"
for t in bash sh env git curl python3 jq sed awk grep cut tr cat ls mkdir rm ln mktemp readlink dirname basename date sort head tail wc uname md5sum sleep notify-send tmux crontab; do
  p="$(command -v "$t" 2>/dev/null)" && ln -sf "$p" "$T/bin/$t"
done
FARM="$T/bin"

run_without() {          # run_without <absent-tool> <bash -c script>
  local absent="$1"; shift
  PATH="$FARM" bash -c "command -v $absent >/dev/null && { echo 'SETUP FAIL: $absent still visible'; exit 9; }; $*"
}

# ── glab absent -> REST v4 ────────────────────────────────────────────────────────
out="$(run_without glab ". '$ROOT/scripts/agent-tools.sh'; gl_backend")"
[ "$out" = "REST v4" ] && ok "glab absent: backend reports REST v4" || bad "backend" "$out"

out="$(run_without glab ". '$ROOT/scripts/agent-tools.sh'; gl_project")"
[[ "$out" == *%2F* ]] && ok "project resolves url-encoded without glab ($out)" \
                      || bad "gl_project" "$out"

out="$(run_without glab ". '$ROOT/scripts/agent-tools.sh'; gl_host")"
# http is legitimate here (the internal GitLab serves plain http), so the assertion is a scheme
# plus a host — and NO `user:token@`, which a CI checkout's origin URL carries.
[[ "$out" =~ ^https?://[^@]+$ ]] && ok "host is a URL with no embedded credential ($out)" \
                                 || bad "gl_host" "$out"

# a CI checkout's origin: http, with the job token embedded. The token must not survive.
cred_repo="$(mktemp -d)"; git -C "$cred_repo" init -q
git -C "$cred_repo" remote add origin "http://gitlab-ci-token:s3cret@gitlab.example.corp/grp/repo.git"
out="$(cd "$cred_repo" && env -u GITLAB_HOST PATH="$FARM" bash -c ". '$ROOT/scripts/agent-tools.sh'; gl_host")"
rm -rf "$cred_repo"
[ "$out" = "http://gitlab.example.corp" ] && ok "a credentialed CI remote loses the token, keeps http" \
                                          || bad "gl_host strips credentials" "$out"

# the failure that must never look like "no results": no glab AND no token
out="$(cd "$ROOT" && env -u GITLAB_TOKEN -u GLAB_TOKEN -u CI_JOB_TOKEN \
        GITLAB_TOKEN_GOPASS=nope/definitely-not-here \
        PATH="$FARM" bash -c ". '$ROOT/scripts/agent-tools.sh'; gl_api 'projects/:id'" 2>&1)"
rc=$?
[ $rc -ne 0 ] && ok "no glab and no token exits non-zero" || bad "silent success without a token"
[[ "$out" == *GITLAB_TOKEN* && "$out" == *gopass* ]] \
  && ok "the error names both ways to fix it" || bad "error text" "$out"
[[ "$out" != *'"id"'* ]] && ok "no JSON body on that failure" || bad "printed a body anyway"

# ── wt absent -> git worktree ─────────────────────────────────────────────────────
repo="$T/repo"; mkdir -p "$repo"
( cd "$repo" && git init -q . && git config user.email t@t && git config user.name t \
  && echo x > f && git add -A && git -c commit.gpgsign=false commit -qm c ) >/dev/null

out="$(run_without wt "cd '$repo'; python3 -c \"
import sys; sys.path.insert(0, '$ROOT')
import agent_tools as a
print(a.backend()['worktree']['tool'])\"")"
[ "$out" = "git worktree" ] && ok "wt absent: backend reports git worktree" || bad "worktree backend" "$out"

out="$(run_without wt "cd '$repo'; python3 -c \"
import sys; sys.path.insert(0, '$ROOT')
import agent_tools as a
b, path, err = a.worktree_add('$repo', 'feat/x', '$T/wt-x')
print(b, err)\"")"
[[ "$out" == "git-worktree None" ]] && ok "worktree created via git" || bad "worktree_add" "$out"
[ -d "$T/wt-x" ] && ok "the worktree directory exists" || bad "no worktree on disk"
( cd "$repo" && git branch --list feat/x | grep -q feat/x ) && ok "branch created" || bad "no branch"

out="$(run_without wt "cd '$repo'; python3 -c \"
import sys; sys.path.insert(0, '$ROOT')
import agent_tools as a
b, err = a.worktree_remove('$repo', '$T/wt-x', branch='feat/x')
print(b, err)\"")"
[[ "$out" == "git-worktree None" ]] && ok "worktree removed via git" || bad "worktree_remove" "$out"
[ ! -d "$T/wt-x" ] && ok "directory gone" || bad "worktree left on disk"
( cd "$repo" && ! git branch --list feat/x | grep -q feat/x ) \
  && ok "branch deleted too (git worktree remove alone would leave it)" || bad "branch left behind"

# ── bd absent -> jira, and the narrower answer is LABELLED ────────────────────────
out="$(run_without bd "cd '$repo'; python3 -c \"
import sys; sys.path.insert(0, '$ROOT')
import agent_tools as a
print(a.backend()['tasks']['note'])\"")"
[[ "$out" == *"dependency graph"* ]] && ok "bd absent: the missing check is named, not hidden" \
                                    || bad "tasks note" "$out"

# an explicit JIRA_PY that does not exist must be named, not silently replaced by the default
out="$(run_without bd "cd '$repo'; JIRA_PY=/nonexistent python3 -c \"
import sys; sys.path.insert(0, '$ROOT')
import agent_tools as a
try:
    a.tasks_ready('$repo')
except a.ToolError as e:
    print('raised:', e)\"")"
[[ "$out" == *"/nonexistent"* ]] && ok "a wrong JIRA_PY names the bad path" || bad "JIRA_PY" "$out"

# neither tool at all: HOME moved so no candidate jira.py resolves either
out="$(run_without bd "cd '$repo'; HOME='$T/empty-home' python3 -c \"
import sys; sys.path.insert(0, '$ROOT')
import agent_tools as a
try:
    a.tasks_ready('$repo')
except a.ToolError as e:
    print('raised:', e)\"")"
[[ "$out" == *"install beads"* ]] && ok "neither tool: raises with the next action" || bad "tasks_ready" "$out"

# and the status report still renders with a broken JIRA_PY -- it must not explode
out="$(run_without bd "cd '$repo'; JIRA_PY=/nonexistent python3 -c \"
import sys; sys.path.insert(0, '$ROOT')
import agent_tools as a
print('tool =', a.backend()['tasks']['tool'])\"")"
[[ "$out" == "tool = None" ]] && ok "status report survives a broken JIRA_PY" || bad "backend()" "$out"

# ── the watcher, driven for real with glab absent and no token ────────────────────
# It used to die on its own first line (set -e -o pipefail + a suppressed error) and print
# NOTHING with exit 1, which reads identically to "no MR found".
out="$(cd "$ROOT" && env -u GITLAB_TOKEN -u GLAB_TOKEN -u CI_JOB_TOKEN \
        GITLAB_TOKEN_GOPASS=nope/definitely-not-here PATH="$FARM" \
        bash "$ROOT/scripts/glab-watch-mr.sh" --once 2>&1)"
rc=$?
[ "$rc" = 4 ] && ok "watcher exits 4 (cannot ask), not 1 (no MR)" || bad "watcher exit" "rc=$rc"
[[ "$out" == *"NOT 'no MR'"* ]] && ok "watcher says the query failed, not that no MR exists" \
                               || bad "watcher message" "$out"
[[ -n "$out" ]] && ok "watcher is not silent" || bad "watcher printed nothing"

echo; [ $fail -eq 0 ] && echo "agent tools: PASS" || echo "agent tools: FAIL"
exit $fail
