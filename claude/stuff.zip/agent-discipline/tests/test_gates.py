"""The two destructive scripts must refuse. Run: python3 tests/test_gates.py"""
import importlib.util, os, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def load(name):
    path = os.path.join(ROOT, "scripts", name + ".py")
    spec = importlib.util.spec_from_file_location(name.replace("-", "_"), path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

am, reap = load("mr-automerge"), load("worktree-reap")

def mr(**over):
    base = dict(iid=1, title="docs: tidy readme", draft=False, has_conflicts=False,
                blocking_discussions_resolved=True, detailed_merge_status="mergeable",
                head_pipeline={"status": "success"}, labels=[])
    base.update(over)
    return base

def changes(paths):
    am.api = lambda repo, path: {"changes": [{"new_path": p, "diff": "+x\n"} for p in paths]}

# --- eligibility gate -------------------------------------------------------
changes(["README.md"])
ok, why, *_ = am.assess(".", mr(), 10, 200)
assert ok, why

for over, expect in [
    (dict(draft=True), "draft"),
    (dict(has_conflicts=True), "conflicts"),
    (dict(blocking_discussions_resolved=False), "unresolved"),
    (dict(head_pipeline={}), "absent is not a pass"),
    (dict(head_pipeline={"status": "failed"}), "pipeline failed"),
    (dict(detailed_merge_status="checking"), "merge status"),
    (dict(labels=["do-not-merge"]), "do-not-merge"),
]:
    ok, why, *_ = am.assess(".", mr(**over), 10, 200)
    assert not ok and any(expect in w for w in why), (over, why)

for paths, expect in [
    ([".gitlab-ci.yml"], "CI configuration"),
    (["db/migrations/001.sql"], "database migration"),
    (["uv.lock"], "dependency manifest"),
    (["Dockerfile"], "container build"),
    (["terraform/main.tf"], "infrastructure"),
    ([".env.example"], "possible secret"),
]:
    changes(paths)
    ok, why, *_ = am.assess(".", mr(title="chore: bump"), 10, 200)
    assert not ok and any(expect in w for w in why), (paths, why)

# title alone is a claim; the paths are the evidence — both must hold
changes(["src/app.py"])
ok, why, *_ = am.assess(".", mr(title="feat: add thing"), 10, 200)
assert not ok and any("title is not" in w for w in why), why
ok, why, *_ = am.assess(".", mr(title="chore: bump timeout"), 10, 200)
assert not ok and any("non-docs path: src/app.py" in w for w in why), why
changes(["README.md"])
ok, why, *_ = am.assess(".", mr(title="feat: docs only but wrong prefix"), 10, 200)
assert not ok and any("title is not" in w for w in why), why

changes([f"doc{i}.md" for i in range(11)])
ok, why, *_ = am.assess(".", mr(), 10, 200)
assert not ok and any("> 10" in w for w in why), why

# --- reap verdict: fails closed --------------------------------------------
def stub(mrs, dirty="", ahead="", status_rc=0):
    reap.mr_states = lambda repo, br: mrs
    def sh(cmd, cwd=None, timeout=90):
        if "status" in cmd:
            return status_rc, dirty, ""
        return 0, ahead, ""
    reap.sh = sh

wt = {"branch": "feat/x", "path": "/tmp/wt"}
stub(None)
assert reap.verdict(".", wt) == (False, "could not query MRs — UNKNOWN, not reaped")
stub([])
assert not reap.verdict(".", wt)[0]
stub([(1, "opened")])
assert "still open" in reap.verdict(".", wt)[1]
stub([(1, "closed")])
assert "without merging" in reap.verdict(".", wt)[1]
stub([(1, "merged")], dirty="M a.py")
assert "uncommitted" in reap.verdict(".", wt)[1]
stub([(1, "merged")], ahead="abc123 wip")
assert "not on origin" in reap.verdict(".", wt)[1]
stub([(1, "merged")], status_rc=1)
assert "cannot read" in reap.verdict(".", wt)[1]
stub([(1, "merged")])
ok, reason = reap.verdict(".", wt)
assert ok and "merged" in reason, reason
for br in reap.PROTECTED:
    assert not reap.verdict(".", {"branch": br, "path": "/tmp/wt"})[0]

# --- the surface says what to do (UX obviousness) ---------------------------
r = subprocess.run([sys.executable, os.path.join(ROOT, "scripts", "mr-automerge.py"),
                    "--repo", ROOT, "--merge", "1"], capture_output=True, text=True)
assert r.returncode == 1, r
assert "--yes" in r.stdout and "shared branch" in r.stdout, r.stdout

r = subprocess.run([sys.executable, os.path.join(ROOT, "scripts", "worktree-reap.py"), "--help"],
                   capture_output=True, text=True)
assert "default: dry run" in r.stdout, r.stdout

print("ok — gate assertions passed")
