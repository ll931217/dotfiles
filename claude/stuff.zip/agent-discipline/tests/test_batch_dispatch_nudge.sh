#!/usr/bin/env bash
# E2E for hooks/batch-dispatch-nudge.py. The gap it covers: both other orchestration guards
# need a worktree to already exist, so a session handed a batch that never dispatches is never
# nudged and implements the lot itself. Text alone must not fire — a batch-shaped sentence with
# no ids and no ready beads is a sentence, not a batch.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
HOOK="$ROOT/hooks/batch-dispatch-nudge.py"
T="$(mktemp -d)"; trap 'rm -rf "$T" "$HOME/.claude/tmp/batch-dispatch-nudge/t-"*.done' EXIT
fail=0
ok()  { echo "ok   $1"; }
bad() { echo "FAIL $1"; [ $# -gt 1 ] && echo "     got:  ${2:-<empty>}"; fail=1; }

REPO="$T/repo"
git init -q "$REPO" && git -C "$REPO" -c user.name=t -c user.email=t@t commit -q --allow-empty -m init
export PATH="$T/bin:$PATH"; mkdir -p "$T/bin"
printf '#!/bin/sh\nexit 1\n' > "$T/bin/bd"; chmod +x "$T/bin/bd"   # no beads => no ready items

fire() {   # sid, prompt, cwd -> nudge text (empty when silent)
  jq -nc --arg s "$1" --arg p "$2" --arg w "$3" \
    '{session_id:$s,cwd:$w,prompt:$p}' | python3 "$HOOK" \
  | jq -r '.hookSpecificOutput.additionalContext // ""' 2>/dev/null
}

# ── silent cases ──────────────────────────────────────────────────────────────────
out="$(fire t-a 'fix the login bug in auth.py' "$REPO")"
[ -z "$out" ] && ok "a single plain task is silent" || bad "single task fired" "$out"

out="$(fire t-b 'work through these tasks' "$REPO")"
[ -z "$out" ] && ok "batch words with no ids and no ready beads stay silent" || bad "text alone fired" "$out"

out="$(fire t-c '/orchestrate DE-1 and DE-2' "$REPO")"
[ -z "$out" ] && ok "already invoking /orchestrate is silent" || bad "orchestrate fired" "$out"

mkdir -p "$REPO/.worktrees/w/.claude"
echo '{"status":"assigned"}' > "$REPO/.worktrees/w/.claude/delegate.json"
out="$(fire t-d 'do DE-1 and DE-2' "$REPO")"
[ -z "$out" ] && ok "silent once a worker is already active" || bad "fired with worker active" "$out"
rm -rf "$REPO/.worktrees"

# ── the true positive ─────────────────────────────────────────────────────────────
out="$(fire t-e 'please implement DE-452 and DE-455 today' "$REPO")"
[[ "$out" == *"hands over 2 tasks"* ]] && ok "two ids fire the nudge" || bad "two ids" "$out"
[[ "$out" == *"/orchestrate"* ]] && ok "the nudge names the command to run" || bad "no command named" "$out"
[[ "$out" == *"workers type"* ]] && ok "it states the role split" || bad "no role split" "$out"

out="$(fire t-e 'and also DE-460 and DE-461' "$REPO")"
[ -z "$out" ] && ok "it says this once per session, not every prompt" || bad "repeated" "$out"

[ $fail -eq 0 ] && echo "PASS" || echo "FAILURES"
exit $fail
