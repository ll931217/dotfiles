"""Characterization tests: what the ledger hook does TODAY, pinned before anything changes it.

These assert current behaviour, not desired behaviour. Spec §2 forbids altering unclear existing
behaviour without characterizing it first, and the gap analysis records an open conflict (C1)
about whether the deny should survive Phase 4's shadow mode. Until that is decided, this file is
the record of what "unchanged" means — if a change here goes red, that is the conflict surfacing,
not a flaky test.

The hook is driven as a SUBPROCESS, the way Claude Code runs it: `#!/usr/bin/env python3`, the
system interpreter, against a throwaway memory directory. Nothing here touches the user's real
ledger.
"""
import json
import os
import subprocess
import sys
import textwrap

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HOOK = os.path.join(ROOT, "hooks", "pref-checkpoint.py")

RECORD = textwrap.dedent("""\
    ---
    description: "worktree instead of a branch when starting new work"
    triggers: "worktree, worktrunk, branch, checkout"
    metadata:
      confidence: stated
    ---

    **Preference:** start new work in a worktree, never `git checkout -b` in the main checkout.

    **Chose:** a worktree per unit of work
    **Over:** branching inside the single main checkout

    **Why:** stated by the user.

    **Does NOT apply when:** the branch is already checked out.
    """)


@pytest.fixture
def ledger(tmp_path):
    """A throwaway memory directory with one record, plus a runner for the hook."""
    mem = tmp_path / "memory"
    (mem / "topics").mkdir(parents=True)
    (mem / "topics" / "pref-worktree-not-branch.md").write_text(RECORD)

    def run(payload, state_home=None, deny=None):
        env = dict(os.environ)
        env["AGENT_DISCIPLINE_MEMORY_DIR"] = str(mem)
        env["AGENT_DISCIPLINE_CONFIG"] = str(tmp_path / "no-such-config.env")
        if deny is not None:
            env["LCG_ASK_DENY"] = "1" if deny else "0"
        env["HOME"] = str(state_home or tmp_path / "home")
        os.makedirs(env["HOME"], exist_ok=True)
        p = subprocess.run([sys.executable, HOOK], input=json.dumps(payload),
                           capture_output=True, text=True, timeout=60, env=env)
        return p

    run.mem = mem
    return run


def ask(question="Should I create a worktree or just branch?", header="Worktree",
        options=(("worktree", "one per task"), ("branch", "in the main checkout"))):
    return {
        "tool_name": "AskUserQuestion",
        "session_id": "sess-1",
        "tool_input": {"questions": [{
            "question": question, "header": header,
            "options": [{"label": l, "description": d} for l, d in options]}]},
    }


def decision(proc):
    """The permissionDecision the hook emitted, or None when it stayed silent (= allow)."""
    if not proc.stdout.strip():
        return None
    return json.loads(proc.stdout)["hookSpecificOutput"].get("permissionDecision")


# --- allowing ---------------------------------------------------------------------------

def test_silent_when_the_ledger_has_nothing_to_say(ledger, tmp_path):
    os.remove(ledger.mem / "topics" / "pref-worktree-not-branch.md")
    p = ledger(ask())
    assert p.returncode == 0
    assert p.stdout.strip() == "", "an empty ledger must never deny"


def test_silent_for_a_tool_that_is_not_askuserquestion(ledger):
    p = ledger({"tool_name": "Bash", "session_id": "s", "tool_input": {"command": "ls"}})
    assert p.returncode == 0 and p.stdout.strip() == ""


def test_silent_when_the_question_text_is_empty(ledger):
    p = ledger({"tool_name": "AskUserQuestion", "session_id": "s",
                "tool_input": {"questions": [{"question": "", "header": "", "options": []}]}})
    assert p.stdout.strip() == ""


def test_silent_on_malformed_input(ledger):
    env = dict(os.environ, AGENT_DISCIPLINE_MEMORY_DIR=str(ledger.mem))
    p = subprocess.run([sys.executable, HOOK], input="not json",
                       capture_output=True, text=True, timeout=60, env=env)
    assert p.returncode == 0 and p.stdout.strip() == "", "bad input must degrade, not crash"


def test_an_unrelated_question_scores_below_the_threshold(ledger):
    p = ledger(ask(question="What colour should the button be?", header="Colour",
                   options=(("blue", "calm"), ("red", "loud"))))
    assert decision(p) is None, "the matcher must have a path to staying silent"


# --- informing: the DEFAULT since 2026-09-03 (gap-analysis C1, user chose B) ---------------
#
# The spec's own AskUserQuestion interception emits only permissionDecision "allow" (§18.9) and
# its Phase 4 exit criterion is "no question is suppressed". These pin that.

def test_by_default_a_matching_record_informs_and_does_not_deny(ledger):
    p = ledger(ask())
    assert decision(p) == "allow", "the default must never suppress a question"


def test_informing_carries_the_records_content_not_just_its_name(ledger):
    out = json.loads(ledger(ask()).stdout)["hookSpecificOutput"]
    ctx = out["additionalContext"]
    assert "start new work in a worktree" in ctx, "rule AS1: carry the content, not the filename"
    assert "**Over:** branching inside" in ctx, "the rejected option is the derivable half"
    assert "pref-worktree-not-branch.md" in ctx
    assert "confidence: stated" in ctx
    assert "NOT blocked" in ctx, "the model must know the user is still being asked"
    assert "permissionDecisionReason" not in out, "a reason belongs to a denial, not to informing"


def test_informing_repeats_every_time_because_nothing_was_suppressed(ledger, tmp_path):
    home = tmp_path / "home1"
    assert decision(ledger(ask(), state_home=home)) == "allow"
    assert decision(ledger(ask(), state_home=home)) == "allow", \
        "seen-state is a deny-mode concept; informing has nothing to de-duplicate"


def test_a_broken_config_does_not_resurrect_blocking(ledger, tmp_path):
    """If config.py cannot be imported the hook must fail toward informing, never toward deny."""
    env = dict(os.environ, AGENT_DISCIPLINE_MEMORY_DIR=str(ledger.mem),
               HOME=str(tmp_path / "h"), PYTHONPATH=str(tmp_path / "empty"))
    os.makedirs(env["HOME"], exist_ok=True)
    (tmp_path / "empty").mkdir(exist_ok=True)
    p = subprocess.run([sys.executable, HOOK], input=json.dumps(ask()),
                       capture_output=True, text=True, timeout=60, env=env)
    assert decision(p) != "deny"


# --- denying: the LEGACY path, still available behind LCG_ASK_DENY=1 -----------------------

def test_the_legacy_flag_still_denies_the_first_time(ledger):
    assert decision(ledger(ask(), deny=True)) == "deny"


def test_the_legacy_denial_states_its_escape_hatch(ledger):
    reason = json.loads(ledger(ask(), deny=True).stdout)["hookSpecificOutput"]["permissionDecisionReason"]
    assert "re-issue the SAME question" in reason, "a gate with no way through is a wall"


def test_the_legacy_path_allows_a_reissue(ledger, tmp_path):
    home = tmp_path / "home2"
    assert decision(ledger(ask(), state_home=home, deny=True)) == "deny"
    assert decision(ledger(ask(), state_home=home, deny=True)) is None, \
        "challenge-once-then-allow: a genuine question costs one round trip, never a wall"


def test_the_legacy_path_challenges_a_new_session_again(ledger, tmp_path):
    home = tmp_path / "home3"
    assert decision(ledger(ask(), state_home=home, deny=True)) == "deny"
    assert decision(ledger(dict(ask(), session_id="sess-2"), state_home=home, deny=True)) == "deny"


# --- the audit trail --------------------------------------------------------------------

def test_informing_is_logged_under_its_own_kind(ledger, tmp_path):
    """`inform` is deliberately NOT `deny`. The question still reached the user, so summing the
    two would report prevented asks that never happened (canon EF5)."""
    ledger(ask(), state_home=tmp_path / "h4")
    rows = (ledger.mem / "pref_events.tsv").read_text().splitlines()
    assert rows[0].split("\t") == ["ts", "kind", "session", "detail", "extra"], \
        "the dashboard reads these columns; append only, never reorder"
    assert [r.split("\t")[1] for r in rows[1:]] == ["inform"]


def test_the_legacy_path_logs_a_denial_then_a_reissue(ledger, tmp_path):
    home = tmp_path / "h5"
    ledger(ask(), state_home=home, deny=True)
    ledger(ask(), state_home=home, deny=True)
    rows = (ledger.mem / "pref_events.tsv").read_text().splitlines()
    assert [r.split("\t")[1] for r in rows[1:]] == ["deny", "reissued"]


def test_nothing_is_logged_when_the_ledger_stays_silent(ledger):
    ledger({"tool_name": "Bash", "session_id": "s", "tool_input": {"command": "ls"}})
    assert not (ledger.mem / "pref_events.tsv").exists()


# --- the flag surface -------------------------------------------------------------------

def test_every_new_behaviour_flag_defaults_off(monkeypatch, tmp_path):
    # A clean environment means no user config either: a real ~/.config/agent-discipline.env
    # turning a flag on is the user's choice, not a broken default.
    monkeypatch.setenv("AGENT_DISCIPLINE_CONFIG", str(tmp_path / "none.env"))
    sys.path.insert(0, ROOT)
    import config, importlib
    importlib.reload(config)
    for name in config.MUST_DEFAULT_OFF:
        monkeypatch.delenv(name, raising=False)
        assert config.FLAGS[name][0] == "0", f"{name} must ship off"
        assert not config.on(name), f"{name} resolved on with a clean environment"


def test_the_ask_hook_defaults_to_informing_not_denying():
    """Changed deliberately on 2026-09-03 (gap-analysis C1). The spec's AskUserQuestion hook never
    denies at any autonomy level, and hooks here inform rather than block."""
    sys.path.insert(0, ROOT)
    import config
    assert not config.on("LCG_ASK_DENY"), "the default must not block a question"
    assert config.mode() == "observe"


def test_config_is_importable_under_the_interpreter_hooks_actually_use():
    """Risk R1: hooks run as `#!/usr/bin/env python3` (3.12 here), not the uv env (3.14)."""
    p = subprocess.run(["/usr/bin/env", "python3", "-c",
                        f"import sys; sys.path.insert(0, {ROOT!r}); import config; "
                        "print(config.mode())"],
                       capture_output=True, text=True, timeout=60)
    assert p.returncode == 0, f"config.py must import on the hook interpreter:\n{p.stderr}"
    assert p.stdout.strip() == "observe"
