"""Documentation drift, end to end in a throwaway git repo: the three states, and the nudge
text a human actually sees at the edit. Drives the real CLI and the real hook."""
import json
import os
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
DRIFT = os.path.join(ROOT, "scripts", "docs-drift.py")
HOOK = os.path.join(ROOT, "hooks", "docs-drift-nudge.py")


def sh(*args, cwd):
    r = subprocess.run(args, cwd=cwd, capture_output=True, text=True)
    assert r.returncode == 0, f"{args}: {r.stderr}"
    return r.stdout


def repo(tmp_path):
    d = tmp_path / "repo"
    (d / "scripts").mkdir(parents=True)
    (d / "docs").mkdir()
    sh("git", "init", "-q", cwd=d)
    sh("git", "config", "user.email", "t@t", cwd=d)
    sh("git", "config", "user.name", "t", cwd=d)
    return d


def commit(d, msg="c"):
    sh("git", "add", "-A", cwd=d)
    sh("git", "-c", "commit.gpgsign=false", "commit", "-q", "-m", msg, cwd=d)


def drift(d, *args):
    r = subprocess.run([sys.executable, DRIFT, "-C", str(d), *args],
                       capture_output=True, text=True)
    return r


def report(d):
    return json.loads(drift(d, "--json").stdout)


def bind(d, doc="docs/feature.md", refs=("scripts/feature.py",)):
    body = "---\ncode_refs:\n" + "".join(f"  - {r}\n" for r in refs) + "---\n\nthe doc.\n"
    (d / doc).write_text(body)


def test_no_bindings_is_reported_as_nothing_checked_not_as_a_pass(tmp_path):
    d = repo(tmp_path)
    (d / "scripts" / "feature.py").write_text("x = 1\n")
    (d / "docs" / "feature.md").write_text("# no frontmatter\n")
    commit(d)
    out = drift(d).stdout
    assert "NOTHING is checked" in out and "not a pass" in out
    assert report(d)["docs_with_bindings"] == 0


def test_code_newer_than_its_doc_is_stale_and_names_the_file(tmp_path):
    d = repo(tmp_path)
    (d / "scripts" / "feature.py").write_text("x = 1\n")
    bind(d)
    commit(d, "doc and code together")
    assert report(d)["stale"] == 0, "committed together is in sync"

    time.sleep(1.1)                     # git commit timestamps are whole seconds
    (d / "scripts" / "feature.py").write_text("x = 2\n")
    commit(d, "code only")
    r = report(d)
    assert r["stale"] == 1
    assert r["stale_docs"]["docs/feature.md"] == ["scripts/feature.py"]
    assert "scripts/feature.py" in drift(d).stdout


def test_uncommitted_code_makes_its_doc_stale_before_any_commit(tmp_path):
    d = repo(tmp_path)
    (d / "scripts" / "feature.py").write_text("x = 1\n")
    bind(d)
    commit(d)
    (d / "scripts" / "feature.py").write_text("x = 2\n")
    assert report(d)["stale"] == 1
    out = drift(d, "--changed").stdout
    assert "STALE" in out and "docs/feature.md" in out


def test_editing_the_doc_too_clears_the_drift(tmp_path):
    d = repo(tmp_path)
    (d / "scripts" / "feature.py").write_text("x = 1\n")
    bind(d)
    commit(d)
    (d / "scripts" / "feature.py").write_text("x = 2\n")
    (d / "docs" / "feature.md").write_text(
        (d / "docs" / "feature.md").read_text() + "\nnow it says x = 2.\n")
    assert report(d)["stale"] == 0


def test_a_ref_pointing_at_nothing_is_reported_as_broken(tmp_path):
    d = repo(tmp_path)
    (d / "scripts" / "feature.py").write_text("x = 1\n")
    bind(d, refs=("scripts/renamed_away.py",))
    commit(d)
    r = report(d)
    assert r["broken_refs"] == 1
    assert r["broken_ref_docs"]["docs/feature.md"] == ["scripts/renamed_away.py"]
    assert "renamed_away.py" in drift(d).stdout


def test_code_no_doc_claims_is_unbound(tmp_path):
    d = repo(tmp_path)
    (d / "scripts" / "feature.py").write_text("x = 1\n")
    (d / "scripts" / "orphan.py").write_text("y = 1\n")
    bind(d)
    commit(d)
    r = report(d)
    assert r["unbound_files"] == ["scripts/orphan.py"]
    assert "scripts/orphan.py" in drift(d, "--unbound").stdout


def test_strict_gates_only_when_asked(tmp_path):
    d = repo(tmp_path)
    (d / "scripts" / "feature.py").write_text("x = 1\n")
    bind(d)
    commit(d)
    (d / "scripts" / "feature.py").write_text("x = 2\n")
    assert drift(d).returncode == 0, "the report never gates"
    assert drift(d, "--strict").returncode == 1


# ── the hook: what a human actually sees at the moment of the edit ────────────────
def nudge(d, path, session, tmp_home):
    ev = {"session_id": session, "tool_name": "Edit", "tool_input": {"file_path": str(path)}}
    r = subprocess.run([sys.executable, HOOK], input=json.dumps(ev), capture_output=True,
                       text=True, env=dict(os.environ, HOME=str(tmp_home)))
    if not r.stdout.strip():
        return ""
    return json.loads(r.stdout)["hookSpecificOutput"]["additionalContext"]


def test_nudge_names_the_doc_and_the_next_action(tmp_path):
    d = repo(tmp_path)
    (d / "scripts" / "feature.py").write_text("x = 1\n")
    bind(d)
    commit(d)
    msg = nudge(d, d / "scripts" / "feature.py", "s-bound", tmp_path / "home")
    assert "docs/feature.md" in msg, msg
    assert "/docs" in msg and "Update it in this session" in msg


def test_nudge_is_silent_the_second_time_for_the_same_file(tmp_path):
    d = repo(tmp_path)
    (d / "scripts" / "feature.py").write_text("x = 1\n")
    bind(d)
    commit(d)
    home = tmp_path / "home"
    assert nudge(d, d / "scripts" / "feature.py", "s-dedup", home)
    assert nudge(d, d / "scripts" / "feature.py", "s-dedup", home) == ""


def test_nudge_goes_quiet_once_the_doc_itself_is_edited(tmp_path):
    d = repo(tmp_path)
    (d / "scripts" / "feature.py").write_text("x = 1\n")
    bind(d)
    commit(d)
    home = tmp_path / "home"
    assert nudge(d, d / "docs" / "feature.md", "s-order", home) == "", "doc edits never nudge"
    assert nudge(d, d / "scripts" / "feature.py", "s-order", home) == ""


def test_nudge_on_unbound_code_asks_for_a_doc_and_shows_the_frontmatter(tmp_path):
    d = repo(tmp_path)
    (d / "scripts" / "orphan.py").write_text("y = 1\n")
    bind(d)
    commit(d)
    msg = nudge(d, d / "scripts" / "orphan.py", "s-unbound", tmp_path / "home")
    assert "No document claims scripts/orphan.py" in msg
    assert "code_refs:" in msg and "- scripts/orphan.py" in msg


def test_a_top_level_module_is_real_code_not_a_broken_binding(tmp_path):
    """The checker used to scan only the code roots, so a doc pointing at a root-level module
    was reported as BROKEN -- the checker accusing the doc of its own blind spot."""
    d = repo(tmp_path)
    (d / "paths.py").write_text("x = 1\n")
    (d / "README.md").write_text("# prose, not a feature\n")
    bind(d, refs=("paths.py",))
    commit(d)
    r = report(d)
    assert r["broken_refs"] == 0
    assert r["bound"] == 1
    assert "README.md" not in r["unbound_files"], "root prose is not undocumented code"
    assert "paths.py" in drift(d, "--for", str(d / "paths.py")).stdout


def test_engine_tree_counts_and_test_scripts_do_not(tmp_path):
    """engine/ is where a kit keeps its deployed code (memory-kit copies engine/scripts and
    engine/hooks into ~/.claude). A test named as a FILE beside real scripts is not a feature:
    SKIP_PARTS only prunes directories, so scripts/test-thing.sh used to be reported as
    undocumented and buried the real findings."""
    d = repo(tmp_path)
    (d / "engine" / "hooks").mkdir(parents=True)
    (d / "engine" / "hooks" / "real.sh").write_text("echo hi\n")
    (d / "scripts" / "test-thing.sh").write_text("echo test\n")
    (d / "scripts" / "feature.py").write_text("x = 1\n")
    bind(d, refs=("engine/hooks/real.sh",))
    commit(d)
    r = report(d)
    assert r["bound"] == 1 and r["broken_refs"] == 0, "engine/ must be visible"
    assert "scripts/test-thing.sh" not in r["unbound_files"]
    assert "scripts/feature.py" in r["unbound_files"], "real code is still reported"
