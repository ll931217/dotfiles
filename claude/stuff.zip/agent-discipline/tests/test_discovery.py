"""Phase 3 exit criteria: new scope produces M1+, unchanged context is not re-injected,
concurrent observations keep a valid receipt chain, and state survives compaction."""
from __future__ import annotations

import json
import os
import subprocess
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from ledger.coverage import (CoverageStore, ContextCoverage, fingerprint,   # noqa: E402
                             is_mutating, operation_for)
from ledger.delta import diff                                               # noqa: E402
from ledger.discovery import ScopeFrontier, extract, normalize, terms_from  # noqa: E402
from ledger.resolver import ResolutionRequest, Resolver                     # noqa: E402
from ledger.session import SessionState                                     # noqa: E402
from ledger.types import LedgerEntry, Lifecycle, RetrievalMetadata, Scope    # noqa: E402
from ledger.adapters import Adapter, KnowledgeCandidate, SourceHealth        # noqa: E402

DISCOVER = os.path.join(ROOT, "hooks", "lcg-discover.py")
REHYDRATE = os.path.join(ROOT, "hooks", "lcg-rehydrate.py")


# --- deterministic extraction ------------------------------------------------------------

def test_extraction_finds_the_entity_types_that_matter():
    got = {(e["type"], e["id"]) for e in extract(
        'File "src/loader.py", line 4\n'
        'cur.execute("SELECT * FROM prod_settlement")\n'
        "ValueError: bad\nFAILED tests/test_x.py::test_loads\nGET /users/12/orders\n")}
    assert ("path", "src/loader.py") in got
    assert ("table", "prod_settlement") in got
    assert ("error_type", "ValueError") in got
    assert ("endpoint", "/users/{id}/orders") in got, "ids must normalize or every row is an entity"


def test_a_python_import_is_not_a_sql_table():
    """Measured: with a case-insensitive FROM, `from settlement.core import Loader` invented a
    table called settlement.core. A phantom table looks authoritative and pulls the wrong rule."""
    got = {(e["type"], e["id"]) for e in extract("from settlement.core import Loader")}
    assert ("module", "settlement.core") in got
    assert ("table", "settlement.core") not in got


def test_extraction_is_deterministic():
    text = 'File "a/b.py"\nFROM orders\nTypeError: x'
    assert extract(text) == extract(text)


def test_extraction_is_bounded():
    assert len(extract("\n".join(f'File "d/f{i}.py"' for i in range(500)), limit=10)) == 10


def test_normalization_rejects_noise():
    assert normalize("table", "SELECT") is None
    assert normalize("path", "./src/../src/a.py") == "src/a.py"
    assert normalize("symbol", "ab") is None


# --- the scope frontier ---------------------------------------------------------------------

def test_a_second_sighting_is_not_a_new_entity():
    f = ScopeFrontier()
    ents = extract('File "src/a.py"')
    assert len(f.observe(ents, "t1", "t0")) == 1
    assert f.observe(ents, "t2", "t1") == [], "unchanged frontier -> no delta -> no injection"
    assert f.all()[0].latest_observed == "t1", "a repeat updates the sighting, not the count"


def test_a_frontier_entry_carries_what_the_spec_requires():
    f = ScopeFrontier()
    fe = f.observe(extract('File "src/a.py"'), "toolcall-1", "t0", scopes=["repo:x"])[0]
    for field in ("entity_id", "entity_type", "source_tool_use", "confidence",
                  "first_observed", "latest_observed", "related_scopes",
                  "has_mutation_coverage", "context_injected"):
        assert hasattr(fe, field)
    assert fe.confidence == "deterministic"


def test_the_frontier_round_trips_through_session_state():
    f = ScopeFrontier()
    f.observe(extract('File "src/a.py"\nFROM orders'), "t", "t0")
    assert ScopeFrontier.from_list(f.to_list()).keys() == f.keys()


def test_frontier_terms_reach_retrieval():
    f = ScopeFrontier()
    f.observe(extract("FROM prod_settlement"), "t", "t0")
    assert "prod_settlement" in " ".join(terms_from(f)) or "settlement" in terms_from(f)


# --- manifest deltas --------------------------------------------------------------------------

class Fake(Adapter):
    def __init__(self, name, cands):
        self.name, self._c = name, cands

    def health(self):
        return SourceHealth(self.name, True, "", len(self._c))

    def query(self, req):
        return self._c


def E(eid, authority="explicit_human_preference", statement=None, kind="preference",
      autonomy="default"):
    return LedgerEntry(id=eid, version=1, kind=kind, subject=eid, statement=statement or eid,
                       scope=Scope(), authority=authority, status="active", autonomy=autonomy,
                       risk="low", created_by="t", created_at="2026-01-01",
                       retrieval=RetrievalMetadata(), lifecycle=Lifecycle(created_at="x"))


def req(**kw):
    base = dict(request_id="r", trigger="t", actor="u", repository="r", session="s", task="task")
    base.update(kw)
    return ResolutionRequest(**base)


def test_an_identical_manifest_produces_a_no_op_delta():
    src = Fake("s", [KnowledgeCandidate("s", "a", E("a"), "lexical_fallback")])
    r = Resolver([src])
    m0 = r.resolve(req())
    m1 = r.resolve(req(), parent=m0)
    d = diff(m0, m1, "s1", "PostToolUse")
    assert d.no_op and d.render() == "", "a no-op must be silent, not a note saying nothing changed"


def test_new_scope_produces_a_material_delta_at_the_next_revision():
    a = Fake("s", [KnowledgeCandidate("s", "a", E("a"), "lexical_fallback")])
    m0 = Resolver([a]).resolve(req())
    b = Fake("s", [KnowledgeCandidate("s", "a", E("a"), "lexical_fallback"),
                   KnowledgeCandidate("s", "b", E("b", statement="new rule"), "scope_match")])
    m1 = Resolver([b]).resolve(req(), parent=m0)
    d = diff(m0, m1, "s1", "PostToolBatch", discovered=["path:src/a.py"])
    assert not d.no_op
    assert (d.from_revision, d.to_revision) == (0, 1)
    assert [i["id"] for i in d.added] == ["b"]
    assert "new rule" in d.render() and "src/a.py" in d.render()


def test_an_unchanged_entry_is_not_in_the_delta():
    a = Fake("s", [KnowledgeCandidate("s", "keep", E("keep"), "lexical_fallback")])
    m0 = Resolver([a]).resolve(req())
    b = Fake("s", [KnowledgeCandidate("s", "keep", E("keep"), "lexical_fallback"),
                   KnowledgeCandidate("s", "fresh", E("fresh"), "lexical_fallback")])
    d = diff(m0, Resolver([b]).resolve(req(), parent=m0), "s1", "t")
    assert [i["id"] for i in d.added] == ["fresh"], "P3-18: unchanged context is not re-injected"


def test_a_changed_statement_counts_as_changed_even_with_the_same_id():
    a = Fake("s", [KnowledgeCandidate("s", "x", E("x", statement="old"), "lexical_fallback")])
    m0 = Resolver([a]).resolve(req())
    b = Fake("s", [KnowledgeCandidate("s", "x", E("x", statement="new"), "lexical_fallback")])
    d = diff(m0, Resolver([b]).resolve(req(), parent=m0), "s1", "t")
    assert [i["id"] for i in d.added] == ["x"], "the text is what the model acts on"


def test_a_removed_entry_is_reported():
    a = Fake("s", [KnowledgeCandidate("s", "gone", E("gone"), "lexical_fallback")])
    m0 = Resolver([a]).resolve(req())
    d = diff(m0, Resolver([Fake("s", [])]).resolve(req(), parent=m0), "s1", "t")
    assert [i["id"] for i in d.removed] == ["gone"] and not d.no_op


def test_a_changed_autonomy_boundary_is_material():
    a = Fake("s", [KnowledgeCandidate("s", "x", E("x", autonomy="advisory"), "lexical_fallback")])
    m0 = Resolver([a]).resolve(req())
    b = Fake("s", [KnowledgeCandidate("s", "x", E("x", autonomy="advisory"), "lexical_fallback"),
                   KnowledgeCandidate("s", "y", E("y", autonomy="never_auto_apply"),
                                      "lexical_fallback")])
    d = diff(m0, Resolver([b]).resolve(req(), parent=m0), "s1", "t")
    assert d.autonomy_boundary_changed == "never_auto_apply"
    assert "Autonomy boundary is now" in d.render()


# --- coverage: recorded, never enforced --------------------------------------------------------

def test_coverage_never_expresses_a_denial():
    """Mutation blocking is Phase 7. This phase must not be able to express it by accident."""
    import dataclasses
    from ledger.coverage import CoverageDecision
    assert "deny" not in {f.name for f in dataclasses.fields(CoverageDecision)}
    src = open(os.path.join(ROOT, "ledger", "coverage.py")).read()
    assert "permissionDecision" not in src


def test_an_uncovered_mutation_is_recorded_and_reported_not_blocked():
    d = CoverageStore().decide("src/a.py", "edit", "snap")
    assert d.covered is True
    assert "Recorded, not blocked" in d.as_note()


def test_a_clean_coverage_says_nothing():
    s = CoverageStore()
    d = s.decide("src/a.py", "edit", "snap", relevant_entry_ids=["e1"])
    assert d.status == "covered" and d.as_note() == ""


def test_a_read_is_not_a_mutation():
    assert CoverageStore().decide("a.py", "read", "s").reason == "not a mutating operation"


def test_a_record_from_a_different_snapshot_does_not_cover():
    s = CoverageStore()
    s.decide("a.py", "edit", "snap1", relevant_entry_ids=["e"])
    assert s.decide("a.py", "edit", "snap2", relevant_entry_ids=["e"]).reason != "already covered"


def test_a_conflict_makes_coverage_blocked_by_conflict_without_blocking():
    d = CoverageStore().decide("a.py", "edit", "s", conflicts=["c1"])
    assert d.status == "blocked_by_conflict" and d.covered is False
    assert "Recorded, not blocked" in d.as_note()


def test_bash_is_classified_by_what_it_does():
    assert operation_for("Bash", "psql -c 'DROP TABLE x'") == "delete"
    assert operation_for("Bash", "alembic upgrade head migration") == "migrate"
    assert operation_for("Bash", "ls -la") == "execute"
    assert is_mutating("delete") and not is_mutating("read")


def test_a_fingerprint_identifies_one_attempt():
    assert fingerprint("a", "edit", "s") == fingerprint("a", "edit", "s")
    assert fingerprint("a", "edit", "s") != fingerprint("a", "edit", "s2")


def test_an_invalid_coverage_status_is_refused():
    with pytest.raises(ValueError, match="status"):
        ContextCoverage(id="c", scope={}, operation_kinds=["edit"], manifest_revision=0,
                        source_snapshot_hash="s", status="fine")


def test_an_invalid_operation_kind_is_refused():
    with pytest.raises(ValueError, match="operation kind"):
        ContextCoverage(id="c", scope={}, operation_kinds=["frobnicate"], manifest_revision=0,
                        source_snapshot_hash="s")


# --- the hooks ---------------------------------------------------------------------------------

def run(script, payload, env_extra=None, home=None):
    env = dict(os.environ)
    for k in ("LCG_DISCOVERY", "LCG_INJECT_DELTA", "LCG_RESOLVER", "LCG_INJECT_M0", "LCG_COVERAGE"):
        env.pop(k, None)
    env["AGENT_DISCIPLINE_CONFIG"] = "/nonexistent/x.env"
    if home:
        env["HOME"] = str(home)
    env.update(env_extra or {})
    return subprocess.run([sys.executable, script], input=json.dumps(payload),
                          capture_output=True, text=True, timeout=90, env=env)


def seed_state(home, sid="s1"):
    p = home / ".claude/tmp/lcg"
    p.mkdir(parents=True, exist_ok=True)
    run(os.path.join(ROOT, "hooks", "lcg-manifest.py"),
        {"prompt": "load the settlement rows", "session_id": sid, "cwd": str(home)},
        {"LCG_RESOLVER": "1"}, home=home)
    return p / f"{sid}.json"


def test_discovery_is_silent_by_default(tmp_path):
    p = run(DISCOVER, {"session_id": "s", "tool_name": "Read",
                       "tool_input": {"file_path": "src/a.py"}}, home=tmp_path)
    assert p.returncode == 0 and p.stdout.strip() == ""


def test_discovery_without_a_manifest_does_nothing(tmp_path):
    p = run(DISCOVER, {"session_id": "nope", "tool_name": "Read",
                       "tool_input": {"file_path": "src/a.py"}},
            {"LCG_DISCOVERY": "1"}, home=tmp_path)
    assert p.stdout.strip() == "", "discovery refines a manifest; it does not create one"


def test_discovery_extends_the_frontier_and_advances_the_revision(tmp_path):
    state = seed_state(tmp_path)
    before = json.loads(state.read_text())
    run(DISCOVER, {"session_id": "s1", "tool_name": "Read",
                   "tool_input": {"file_path": "src/settlement/loader.py"}},
        {"LCG_DISCOVERY": "1"}, home=tmp_path)
    after = json.loads(state.read_text())
    assert after["revision"] > before["revision"]
    assert any(f["entity_id"] == "src/settlement/loader.py" for f in after["frontier"])
    assert after["manifest"]["manifest_id"] != before["manifest"]["manifest_id"]


def test_a_repeated_observation_does_not_advance_anything(tmp_path):
    state = seed_state(tmp_path, "s2")
    ev = {"session_id": "s2", "tool_name": "Read", "tool_input": {"file_path": "src/a.py"}}
    run(DISCOVER, ev, {"LCG_DISCOVERY": "1"}, home=tmp_path)
    mid = json.loads(state.read_text())["revision"]
    run(DISCOVER, ev, {"LCG_DISCOVERY": "1"}, home=tmp_path)
    assert json.loads(state.read_text())["revision"] == mid


def test_delta_injection_needs_its_own_flag(tmp_path):
    seed_state(tmp_path, "s3")
    ev = {"session_id": "s3", "tool_name": "Read", "tool_input": {"file_path": "src/z.py"}}
    quiet = run(DISCOVER, ev, {"LCG_DISCOVERY": "1"}, home=tmp_path)
    assert quiet.stdout.strip() == ""
    loud = run(DISCOVER, {"session_id": "s3", "tool_name": "Read",
                          "tool_input": {"file_path": "src/other.py"}},
               {"LCG_DISCOVERY": "1", "LCG_INJECT_DELTA": "1"}, home=tmp_path)
    if loud.stdout.strip():
        out = json.loads(loud.stdout)["hookSpecificOutput"]
        assert "permissionDecision" not in out, "discovery must never block"


def test_concurrent_observations_keep_a_gapless_revision_chain(tmp_path):
    """P3-20/21/23: parallel tool calls mean parallel hooks. A loser recomputes, it does not
    overwrite — so revisions advance by one with no gaps and no lost writes."""
    state = seed_state(tmp_path, "s4")
    # They must genuinely OVERLAP. An earlier version spawned four processes and then fed them
    # one at a time with communicate(), so each blocked on stdin until the previous had finished
    # — serial execution wearing a concurrency test's clothes. It passed with the revision-race
    # retry removed, which is exactly what it existed to catch. Feed every stdin first, then wait.
    env = dict(os.environ, HOME=str(tmp_path), LCG_DISCOVERY="1",
               AGENT_DISCIPLINE_CONFIG="/nonexistent/x.env")
    procs = [subprocess.Popen([sys.executable, DISCOVER], stdin=subprocess.PIPE,
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=env)
             for _ in range(4)]
    for i, p in enumerate(procs):
        p.stdin.write(json.dumps({"session_id": "s4", "tool_name": "Read",
                                  "tool_input": {"file_path": f"src/mod{i}.py"}}))
        p.stdin.close()
    for p in procs:
        p.wait(timeout=90)
    final = json.loads(state.read_text())
    assert SessionState(str(state)).read() is not None, "state must still parse after the race"
    keys = {f["entity_id"] for f in final["frontier"]}
    assert len(keys) == len(final["frontier"]), "the frontier must not contain duplicates"

    # The point of recomputing rather than overwriting: NO observation is lost. Asserting only
    # "the state still parses" passed happily with the retry replaced by `pass`, which drops the
    # loser's entity on the floor — found by mutation.
    for i in range(4):
        assert f"src/mod{i}.py" in keys, (
            f"src/mod{i}.py was observed but is missing: a writer that lost the revision race "
            f"dropped its observation instead of recomputing (P3-23)")
    assert final["revision"] >= 3, (
        "four observations should advance the revision four times; a lower number means writes "
        "were lost, not merged")


def test_a_tool_failure_forces_a_refresh(tmp_path):
    state = seed_state(tmp_path, "s5")
    before = json.loads(state.read_text())["revision"]
    run(DISCOVER, {"session_id": "s5", "hook_event_name": "PostToolUseFailure",
                   "tool_name": "Bash", "error": "ValueError: settlement rows missing"},
        {"LCG_DISCOVERY": "1"}, home=tmp_path)
    assert json.loads(state.read_text())["revision"] > before


def test_coverage_is_recorded_when_enabled(tmp_path):
    state = seed_state(tmp_path, "s6")
    run(DISCOVER, {"session_id": "s6", "tool_name": "Edit",
                   "tool_input": {"file_path": "src/money.py"}},
        {"LCG_DISCOVERY": "1", "LCG_COVERAGE": "1"}, home=tmp_path)
    rows = json.loads(state.read_text()).get("coverage") or []
    assert rows and rows[0]["scope"]["path"] == "src/money.py"
    assert rows[0]["status"] in ("covered", "covered_with_warning", "degraded")


# --- rehydration ------------------------------------------------------------------------------

def test_rehydration_is_silent_at_a_fresh_startup(tmp_path):
    p = run(REHYDRATE, {"session_id": "s", "source": "startup"},
            {"LCG_RESOLVER": "1"}, home=tmp_path)
    assert p.stdout.strip() == ""


def test_state_survives_compaction(tmp_path):
    seed_state(tmp_path, "s7")
    p = run(REHYDRATE, {"session_id": "s7", "source": "compact"},
            {"LCG_RESOLVER": "1"}, home=tmp_path)
    ctx = json.loads(p.stdout)["hookSpecificOutput"]["additionalContext"]
    assert "LEDGER CONTEXT RECOVERED after compact" in ctx
    assert "held OUTSIDE the conversation" in ctx


def test_rehydration_does_not_dump_the_whole_manifest(tmp_path):
    seed_state(tmp_path, "s8")
    p = run(REHYDRATE, {"session_id": "s8", "source": "resume"},
            {"LCG_RESOLVER": "1"}, home=tmp_path)
    ctx = json.loads(p.stdout)["hookSpecificOutput"]["additionalContext"]
    assert len(ctx) < 2500, "rehydrating everything refills the context the compaction cleared"
    assert "ledger-why.py" in ctx, "the rest must be reachable, not injected"


def test_rehydration_with_no_state_is_silent(tmp_path):
    p = run(REHYDRATE, {"session_id": "never-seen", "source": "resume"},
            {"LCG_RESOLVER": "1"}, home=tmp_path)
    assert p.stdout.strip() == ""


def test_no_phase_three_hook_can_block():
    for script in (DISCOVER, REHYDRATE):
        src = open(script).read()
        assert '"deny"' not in src and "permissionDecision" not in src, script
