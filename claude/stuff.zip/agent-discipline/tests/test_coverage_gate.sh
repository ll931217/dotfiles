#!/usr/bin/env bash
# The coverage floor must be able to go RED, and must say the number when it does.
# Runs against a two-line throwaway project, so it costs nothing and needs no repo state.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
COV="$ROOT/.venv/bin/coverage"; [ -x "$COV" ] || COV=coverage
command -v "$COV" >/dev/null 2>&1 || { echo "SKIP coverage not installed"; exit 0; }
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT; cd "$T"
printf 'def used():\n    return 1\n\n\ndef never_called():\n    return 2\n' > m.py
printf 'import m\nm.used()\n' > drive.py
fail=0
COVERAGE_FILE="$T/.cov" "$COV" run --source=. drive.py >/dev/null 2>&1
out="$(COVERAGE_FILE="$T/.cov" "$COV" report --fail-under=100 2>&1)"; rc=$?
[ "$rc" != 0 ] || { echo "FAIL floor of 100 on partly-covered code exited 0"; fail=1; }
grep -qi 'fail.under=100' <<<"$out" || { echo "FAIL message does not name the floor: $out"; fail=1; }
out2="$(COVERAGE_FILE="$T/.cov" "$COV" report --fail-under=10 2>&1)"; rc2=$?
[ "$rc2" = 0 ] || { echo "FAIL floor of 10 should pass, got $rc2: $out2"; fail=1; }
[ "$fail" = 0 ] && echo "ok   the coverage floor can go red and names the number" || exit 1
