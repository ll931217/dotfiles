"""Phases 5-7. The exit criteria that matter here are all refusals: one answer cannot become
policy, an uncovered mutation is warned about rather than blocked, and autonomy stays shut until
its prerequisites are met from evidence."""
from __future__ import annotations

import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from ledger.autonomy import (KILL_SWITCH_PATH, MIN_PRECISION,          # noqa: E402
                             MIN_SAMPLES_PER_INTENT, kill_switch_engaged,
                             may_auto_answer, readiness)
from ledger.coverage import CoverageStore                               # noqa: E402
from ledger.curation import (AUTHORITIES, CandidateStore, ceiling_for,  # noqa: E402
                             proposed_authority_for, to_entry)
from ledger.decision import need_from_question                          # noqa: E402
from ledger.recommend import (Recommendation, coverage_warning,         # noqa: E402
                              recommend, subagent_scope)
from ledger.types import Lifecycle, LedgerEntry, Scope                  # noqa: E402


def E(eid, authority, statement, kind="decision", autonomy="default"):
    return LedgerEntry(id=eid, version=1, kind=kind, subject="subject", statement=statement,
                       scope=Scope(), authority=authority, status="active", autonomy=autonomy,
                       risk="low", created_by="u", created_at="x",
                       lifecycle=Lifecycle(created_at="x"))


# ============ Phase 5: candidate curation =======================================================

def test_one_answer_cannot_silently_become_team_policy():
    """The phase's headline exit criterion."""
    s = CandidateStore()
    c, action = s.observe("dk", "use uv", "always use uv", "team_convention", "s1")
    assert action == "created"
    assert c.status == "candidate", "not active"
    assert c.needs_approval
    assert c.proposed_authority == "reviewed_human_observation", \
        "the high authority is granted at approval, not proposed at creation"
    with pytest.raises(ValueError, match="only an approved candidate"):
        to_entry(c)


def test_approval_records_who_and_widens_authority():
    s = CandidateStore()
    c, _ = s.observe("dk", "use uv", "always use uv", "team_convention", "s1")
    s.approve(c.id, "liangshih", "approved_team_decision")
    e = to_entry(c)
    assert e.authority == "approved_team_decision"
    assert e.lifecycle.approved_by == "liangshih" and e.lifecycle.approved_at


@pytest.mark.parametrize("cls,ceiling", [
    ("task_choice", "current_task_instruction"),
    ("personal_preference", "explicit_human_preference"),
    ("team_convention", "approved_team_decision"),
    ("architectural_decision", "approved_architectural_decision"),
    ("insufficient_to_classify", "repeated_agent_observation"),
])
def test_every_answer_class_has_an_authority_ceiling(cls, ceiling):
    assert ceiling_for(cls) == ceiling


def test_no_answer_class_can_reach_hard_policy():
    """hard_policy is the one authority a task instruction may never override, so a single
    conversation must not be able to mint it. An earlier version skipped this check for exactly
    the classes that need approval, so a team convention could be approved straight to it."""
    s = CandidateStore()
    for cls in ("task_choice", "team_convention", "architectural_decision"):
        c, _ = s.observe(f"dk-{cls}", f"s-{cls}", f"stmt {cls}", cls, "s1")
        with pytest.raises(ValueError, match="ceiling"):
            s.approve(c.id, "someone", "hard_policy")


def test_an_agent_observation_stops_at_the_observation_ceiling():
    assert proposed_authority_for("insufficient_to_classify") == "repeated_agent_observation"
    assert AUTHORITIES.index("repeated_agent_observation") > AUTHORITIES.index("hard_policy")


def test_a_repeated_answer_attaches_evidence_instead_of_duplicating():
    s = CandidateStore()
    a, _ = s.observe("dk", "use uv", "always use uv", "team_convention", "s1")
    b, action = s.observe("dk", "use uv", "always use uv", "team_convention", "s2")
    assert action == "evidence_attached" and a.id == b.id
    assert len(s.all()) == 1 and b.support_count() == 2


def test_a_paraphrase_is_not_a_new_candidate():
    s = CandidateStore()
    s.observe("dk1", "use uv", "always use uv for python projects", "team_convention", "s1")
    _, action = s.observe("dk2", "use uv", "always use uv for python project", "team_convention",
                          "s2")
    assert action == "evidence_attached", "paraphrased duplicates inflate the ledger (P4-17)"


def test_a_contradiction_creates_a_conflict_link_not_a_silent_second_truth():
    s = CandidateStore()
    a, _ = s.observe("dk1", "use uv", "always use uv", "team_convention", "s1")
    b, action = s.observe("dk2", "use uv", "never use uv, stick with pip", "team_convention", "s2")
    assert action == "created_with_conflict"
    assert b.id in a.conflicts_with and a.id in b.conflicts_with


def test_a_rejected_candidate_stays_auditable():
    s = CandidateStore()
    c, _ = s.observe("dk", "s", "statement", "team_convention", "s1")
    s.reject(c.id, "we tried this and it broke staging")
    assert c.status == "rejected"
    assert c in s.all(), "a rejected candidate is deleted nowhere"
    assert c.negative_count() == 1
    assert "broke staging" in c.rejected_reason


def test_a_rejected_candidate_cannot_be_approved_by_accident():
    s = CandidateStore()
    c, _ = s.observe("dk", "s", "statement", "team_convention", "s1")
    s.reject(c.id, "no")
    with pytest.raises(ValueError, match="rejected"):
        s.approve(c.id, "someone")


def test_a_correction_is_negative_evidence_and_does_not_delete_the_record():
    s = CandidateStore()
    c, _ = s.observe("dk", "s", "the column is created_at", "factual_correction", "s1")
    s.correct(c.id, "actually it is settled_at", "s2")
    assert c.negative_count() == 1 and c in s.all()


def test_task_assumptions_expire():
    s = CandidateStore()
    c, _ = s.observe("dk", "s", "assume x", "task_choice", "s1", expires_at="2020-01-01")
    gone = s.expire_task_assumptions(now="2026-09-03")
    assert gone == [c] and c.status == "rejected" and "expired" in c.rejected_reason


def test_a_live_assumption_does_not_expire():
    s = CandidateStore()
    s.observe("dk", "s", "assume x", "task_choice", "s1", expires_at="2099-01-01")
    assert s.expire_task_assumptions(now="2026-09-03") == []


# ============ Phase 6: recommendation and advisory ===============================================

def test_a_recommendation_names_its_sources_intent_and_risk():
    """The phase's exit criterion, verbatim."""
    n = need_from_question("worktree or branch?", "H", ("worktree", "branch"),
                           has_established=True)
    r = recommend(n, [E("e1", "approved_team_decision", "worktree")])
    assert r.recommends and r.answer == "worktree"
    assert r.source_ids == ("e1",) and r.intent and r.risk
    out = r.render()
    assert "e1" in out and "Advisory only" in out and "Nothing was answered for you" in out


@pytest.mark.parametrize("question,why", [
    ("Should I DROP the settlement table?", "destructive"),
    ("Which auth scheme should we use?", "security"),
])
def test_a_mandatory_category_is_never_recommended(question, why):
    n = need_from_question(question, "H", ("a", "b"), has_established=True)
    r = recommend(n, [E("e1", "hard_policy", "a")])
    assert not r.recommends and why in r.human_required_reasons
    assert "This one is yours" in r.render()


def test_changing_an_established_decision_is_never_recommended():
    n = need_from_question("use pip instead of uv?", "H", ("pip", "uv"), has_established=True)
    r = recommend(n, [E("e1", "approved_team_decision", "uv")])
    assert not r.recommends and "human" in r.why_not


def test_a_high_risk_new_decision_stays_human_controlled():
    """Phase 6 exit criterion."""
    n = need_from_question("migrate the schema to the new layout?", "H", ("yes", "no"))
    assert n.intent == "choose_new" and n.risk in ("high", "critical")
    r = recommend(n, [E("e1", "approved_team_decision", "yes")])
    assert not r.recommends


def test_a_conflict_blocks_a_recommendation_and_says_so():
    n = need_from_question("worktree or branch?", "H", ("worktree", "branch"),
                           has_established=True)
    r = recommend(n, [E("e1", "approved_team_decision", "worktree")], conflicts=("c1",))
    assert not r.recommends and "conflict" in r.why_not


def test_stale_support_is_not_recommended_from():
    n = need_from_question("worktree or branch?", "H", ("worktree", "branch"),
                           has_established=True)
    r = recommend(n, [E("e1", "approved_team_decision", "worktree")], stale=("e1",))
    assert not r.recommends and "review date" in r.why_not


def test_an_inexact_option_match_abstains_rather_than_guessing():
    n = need_from_question("worktree or branch?", "H", ("worktree", "branch"),
                           has_established=True)
    r = recommend(n, [E("e1", "approved_team_decision", "use a worktree, obviously")])
    assert not r.recommends and "exactly" in r.why_not


def test_two_options_matching_equally_well_abstains():
    """P4-18 permits mapping only when NO other option is equivalent. The previous test used a
    statement matching zero options, so the count was zero either way and loosening `== 1` to
    `>= 1` went undetected — found by mutation."""
    n = need_from_question("which one?", "H", ("worktree", "Worktree"), has_established=True)
    r = recommend(n, [E("e1", "approved_team_decision", "worktree")])
    assert not r.recommends, "two options match equally; picking one is a guess, not a mapping"
    assert "exactly" in r.why_not


def test_nothing_known_says_so_rather_than_staying_silent():
    n = need_from_question("pick a colour", "H", ("blue", "green"))
    r = recommend(n, [])
    assert "nothing in the ledger" in r.why_not
    assert "knows nothing relevant" in r.render()


def test_a_coverage_warning_states_what_enforcement_would_have_done():
    """Exit criterion: accurate enough to calibrate enforcement against."""
    d = CoverageStore().decide("src/money.py", "edit", "snap")
    w = coverage_warning(d)
    assert "would have been" in w and "Nothing was blocked" in w


def test_a_clean_coverage_produces_no_warning():
    d = CoverageStore().decide("a.py", "edit", "s", relevant_entry_ids=["e1"])
    assert coverage_warning(d) == ""


def test_a_subagent_inherits_constraints_not_the_parents_whole_manifest():
    manifest = {"applicable_policies": [
        {"statement": "no direct db access", "authority": "hard_policy", "autonomy": "mandatory"},
        {"statement": "prefer tabs", "authority": "agent_inference", "autonomy": "advisory"}],
        "preferences": [{"statement": "irrelevant", "authority": "agent_inference",
                         "autonomy": "advisory"}]}
    out = subagent_scope(manifest, "fix the loader")
    assert "no direct db access" in out
    assert "prefer tabs" not in out and "irrelevant" not in out
    assert "inherited constraints" in out


def test_a_subagent_with_no_constraints_gets_nothing():
    assert subagent_scope({"applicable_policies": []}, "task") == ""


# ============ Phase 7: the gate ==================================================================

def test_autonomy_is_not_ready_on_a_machine_with_no_measurements():
    r = readiness()
    assert not r.ready and len(r.unmet()) == 6
    assert "NOT READY" in r.render() and "no flag overrides this" in r.render()


def test_forcing_resolve_mode_does_not_bypass_the_prerequisites():
    n = need_from_question("worktree or branch?", "H", ("worktree", "branch"),
                           has_established=True)
    rec = Recommendation(decision_key=n.key, intent="apply_established", risk="low",
                         answer="worktree", source_ids=("e1",))
    d = may_auto_answer(n, rec, readiness(), mode="resolve", receipt_id="ctxr_1")
    assert not d.allowed and "prerequisites unmet" in d.reason


def ready_now(**kw):
    """A readiness object with every prerequisite met, for testing what happens AFTER."""
    preds, outs = [], []
    for i in range(MIN_SAMPLES_PER_INTENT):
        for intent in ("apply_established", "choose_new", "verify_fact"):
            pid = f"{intent}-{i}"
            preds.append({"id": pid, "predicted_answer": "a", "intent": intent, "risk": "low",
                          "confidence": "exact_key", "supporting_entry_ids": ["e"],
                          "mandatory_human": []})
            outs.append({"prediction_id": pid, "agreed_with_prediction": True})
    stop = [{"candidate": True, "false_positive": False} for _ in range(20)]
    base = dict(predictions=preds, outcomes=outs, stop_rows=stop, security_reviewed=True,
                persistence_ok=True, kill_switch_verified=True)
    base.update(kw)
    return readiness(**base)


def test_the_prerequisites_can_be_met_so_the_gate_is_not_merely_impossible():
    """A gate that can never open is indistinguishable from a bug. This proves the shape."""
    assert ready_now().ready


@pytest.mark.parametrize("kw,name", [
    ({"security_reviewed": False}, "security review"),
    ({"kill_switch_verified": False}, "kill switch verified"),
    ({"persistence_ok": False}, "receipt and state persistence"),
])
def test_each_prerequisite_is_load_bearing(kw, name):
    r = ready_now(**kw)
    assert not r.ready and name in [p.name for p in r.unmet()]


def test_thin_calibration_data_is_not_enough():
    preds = [{"id": "1", "predicted_answer": "a", "intent": "choose_new", "risk": "low",
              "confidence": "exact_key", "supporting_entry_ids": ["e"], "mandatory_human": []}]
    outs = [{"prediction_id": "1", "agreed_with_prediction": True}]
    r = readiness(predictions=preds, outcomes=outs, security_reviewed=True,
                  kill_switch_verified=True, stop_rows=[{"candidate": True,
                                                         "false_positive": False}])
    assert not r.ready
    assert "calibration sample count" in [p.name for p in r.unmet()], \
        "100% precision over one sample is not evidence"


def test_unreviewed_stop_flags_do_not_count_as_a_low_false_positive_rate():
    """A false-positive rate you have not measured is not a low one."""
    r = ready_now(stop_rows=[{"candidate": True} for _ in range(20)])
    assert not r.ready
    assert "coverage false-positive rate" in [p.name for p in r.unmet()]


def test_the_kill_switch_refuses_before_any_other_check(tmp_path):
    """It must not depend on a calibration table being loadable."""
    kill = tmp_path / "KILL"
    kill.write_text("engaged")
    n = need_from_question("worktree or branch?", "H", ("worktree", "branch"),
                           has_established=True)
    rec = Recommendation(decision_key=n.key, intent="apply_established", risk="low",
                         answer="worktree", source_ids=("e1",))
    d = may_auto_answer(n, rec, ready_now(), mode="resolve", receipt_id="r",
                        kill_path=str(kill))
    assert not d.allowed and d.reason == "kill switch engaged"
    assert kill_switch_engaged(str(kill))


def test_with_everything_met_a_low_risk_established_decision_is_answered(tmp_path):
    n = need_from_question("worktree or branch?", "H", ("worktree", "branch"),
                           has_established=True)
    rec = Recommendation(decision_key=n.key, intent="apply_established", risk="low",
                         answer="worktree", source_ids=("e1",))
    d = may_auto_answer(n, rec, ready_now(), mode="resolve", receipt_id="ctxr_1",
                        kill_path=str(tmp_path / "nokill"))
    assert d.allowed and d.answer == "worktree" and d.receipt_id == "ctxr_1"


@pytest.mark.parametrize("kw,expect", [
    (dict(mode="shadow"), "mode is shadow"),
    (dict(receipt_id=""), "no context receipt"),
])
def test_a_single_missing_condition_refuses_even_when_ready(kw, expect, tmp_path):
    n = need_from_question("worktree or branch?", "H", ("worktree", "branch"),
                           has_established=True)
    rec = Recommendation(decision_key=n.key, intent="apply_established", risk="low",
                         answer="worktree", source_ids=("e1",))
    args = dict(mode="resolve", receipt_id="ctxr_1", kill_path=str(tmp_path / "nokill"))
    args.update(kw)
    assert not may_auto_answer(n, rec, ready_now(), **args).allowed


def test_a_mandatory_category_is_refused_even_when_fully_ready(tmp_path):
    n = need_from_question("Should I DROP the settlement table?", "H", ("yes", "no"),
                           has_established=True)
    rec = Recommendation(decision_key=n.key, intent="apply_established", risk="critical",
                         answer="no", source_ids=("e1",))
    d = may_auto_answer(n, rec, ready_now(), mode="resolve", receipt_id="r",
                        kill_path=str(tmp_path / "nokill"))
    assert not d.allowed and "mandatory human" in d.reason


def test_a_high_risk_new_decision_is_refused_even_when_ready(tmp_path):
    n = need_from_question("pick the new storage engine", "H", ("a", "b"))
    rec = Recommendation(decision_key=n.key, intent="choose_new", risk="high", answer="a",
                         source_ids=("e1",))
    d = may_auto_answer(n, rec, ready_now(), mode="resolve", receipt_id="r",
                        kill_path=str(tmp_path / "nokill"))
    assert not d.allowed and "ceiling" in d.reason


def test_a_per_decision_override_can_forbid_one_question(tmp_path):
    n = need_from_question("worktree or branch?", "H", ("worktree", "branch"),
                           has_established=True)
    rec = Recommendation(decision_key=n.key, intent="apply_established", risk="low",
                         answer="worktree", source_ids=("e1",))
    d = may_auto_answer(n, rec, ready_now(), mode="resolve", receipt_id="r",
                        kill_path=str(tmp_path / "nokill"), overrides={n.key: "never"})
    assert not d.allowed and "override" in d.reason


def test_the_autonomy_flags_default_off():
    sys.path.insert(0, ROOT)
    import config
    for f in ("LCG_AUTONOMY", "LCG_ENFORCE_COVERAGE", "LCG_STOP_RECOVERY",
              "LCG_CURATION", "LCG_RECOMMEND", "LCG_SUBAGENT_SCOPE"):
        assert f in config.MUST_DEFAULT_OFF and not config.on(f)
