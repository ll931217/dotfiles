#!/usr/bin/env bash
# E2E for hooks/orchestrator-hands-off.py and the nudge's heredoc guard: what the orchestrator
# sees when it edits the main checkout while a worker is active, and silence otherwise.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
fail=0
check() { if [[ "$2" == *"$3"* ]]; then echo "ok   $1"; else echo "FAIL $1"; echo "     want: $3"; echo "     got:  $2"; fail=1; fi; }
silent() { if [[ -z "$2" ]]; then echo "ok   $1"; else echo "FAIL $1 (expected no output)"; echo "     got: $2"; fail=1; fi; }

git -C "$T" init -q repo; echo x > "$T/repo/app.py"
ev() { printf '{"tool_input":{"file_path":"%s"}}' "$1" | python3 "$ROOT/hooks/orchestrator-hands-off.py"; }

silent "no workers: silent" "$(ev "$T/repo/app.py")"

mkdir -p "$T/repo/.worktrees/feat-x/.claude"
echo '{"status":"assigned","round":0}' > "$T/repo/.worktrees/feat-x/.claude/delegate.json"
out="$(ev "$T/repo/app.py")"
check "active worker: names the file" "$out" "edited the main checkout (app.py)"
check "active worker: names the worker and its state" "$out" "feat-x (assigned)"
check "active worker: says what to do" "$out" "SendMessage the worker the issue"

silent "edit inside the worktree itself: silent" "$(ev "$T/repo/.worktrees/feat-x/app.py")"
echo '{"status":"accepted"}' > "$T/repo/.worktrees/feat-x/.claude/delegate.json"
silent "worker accepted: silent" "$(ev "$T/repo/app.py")"

nudge() { printf '{"tool_input":{"command":%s}}' "$(python3 -c 'import json,sys;print(json.dumps(sys.argv[1]))' "$1")" | python3 "$ROOT/hooks/worktree-delegate-nudge.py"; }
check "nudge fires on a real wt create" "$(nudge 'wt switch --create feat/y --yes')" "A worktree was just created"
silent "nudge stays quiet when a heredoc merely mentions wt create" "$(nudge $'cat > t.sh <<EOF\nwt switch --create feat/y\nEOF')"

[[ $fail -eq 0 ]] && echo "ok — hands-off hook E2E passed" || { echo "FAILED"; exit 1; }
