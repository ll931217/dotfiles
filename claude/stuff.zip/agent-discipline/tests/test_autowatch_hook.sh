#!/usr/bin/env bash
# E2E for hooks/glab-autowatch.sh: feeds the real hook real PostToolUse payloads and
# asserts the OBSERVABLE — whether a watcher was spawned — not just the exit code,
# which a hook always returns as 0.
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
HOOK="$ROOT/hooks/glab-autowatch.sh"
TMP="$(mktemp -d)"
# Kill what we spawned, not just the lock files: every probe starts a real detached watcher, and
# leaving them behind litters the machine with pollers for a throwaway repo.
cleanup() {
  for l in /tmp/glab-watch-*.lock; do
    [ -e "$l" ] || continue
    read -r p _ < "$l" 2>/dev/null || true
    [ -n "${p:-}" ] && { pkill -P "$p" 2>/dev/null; kill "$p" 2>/dev/null; }
  done
  # Only pids this test's own lock files name. A pattern-based pkill here would also kill the
  # watchers following the user's REAL merge requests.
  rm -rf "$TMP"; rm -f /tmp/glab-watch-*.lock
}
trap cleanup EXIT
fails=0

# A repo with no remote: the spawned watcher dies immediately, and the lock file it
# writes first is the evidence that it was spawned at all.
REPO="$TMP/repo"; mkdir -p "$REPO"; git -C "$REPO" init -q .
git -C "$REPO" commit -q --allow-empty -m init 2>/dev/null

probe() {  # want, label, command, stdout, cwd
  local want="$1" label="$2" payload
  payload="$(jq -nc --arg c "$3" --arg o "$4" --arg w "$5" \
    '{tool_input:{command:$c},tool_response:{stdout:$o},cwd:$w}')"
  for l in /tmp/glab-watch-*.lock; do
    [ -e "$l" ] || continue
    read -r op _ < "$l" 2>/dev/null || true
    [ -n "${op:-}" ] && { pkill -P "$op" 2>/dev/null; kill "$op" 2>/dev/null; }
  done
  rm -f /tmp/glab-watch-*.lock
  printf '%s' "$payload" | bash "$HOOK" >/dev/null 2>&1
  local rc=$?
  # Poll, never sleep a fixed amount: the watcher is spawned with setsid and writes its lock
  # a moment later, so a flat `sleep 1` fails under load and passes on an idle machine.
  local got=0 i
  for i in $(seq 60); do
    got="$(ls /tmp/glab-watch-*.lock 2>/dev/null | wc -l)"
    [[ "$got" == "$want" ]] && break
    sleep 0.1
  done
  if [[ "$got" == "$want" && "$rc" == "0" ]]; then
    echo "  ok   $label (spawned=$got)"
  else
    echo "  FAIL $label: spawned=$got want=$want, hook exit=$rc want=0"; fails=$((fails+1))
  fi
}

echo "autowatch hook:"
probe 1 "a successful push starts a watcher"      "git push -u origin feat/x" "To gitlab: * [new branch] feat/x" "$REPO"
probe 0 "a rejected push starts nothing"          "git push"                  "! [rejected] main -> main (fetch first)" "$REPO"
probe 1 "a created MR starts a watcher"           "glab mr create --yes"      "http://gl/x/-/merge_requests/9" "$REPO"
probe 0 "a failed MR create starts nothing"       "glab mr create --yes"      "error: nope" "$REPO"
probe 0 "an unrelated command starts nothing"     "ls -la"                    "x" "$REPO"
probe 0 "a push outside a git repo starts nothing" "git push"                 "ok" "$TMP"

# --- the sequence that actually happens: push, then create the MR seconds later ---------
# A plain "something is already running" lock made the create a no-op, so the MR itself was
# never watched: the branch-pipeline watcher went green, exited, and the merge went unseen.
rm -f /tmp/glab-watch-*.lock
ev() { jq -nc --arg c "$1" --arg o "$2" --arg w "$3" '{tool_input:{command:$c},tool_response:{stdout:$o},cwd:$w}'; }
say() { if [[ "$2" == *"$3"* ]]; then echo "  ok   $1"; else echo "  FAIL $1"; echo "       want: $3"; echo "       got:  ${2:0:400}"; fails=$((fails+1)); fi; }

# a long-lived fake watcher so the lock is held by a LIVE pid, as it is in the real sequence
lockfile="/tmp/glab-watch-$(printf '%s' "${REPO}$(git -C "$REPO" branch --show-current)" | md5sum | cut -c1-12).lock"
sleep 300 & fake=$!; echo "$fake pipeline" > "$lockfile"
out="$(ev "glab mr create --yes" "http://gl/x/-/merge_requests/9" "$REPO" | bash "$HOOK" 2>&1)"
now_pid=""; now_kind=""
for i in $(seq 60); do
  read -r now_pid now_kind < "$lockfile" 2>/dev/null || true
  [[ "$now_kind" == "mr" ]] && break
  sleep 0.1
done
if [[ "$now_kind" == "mr" && "$now_pid" != "$fake" ]]; then
  echo "  ok   an MR create supersedes a running branch-pipeline watch"
else
  echo "  FAIL MR create did not supersede the pipeline watch (lock: ${now_pid:-} ${now_kind:-})"; fails=$((fails+1))
fi
kill "$fake" 2>/dev/null; wait "$fake" 2>/dev/null

# the opposite direction must NOT churn: a push while the MR is already watched changes nothing
echo "$$ mr" > "$lockfile"
out="$(ev "git push" "To gitlab: ok" "$REPO" | bash "$HOOK" 2>&1)"
read -r _ still < "$lockfile"
[[ "$still" == "mr" ]] && echo "  ok   a push leaves a running MR watch alone" || { echo "  FAIL push clobbered the MR watch"; fails=$((fails+1)); }

# --- the session has to be told, because the detached watcher cannot tell it ------------
rm -f /tmp/glab-watch-*.lock
out="$(ev "glab mr create --yes" "http://gl/x/-/merge_requests/9" "$REPO" | bash "$HOOK" 2>/dev/null)"
say "MR create hands the session a wake-up command" "$out" "run_in_background"
say "the wake-up covers merge, close, red pipeline and conflict" "$out" "MERGED|CLOSED|PIPELINE (FAILED|CANCELED)|MERGE CONFLICT"
say "it says the detached watcher cannot reach the session" "$out" "CANNOT notify you"
say "it is valid hook JSON" "$(printf '%s' "$out" | jq -r '.hookSpecificOutput.hookEventName')" "PostToolUse"
# an old MERGED line from a previous MR on this branch must not satisfy the new watch
logf="$HOME/.cache/glab-watch/$(git -C "$REPO" branch --show-current | tr / _).log"
offset="$(printf '%s' "$out" | grep -o 'tail -c +[0-9]*' | head -1 | grep -o '[0-9]*')"
[[ -n "$offset" && "$offset" -gt 0 ]] && echo "  ok   the wake-up reads the log from this watch's offset ($offset)" || { echo "  FAIL no log offset in the injected command"; fails=$((fails+1)); }

rm -f /tmp/glab-watch-*.lock
[[ $fails -eq 0 ]] && echo "all autowatch checks passed" || echo "$fails autowatch check(s) failed"
exit $((fails > 0))
