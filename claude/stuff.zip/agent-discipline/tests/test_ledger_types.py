"""Phase 1 exit criteria: existing records readable, governance fields required, and
supersession / expiry / invalidation / exact decision-key retrieval all tested."""
from __future__ import annotations

import os
import subprocess
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from ledger.compat import read_all, read_entry, report          # noqa: E402
from ledger.events import EventLog, ReceiptStore                 # noqa: E402
from ledger.projection import ActiveProjection                   # noqa: E402
from ledger.types import (AUTHORITIES, LedgerEntry, LedgerError,  # noqa: E402
                          Lifecycle, RetrievalMetadata, Scope, decision_key)


def entry(**kw):
    base = dict(id="e1", version=1, kind="preference", subject="db access",
                statement="use the repository layer", scope=Scope(),
                authority="explicit_human_preference", status="active",
                autonomy="default", risk="low", created_by="u", created_at="2026-01-01")
    base.update(kw)
    return LedgerEntry(**base)


# --- new entries cannot omit required governance fields -----------------------------------

@pytest.mark.parametrize("field", ["id", "subject", "statement", "created_by", "created_at"])
def test_a_required_field_cannot_be_blank(field):
    with pytest.raises(LedgerError, match=field):
        entry(**{field: "  "})


@pytest.mark.parametrize("field,bad", [
    ("kind", "opinion"), ("authority", "vibes"), ("status", "maybe"),
    ("autonomy", "whenever"), ("risk", "spicy"),
])
def test_a_governance_field_must_use_the_specs_vocabulary(field, bad):
    with pytest.raises(LedgerError, match=field):
        entry(**{field: bad})


def test_scope_must_be_a_scope_not_a_dict():
    """A dict cannot express 'not constrained by this dimension' versus 'constrained to None'."""
    with pytest.raises(LedgerError, match="scope"):
        entry(scope={"repository": "atlas"})


def test_approval_records_who_and_when_together():
    with pytest.raises(LedgerError, match="approved_at"):
        entry(lifecycle=Lifecycle(created_at="x", approved_by="someone"))


# --- authority and scope precedence --------------------------------------------------------

def test_a_narrow_preference_does_not_beat_a_broad_hard_policy():
    """R-004 and R-005: the failure this whole model exists to prevent."""
    policy = entry(id="pol", authority="hard_policy", scope=Scope(organization="vici"),
                   statement="no direct database access")
    pref = entry(id="pref", authority="explicit_human_preference",
                 scope=Scope(repository="atlas", path="src/", symbol="load"),
                 statement="direct database access is fine here")
    ranked = ActiveProjection([policy, pref]).rank([pref, policy])
    assert ranked[0].id == "pol"


def test_specificity_only_breaks_ties_inside_one_authority_class():
    broad = entry(id="broad", scope=Scope(repository="atlas"))
    narrow = entry(id="narrow", scope=Scope(repository="atlas", symbol="fetch"))
    assert ActiveProjection([broad, narrow]).rank([broad, narrow])[0].id == "narrow"


def test_authority_order_is_the_specs_order():
    assert AUTHORITIES[0] == "hard_policy"
    assert AUTHORITIES[-1] == "generated_summary"
    assert AUTHORITIES.index("explicit_human_preference") < AUTHORITIES.index("agent_inference")


# --- scope matching ------------------------------------------------------------------------

def test_a_declared_dimension_must_match():
    e = entry(scope=Scope(repository="atlas"))
    assert e.scope.matches({"repository": "atlas"})
    assert not e.scope.matches({"repository": "rom"})
    assert not e.scope.matches({}), "an absent context cannot satisfy a declared constraint"


def test_a_branch_scoped_fact_does_not_leak_to_another_branch():
    e = entry(scope=Scope(branches=("staging",)))
    assert e.scope.matches({"branches": "staging"})
    assert not e.scope.matches({"branches": "main"})


def test_an_undeclared_dimension_does_not_constrain():
    assert entry(scope=Scope()).scope.matches({"repository": "anything", "branches": "x"})


# --- lifecycle: supersession, expiry, invalidation -------------------------------------------

def test_an_expired_entry_is_not_active_and_is_not_returned():
    e = entry(id="old", lifecycle=Lifecycle(created_at="x", expires_at="2020-01-01"))
    assert not e.is_active(now="2026-09-03")
    assert ActiveProjection([e], now="2026-09-03").active == []


def test_an_entry_before_its_effective_date_is_not_active():
    e = entry(lifecycle=Lifecycle(created_at="x", effective_from="2099-01-01"))
    assert not e.is_active(now="2026-09-03")


def test_supersession_moves_status_and_bumps_the_version():
    e = entry()
    s = e.with_status("superseded", superseded_by="e2")
    assert (s.status, s.version, s.lifecycle.superseded_by) == ("superseded", 2, "e2")
    assert ActiveProjection([s], now="2026-09-03").active == []


def test_invalidation_removes_an_entry_from_the_active_projection():
    assert ActiveProjection([entry().with_status("invalidated")]).active == []


def test_an_illegal_transition_is_refused():
    with pytest.raises(LedgerError, match="not a permitted transition"):
        entry(status="active").with_status("candidate")


def test_a_stale_entry_is_still_active_but_flagged():
    e = entry(lifecycle=Lifecycle(created_at="x", review_after="2020-01-01"))
    p = ActiveProjection([e], now="2026-09-03")
    assert e.is_active(now="2026-09-03") and e.is_stale(now="2026-09-03")
    assert p.stale() == [e], "R-007: a stale fact surfaced as current needs a warning"


# --- exact decision-key retrieval -------------------------------------------------------------

def test_a_decision_key_is_stable_and_carries_scope():
    assert decision_key("Worktree or Branch?") == "worktree-or-branch"
    assert decision_key("x", Scope(repository="atlas")) == "x@repository=atlas"
    assert decision_key("x") == decision_key("  X  "), "the key must not depend on formatting"


def test_a_key_is_not_session_dependent():
    """The existing question hash mixes in session_id, so it can never match across sessions."""
    assert decision_key("same question") == decision_key("same question")


def test_exact_key_retrieval_outranks_a_scope_match():
    keyed = entry(id="keyed", authority="agent_inference",
                  retrieval=RetrievalMetadata(decision_keys=("db-access",)))
    scoped = entry(id="scoped", authority="agent_inference", scope=Scope(repository="atlas"))
    got = ActiveProjection([keyed, scoped]).resolve({"repository": "atlas"}, key="db-access")
    assert got[0][0].id == "keyed" and got[0][1] == "exact_decision_key"


def test_an_expired_entry_never_answers_a_key_lookup():
    e = entry(retrieval=RetrievalMetadata(decision_keys=("k",)),
              lifecycle=Lifecycle(created_at="x", expires_at="2020-01-01"))
    assert ActiveProjection([e], now="2026-09-03").by_decision_key("k") == []


# --- conflicts ----------------------------------------------------------------------------------

def test_a_conflict_is_grouped_and_decided_by_authority_not_sort_order():
    a = entry(id="a", authority="hard_policy", statement="never do X")
    b = entry(id="b", authority="agent_inference", statement="X is fine")
    c = ActiveProjection([a, b]).conflicts([b, a])
    assert len(c) == 1 and c[0]["winner"].id == "a" and c[0]["decided_by"] == "authority"


def test_two_records_agreeing_are_not_a_conflict():
    a, b = entry(id="a"), entry(id="b")
    assert ActiveProjection([a, b]).conflicts([a, b]) == []


# --- append-only history and receipts --------------------------------------------------------

def test_the_event_log_appends_and_never_rewrites(tmp_path):
    log = EventLog(str(tmp_path / "events.jsonl"))
    log.append("e1", "created", "u")
    log.append("e1", "activated", "u")
    assert [r["kind"] for r in log.read("e1")] == ["created", "activated"]


def test_an_unknown_event_kind_is_refused(tmp_path):
    with pytest.raises(ValueError, match="not a ledger event kind"):
        EventLog(str(tmp_path / "e.jsonl")).append("e1", "vibed", "u")


def test_a_torn_line_does_not_lose_the_rest_of_the_history(tmp_path):
    p = tmp_path / "events.jsonl"
    log = EventLog(str(p))
    log.append("e1", "created", "u")
    with open(p, "a") as f:
        f.write("{not json\n")
    log.append("e1", "activated", "u")
    assert [r["kind"] for r in log.read("e1")] == ["created", "activated"]


def test_a_receipt_records_what_was_selected_and_rejected(tmp_path):
    s = ReceiptStore(str(tmp_path / "r.jsonl"))
    s.write("ctxr_1", "M0", 0, [{"id": "a", "state": "selected"},
                                {"id": "b", "state": "rejected", "why": "lower authority"}])
    got = s.get("ctxr_1")
    assert [i["state"] for i in got["items"]] == ["selected", "rejected"]


def test_a_receipt_item_needs_a_known_state(tmp_path):
    with pytest.raises(ValueError, match="state"):
        ReceiptStore(str(tmp_path / "r.jsonl")).write("c", "M0", 0, [{"id": "a", "state": "eh"}])


# --- existing records remain readable ----------------------------------------------------------

RECORD = '''---
name: pref-example
description: "when to do the thing"
triggers: "thing, stuff"
metadata:
  status: provisional
  confidence: derived-weak
  observations: 1
---

**Preference:** do the thing.

**Chose:** the thing
**Over:** the other thing

**Does NOT apply when:** it is Tuesday.
'''


def test_an_existing_record_reads_as_a_typed_entry(tmp_path):
    (tmp_path / "pref-example.md").write_text(RECORD)
    e = read_entry(str(tmp_path / "pref-example.md"))
    assert e.kind == "preference"
    assert e.statement == "do the thing."
    assert e.retrieval.trigger_terms == ("thing", "stuff")
    assert e.retrieval.applies_when == ("it is Tuesday.",)


def test_a_provisional_record_stays_ACTIVE_not_candidate(tmp_path):
    """Mapping provisional->candidate would drop it out of the active projection and silently
    change retrieval — the reinterpretation spec §2 forbids. The frontmatter value is kept."""
    (tmp_path / "pref-example.md").write_text(RECORD)
    e = read_entry(str(tmp_path / "pref-example.md"))
    assert e.status == "active"
    assert "frontmatter_status:provisional" in e.source_references


def test_the_confidence_ladder_maps_onto_autonomy(tmp_path):
    for conf, authority, autonomy in [
        ("stated", "explicit_human_preference", "default"),
        ("derived-strong", "agent_inference", "advisory"),
        ("derived-weak", "agent_inference", "ask_before_applying"),
    ]:
        (tmp_path / "pref-x.md").write_text(RECORD.replace("derived-weak", conf))
        e = read_entry(str(tmp_path / "pref-x.md"))
        assert (e.authority, e.autonomy) == (authority, autonomy), conf


def test_an_unstated_confidence_gets_the_most_cautious_autonomy(tmp_path):
    (tmp_path / "pref-x.md").write_text(RECORD.replace("  confidence: derived-weak\n", ""))
    assert read_entry(str(tmp_path / "pref-x.md")).autonomy == "ask_before_applying"


def test_existing_records_are_unscoped_which_is_not_global_authority(tmp_path):
    (tmp_path / "pref-example.md").write_text(RECORD)
    e = read_entry(str(tmp_path / "pref-example.md"))
    assert e.scope.declared() == {}
    policy = entry(id="p", authority="hard_policy", scope=Scope(organization="o"))
    assert ActiveProjection([e, policy]).rank([e, policy])[0].id == "p"


def test_a_file_without_a_preference_line_is_reported_not_dropped(tmp_path):
    (tmp_path / "pref-note.md").write_text("---\nname: x\n---\n\n**Rule:** something else.\n")
    entries, skipped = read_all(str(tmp_path))
    assert entries == []
    assert skipped and "not a ledger record" in skipped[0][1]


def test_the_report_writes_nothing(tmp_path):
    (tmp_path / "pref-example.md").write_text(RECORD)
    before = (tmp_path / "pref-example.md").read_text()
    r = report(str(tmp_path))
    assert r["would_write"] == []
    assert (tmp_path / "pref-example.md").read_text() == before


def test_the_real_ledger_still_reads(tmp_path):
    """The actual user records, whatever they are today. Exit criterion: existing records remain
    readable. Skips cleanly when there is no ledger on this machine."""
    from agent_discipline_paths import topics_dir
    src = topics_dir()
    if not os.path.isdir(src):
        pytest.skip("no ledger on this machine")
    r = report(src)
    assert r["readable"] > 0
    assert all(e.kind == "preference" for e in r["entries"])
    ActiveProjection(r["entries"])   # must not raise


def test_the_core_does_not_import_claude_code_hook_types():
    """R-013 / gap-analysis C4: the resolver core stays free of hook payload types."""
    import pathlib
    for f in pathlib.Path(ROOT, "ledger").glob("*.py"):
        src = f.read_text()
        assert "tool_input" not in src, f"{f.name} reaches into a hook payload"
        assert "hookSpecificOutput" not in src, f"{f.name} emits a hook response"


def test_the_core_imports_on_the_hook_interpreter():
    p = subprocess.run(["/usr/bin/env", "python3", "-c",
                        f"import sys; sys.path.insert(0, {ROOT!r}); "
                        "import ledger.types, ledger.events, ledger.projection, ledger.compat; "
                        "print('ok')"], capture_output=True, text=True, timeout=60)
    assert p.returncode == 0, p.stderr
    assert p.stdout.strip() == "ok"
