#!/usr/bin/env bash
# E2E for install.sh's ~/.scripts entry points. Runs the real installer against a throwaway
# HOME, then drives each linked script THROUGH THE SYMLINK -- the failure this covers was
# silence: the rules said "log it with ~/.scripts/blocker-log.py", the link did not exist,
# and no blocker was ever logged.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
fail=0
ok()   { echo "ok   $1"; }
bad()  { echo "FAIL $1"; [ $# -gt 1 ] && echo "     got:  $2"; fail=1; }

export HOME="$T" AGENT_DISCIPLINE_NO_CRON=1 AGENT_DISCIPLINE_CONFIG="$T/agent-discipline.env"
out="$(bash "$ROOT/install.sh" 2>&1)"

# every entry point the installer claims to link is a symlink into THIS checkout
mapfile -t names < <(sed -n '/^SCRIPT_LINKS=(/,/)/p' "$ROOT/install.sh" \
                     | tr ' ()' '\n\n\n' | sed 's/SCRIPT_LINKS=//' | grep -E '\.(sh|py)$')
[ "${#names[@]}" -ge 6 ] && ok "installer declares ${#names[@]} entry points" \
                         || bad "could not parse SCRIPT_LINKS" "${names[*]:-none}"
for n in "${names[@]}"; do
  t="$HOME/.scripts/$n"
  if [ -L "$t" ] && [ "$(readlink -f "$t")" = "$ROOT/scripts/$n" ]; then ok "~/.scripts/$n linked here"
  else bad "~/.scripts/$n not linked to this checkout" "$(readlink -f "$t" 2>/dev/null)"; fi
done
case " ${names[*]} " in *" blocker-log.py "*) ok "blocker-log.py is in the list" ;;
  *) bad "blocker-log.py missing from SCRIPT_LINKS -- the rules call that exact path" ;; esac

# the link must WORK, not merely exist: a script that resolves its own package root with
# abspath() gets ~/.scripts as the root and dies on import.
export AGENT_DISCIPLINE_MEMORY_DIR="$T/mem"
out="$("$HOME/.scripts/blocker-log.py" block --task T-1 --title "installer smoke" \
        --class access --reason "no credential" 2>&1)"
[[ "$out" == *"T-1"* ]] && ok "blocker-log.py runs through the symlink" \
                        || bad "blocker-log.py broken via symlink" "$out"
[ -f "$T/mem/blocker_log.tsv" ] && ok "blocker event landed in the memory dir" \
                                || bad "no blocker_log.tsv written"

out="$(bash "$ROOT/install.sh" --check 2>&1)"
[[ "$out" == *"already linked"* ]] && ok "--check on an installed tree says already linked" \
                                   || bad "second run not idempotent" "$out"

echo; [ $fail -eq 0 ] && echo "install links: PASS" || echo "install links: FAIL"
exit $fail
