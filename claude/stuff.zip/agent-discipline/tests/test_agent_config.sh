#!/usr/bin/env bash
# E2E for the roles config: agent-config.sh --show/--init, the precedence env > file > default,
# and both launchers reading it. Drives the real scripts; never starts claude (--show).
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
export AGENT_DISCIPLINE_CONFIG="$T/agent-discipline.env"
fail=0
check() { if [[ "$2" == *"$3"* ]]; then echo "ok   $1"; else echo "FAIL $1"; echo "     want: $3"; echo "     got:  $2"; fail=1; fi; }

out="$(bash "$ROOT/scripts/agent-config.sh" --show 2>&1)"
check "no file: show says how to create it" "$out" "not present, run agent-config.sh --init"
check "no file: defaults named with their source" "$out" "WORKER_MODEL         opus       from default"

out="$(bash "$ROOT/scripts/agent-config.sh" --init 2>&1)"
check "init says where it wrote and when it applies" "$out" "wrote $AGENT_DISCIPLINE_CONFIG"
grep -q '^WORKER_MODEL=opus' "$AGENT_DISCIPLINE_CONFIG" && echo "ok   template carries the defaults" || { echo "FAIL template"; fail=1; }
out="$(bash "$ROOT/scripts/agent-config.sh" --init 2>&1)"
check "second init does not overwrite" "$out" "already exists"

sed -i 's/^WORKER_MODEL=.*/WORKER_MODEL=sonnet  # cheaper/; s/^REVIEWER_MODEL=.*/REVIEWER_MODEL=haiku/' "$AGENT_DISCIPLINE_CONFIG"
out="$(bash "$ROOT/scripts/agent-config.sh" --show 2>&1)"
check "file value used, comment stripped, source is the file" "$out" "WORKER_MODEL         sonnet     from $AGENT_DISCIPLINE_CONFIG"
out="$(WORKER_MODEL=opus bash "$ROOT/scripts/agent-config.sh" --show 2>&1)"
check "env beats file" "$out" "WORKER_MODEL         opus       from env"

out="$(cd "$ROOT" && bash "$ROOT/scripts/agent-worker.sh" --show 2>&1)"
check "worker launcher reads the file" "$out" "model=sonnet effort=high reviewers=haiku"
check "worker launcher says where to change it" "$out" "change these in $AGENT_DISCIPLINE_CONFIG"
[[ "$out" != *"agent-discipline roles"* ]] && echo "ok   sourcing the config does not print its own --show" || { echo "FAIL config table leaked into worker output"; fail=1; }

out="$(cd "$ROOT" && bash "$ROOT/scripts/agent-orchestrator.sh" --show 2>&1)"; rc=$?
check "orchestrator launcher names effort and the worker/reviewer models" "$out" "effort=xhigh workers=sonnet/high reviewers=haiku"
[[ $rc -eq 0 ]] && echo "ok   orchestrator --show exits 0" || { echo "FAIL orchestrator --show exit $rc"; fail=1; }
out="$(cd "$ROOT" && ORCHESTRATOR_MODEL=opus bash "$ROOT/scripts/agent-orchestrator.sh" --show 2>&1)"
check "orchestrator model from env" "$out" "model=opus effort=xhigh"

# the rendered worker prompt carries the reviewer model, not the placeholder
out="$(sed "s/{{REVIEWER_MODEL}}/haiku/g" "$ROOT/prompts/worker.md")"
check "worker prompt has a reviewer-model slot" "$(cat "$ROOT/prompts/worker.md")" 'model: "{{REVIEWER_MODEL}}"'
check "rendered prompt names the model" "$out" 'model: "haiku"'

[[ $fail -eq 0 ]] && echo "ok — agent-config E2E passed" || { echo "FAILED"; exit 1; }
