"""Phase 2 exit criteria: a task creates M0, session state lives outside model context, exact
and structured retrieval outrank the lexical fallback, and context stays within budget."""
from __future__ import annotations

import json
import os
import subprocess
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from ledger.adapters import (Adapter, CanonAdapter, KnowledgeCandidate,  # noqa: E402
                             LedgerAdapter, MemoryKitAdapter, SourceHealth)
from ledger.events import ReceiptStore                                    # noqa: E402
from ledger.resolver import ResolutionRequest, Resolver                   # noqa: E402
from ledger.session import RevisionConflict, SessionState                 # noqa: E402
from ledger.types import (LedgerEntry, Lifecycle, RetrievalMetadata,      # noqa: E402
                          Scope, decision_key)

HOOK = os.path.join(ROOT, "hooks", "lcg-manifest.py")


def E(eid, authority="explicit_human_preference", scope=None, statement=None,
      kind="preference", autonomy="default", **lc):
    return LedgerEntry(id=eid, version=1, kind=kind, subject=eid.replace("-", " "),
                       statement=statement or f"statement for {eid}",
                       scope=scope or Scope(), authority=authority, status="active",
                       autonomy=autonomy, risk="low", created_by="t", created_at="2026-01-01",
                       retrieval=RetrievalMetadata(decision_keys=(eid,)),
                       lifecycle=Lifecycle(created_at="2026-01-01", **lc))


class Fake(Adapter):
    def __init__(self, name, candidates, healthy=True, detail="", raises=None):
        self.name, self._c, self._h, self._d, self._raises = name, candidates, healthy, detail, raises

    def health(self):
        if self._raises == "health":
            raise RuntimeError("boom")
        return SourceHealth(self.name, self._h, self._d, len(self._c))

    def query(self, req):
        if self._raises == "query":
            raise RuntimeError("query exploded")
        return self._c


def req(**kw):
    base = dict(request_id="r1", trigger="UserPromptSubmit", actor="u",
                repository="atlas", session="s1", task="change the settlement loader")
    base.update(kw)
    return ResolutionRequest(**base)


# --- a task creates M0 ---------------------------------------------------------------------

def test_a_task_creates_m0_at_revision_zero():
    m = Resolver([]).resolve(req())
    assert (m.manifest_id, m.revision, m.parent_manifest_id) == ("M0", 0, "")
    assert m.receipt_id.startswith("ctxr_")
    assert m.resolver_version


def test_a_child_manifest_increments_from_its_parent():
    r = Resolver([])
    m1 = r.resolve(req(), parent=r.resolve(req()))
    assert (m1.manifest_id, m1.revision, m1.parent_manifest_id) == ("M1", 1, "M0")


def test_the_rendered_manifest_says_it_is_incomplete():
    """R-014: M0 is a starting view, not a task specification."""
    assert "STARTING view" in Resolver([]).resolve(req()).render()


# --- authority beats the tier that found it -------------------------------------------------

def test_a_lexically_found_policy_still_outranks_an_exactly_keyed_inference():
    """R-003: retrieval must never cross an authority boundary. The tier only breaks ties.

    Both candidates are the SAME kind on purpose. An earlier version of this test used a policy
    and a preference, which land in different manifest sections — so it asserted the order of a
    one-item list and passed happily with authority and tier swapped in the sort key. A mutation
    run found it. Same bucket, or the assertion cannot fail."""
    weak = Fake("a", [KnowledgeCandidate("a", "w", E("w", "agent_inference", kind="policy"),
                                         "exact_decision_key")])
    strong = Fake("b", [KnowledgeCandidate("b", "s", E("s", "hard_policy", kind="policy"),
                                           "lexical_fallback")])
    ids = [p["id"] for p in Resolver([weak, strong]).resolve(req()).applicable_policies]
    assert ids == ["s", "w"], "a lexical hit on a hard policy still outranks a keyed inference"


def test_within_one_authority_class_the_better_tier_wins():
    a = Fake("a", [KnowledgeCandidate("a", "lex", E("lex"), "lexical_fallback")])
    b = Fake("b", [KnowledgeCandidate("b", "key", E("key"), "exact_decision_key")])
    ids = [p["id"] for p in Resolver([a, b]).resolve(req()).preferences]
    assert ids.index("key") < ids.index("lex")


def test_the_same_entry_from_two_tiers_keeps_the_better_one():
    e = E("dup")
    a = Fake("a", [KnowledgeCandidate("a", "dup", e, "lexical_fallback")])
    b = Fake("b", [KnowledgeCandidate("b", "dup", e, "exact_decision_key")])
    prefs = Resolver([a, b]).resolve(req()).preferences
    assert len(prefs) == 1 and prefs[0]["why"] == "exact_decision_key"


# --- budget ---------------------------------------------------------------------------------

def test_context_stays_within_budget_and_says_what_it_dropped():
    many = [KnowledgeCandidate("a", f"e{i}", E(f"e{i}", statement="x" * 200), "lexical_fallback")
            for i in range(20)]
    m = Resolver([Fake("a", many)]).resolve(req(character_budget=600))
    assert m.truncated, "a budget that never truncates is not a budget"
    assert len(m.preferences) < 20
    assert "omitted to stay within" in m.render()


def test_a_mandatory_item_is_never_dropped_for_budget():
    filler = [KnowledgeCandidate("a", f"f{i}", E(f"f{i}", statement="y" * 300), "lexical_fallback")
              for i in range(10)]
    must = KnowledgeCandidate("a", "must", E("must", "hard_policy", kind="policy",
                                             autonomy="mandatory", statement="z" * 300),
                              "lexical_fallback")
    m = Resolver([Fake("a", filler + [must])]).resolve(req(character_budget=100))
    assert [p["id"] for p in m.applicable_policies] == ["must"]
    assert "must" not in [t["id"] for t in m.truncated]


# --- degraded sources -------------------------------------------------------------------------

def test_an_unavailable_source_is_reported_not_silently_skipped():
    m = Resolver([Fake("canon", [], healthy=False, detail="not installed")]).resolve(req())
    assert m.degraded_sources[0]["source"] == "canon"
    assert "DEGRADED SOURCES" in m.render()


def test_a_source_that_raises_during_query_degrades_rather_than_crashing():
    m = Resolver([Fake("x", [], raises="query")]).resolve(req())
    assert "query exploded" in m.degraded_sources[0]["detail"]


def test_a_source_that_raises_during_health_degrades():
    m = Resolver([Fake("x", [], raises="health")]).resolve(req())
    assert "health check raised" in m.degraded_sources[0]["detail"]


def test_an_available_source_with_something_to_say_still_reports_it():
    """Unreadable records are not a failure, but the user must not learn of them by absence."""
    m = Resolver([Fake("ledger", [], detail="1 pref-* file unreadable")]).resolve(req())
    assert m.degraded_sources[0]["detail"] == "1 pref-* file unreadable"


# --- conflicts and autonomy boundary -----------------------------------------------------------

def test_a_conflict_is_reported_with_the_winner_and_the_reason():
    a = KnowledgeCandidate("s", "a", E("a", "hard_policy", kind="policy",
                                       statement="never"), "lexical_fallback")
    b = KnowledgeCandidate("s", "b", E("b", "agent_inference", kind="policy",
                                       statement="always"), "lexical_fallback")
    object.__setattr__(b.entry, "subject", a.entry.subject)
    m = Resolver([Fake("s", [a, b])]).resolve(req())
    assert m.conflicts and m.conflicts[0]["winner"] == "a"
    assert "Conflicts" in m.render()


def test_the_autonomy_boundary_is_the_most_restrictive_selected():
    c = [KnowledgeCandidate("s", "x", E("x", autonomy="advisory"), "lexical_fallback"),
         KnowledgeCandidate("s", "y", E("y", autonomy="never_auto_apply"), "lexical_fallback")]
    assert Resolver([Fake("s", c)]).resolve(req()).autonomy_boundary == "never_auto_apply"


# --- receipts -------------------------------------------------------------------------------------

def test_a_receipt_records_both_what_was_used_and_what_was_left_out(tmp_path):
    store = ReceiptStore(str(tmp_path / "r.jsonl"))
    many = [KnowledgeCandidate("a", f"e{i}", E(f"e{i}", statement="x" * 200), "lexical_fallback")
            for i in range(10)]
    m = Resolver([Fake("a", many)], receipts=store).resolve(req(character_budget=400))
    rec = store.get(m.receipt_id)
    assert {i["state"] for i in rec["items"]} >= {"selected", "rejected"}


# --- session state lives outside model context ------------------------------------------------

def test_state_round_trips_and_is_revisioned(tmp_path):
    s = SessionState(str(tmp_path / "s.json"))
    assert s.revision() == -1
    s.write({"a": 1})
    assert s.revision() == 0 and s.read()["a"] == 1
    s.write({"a": 2}, expected_revision=0)
    assert s.revision() == 1


def test_a_stale_writer_is_refused_rather_than_overwriting(tmp_path):
    s = SessionState(str(tmp_path / "s.json"))
    s.write({"a": 1})
    s.write({"a": 2}, expected_revision=0)
    with pytest.raises(RevisionConflict, match="recompute"):
        s.write({"a": 3}, expected_revision=0)


def test_creating_over_existing_state_is_refused(tmp_path):
    s = SessionState(str(tmp_path / "s.json"))
    s.write({"a": 1})
    with pytest.raises(RevisionConflict, match="already exists"):
        s.write({"a": 2})


def test_unreadable_state_reads_as_absent_not_as_a_crash(tmp_path):
    p = tmp_path / "s.json"
    p.write_text("{ truncated")
    assert SessionState(str(p)).read() is None


# --- adapters ------------------------------------------------------------------------------------

def test_the_ledger_adapter_prefers_exact_key_then_scope_then_lexical(tmp_path):
    topics = tmp_path / "topics"
    topics.mkdir()
    for name, triggers in [("pref-alpha", "settlement, loader"), ("pref-beta", "unrelated")]:
        (topics / f"{name}.md").write_text(
            f'---\nname: {name}\ndescription: "d"\ntriggers: "{triggers}"\n'
            f'metadata:\n  confidence: stated\n---\n\n**Preference:** do {name}.\n')
    ad = LedgerAdapter(str(topics))
    got = ad.query(req(decision_key=decision_key("pref-alpha")))
    assert got[0].entry.id == "pref-alpha" and got[0].why == "exact_decision_key"


def test_an_unscoped_entry_is_not_a_scope_match(tmp_path):
    """Measured: treating unscoped entries as scope matches returned the whole ledger for every
    prompt. An undeclared dimension does not constrain, so it cannot be a reason to retrieve."""
    from ledger.projection import ActiveProjection
    assert ActiveProjection([E("u")]).by_scope({"repository": "atlas"}) == []
    assert ActiveProjection([E("s", scope=Scope(repository="atlas"))]).by_scope(
        {"repository": "atlas"})


def test_the_canon_adapter_finds_rules_and_marks_them_mandatory(tmp_path):
    d = tmp_path / "canon"
    d.mkdir()
    (d / "data-safety.md").write_text(
        "## DS1: destructive SQL needs a bounded SELECT first\n"
        "<!-- key: 8f8b42 -->\n<!-- triggers: DELETE, DROP, production -->\n\nbody\n")
    ad = CanonAdapter(str(d))
    assert ad.health().available
    got = ad.query(req(task="DELETE rows from the production table"))
    assert got and got[0].entry.autonomy == "mandatory"
    assert got[0].entry.authority == "approved_team_decision"


def test_canon_missing_is_reported_as_unavailable_not_as_no_rules(tmp_path):
    h = CanonAdapter(str(tmp_path / "nope")).health()
    assert h.degraded and "UNAVAILABLE, not absent" in h.detail


def test_the_memory_adapter_ignores_ledger_records(tmp_path):
    d = tmp_path / "t"
    d.mkdir()
    (d / "pref-x.md").write_text("---\nname: pref-x\n---\n\n**Preference:** p.\n")
    (d / "note.md").write_text('---\nname: note\ndescription: "a fact"\ntriggers: "fact"\n---\n')
    ids = [e.id for e in MemoryKitAdapter(str(d))._load()]
    assert ids == ["memory:note"], "pref-* belongs to the ledger adapter"


# --- the hook ---------------------------------------------------------------------------------------

def run_hook(payload, env_extra=None, home=None):
    env = dict(os.environ)
    env.pop("LCG_RESOLVER", None)
    env.pop("LCG_INJECT_M0", None)
    env["AGENT_DISCIPLINE_CONFIG"] = "/nonexistent/agent-discipline.env"
    if home:
        env["HOME"] = str(home)
    env.update(env_extra or {})
    return subprocess.run([sys.executable, HOOK], input=json.dumps(payload),
                          capture_output=True, text=True, timeout=90, env=env)


def test_the_hook_is_silent_by_default(tmp_path):
    p = run_hook({"prompt": "anything", "session_id": "s", "cwd": str(tmp_path)}, home=tmp_path)
    assert p.returncode == 0 and p.stdout.strip() == ""


def test_the_resolver_alone_writes_state_but_injects_nothing(tmp_path):
    p = run_hook({"prompt": "worktree", "session_id": "sx", "cwd": str(tmp_path)},
                 {"LCG_RESOLVER": "1"}, home=tmp_path)
    assert p.stdout.strip() == "", "LCG_RESOLVER alone is a measurement lane"
    assert (tmp_path / ".claude/tmp/lcg/sx.json").exists()


def test_injection_requires_its_own_flag(tmp_path):
    p = run_hook({"prompt": "worktree", "session_id": "sy", "cwd": str(tmp_path)},
                 {"LCG_RESOLVER": "1", "LCG_INJECT_M0": "1"}, home=tmp_path)
    out = json.loads(p.stdout)["hookSpecificOutput"]
    assert out["hookEventName"] == "UserPromptSubmit"
    assert "LEDGER TASK CONTEXT" in out["additionalContext"]
    assert "permissionDecision" not in out, "UserPromptSubmit cannot and must not block"


def test_the_hook_never_crashes_a_prompt(tmp_path):
    assert run_hook({"not": "a prompt"}, {"LCG_RESOLVER": "1"}, home=tmp_path).returncode == 0
    p = subprocess.run([sys.executable, HOOK], input="not json",
                       capture_output=True, text=True, timeout=60)
    assert p.returncode == 0


def test_state_is_written_outside_the_repository(tmp_path):
    run_hook({"prompt": "x", "session_id": "sz", "cwd": str(tmp_path)},
             {"LCG_RESOLVER": "1"}, home=tmp_path)
    state = tmp_path / ".claude/tmp/lcg/sz.json"
    assert state.exists()
    d = json.loads(state.read_text())
    assert d["revision"] == 0 and d["manifest"]["manifest_id"] == "M0"


def test_the_resolver_core_still_has_no_hook_types():
    import pathlib
    for f in pathlib.Path(ROOT, "ledger").glob("*.py"):
        src = f.read_text()
        assert "tool_input" not in src and "hookSpecificOutput" not in src, f.name
