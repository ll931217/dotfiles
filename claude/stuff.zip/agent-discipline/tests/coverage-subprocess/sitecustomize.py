# On PYTHONPATH only while scripts/run-tests.sh measures coverage: makes every python3 subprocess
# a shell test spawns record its own coverage. Without it the CLI scripts read as 0% covered even
# though tests/*.sh drive them end to end. Silent when coverage is absent — this file must never
# be the reason a subprocess fails to start.
try:
    import coverage
    coverage.process_startup()
except Exception:
    pass
