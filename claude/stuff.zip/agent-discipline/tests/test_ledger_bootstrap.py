"""ledger-bootstrap.py: candidates, never records — and a draft that does not know what was
rejected cannot enter the ledger. Runs against a synthetic memory dir."""
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
BOOT = os.path.join(ROOT, "scripts", "ledger-bootstrap.py")
HOOK = os.path.join(ROOT, "hooks", "pref-checkpoint.py")

CORRECTION = (
    "2026-08-04T09:12:59+08:00\tsess-1\thuman-correction\t-\t"
    "Rejected disabling gbrain self_upgrade; directed proxy env on the MCP entry instead"
    "\tturn ~3\n")
TOPIC = """---
description: a cue line that is metadata, not a preference
triggers: compile, build
---

# Local compiles

User correction: "don't ever compile on this machine, always use the build server" — the
workstation thermal-throttles and the run takes four times as long.
"""


def mem(tmp_path, corrections=True, topic=True, uncovered=0):
    d = tmp_path / "mem"
    (d / "topics").mkdir(parents=True)
    if corrections:
        (d / "rule_effect_log.tsv").write_text(CORRECTION)
    if topic:
        (d / "topics" / "no-local-compile.md").write_text(TOPIC)
    if uncovered:
        rows = ["ts\tkind\tsession\tdetail\textra"]
        rows += ["2026-09-03T10:00:00+08:00\tuncovered\ts1\t-\twhich region for the cluster?"
                 ] * uncovered
        (d / "pref_events.tsv").write_text("\n".join(rows) + "\n")
    return d


def run(memdir, *args):
    env = dict(os.environ, AGENT_DISCIPLINE_MEMORY_DIR=str(memdir))
    return subprocess.run([sys.executable, BOOT, *args], env=env, capture_output=True, text=True)


def test_dry_run_is_the_default_and_writes_nothing(tmp_path):
    d = mem(tmp_path)
    r = run(d)
    assert "DRY RUN" in r.stdout and "nothing written" in r.stdout
    assert not (d / "topics" / "drafts").exists()


def test_frontmatter_is_not_mistaken_for_a_preference(tmp_path):
    d = mem(tmp_path)
    out = run(d).stdout
    assert "a cue line that is metadata" not in out, "description: is a retrieval cue, not a rule"
    assert "compile on this machine" in out


def test_drafts_land_outside_the_flat_topics_dir(tmp_path):
    d = mem(tmp_path)
    r = run(d, "--write-drafts")
    assert r.returncode == 0, r.stderr
    drafts = list((d / "topics" / "drafts").glob("*.md"))
    assert drafts, r.stdout
    # the recall hook and pref-checkpoint scan the FLAT topics/ only
    assert not list((d / "topics").glob("pref-*.md")), "a draft must not be a record"


def test_a_draft_is_invisible_to_the_checkpoint_hook(tmp_path):
    import json
    d = mem(tmp_path)
    run(d, "--write-drafts")
    ev = {"tool_name": "AskUserQuestion", "session_id": "s", "tool_input": {"questions": [
        {"question": "should we compile on this machine or the build server?", "header": "H",
         "options": [{"label": "a", "description": "x"}, {"label": "b", "description": "y"}]}]}}
    r = subprocess.run([sys.executable, HOOK], input=json.dumps(ev), capture_output=True,
                       text=True, env=dict(os.environ, AGENT_DISCIPLINE_MEMORY_DIR=str(d)))
    assert r.stdout.strip() == "", "a draft was injected as if it were a decision"


def test_promote_is_refused_while_the_rejected_option_is_unknown(tmp_path):
    d = mem(tmp_path)
    run(d, "--write-drafts")
    slug = sorted(p.stem for p in (d / "topics" / "drafts").glob("*.md"))[0]
    r = run(d, "--promote", slug)
    assert r.returncode == 1
    assert "REFUSED" in r.stdout and "UNKNOWN" in r.stdout
    assert not (d / "topics" / f"pref-{slug}.md").exists()


def test_promote_works_once_a_human_filled_it_in(tmp_path):
    d = mem(tmp_path)
    run(d, "--write-drafts")
    slug = sorted(p.stem for p in (d / "topics" / "drafts").glob("*.md"))[0]
    p = d / "topics" / "drafts" / f"{slug}.md"
    body = p.read_text()
    while "UNKNOWN" in body:
        body = body.replace("UNKNOWN — fill this in or delete the draft", "the build server", 1)
    p.write_text(body)
    r = run(d, "--promote", slug)
    assert r.returncode == 0, r.stdout
    assert (d / "topics" / f"pref-{slug}.md").exists()
    assert not p.exists(), "the draft is moved, not copied"
    assert "triggers:" in r.stdout, "it must remind you the cue is still empty"


def test_list_says_which_drafts_are_ready(tmp_path):
    d = mem(tmp_path)
    run(d, "--write-drafts")
    out = run(d, "--list").stdout
    assert "needs edit" in out and "UNKNOWN" in out


def test_rerun_skips_what_is_already_in_the_ledger(tmp_path):
    d = mem(tmp_path)
    run(d, "--write-drafts")
    slug = sorted(p.stem for p in (d / "topics" / "drafts").glob("*.md"))[0]
    (d / "topics" / f"pref-{slug}.md").write_text("**Preference:** x\n")
    out = run(d).stdout
    assert "already in the ledger, skipped" in out


def test_repeated_uncovered_asks_become_a_stub_with_no_invented_answer(tmp_path):
    d = mem(tmp_path, corrections=False, topic=False, uncovered=3)
    out = run(d).stdout
    assert "uncovered-only" in out and "which region for the cluster?" in out
    run(d, "--write-drafts")
    body = sorted((d / "topics" / "drafts").glob("*.md"))[0].read_text()
    assert body.count("UNKNOWN") >= 4, "nothing about the answer may be invented"
    assert "confidence: uncovered-only" in body


def test_empty_memory_says_what_it_could_not_read(tmp_path):
    d = tmp_path / "mem"
    (d / "topics").mkdir(parents=True)
    out = run(d).stdout
    assert "nothing to draft" in out
    assert "not the same as" in out, "an empty result must not read as a clean bill of health"
