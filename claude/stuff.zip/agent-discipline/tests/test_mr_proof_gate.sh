#!/usr/bin/env bash
# E2E for hooks/mr-proof-gate.py. The failure it covers: an MR body that CLAIMS the tests pass,
# which a reviewer cannot verify from the MR page. A "Proof" heading over prose is the same
# claim with a heading on it, so the gate needs both the section and a real artifact.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
HOOK="$ROOT/hooks/mr-proof-gate.py"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
fail=0
ok()  { echo "ok   $1"; }
bad() { echo "FAIL $1"; [ $# -gt 1 ] && echo "     got:  ${2:-<empty>}"; fail=1; }

fire() {   # command, cwd -> deny reason (empty when allowed)
  jq -nc --arg c "$1" --arg w "$2" '{tool_name:"Bash",cwd:$w,tool_input:{command:$c}}' \
  | python3 "$HOOK" | jq -r '.hookSpecificOutput.permissionDecisionReason // ""' 2>/dev/null
}

# ── allowed ───────────────────────────────────────────────────────────────────────
out="$(fire 'git push -u origin HEAD' "$T")"
[ -z "$out" ] && ok "an unrelated command is untouched" || bad "unrelated denied" "$out"

out="$(fire 'glab mr create --fill --yes' "$T")"
[ -z "$out" ] && ok "--fill (the documented chore path) is exempt" || bad "--fill denied" "$out"

printf '## Proof\n```\n$ ./run-tests.sh\n42 passed\n```\n' > "$T/good.md"
out="$(fire 'glab mr create --description "$(cat good.md)" --yes' "$T")"
[ -z "$out" ] && ok "a Proof section with a fenced run passes" || bad "good body denied" "$out"

printf 'Body.\n\n**Proof:** ![shot](/uploads/a/b.png)\n' > "$T/img.md"
out="$(fire 'glab mr create --description-file img.md --yes' "$T")"
[ -z "$out" ] && ok "a screenshot counts as the artifact" || bad "screenshot denied" "$out"

# ── denied ────────────────────────────────────────────────────────────────────────
printf 'Splits transport into client and stream.\n\nCheck: tests/test_transport.py\n' > "$T/none.md"
out="$(fire 'glab mr create --description "$(cat none.md)" --yes' "$T")"
[[ "$out" == *"missing a Proof section"* ]] && ok "no Proof section is denied" || bad "no proof" "$out"
[[ "$out" == *"tmux capture-pane"* ]] && ok "the deny says how to capture it" || bad "no how-to" "$out"

printf '## Proof\nAll tests pass, I ran the suite locally.\n' > "$T/prose.md"
out="$(fire 'glab mr create --description "$(cat prose.md)" --yes' "$T")"
[[ "$out" == *"missing an artifact under Proof"* ]] && ok "a Proof heading over prose is denied" \
                                                    || bad "prose proof allowed" "$out"

out="$(fire 'glab mr create --description "one line, no proof" --yes' "$T")"
[[ "$out" == *"missing a Proof section"* ]] && ok "an inline body is judged too" || bad "inline" "$out"

[ $fail -eq 0 ] && echo "PASS" || echo "FAILURES"
exit $fail
