#!/usr/bin/env bash
# E2E for scripts/orchestrate.py: drives the real script against a throwaway git repo with a
# fake `wt`, `glab` and `bd` on PATH. Asserts what the orchestrator SEES, not just exit codes.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ORCH="$ROOT/scripts/orchestrate.py"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
fail=0
check() { if [[ "$2" == *"$3"* ]]; then echo "ok   $1"; else echo "FAIL $1"; echo "     want: $3"; echo "     got:  $2"; fail=1; fi; }

# ledger with one record whose cue overlaps the task
mkdir -p "$T/mem/topics"
cat > "$T/mem/topics/pref-worktree-not-branch.md" <<'P'
---
description: "worktree instead of branch"
triggers: "worktree, branch"
---
**Preference:** start work in a worktree, never `git checkout -b` in the main checkout.

**Chose:** x
P
export AGENT_DISCIPLINE_MEMORY_DIR="$T/mem"

# repo + fakes
git -C "$T" init -q repo && cd "$T/repo" && git -c user.name=t -c user.email=t@t commit -q --allow-empty -m init
mkdir -p "$T/bin"
cat > "$T/bin/wt" <<'W'
#!/usr/bin/env bash
# fake worktrunk: `wt switch --create B --yes [--base X]` -> git worktree add
b="$3"; root="$(git rev-parse --show-toplevel)"
git worktree add -q -b "$b" "$root/.worktrees/${b//\//-}" >/dev/null 2>&1
W
cat > "$T/bin/glab" <<'G'
#!/usr/bin/env bash
echo '[{"iid": 7, "state": "opened", "head_pipeline": {"status": "running"}}]'
G
chmod +x "$T/bin/wt" "$T/bin/glab"
export PATH="$T/bin:$PATH"; unset TMUX

# no bd AND no jira.py: plan has no source at all and must say how to proceed by hand
out="$(JIRA_PY=/nonexistent-jira python3 "$ORCH" plan 2>&1)"
check "plan with no task source names what is missing" "$out" "nothing to plan from"
check "plan names the dispatch command" "$out" "orchestrate.py dispatch --branch"

# no bd but a jira.py present: it falls back, and the NARROWER answer must be labelled
cat > "$T/bin/fake-jira.py" <<'J'
import json, sys
print(json.dumps({"count": 1, "issues": [
    {"key": "DE-1", "summary": "a jira task", "priority": "High"}]}))
J
out="$(JIRA_PY="$T/bin/fake-jira.py" python3 "$ORCH" plan 2>&1)"
check "jira fallback lists the task"        "$out" "DE-1"
check "jira fallback names its source"      "$out" "[source: jira]"
check "jira fallback admits what it cannot check" "$out" "Blocked-by relationships were NOT checked"

out="$(python3 "$ORCH" status 2>&1)"
check "status with nothing dispatched says so" "$out" "no worktrees — nothing dispatched"

out="$(python3 "$ORCH" dispatch --branch feat/x --task "move the worktree helper into a branch-safe module" --orchestrator agent-discipline-81 2>&1)"; rc=$?
[[ $rc -eq 0 ]] && echo "ok   dispatch exits 0" || { echo "FAIL dispatch exit $rc: $out"; fail=1; }
wt="$T/repo/.worktrees/feat-x"
check "dispatch names the worktree" "$out" "worktree : $wt"
check "dispatch names the worker as ListAgents will show it" "$out" '`worker:feat/x`'
check "dispatch warns when no tmux started a worker" "$out" "no tmux"
# no worker was started here (no TMUX), so it must NOT tell the orchestrator to message one
[[ "$out" != *'SendMessage it:'* ]] \
  && echo "ok   no worker started -> no SendMessage instruction" \
  || { echo "FAIL tells you to message a worker that was never started"; fail=1; }

# with wt AND tmux, the worker really does start, so the SendMessage line is the right next step
out2="$(TMUX=fake python3 "$ORCH" dispatch --branch feat/tmux --task "another task" --orchestrator agent-discipline-81 2>&1)"
check "with tmux, dispatch says what to do next" "$out2" 'SendMessage it: "Read .claude/TASK.md and begin."'
[[ "$out2" != *"NO worker session"* ]] && echo "ok   with wt+tmux it does not claim the worker is missing" \
  || { echo "FAIL contradicts itself about the worker"; fail=1; }
task="$(cat "$wt/.claude/TASK.md")"
check "TASK.md carries the orchestrator name" "$task" "Orchestrator: agent-discipline-81"
check "TASK.md carries the matching preference text, not just its filename" "$task" "start work in a worktree, never"
check "TASK.md says MR target is staging" "$task" "MR target: staging"

out="$(python3 "$ORCH" status 2>&1)"
check "status shows the worker with no DoD yet" "$out" "dod no DoD yet"
check "status shows the MR the fake glab returned" "$out" "mr !7 opened"

python3 "$ROOT/scripts/delegate.py" start --worktree "$wt" --task t --dod "[tests] one" --key DE-9 >/dev/null
python3 "$ROOT/scripts/delegate.py" report --worktree "$wt" >/dev/null
out="$(python3 "$ORCH" status --no-mr 2>&1)"
check "reported worker tells the orchestrator to review" "$out" "REVIEW: read the DoD named below"
check "status names the task's own DoD file"           "$out" ".claude/dod/DE-9.md"
# One DoD per task: a shared .claude/DOD.md is tracked, and two workers on one repo collided
# on it in git — the second ran against a DoD it could not write.
[[ -f "$wt/.claude/dod/DE-9.md" ]] && echo "ok   the DoD is written per task" \
  || { echo "FAIL no per-task DoD file"; fail=1; }
[[ ! -f "$wt/.claude/DOD.md" ]] && echo "ok   the shared DOD.md is not created" \
  || { echo "FAIL wrote the shared DOD.md"; fail=1; }
# a delegation started before this change keeps its file
wt2="$T/repo/.worktrees/feat-legacy"; mkdir -p "$wt2/.claude"; : > "$wt2/.claude/DOD.md"
out="$(python3 "$ROOT/scripts/delegate.py" start --worktree "$wt2" --task t --dod "- x" --key DE-8 2>&1)"
[[ "$out" == *".claude/DOD.md"* ]] && echo "ok   an existing legacy DOD.md keeps being used" \
  || { echo "FAIL legacy DoD abandoned mid-flight"; echo "     got: $out"; fail=1; }

out="$(python3 "$ORCH" reject --worktree "$wt" --issue "tests item fails: no red path" 2>&1)"
check "reject prints the message to send" "$out" "Rejected: tests item fails"
out="$(python3 "$ORCH" approve --worktree "$wt" 2>&1)"
check "approve prints the MR instruction for the worker" "$out" "glab mr create --target-branch staging"
check "and tells the worker to write the body with show-me, not --fill" "$out" "show-me skill"
[[ "$out" != *"--fill"* ]] && echo "ok   approve does not offer --fill on reviewed work" \
  || { echo "FAIL approve still suggests --fill"; fail=1; }

# The worker's MR command must only use flags the real glab has. --description-file does not
# exist in glab 1.x, so a finished task died at its last step with "unknown flag".
# ponytail: guards the one flag that bit us; widen to a --help diff if a second flag ever does.
for src in "$out" "$(cat "$ROOT/prompts/worker.md")" "$(cat "$ROOT/skills/show-me/SKILL.md")"; do
  [[ "$src" == *"--description-file"* ]] && { echo "FAIL --description-file is not a glab flag"; fail=1; }
done
[[ $fail -eq 0 ]] && echo "ok   the MR command uses --description, which glab actually has"

out="$(cd "$wt" && python3 "$ORCH" dispatch --branch feat/y --task t --orchestrator o 2>&1)"; rc=$?
check "dispatch from inside a worktree refuses and says where to run" "$out" "run dispatch from the MAIN checkout"
[[ $rc -ne 0 ]] && echo "ok   refused dispatch exits non-zero" || { echo "FAIL refused dispatch exited 0"; fail=1; }

[[ $fail -eq 0 ]] && echo "ok — orchestrate E2E passed" || { echo "FAILED"; exit 1; }

# ── the bookkeeping must be invisible to git, or the reaper can never clean up ─────
# Written into the MAIN checkout: .gitignore is tracked with one working copy per worktree, so
# appending to the worktree's copy dirties the worktree — the exact state that blocks reaping.
grep -q "agent-discipline: delegation bookkeeping" "$T/repo/.gitignore" \
  && echo "ok   dispatch added the ignore block to the main .gitignore" \
  || { echo "FAIL no ignore block in .gitignore"; fail=1; }
grep -q "^.claude/dod/$" "$T/repo/.gitignore" \
  && echo "ok   the per-task DoD directory is ignored, not just DOD.md" \
  || { echo "FAIL .claude/dod/ not ignored"; fail=1; }
grep -q "^.claude/TASK.md$" "$T/repo/.git/info/exclude" \
  && echo "ok   info/exclude carries it too (in effect before any commit)" \
  || { echo "FAIL nothing in info/exclude"; fail=1; }
[[ -z "$(git -C "$wt" status --porcelain)" ]] \
  && echo "ok   the dispatched worktree is CLEAN, so worktree-reap can remove it" \
  || { echo "FAIL worktree dirty: $(git -C "$wt" status --porcelain | head -3)"; fail=1; }

before="$(wc -l < "$T/repo/.gitignore")"
python3 "$ORCH" dispatch --branch feat/again --task "t2" --orchestrator me --key DE-6 >/dev/null 2>&1
after="$(wc -l < "$T/repo/.gitignore")"
[[ "$before" == "$after" ]] && echo "ok   a second dispatch does not append the block again ($after lines)" \
  || { echo "FAIL block appended twice ($before -> $after)"; fail=1; }

# entries already there by hand: leave the file alone entirely
r2="$T/handwritten"; git init -q "$r2"
printf '.claude/TASK.md\n.claude/delegate.json\n.claude/dod/\n.claude/DOD.md\n.claude/mr-body.md\n' > "$r2/.gitignore"
sum_before="$(md5sum < "$r2/.gitignore")"
python3 - "$ROOT" "$r2" <<'PY'
import importlib.util, sys
spec = importlib.util.spec_from_file_location("d", f"{sys.argv[1]}/scripts/delegate.py")
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
m.ensure_ignored(sys.argv[2])
PY
[[ "$sum_before" == "$(md5sum < "$r2/.gitignore")" ]] \
  && echo "ok   entries already present by hand: the file is not touched" \
  || { echo "FAIL rewrote a .gitignore that already had the entries"; fail=1; }

# ── the small lane: gated on the paths, and it says which path failed ──────────────
out="$(python3 "$ORCH" dispatch --branch feat/small --task "let STRDs review own machines" \
        --orchestrator me --key DE-7 --small --touches src/perms.py 2>&1)"
check "small lane accepted, and dispatch SAYS the lane is small" "$out" "lane     : SMALL"
check "it names what the lane costs the worker" "$out" "2 lenses (intent, tests), 1 round"
swt="$(python3 "$ORCH" status --repo "$T/repo" --no-mr | grep -A1 '^feat/small$' | sed -n 's/^  path //p')"
grep -q '^## Lane: SMALL$' "$swt/.claude/TASK.md" \
  && echo "ok   TASK.md carries the Lane: SMALL block the worker reads" \
  || { echo "FAIL no Lane: SMALL block in $swt/.claude/TASK.md"; fail=1; }
grep -q 'ONLY `dod-intent` and `dod-tests`' "$swt/.claude/TASK.md" \
  && echo "ok   the block names the two lenses, so the worker needs no other source" \
  || { echo "FAIL block does not name the reduced lens set"; fail=1; }

# a CI path can never take the lane — and the refusal must name the offending path
out="$(python3 "$ORCH" dispatch --branch feat/ci --task "t" --orchestrator me \
        --small --touches src/perms.py .gitlab-ci.yml 2>&1)"; rc=$?
[[ $rc -ne 0 ]] && echo "ok   --small with a CI path exits non-zero" \
  || { echo "FAIL CI path was allowed onto the small lane"; fail=1; }
check "the refusal names the offending path" "$out" ".gitlab-ci.yml"
check "the refusal names the next action" "$out" "re-run without --small"
[[ -z "$(git -C "$T/repo" worktree list | grep feat/ci || true)" ]] \
  && echo "ok   a refused --small left no worktree behind" \
  || { echo "FAIL refused dispatch still created a worktree"; fail=1; }

# too many paths, and --small with no --touches at all
out="$(python3 "$ORCH" dispatch --branch feat/many --task "t" --orchestrator me --small \
        --touches a.py b.py c.py d.py 2>&1)"
check "4 paths refused, with the count and the limit" "$out" "at most 3"
out="$(python3 "$ORCH" dispatch --branch feat/none --task "t" --orchestrator me --small 2>&1)"
check "--small without --touches is refused, not silently allowed" "$out" "--small needs --touches"

# without --small nothing changes: no lane block
out="$(python3 "$ORCH" dispatch --branch feat/full --task "t" --orchestrator me 2>&1)"
fwt="$(python3 "$ORCH" status --repo "$T/repo" --no-mr | grep -A1 '^feat/full$' | sed -n 's/^  path //p')"
grep -q 'Lane: SMALL' "$fwt/.claude/TASK.md" \
  && { echo "FAIL full-lane TASK.md claims the small lane"; fail=1; } \
  || echo "ok   a normal dispatch writes no lane block (full ceremony stays the default)"

# ── the urgent lane: no path gate, but the skipped review must be BOOKED ──────────
cat > "$T/bin/bd" <<'B'
#!/usr/bin/env bash
[[ "$1" == "create" ]] && { echo "$*" >> "$BD_LOG"; echo "created issue repo-u1"; exit 0; }
exit 1
B
chmod +x "$T/bin/bd"; export BD_LOG="$T/bd.log"; mkdir -p "$T/repo/.beads"
out="$(python3 "$ORCH" dispatch --branch fix/prod-auth --task "restore STRD login" \
        --orchestrator me --key DE-9 --urgent --why "all STRD logins 403 since 09:12" 2>&1)"
check "urgent lane accepted and named" "$out" "lane     : URGENT"
check "dispatch says the debt was booked, with the id" "$out" "debt     : repo-u1"
check "the debt bead carries the urgent-lane-debt label" "$(cat "$T/bd.log")" "urgent-lane-debt"
check "the bead body names what was skipped" "$(cat "$T/bd.log")" "dod-intent"
uwt="$(python3 "$ORCH" status --repo "$T/repo" --no-mr | grep -A1 '^fix/prod-auth$' | sed -n 's/^  path //p')"
grep -q '^## Lane: URGENT$' "$uwt/.claude/TASK.md" \
  && echo "ok   TASK.md carries the Lane: URGENT block" \
  || { echo "FAIL no Lane: URGENT block"; fail=1; }
check "the block quotes what is broken" "$(cat "$uwt/.claude/TASK.md")" "all STRD logins 403 since 09:12"
check "the block tells the worker not to wait for approval" "$(cat "$uwt/.claude/TASK.md")" "do not wait for the orchestrator to approve"
check "the block names the debt bead so the MR can cite it" "$(cat "$uwt/.claude/TASK.md")" "repo-u1"

# a CI path is fine here — that is the whole difference from --small
out="$(python3 "$ORCH" dispatch --branch fix/ci-urgent --task "t" --orchestrator me \
        --urgent --why "deploys blocked" --touches .gitlab-ci.yml 2>&1)"
check "urgent has NO path gate: a CI path is accepted" "$out" "lane     : URGENT"

# the guards that keep the lane from becoming the default
out="$(python3 "$ORCH" dispatch --branch fix/nowhy --task "t" --orchestrator me --urgent 2>&1)"; rc=$?
[[ $rc -ne 0 ]] && echo "ok   --urgent without --why exits non-zero" \
  || { echo "FAIL --urgent accepted with no reason"; fail=1; }
check "and says what --why is for" "$out" "what is broken in production"
out="$(python3 "$ORCH" dispatch --branch fix/both --task "t" --orchestrator me --small \
        --touches a.py --urgent --why "x" 2>&1)"
check "--small and --urgent together are refused" "$out" "Pick one."
[[ -z "$(git -C "$T/repo" worktree list | grep -E 'fix/nowhy|fix/both' || true)" ]] \
  && echo "ok   a refused lane left no worktree behind" \
  || { echo "FAIL refused dispatch still created a worktree"; fail=1; }

# no bd -> the skip must be announced as UNRECORDED, never silently dropped
rm "$T/bin/bd"
out="$(python3 "$ORCH" dispatch --branch fix/nobd --task "t" --orchestrator me \
        --urgent --why "prod down" 2>&1)"
check "with no bd, dispatch says the debt is NOT booked" "$out" "NOT BOOKED"
nwt="$(python3 "$ORCH" status --repo "$T/repo" --no-mr | grep -A1 '^fix/nobd$' | sed -n 's/^  path //p')"
check "and TASK.md tells the worker to escalate it" "$(cat "$nwt/.claude/TASK.md")" "could NOT be booked"

# ── the risky lane: you fall into it, and it stops before any code ─────────────────
out="$(python3 "$ORCH" dispatch --branch feat/risky --task "add a column" --orchestrator me \
        --key DE-R1 --touches migrations/003_add_col.sql 2>&1)"
check "a migration path upgrades a plain dispatch to the risky lane" "$out" "lane     : RISKY"
check "and says the paths chose it, not a person" "$out" "the paths did"
rwt="$(python3 "$ORCH" status --repo "$T/repo" --no-mr | grep -A1 '^feat/risky$' | sed -n 's/^  path //p')"
check "TASK.md tells the worker to submit a plan first" "$(cat "$rwt/.claude/TASK.md")" "plan-ready --worktree ."
check "and to write no code until it is approved" "$(cat "$rwt/.claude/TASK.md")" "Write no code until it approves"
out="$(python3 "$ORCH" dispatch --branch feat/risky2 --task "t" --orchestrator me --lane risky 2>&1)"
check "--lane risky can also be asked for outright" "$out" "lane     : RISKY"

# the gate itself: plan-ready -> the orchestrator reviews a PLAN, and approve means "start"
python3 "$ROOT/scripts/delegate.py" start --worktree "$rwt" --task t --dod "[intent] one" --key DE-R1 >/dev/null
python3 "$ROOT/scripts/delegate.py" plan-ready --worktree "$rwt" --plan "add the column, no backfill" >/dev/null
out="$(python3 "$ORCH" status --repo "$T/repo" --no-mr 2>&1)"
check "status distinguishes a plan waiting from a diff waiting" "$out" "REVIEW THE PLAN"
check "and says no code exists yet" "$out" "no code exists yet"
out="$(python3 "$ORCH" approve --worktree "$rwt" 2>&1)"
check "approving a plan tells the worker to implement, not to open an MR" "$out" "Plan approved. Implement it."
[[ "$out" != *"glab mr create"* ]] && echo "ok   a plan approval does not ask for an MR on an empty branch" \
  || { echo "FAIL told the worker to open an MR before any code"; fail=1; }
out="$(python3 "$ORCH" approve --worktree "$rwt" 2>&1)"
check "approving again is the ordinary accept, now that the plan gate is passed" "$out" "glab mr create"
# the MR body file is bookkeeping: un-ignored, it dirties the worktree and blocks the reaper
grep -q "^.claude/mr-body.md$" "$T/repo/.gitignore" \
  && echo "ok   the MR body file is git-ignored, so writing it keeps the worktree reapable" \
  || { echo "FAIL .claude/mr-body.md not ignored"; fail=1; }

# ── mechanical: many files, one shape — no path CAP, but the same risky-path gate ──
out="$(python3 "$ORCH" dispatch --branch chore/rename --task "rename fetchQuote" --orchestrator me \
        --lane mechanical --touches a.py b.py c.py d.py e.py 2>&1)"
check "5 paths are fine on the mechanical lane" "$out" "lane     : MECHANICAL"
mwt="$(python3 "$ORCH" status --repo "$T/repo" --no-mr | grep -A1 '^chore/rename$' | sed -n 's/^  path //p')"
check "TASK.md makes the worker prove the diff is uniform" "$(cat "$mwt/.claude/TASK.md")" "must be the same edit repeated"
out="$(python3 "$ORCH" dispatch --branch chore/mech-ci --task "t" --orchestrator me \
        --lane mechanical --touches a.py Dockerfile 2>&1)"; rc=$?
[[ $rc -ne 0 ]] && echo "ok   mechanical still refuses an infra path" || { echo "FAIL infra path on mechanical"; fail=1; }
check "and names it" "$out" "Dockerfile"

# ── spike: no lenses, no MR, and it must name the question ────────────────────────
out="$(python3 "$ORCH" dispatch --branch spike/x --task "try duckdb" --orchestrator me \
        --lane spike --why "is duckdb fast enough for the nightly join" 2>&1)"
check "spike lane names what it costs" "$out" "no lenses, no MR"
swt2="$(python3 "$ORCH" status --repo "$T/repo" --no-mr | grep -A1 '^spike/x$' | sed -n 's/^  path //p')"
check "TASK.md carries the question being answered" "$(cat "$swt2/.claude/TASK.md")" "is duckdb fast enough"
check "and forbids growing the spike into the real work" "$(cat "$swt2/.claude/TASK.md")" "never grow this one into it"
out="$(python3 "$ORCH" dispatch --branch spike/noq --task "t" --orchestrator me --lane spike 2>&1)"; rc=$?
[[ $rc -ne 0 ]] && echo "ok   a spike with no question is refused" || { echo "FAIL spike with no question"; fail=1; }
check "and says why a question is required" "$out" "just unreviewed code"

# ── revert: must name the commit it undoes ────────────────────────────────────────
out="$(python3 "$ORCH" dispatch --branch revert/bad --task "undo the bad merge" --orchestrator me \
        --lane revert --revert-of deadbee 2>&1)"
check "revert lane accepted" "$out" "lane     : REVERT"
vwt="$(python3 "$ORCH" status --repo "$T/repo" --no-mr | grep -A1 '^revert/bad$' | sed -n 's/^  path //p')"
check "TASK.md gives the exact revert command" "$(cat "$vwt/.claude/TASK.md")" "git revert --no-edit deadbee"
check "and voids the lane if the diff carries anything extra" "$(cat "$vwt/.claude/TASK.md")" "voids the lane"
out="$(python3 "$ORCH" dispatch --branch revert/none --task "t" --orchestrator me --lane revert 2>&1)"; rc=$?
[[ $rc -ne 0 ]] && echo "ok   revert without --revert-of is refused" || { echo "FAIL revert with no target"; fail=1; }
check "and names the flag it needs" "$out" "--revert-of <sha>"

# ── repay: the urgent lane's debt actually comes back ─────────────────────────────
cat > "$T/bin/bd" <<'B'
#!/usr/bin/env bash
case "$1" in
  create) echo "$*" >> "$BD_LOG"; echo "created issue repo-u1";;
  show)   echo "[urgent-lane] review fix/prod-auth with the lenses the fire skipped"
          echo "What: re-review through dod-intent, dod-discipline, dod-prefs, domain lenses.";;
  update) echo "updated $2";;
  *) exit 1;;
esac
B
chmod +x "$T/bin/bd"
out="$(python3 "$ORCH" dispatch --branch repay/prod-auth --task "repay the skipped review" \
        --orchestrator me --lane repay --key repo-u1 2>&1)"
check "repay lane names the bead it is closing" "$out" "repaying : repo-u1"
check "and the lenses it read off that bead" "$out" "dod-discipline"
pwt="$(python3 "$ORCH" status --repo "$T/repo" --no-mr | grep -A1 '^repay/prod-auth$' | sed -n 's/^  path //p')"
check "TASK.md points at the merged branch the debt covers" "$(cat "$pwt/.claude/TASK.md")" "fix/prod-auth"
check "and says the bead must be closed or nothing was repaid" "$(cat "$pwt/.claude/TASK.md")" "has repaid nothing"
out="$(python3 "$ORCH" dispatch --branch repay/nokey --task "t" --orchestrator me --lane repay 2>&1)"; rc=$?
[[ $rc -ne 0 ]] && echo "ok   repay without a bead is refused" || { echo "FAIL repay with no bead"; fail=1; }
# the urgent lane must SHIP the repay command, or the debt has no return path
out="$(python3 "$ORCH" dispatch --branch fix/again2 --task "t" --orchestrator me \
        --urgent --why "prod down again" 2>&1)"
check "the debt bead body carries the command that repays it" "$(cat "$T/bd.log")" "--lane repay"

# ── abandon: the dead end is recorded where the next attempt reads it ─────────────
out="$(python3 "$ORCH" abandon --worktree "$mwt" --key DE-A1 --branch chore/rename \
        --why "the rename needs a schema change first" 2>&1)"
check "abandon says where it recorded the reason" "$out" "recorded : "
check "and that the next dispatch will quote it" "$out" "quotes this in TASK.md"
out="$(python3 "$ORCH" dispatch --branch feat/retry --task "rename again" --orchestrator me --key DE-A1 2>&1)"
check "a re-dispatch of the same key warns it was abandoned before" "$out" "prior    : this task was abandoned before"
awt="$(python3 "$ORCH" status --repo "$T/repo" --no-mr | grep -A1 '^feat/retry$' | sed -n 's/^  path //p')"
check "and TASK.md quotes the reason, not just the file path" "$(cat "$awt/.claude/TASK.md")" "needs a schema change first"
[[ -z "$(git -C "$awt" status --porcelain)" ]] \
  && echo "ok   the abandon note lives in .git/, so the worktree stays reapable" \
  || { echo "FAIL abandon note dirtied the worktree"; fail=1; }

# ── two lane flags at once is a refusal, never a silent precedence rule ───────────
out="$(python3 "$ORCH" dispatch --branch x/clash --task "t" --orchestrator me --lane spike --small --touches a.py 2>&1)"; rc=$?
[[ $rc -ne 0 ]] && echo "ok   --lane plus --small is refused" || { echo "FAIL two lanes accepted"; fail=1; }
check "and says they disagree" "$out" "say different things"

# ── --help lists every lane and what it costs (the affordance must be visible) ────
out="$(python3 "$ORCH" dispatch --help 2>&1)"
for L in small urgent risky mechanical spike revert repay; do
  [[ "$out" == *"$L:"* ]] || { echo "FAIL --help does not list lane $L"; fail=1; }
done
echo "ok   --help lists every lane with its price"

echo; [ $fail -eq 0 ] && echo "ok — orchestrate E2E passed" || echo "orchestrate E2E FAILED"
exit $fail
