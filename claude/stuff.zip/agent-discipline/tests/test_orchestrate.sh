#!/usr/bin/env bash
# E2E for scripts/orchestrate.py: drives the real script against a throwaway git repo with a
# fake `wt`, `glab` and `bd` on PATH. Asserts what the orchestrator SEES, not just exit codes.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ORCH="$ROOT/scripts/orchestrate.py"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
fail=0
check() { if [[ "$2" == *"$3"* ]]; then echo "ok   $1"; else echo "FAIL $1"; echo "     want: $3"; echo "     got:  $2"; fail=1; fi; }

# ledger with one record whose cue overlaps the task
mkdir -p "$T/mem/topics"
cat > "$T/mem/topics/pref-worktree-not-branch.md" <<'P'
---
description: "worktree instead of branch"
triggers: "worktree, branch"
---
**Preference:** start work in a worktree, never `git checkout -b` in the main checkout.

**Chose:** x
P
export AGENT_DISCIPLINE_MEMORY_DIR="$T/mem"

# repo + fakes
git -C "$T" init -q repo && cd "$T/repo" && git -c user.name=t -c user.email=t@t commit -q --allow-empty -m init
mkdir -p "$T/bin"
cat > "$T/bin/wt" <<'W'
#!/usr/bin/env bash
# fake worktrunk: `wt switch --create B --yes [--base X]` -> git worktree add
b="$3"; root="$(git rev-parse --show-toplevel)"
git worktree add -q -b "$b" "$root/.worktrees/${b//\//-}" >/dev/null 2>&1
W
cat > "$T/bin/glab" <<'G'
#!/usr/bin/env bash
echo '[{"iid": 7, "state": "opened", "head_pipeline": {"status": "running"}}]'
G
chmod +x "$T/bin/wt" "$T/bin/glab"
export PATH="$T/bin:$PATH"; unset TMUX

out="$(python3 "$ORCH" plan 2>&1)"
check "plan without beads says how to dispatch by hand" "$out" "no beads here"
check "plan names the dispatch command" "$out" "orchestrate.py dispatch --branch"

out="$(python3 "$ORCH" status 2>&1)"
check "status with nothing dispatched says so" "$out" "no worktrees — nothing dispatched"

out="$(python3 "$ORCH" dispatch --branch feat/x --task "move the worktree helper into a branch-safe module" --orchestrator agent-discipline-81 2>&1)"; rc=$?
[[ $rc -eq 0 ]] && echo "ok   dispatch exits 0" || { echo "FAIL dispatch exit $rc: $out"; fail=1; }
wt="$T/repo/.worktrees/feat-x"
check "dispatch names the worktree" "$out" "worktree : $wt"
check "dispatch says what to do next" "$out" 'SendMessage it: "Read .claude/TASK.md and begin."'
check "dispatch names the worker as ListAgents will show it" "$out" 'appears as `worker:feat/x`'
check "dispatch warns when no tmux started a worker" "$out" "no tmux"
task="$(cat "$wt/.claude/TASK.md")"
check "TASK.md carries the orchestrator name" "$task" "Orchestrator: agent-discipline-81"
check "TASK.md carries the matching preference text, not just its filename" "$task" "start work in a worktree, never"
check "TASK.md says MR target is staging" "$task" "MR target: staging"

out="$(python3 "$ORCH" status 2>&1)"
check "status shows the worker with no DoD yet" "$out" "dod no DoD yet"
check "status shows the MR the fake glab returned" "$out" "mr !7 opened"

python3 "$ROOT/scripts/delegate.py" start --worktree "$wt" --task t --dod "[tests] one" >/dev/null
python3 "$ROOT/scripts/delegate.py" report --worktree "$wt" >/dev/null
out="$(python3 "$ORCH" status --no-mr 2>&1)"
check "reported worker tells the orchestrator to review" "$out" "REVIEW: read .claude/DOD.md"

out="$(python3 "$ORCH" reject --worktree "$wt" --issue "tests item fails: no red path" 2>&1)"
check "reject prints the message to send" "$out" "Rejected: tests item fails"
out="$(python3 "$ORCH" approve --worktree "$wt" 2>&1)"
check "approve prints the MR instruction for the worker" "$out" "glab mr create --target-branch staging"

out="$(cd "$wt" && python3 "$ORCH" dispatch --branch feat/y --task t --orchestrator o 2>&1)"; rc=$?
check "dispatch from inside a worktree refuses and says where to run" "$out" "run dispatch from the MAIN checkout"
[[ $rc -ne 0 ]] && echo "ok   refused dispatch exits non-zero" || { echo "FAIL refused dispatch exited 0"; fail=1; }

[[ $fail -eq 0 ]] && echo "ok — orchestrate E2E passed" || { echo "FAILED"; exit 1; }
