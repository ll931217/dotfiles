#!/usr/bin/env bash
# The diagram generators must run clean and the .drawio must be valid XML with the pages the
# README promises — a broken generator is only noticed when someone opens the file in a meeting.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
cp "$ROOT"/docs/*.py "$T/"
fail=0
(cd "$T" && python3 gen_mechanism.py >/dev/null && python3 gen_workflow.py >/dev/null) || { echo "FAIL generators exit non-zero"; exit 1; }
pages="$(python3 -c "
import xml.dom.minidom as m; d=m.parse('$T/agent_discipline_mechanism.drawio')
print('|'.join(x.getAttribute('name') for x in d.getElementsByTagName('diagram')))")"
[[ "$pages" == "Mechanism map|Orchestrator / worker|Roles without the plugin|Roles with the plugin" ]] && echo "ok   mechanism drawio has the 4 pages in demo order" || { echo "FAIL pages: $pages"; fail=1; }
for f in agent_discipline_mechanism.svg agent_discipline_mechanism-orchestrator-worker.svg agent_discipline_mechanism-roles.svg agent_discipline_mechanism-roles-without-the-plugin.svg ai_agent_dev_workflow_v2.svg ai_agent_dev_workflow_v2.drawio; do
  [[ -s "$T/$f" ]] && echo "ok   $f written" || { echo "FAIL $f missing"; fail=1; }
done
wpages="$(python3 -c "
import xml.dom.minidom as m; d=m.parse('$T/ai_agent_dev_workflow_v2.drawio')
print('|'.join(x.getAttribute('name') for x in d.getElementsByTagName('diagram')))")"
[[ "$wpages" == "Without the plugin|With agent-discipline" ]] && echo "ok   workflow drawio has without, then with" || { echo "FAIL workflow pages: $wpages"; fail=1; }
[[ -s "$T/ai_agent_dev_workflow_v2-without-the-plugin.svg" ]] && echo "ok   without-the-plugin svg written" || { echo "FAIL without svg missing"; fail=1; }
grep -q 'value="With agent-discipline"' "$T/ai_agent_dev_workflow_v2.svg" 2>/dev/null; grep -q "no preference ledger" "$T/ai_agent_dev_workflow_v2.svg" && { echo "FAIL bare workflow svg is the WITHOUT page"; fail=1; } || echo "ok   bare workflow svg is still the with-plugin page"
# committed outputs must match the generators (no hand edits, no stale render)
for f in agent_discipline_mechanism.drawio agent_discipline_mechanism.svg ai_agent_dev_workflow_v2.drawio; do
  cmp -s "$T/$f" "$ROOT/docs/$f" && echo "ok   docs/$f is up to date" || { echo "FAIL docs/$f is stale — re-run the generator in docs/"; fail=1; }
done
[[ $fail -eq 0 ]] && echo "ok — diagrams passed" || { echo "FAILED"; exit 1; }
