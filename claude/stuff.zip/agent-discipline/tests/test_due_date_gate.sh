#!/usr/bin/env bash
# E2E for hooks/due-date-gate.py. The failure it covers: an issue with no due date can never be
# late, so it is never picked up. The deny must also SHOW the queue — a date invented without
# the overdue list is the same defect with a number attached.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
HOOK="$ROOT/hooks/due-date-gate.py"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
fail=0
ok()  { echo "ok   $1"; }
bad() { echo "FAIL $1"; [ $# -gt 1 ] && echo "     got:  ${2:-<empty>}"; fail=1; }

mkdir -p "$T/bin"; export PATH="$T/bin:$PATH"
cat > "$T/bin/bd" <<'BD'
#!/bin/sh
case "$*" in
  *--overdue*) echo '[{"id":"repo-a1","priority":1,"due_at":"2026-08-30T00:00:00Z","title":"settlement run drops FINI accounts"}]' ;;
  *--due-before*) echo '[{"id":"repo-a1","priority":1,"due_at":"2026-08-30T00:00:00Z","title":"settlement run drops FINI accounts"},{"id":"repo-b2","priority":2,"due_at":"2026-09-09T00:00:00Z","title":"retry wrapper on fetchQuote"}]' ;;
  *) echo '[]' ;;
esac
BD
chmod +x "$T/bin/bd"

fire() { jq -nc --arg c "$1" --arg w "$T" '{tool_name:"Bash",cwd:$w,tool_input:{command:$c}}' \
       | python3 "$HOOK" | jq -r '.hookSpecificOutput.permissionDecisionReason // ""' 2>/dev/null; }

# ── allowed ───────────────────────────────────────────────────────────────────────
out="$(fire 'bd list --status=open')"
[ -z "$out" ] && ok "a non-create bd command is untouched" || bad "bd list denied" "$out"

out="$(fire 'bd create --title="x" --priority=1 --due=+1w')"
[ -z "$out" ] && ok "bd create WITH --due passes" || bad "due denied" "$out"

out="$(fire 'bd create --title="rename a local var" --priority=3')"
[ -z "$out" ] && ok "small beads-only work (P3) is exempt" || bad "P3 denied" "$out"

out="$(fire 'python3 scripts/jira.py create --project DE --summary "x" --duedate 2026-10-01')"
[ -z "$out" ] && ok "jira create WITH --duedate passes" || bad "duedate denied" "$out"

# ── denied ────────────────────────────────────────────────────────────────────────
out="$(fire 'bd create --title="big bug" --priority=1')"
[[ "$out" == *"needs a due date"* ]] && ok "a P1 bead without --due is denied" || bad "P1" "$out"
[[ "$out" == *"OVERDUE"*"repo-a1"* ]] && ok "the deny shows what is already overdue" || bad "no overdue" "$out"
[[ "$out" == *"repo-b2"* ]] && ok "it also shows what is due soon" || bad "no due-soon" "$out"
[[ "$(grep -c 'repo-a1' <<<"$out")" == 1 ]] && ok "an overdue issue is listed once, not twice" \
                                            || bad "duplicated row" "$out"

out="$(fire 'bd create --title="mirror" --priority=3 --labels jira:DE-452')"
[[ "$out" == *"needs a due date"* ]] && ok "a P3 bead MIRRORING Jira is not exempt" || bad "jira mirror" "$out"

out="$(fire 'python3 scripts/jira.py create --project DE --type Task --summary "x"')"
[[ "$out" == *"--duedate"* ]] && ok "a Jira issue always needs --duedate" || bad "jira" "$out"

[ $fail -eq 0 ] && echo "PASS" || echo "FAILURES"
exit $fail
