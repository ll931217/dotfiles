#!/usr/bin/env bash
# E2E for scripts/testing-handbook.py: drives the real script against throwaway repos of each
# stack and asserts what the USER SEES — the detected rows, the refusal, the written handbook.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
GEN="$ROOT/scripts/testing-handbook.py"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
fail=0
check() { if [[ "$2" == *"$3"* ]]; then echo "ok   $1"; else echo "FAIL $1"; echo "     want: $3"; echo "     got:  ${2:0:500}"; fail=1; fi; }
no()    { if [[ "$2" != *"$3"* ]]; then echo "ok   $1"; else echo "FAIL $1 (should not contain: $3)"; fail=1; fi; }

mkrepo() { local d="$T/$1"; mkdir -p "$d"; git -C "$d" init -q .; echo "$d"; }

# --- node ------------------------------------------------------------------------------
n="$(mkrepo node)"
cat > "$n/package.json" <<'J'
{"scripts":{"test":"vitest run","lint":"eslint .","typecheck":"tsc --noEmit"},
 "devDependencies":{"vitest":"^4","typescript":"^5"}}
J
touch "$n/pnpm-lock.yaml"
out="$(python3 "$GEN" --check --repo "$n" 2>&1)"
check "node: names the package manager it detected"   "$out" "stack   : node (pnpm)"
check "node: unit command comes from the test script" "$out" "pnpm run test"
check "node: absent e2e is MISSING with a reason"     "$out" "E2E                  MISSING — no e2e script, playwright or cypress"
check "node: says how many are unavailable"           "$out" "3 technique(s) unavailable here"
check "node: --check says it wrote nothing"           "$out" "--check: nothing written"
[[ -e "$n/.claude/skills/verify-changes/SKILL.md" ]] && { echo "FAIL --check wrote a file"; fail=1; } || echo "ok   --check really writes nothing"

# --- python ---------------------------------------------------------------------------
p="$(mkrepo py)"
printf '[project]\nname="x"\n[dependency-groups]\ndev=["pytest","hypothesis","ruff"]\n' > "$p/pyproject.toml"
touch "$p/uv.lock"
out="$(python3 "$GEN" --check --repo "$p" 2>&1)"
check "python: detects uv"                        "$out" "stack   : python (uv)"
check "python: unit runs through uv"              "$out" "uv run pytest"
check "python: hypothesis present enables PBT"    "$out" "Property-based       \`uv run pytest"
check "python: mutation names the Python gap"     "$out" "mutmut / cosmic-ray not installed (mewt does not cover Python)"

# --- THE false green: a runner that is installed but collects nothing here ---------------
# `uv run pytest` in a repo whose suite is shell scripts collects zero tests and exits 0, which
# is indistinguishable from a passing suite. Recording it hands every worker a fake green.
fg="$(mkrepo falsegreen)"
printf '[project]\nname="x"\nrequires-python=">=3.10"\n[dependency-groups]\ndev=["pytest"]\n' > "$fg/pyproject.toml"
mkdir -p "$fg/tests"; printf 'echo ok\n' > "$fg/tests/test_a.sh"
out="$(python3 "$GEN" --check --repo "$fg" 2>&1)"
no    "collects-nothing pytest is not recorded as the unit command" "$out" 'Unit / integration   `pytest`'
check "the shell half is recorded instead"                          "$out" 'for t in tests/*.sh; do bash'

# a python repo with real python tests keeps them AND the shell half
mx="$(mkrepo pymixed)"
# No uv.lock on purpose: provisioning a uv venv makes this fixture depend on the network.
printf '[project]\nname="x"\n[dependency-groups]\ndev=["pytest"]\n' > "$mx/pyproject.toml"
mkdir -p "$mx/tests"; printf 'echo ok\n' > "$mx/tests/test_a.sh"; printf 'def test_b(): assert True\n' > "$mx/tests/test_b.py"
out="$(python3 "$GEN" --check --repo "$mx" 2>&1)"
check "mixed python repo keeps a python runner" "$out" 'pytest'
check "mixed python repo runs the shell half"   "$out" 'for t in tests/*.sh'
check "and stops on the first failure"          "$out" '|| exit 1'

# --- a repo with no language manifest still gets one ----------------------------------
s="$(mkrepo shellonly)"; mkdir -p "$s/tests"; touch "$s/tests/test_x.sh"
out="$(python3 "$GEN" --check --repo "$s" 2>&1)"
check "no manifest: still detects a shell suite" "$out" 'for t in tests/*.sh; do bash'
no    "no manifest: does not invent a python half" "$out" 'tests/test_*.py' 

# A scripts repo is usually MIXED. Naming only the shell half hands every worker a command
# that silently runs half the suite and reports green.
m="$(mkrepo mixed)"; mkdir -p "$m/tests"; touch "$m/tests/test_a.sh" "$m/tests/test_b.py"
out="$(python3 "$GEN" --check --repo "$m" 2>&1)"
check "mixed repo: says both kinds are present" "$out" "(shell + python tests)"
check "mixed repo: the command runs the shell half"  "$out" 'for t in tests/*.sh'
check "mixed repo: and the python half"              "$out" 'for t in tests/test_*.py'
no    "mixed repo: no bare n/a in the add column"    "$out" "add it: \`n/a"

# --- writing, refusing, forcing --------------------------------------------------------
out="$(python3 "$GEN" --repo "$n" 2>&1)"; rc=$?
book="$n/.claude/skills/verify-changes/SKILL.md"
check "write: names the file it wrote" "$out" "wrote $book"
[[ $rc -eq 0 && -s "$book" ]] && echo "ok   write: exits 0 and the file is non-empty" || { echo "FAIL write rc=$rc"; fail=1; }

body="$(cat "$book")"
check "handbook: carries the routing table"           "$body" "Which techniques does THIS change need?"
check "handbook: routes surfaces to an E2E"           "$body" "one E2E asserting what the user SEES"
check "handbook: routes shared libraries to mutation" "$body" "mutation testing SCOPED TO THE CHANGED FILES"
check "handbook: shows the NOT RUN shape verbatim"    "$body" "NOT RUN: mutation testing"
check "handbook: missing tool carries its install"    "$body" "add it: \`cargo install mewt"
no    "handbook: never prints 'add it: n/a'"         "$body" "add it: \`n/a"
check "handbook: keeps the red-path rule"             "$body" "A green with no path to red is not a result"
check "handbook: is a loadable skill"                 "$body" "name: verify-changes"
no    "handbook: no unresolved template slot"         "$body" "{stack}"

out="$(python3 "$GEN" --repo "$n" 2>&1)"; rc=$?
check "second run refuses and names the flag" "$out" "Re-run with --force"
[[ $rc -eq 1 ]] && echo "ok   refusal exits 1" || { echo "FAIL refusal exit $rc"; fail=1; }

printf 'hand written, not ours\n' > "$book"
out="$(python3 "$GEN" --repo "$n" 2>&1)"; rc=$?
check "a hand-written handbook is not clobbered" "$out" "was NOT generated by this script"
[[ "$(cat "$book")" == "hand written, not ours" ]] && echo "ok   hand-written content survives" || { echo "FAIL clobbered a hand-written file"; fail=1; }
[[ $rc -eq 1 ]] && echo "ok   hand-written refusal exits 1" || { echo "FAIL exit $rc"; fail=1; }

out="$(python3 "$GEN" --repo "$n" --force 2>&1)"
check "--force overwrites" "$out" "wrote $book"
grep -q 'name: verify-changes' "$book" && echo "ok   --force restored a real handbook" || { echo "FAIL force output"; fail=1; }

# --- the learned section, and what regeneration must NOT destroy ------------------------
l="$(mkrepo learned)"
cat > "$l/package.json" <<'J'
{"scripts":{"test":"vitest run"},"devDependencies":{"vitest":"^4"}}
J
lb="$l/.claude/skills/verify-changes/SKILL.md"
out="$(python3 "$GEN" --repo "$l" --learn "x" 2>&1)"; rc=$?
check "--learn before any handbook says what to run first" "$out" "run this script with no flags first"
[[ $rc -ne 0 ]] && echo "ok   --learn with no handbook exits non-zero" || { echo "FAIL exit $rc"; fail=1; }

python3 "$GEN" --repo "$l" >/dev/null
out="$(python3 "$GEN" --repo "$l" --learn "the API fixtures must be seeded before test:e2e" 2>&1)"
check "--learn confirms what it recorded"     "$out" "the API fixtures must be seeded"
check "--learn says the line survives"        "$out" "survives every regeneration"
check "--learn dates the line"                "$(cat "$lb")" "$(date +%Y-%m-)"
out="$(python3 "$GEN" --repo "$l" --learn "the API fixtures must be seeded before test:e2e" 2>&1)"
check "--learn is idempotent, not a duplicate" "$out" "already recorded, unchanged"
[[ "$(grep -c 'API fixtures must be seeded' "$lb")" == "1" ]] && echo "ok   the line appears exactly once" || { echo "FAIL duplicated"; fail=1; }

# THE point of the split: --force must re-detect and still keep what a worker paid for.
out="$(python3 "$GEN" --repo "$l" --force 2>&1)"
check "--force reports what it kept" "$out" "kept the 'Learned here' section unchanged (1 line(s))"
grep -q 'API fixtures must be seeded' "$lb" && echo "ok   --force preserved the learned line" || { echo "FAIL --force destroyed a learned line"; fail=1; }
no "the generated half no longer promises to keep hand edits" "$(cat "$lb")" "Hand edits below the marker are kept"
check "it says instead where edits survive" "$(cat "$lb")" "An edit here is lost on the next --force"

# --- drift has a path to red: gain a tool, the check must SAY so ------------------------
out="$(python3 "$GEN" --repo "$l" --check 2>&1)"
check "no drift when nothing changed" "$out" "no drift:"
cat > "$l/package.json" <<'J'
{"scripts":{"test":"vitest run","test:e2e":"playwright test"},
 "devDependencies":{"vitest":"^4","@playwright/test":"^1","fast-check":"^3"}}
J
out="$(python3 "$GEN" --repo "$l" --check 2>&1)"
check "drift is announced"                    "$out" "DRIFT"
check "a gained tool reads NOW AVAILABLE"     "$out" "E2E:  NOW AVAILABLE"
check "drift shows both sides"                "$out" "handbook says: MISSING — no e2e script"
check "drift names the fix and the guarantee" "$out" "--force (the 'Learned here' section is preserved)"
[[ "$(grep -c 'MISSING — no e2e' "$lb")" == "1" ]] && echo "ok   --check still wrote nothing" || { echo "FAIL --check modified the handbook"; fail=1; }
python3 "$GEN" --repo "$l" --force >/dev/null
grep -qE '^\| \*\*E2E\*\* \| `npm run test:e2e`' "$lb" && echo "ok   regeneration picked the new tool up" || { echo "FAIL row not refreshed"; fail=1; }
grep -q 'API fixtures must be seeded' "$lb" && echo "ok   and STILL kept the learned line" || { echo "FAIL lost the learned line on refresh"; fail=1; }

out="$(python3 "$GEN" --repo "$T" 2>&1)"; rc=$?
check "outside a git repo it says so" "$out" "not a git checkout"
[[ $rc -ne 0 ]] && echo "ok   non-repo exits non-zero" || { echo "FAIL non-repo exit 0"; fail=1; }

[[ $fail -eq 0 ]] && echo "ok — testing-handbook E2E passed" || { echo "FAILED"; exit 1; }
