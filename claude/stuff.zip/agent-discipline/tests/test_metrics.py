"""Ask-coverage metrics: the denominator exists, selftest traffic is excluded, --json agrees
with the screen. Drives the real hook and the real dashboard as subprocesses."""
import json
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
HOOK = os.path.join(ROOT, "hooks", "pref-checkpoint.py")
DASH = os.path.join(ROOT, "scripts", "agent-dashboard.py")

RECORD = """---
description: whether the metrics dashboard should be html or a plain terminal script
triggers: dashboard, terminal, metrics
confidence: stated
---
**Preference:** print metrics as a plain terminal script
**Chose:** terminal script
**Over:** an HTML dashboard
**Why:** stated by the user
"""


def mem(tmp_path):
    d = tmp_path / "mem"
    (d / "topics").mkdir(parents=True)
    (d / "topics" / "pref-terminal.md").write_text(RECORD)
    return d


def ask(memdir, question, session="s1"):
    ev = {"tool_name": "AskUserQuestion", "session_id": session, "tool_input": {"questions": [
        {"question": question, "header": "H",
         "options": [{"label": "a", "description": "x"}, {"label": "b", "description": "y"}]}]}}
    env = dict(os.environ, AGENT_DISCIPLINE_MEMORY_DIR=str(memdir))
    return subprocess.run([sys.executable, HOOK], input=json.dumps(ev), env=env,
                          capture_output=True, text=True)


def metrics(memdir):
    env = dict(os.environ, AGENT_DISCIPLINE_MEMORY_DIR=str(memdir))
    r = subprocess.run([sys.executable, DASH, "--json"], env=env, capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    return json.loads(r.stdout)


def test_unmatched_question_is_counted_as_the_denominator(tmp_path):
    d = mem(tmp_path)
    ask(d, "which cloud region should the new Kafka cluster live in?")
    m = metrics(d)["asks"]
    assert m["uncovered"] == 1 and m["ledger_spoke_to"] == 0
    assert m["seen"] == 1 and m["coverage_pct"] == 0.0


def test_coverage_is_a_share_not_a_bare_count(tmp_path):
    d = mem(tmp_path)
    ask(d, "should the metrics dashboard be html or a plain terminal script?")
    for q in ("which cloud region for Kafka?", "what colour should the logo be?",
              "who owns the settlement job?"):
        ask(d, q)
    m = metrics(d)["asks"]
    assert m["seen"] == 4 and m["ledger_spoke_to"] == 1 and m["coverage_pct"] == 25.0


def test_selftest_traffic_never_raises_coverage(tmp_path):
    d = mem(tmp_path)
    ask(d, "which cloud region should the new Kafka cluster live in?", session="selftest-abc")
    assert (d / "pref_events.tsv").exists(), "the hook must still log; only the report filters"
    assert metrics(d)["asks"]["seen"] == 0


def test_json_and_screen_report_the_same_numbers(tmp_path):
    d = mem(tmp_path)
    ask(d, "should the metrics dashboard be html or a plain terminal script?")
    ask(d, "which cloud region should the new Kafka cluster live in?")
    m = metrics(d)["asks"]
    env = dict(os.environ, AGENT_DISCIPLINE_MEMORY_DIR=str(d))
    screen = subprocess.run([sys.executable, DASH], env=env, capture_output=True, text=True).stdout
    assert f"of {m['seen']} the hook saw" in screen
    assert "50% coverage" in screen
    assert "each one is a ledger record you have not written" in screen


def test_no_questions_at_all_is_not_reported_as_full_coverage(tmp_path):
    d = mem(tmp_path)
    m = metrics(d)
    assert m["asks"]["coverage_pct"] is None
    env = dict(os.environ, AGENT_DISCIPLINE_MEMORY_DIR=str(d))
    screen = subprocess.run([sys.executable, DASH], env=env, capture_output=True, text=True).stdout
    assert "NOT full" in screen


# ── panel 5: urgent-lane debt ─────────────────────────────────────────────────────
FAKE_BD = """#!/usr/bin/env python3
import json, os, sys
st = sys.argv[sys.argv.index("--status") + 1]
print(json.dumps(json.load(open(os.environ["BD_FIXTURE"]))[st]))
"""


def dash(memdir, cwd, extra_path=None, fixture=None, json_mode=True):
    env = dict(os.environ, AGENT_DISCIPLINE_MEMORY_DIR=str(memdir))
    if extra_path:
        env["PATH"] = f"{extra_path}{os.pathsep}{env['PATH']}"
    if fixture:
        env["BD_FIXTURE"] = str(fixture)
    r = subprocess.run([sys.executable, DASH] + (["--json"] if json_mode else []),
                       env=env, cwd=str(cwd), capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    return json.loads(r.stdout) if json_mode else r.stdout


def bd_repo(tmp_path, open_beads, closed_beads):
    repo = tmp_path / "repo"
    (repo / ".beads").mkdir(parents=True)
    bind = tmp_path / "bin"
    bind.mkdir()
    bd = bind / "bd"
    bd.write_text(FAKE_BD)
    bd.chmod(0o755)
    fx = tmp_path / "beads.json"
    fx.write_text(json.dumps({"open": open_beads, "closed": closed_beads}))
    return repo, bind, fx


def bead(bid, days_old, title="review the lenses the fire skipped"):
    import datetime
    ts = (datetime.datetime.now().astimezone()
          - datetime.timedelta(days=days_old)).isoformat()
    return {"id": bid, "title": title, "created_at": ts, "status": "open"}


def test_no_bd_reports_debt_unavailable_not_zero(tmp_path):
    """'nothing is owed' and 'nobody can see what is owed' must not print the same."""
    d = mem(tmp_path)
    repo = tmp_path / "plain"
    repo.mkdir()
    u = dash(d, repo)["urgent_debt"]
    assert u["available"] is False and u["why"]
    screen = dash(d, repo, json_mode=False)
    assert "unavailable" in screen and "not as zero debt" in screen


def test_oldest_unpaid_debt_is_reported_with_its_age(tmp_path):
    d = mem(tmp_path)
    repo, bind, fx = bd_repo(
        tmp_path,
        [bead("r-1", 12.0), bead("r-2", 3.0)],
        [bead("r-0", 40.0)],
    )
    u = dash(d, repo, extra_path=bind, fixture=fx)["urgent_debt"]
    assert u["open"] == 2 and u["closed"] == 1
    assert u["oldest_days"] == 12.0, "the oldest OPEN debt, not the oldest bead"
    assert u["oldest"][0][1] == "r-1"

    screen = dash(d, repo, extra_path=bind, fixture=fx, json_mode=False)
    assert "oldest unpaid debt" in screen
    assert "12.0d" in screen and "r-1" in screen
    assert "unreviewed code in production" in screen
    assert "look bad" in screen, "the panel must name its own bad number (EF10)"


def test_unused_lane_does_not_read_as_a_pass(tmp_path):
    d = mem(tmp_path)
    repo, bind, fx = bd_repo(tmp_path, [], [])
    screen = dash(d, repo, extra_path=bind, fixture=fx, json_mode=False)
    assert "has not been used" in screen
    assert "NOT that it is safe" in screen


def test_piped_output_carries_no_ansi_escapes(tmp_path):
    """/ledger reprints the panels into a chat message. A raw \x1b[1m there renders as literal
    "ESC[1m" in the heading, so bold is a terminal-only decoration."""
    d = mem(tmp_path)
    env = dict(os.environ, AGENT_DISCIPLINE_MEMORY_DIR=str(d))
    r = subprocess.run([sys.executable, DASH, "--days", "30"], env=env,
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    assert "\033" not in r.stdout
    assert "agent dashboard" in r.stdout


def test_ledger_command_asks_for_the_panels_verbatim(tmp_path):
    """The command must run the script itself and forbid a summary — the panels ARE the answer."""
    body = open(os.path.join(ROOT, "commands", "ledger.md")).read()
    assert "!`python3" in body                 # runs at expansion, output reaches the message
    assert "allowed-tools:" in body            # ...which requires the permission declared
    assert "verbatim" in body and "Do not summarise" in body
