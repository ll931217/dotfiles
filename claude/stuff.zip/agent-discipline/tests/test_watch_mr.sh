#!/usr/bin/env bash
# E2E for glab-watch-mr.sh: fake `glab` on PATH, assert the user-visible notifications.
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SCRIPT="$ROOT/scripts/glab-watch-mr.sh"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/bin"

cat > "$TMP/bin/glab" <<'FAKE'
#!/usr/bin/env bash
case "$2" in
  projects/:id) echo '{"path_with_namespace":"acme/widget"}' ;;
  projects/:id/merge_requests/*) cat "$FIXTURES/mr.json" ;;
  *) echo '[]' ;;
esac
FAKE
chmod +x "$TMP/bin/glab"
# notify-send would fire real desktop popups during the test run.
printf '#!/usr/bin/env bash\nexit 0\n' > "$TMP/bin/notify-send"; chmod +x "$TMP/bin/notify-send"
export PATH="$TMP/bin:$PATH" FIXTURES="$TMP" INTERVAL=1 NO_REAP=1 fails=0

mr() {  # state, pipeline status
  cat > "$TMP/mr.json" <<EOF
{"state":"$1","head_pipeline":{"status":"$2","web_url":"https://gl/p/1"},
 "merge_status":"can_be_merged","web_url":"https://gl/mr/18","iid":18}
EOF
}

run() { "$SCRIPT" 18 2>&1; }

mr merged success
out="$(run)"; rc=$?
n="$(grep -c "^\[[0-9:]*\] acme/widget !18" <<<"$out")"
[[ $rc -eq 0 && "$n" -eq 1 ]] && echo "ok   merged notifies once, not twice" \
  || { echo "FAIL merged: exit $rc, $n notification(s), want 1"; echo "$out" | sed 's/^/    /'; fails=$((fails+1)); }
grep -qF "MERGED" <<<"$out" || { echo "FAIL merged: the surviving line is not the MERGED one"; fails=$((fails+1)); }
grep -qF "https://gl/mr/18" <<<"$out" || { echo "FAIL merged: MR url missing"; fails=$((fails+1)); }

mr closed success
out="$(run)"; n="$(grep -c "^\[[0-9:]*\] acme/widget !18" <<<"$out")"
[[ "$n" -eq 1 ]] && echo "ok   closed notifies once" || { echo "FAIL closed: $n notifications"; fails=$((fails+1)); }

mr opened failed
out="$(run)"; rc=$?
n="$(grep -c "^\[[0-9:]*\] acme/widget !18" <<<"$out")"
[[ $rc -eq 2 && "$n" -eq 1 ]] && echo "ok   red pipeline notifies once, exit 2" \
  || { echo "FAIL failed pipeline: exit $rc, $n notification(s)"; echo "$out" | sed 's/^/    /'; fails=$((fails+1)); }
grep -qF "PIPELINE FAILED" <<<"$out" || { echo "FAIL failed pipeline: wrong surviving line"; fails=$((fails+1)); }

# Non-terminal changes must STILL be announced — that is the point of watching.
mr opened running
out="$(timeout 5 "$SCRIPT" --once 18 2>&1)"
grep -qF "!18: opened" <<<"$out" && grep -qF "pipeline=running" <<<"$out" \
  && echo "ok   running state still announced" \
  || { echo "FAIL running state was suppressed"; echo "$out" | sed 's/^/    /'; fails=$((fails+1)); }

(( fails == 0 )) && { echo "ok — watch-mr E2E passed"; exit 0; }
echo "$fails failure(s)"; exit 1
