#!/usr/bin/env bash
# E2E for glab-watch-pipeline.sh: drives the real script with a fake `glab` on PATH
# and asserts what the USER SEES, not just the exit code.
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SCRIPT="$ROOT/scripts/glab-watch-pipeline.sh"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/bin"

cat > "$TMP/bin/glab" <<'FAKE'
#!/usr/bin/env bash
p="$2"
case "$p" in
  projects/:id) echo '{"path_with_namespace":"acme/widget"}' ;;
  projects/:id/pipelines\?ref=*) cat "$FIXTURES/list.json" ;;
  projects/:id/pipelines/*/jobs\?scope=failed*) cat "$FIXTURES/failed.json" ;;
  projects/:id/pipelines/*/jobs*) cat "$FIXTURES/jobs.json" ;;
  projects/:id/pipelines/*) cat "$FIXTURES/pipeline.json" ;;
  projects/:id/jobs/*/trace) printf 'line A\nERROR: boom on line 42\n' ;;
  *) echo '{}' ;;
esac
FAKE
chmod +x "$TMP/bin/glab"
export PATH="$TMP/bin:$PATH" FIXTURES="$TMP" INTERVAL=1 fails=0

fixture() {  # status, list-json
  echo "$2" > "$TMP/list.json"
  cat > "$TMP/pipeline.json" <<EOF
{"status":"$1","ref":"feat/x","sha":"deadbeefcafe","web_url":"https://gl/p/7"}
EOF
  echo '[{"id":9,"name":"lint","status":"failed","stage":"test"},{"id":8,"name":"build","status":"success","stage":"build"}]' > "$TMP/jobs.json"
  echo '[{"id":9,"name":"lint","status":"failed","stage":"test"}]' > "$TMP/failed.json"
}

check() {  # label, expected_rc, actual_rc, output, expected substrings...
  local label="$1" want="$2" got="$3" out="$4"; shift 4
  [[ "$got" == "$want" ]] || { echo "FAIL $label: exit $got, want $want"; fails=$((fails+1)); return; }
  local s
  for s in "$@"; do
    grep -qF -- "$s" <<<"$out" || { echo "FAIL $label: output missing '$s'"; echo "$out" | sed 's/^/    /'; fails=$((fails+1)); return; }
  done
  echo "ok   $label"
}

fixture success '[]'
out="$(cd "$TMP" && "$SCRIPT" 2>&1)"; rc=$?
check "no pipeline names the fix" 1 $rc "$out" "No pipeline found" "Push first"

fixture success '[{"id":7}]'
out="$("$SCRIPT" 7 2>&1)"; rc=$?
check "success is announced" 0 $rc "$out" "acme/widget" "#7" "PASSED"

fixture failed '[{"id":7}]'
out="$("$SCRIPT" 7 2>&1)"; rc=$?
check "failure names the job and shows the log" 2 $rc "$out" \
  "FAILED" "failed jobs: test/lint" "ERROR: boom on line 42" "full log: glab api"

fixture failed '[{"id":7}]'
out="$(NO_TRACE=1 "$SCRIPT" 7 2>&1)"; rc=$?
check "NO_TRACE=1 keeps the names, drops the log" 2 $rc "$out" "failed jobs: test/lint"
grep -qF "boom" <<<"$out" && { echo "FAIL NO_TRACE=1 still printed the trace"; fails=$((fails+1)); }

fixture canceled '[{"id":7}]'
out="$("$SCRIPT" 7 2>&1)"; rc=$?
check "canceled is its own exit code" 3 $rc "$out" "CANCELED"

fixture running '[{"id":7}]'
out="$("$SCRIPT" --once 7 2>&1)"; rc=$?
check "--once does not loop" 0 $rc "$out" "running" "test/lint: failed"

fixture running '[{"id":7}]'
out="$("$SCRIPT" feat/x --once 2>&1 || true)"
grep -qF "#7" <<<"$out" || { echo "FAIL branch arg did not resolve to a pipeline id"; fails=$((fails+1)); }

(( fails == 0 )) && { echo "ok — watch-pipeline E2E passed"; exit 0; }
echo "$fails failure(s)"; exit 1
