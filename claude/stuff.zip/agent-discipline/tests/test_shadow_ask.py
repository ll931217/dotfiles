"""Phase 4 exit criteria: no question is suppressed, equivalent questions map consistently,
human answers become task-local resolved needs, Stop candidates are measured for false
positives."""
from __future__ import annotations

import importlib.util
import json
import os
import subprocess
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from ledger.decision import (ANSWER_CLASSES, DecisionNeed, ResolvedNeed,      # noqa: E402
                             ResolvedNeedCache, classify_answer, classify_intent,
                             classify_risk, mandatory_human_reasons,
                             need_from_question, normalize_subject)
from ledger.prediction import (JsonlStore, QuestionOutcome, QuestionPrediction,  # noqa: E402
                               calibrate, new_prediction_id)

ASK = os.path.join(ROOT, "hooks", "lcg-shadow-ask.py")
CAPTURE = os.path.join(ROOT, "hooks", "lcg-capture-answer.py")
STOP = os.path.join(ROOT, "hooks", "lcg-stop-detect.py")


def load_stop():
    spec = importlib.util.spec_from_file_location("sd", STOP)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


# --- normalization and stable keys ---------------------------------------------------------

def test_equivalent_questions_map_to_the_same_key():
    a = need_from_question("Should we use a worktree or just branch?", "Worktree",
                           ("worktree", "branch"))
    b = need_from_question("worktree, or should we just branch??", "Worktree",
                           ("branch", "worktree"))
    assert a.key == b.key, "wording and option order are incidental (P4-04)"


def test_different_questions_do_not_collide():
    a = need_from_question("Which cloud region for Kafka?", "Region", ("tw", "jp"))
    b = need_from_question("Which database for settlement?", "DB", ("pg", "ch"))
    assert a.key != b.key


def test_a_different_option_set_is_a_different_question():
    a = need_from_question("pick one", "H", ("a", "b"))
    b = need_from_question("pick one", "H", ("a", "c"))
    assert a.key != b.key, "the choices offered are part of what is being asked"


def test_a_key_is_stable_across_runs():
    q = ("Should I rebase or merge?", "VCS", ("rebase", "merge"))
    assert need_from_question(*q).key == need_from_question(*q).key


def test_an_unconfident_normalization_keeps_keys_separate():
    """P4-05: two keys beats one wrong merge."""
    a = need_from_question("do it?", "", ())
    b = need_from_question("go?", "", ())
    assert not a.normalization_confident and a.key != b.key


def test_the_original_text_survives_normalization():
    n = need_from_question("Should we PLEASE use uv??", "Tooling", ("uv", "pip"))
    assert n.original_text == "Should we PLEASE use uv??", "P4-02: auditable or it is not a key"


def test_normalization_drops_incidental_words():
    assert normalize_subject("Should we use the worktree?") == normalize_subject("use worktree")


# --- intent, risk, mandatory categories -----------------------------------------------------

def test_intent_is_classified():
    assert classify_intent("should we use x?", has_established=False) == "choose_new"
    assert classify_intent("should we use x?", has_established=True) == "apply_established"
    assert classify_intent("use y instead of x?", has_established=True) == "change_established"
    assert classify_intent("is it true that x?") == "verify_fact"


@pytest.mark.parametrize("text,cat", [
    ("should I DROP the settlement table?", "destructive"),
    ("what auth scheme for the endpoint?", "security"),
    ("change the public API wire format?", "public_api"),
    ("add a migration to alter table x", "schema"),
    ("what retention policy for audit logs?", "compliance"),
])
def test_mandatory_human_categories_are_detected(text, cat):
    assert cat in mandatory_human_reasons(text)


def test_an_ordinary_question_is_not_mandatory():
    assert mandatory_human_reasons("should the button be blue or green?") == []


def test_risk_tracks_the_category():
    assert classify_risk("drop the table") == "critical"
    assert classify_risk("alter table users") == "high"
    assert classify_risk("blue or green?") == "low"


# --- the prediction record refuses to overstep ------------------------------------------------

def test_a_mandatory_human_need_cannot_carry_a_prediction():
    """Structural, not a runtime check somebody can forget to call."""
    with pytest.raises(ValueError, match="mandatory-human"):
        QuestionPrediction(id="p", session_id="s", decision_key="k", question_text="drop it?",
                           options=["y", "n"], mode="shadow", risk="critical",
                           intent="choose_new", confidence="exact_key",
                           predicted_answer="y", mandatory_human=["destructive"])


def test_abstaining_on_a_mandatory_need_is_allowed():
    p = QuestionPrediction(id="p", session_id="s", decision_key="k", question_text="drop it?",
                           options=[], mode="shadow", risk="critical", intent="choose_new",
                           confidence="mandatory_human", mandatory_human=["destructive"])
    assert p.predicted_answer == ""


def test_an_unknown_mode_is_refused():
    with pytest.raises(ValueError, match="mode"):
        QuestionPrediction(id="p", session_id="s", decision_key="k", question_text="q",
                           options=[], mode="cowboy", risk="low", intent="choose_new",
                           confidence="none")


# --- answer classification and the task-local cache --------------------------------------------

@pytest.mark.parametrize("answer,expected", [
    ("from now on always use uv", "team_convention"),
    ("just this once, hack it", "temporary_workaround"),
    ("no", "rejection"),
    ("actually the column is settled_at", "factual_correction"),
    ("i prefer the second one", "personal_preference"),
    ("this is an architectural decision: use CQRS", "architectural_decision"),
    ("unless it is Tuesday", "exception"),
    ("worktree", "task_choice"),
    ("", "insufficient_to_classify"),
])
def test_answers_are_classified(answer, expected):
    assert classify_answer(answer) == expected
    assert expected in ANSWER_CLASSES


def test_a_non_human_answer_is_not_classified():
    assert classify_answer("always use uv", actor_is_human=False) == "insufficient_to_classify"


def test_a_resolved_need_is_task_scoped_by_construction():
    """P4-14: one answer must not silently become a repository or team rule."""
    import dataclasses
    fields = {f.name for f in dataclasses.fields(ResolvedNeed)}
    assert "session_id" in fields and "task" in fields
    assert not fields & {"repository", "team", "organization", "authority"}


def test_the_cache_returns_a_compatible_answer_and_counts_uses():
    need = need_from_question("worktree or branch?", "H", ("worktree", "branch"))
    c = ResolvedNeedCache()
    c.add(ResolvedNeed(key=need.key, answer="worktree", answer_class="task_choice",
                       source="human", session_id="s", task="t", created_at="now"))
    assert c.find(need).answer == "worktree"
    assert c.all()[0].uses == 1


def test_a_cached_answer_does_not_apply_when_scope_changed():
    """P4-08: same words, different situation, different question."""
    need = need_from_question("worktree or branch?", "H", ("worktree", "branch"))
    c = ResolvedNeedCache()
    c.add(ResolvedNeed(key=need.key, answer="worktree", answer_class="task_choice",
                       source="human", session_id="s", task="t", created_at="now",
                       scope_snapshot={"repository": "atlas"}))
    assert c.find(need, scope_now={"repository": "rom"}) is None


# --- calibration -------------------------------------------------------------------------------

def test_an_abstention_is_not_counted_as_a_wrong_answer():
    preds = [{"id": "1", "predicted_answer": "", "intent": "choose_new", "risk": "low",
              "confidence": "none", "supporting_entry_ids": [], "mandatory_human": []},
             {"id": "2", "predicted_answer": "a", "intent": "choose_new", "risk": "low",
              "confidence": "exact_key", "supporting_entry_ids": ["e"], "mandatory_human": []}]
    # The abstention's outcome says agreed=True on purpose. An earlier version set it False, so
    # counting abstentions as answers changed nothing and the assertion had no path to red —
    # found by mutation. A row nobody predicted cannot "agree" with anything.
    outs = [{"prediction_id": "1", "agreed_with_prediction": True},
            {"prediction_id": "2", "agreed_with_prediction": True}]
    c = calibrate(preds, outs)
    assert (c["abstained"], c["predicted"], c["agreed"]) == (1, 1, 1), \
        "an abstention is neither a hit nor a miss; counting it as either is a lie"
    assert c["precision"] == 1.0


def test_precision_is_undefined_not_zero_when_nothing_was_predicted():
    c = calibrate([{"id": "1", "predicted_answer": "", "intent": "x", "risk": "low",
                    "confidence": "none", "supporting_entry_ids": [], "mandatory_human": []}],
                  [{"prediction_id": "1", "agreed_with_prediction": False}])
    assert c["precision"] is None


def test_calibration_groups_rather_than_giving_one_number():
    c = calibrate([{"id": "1", "predicted_answer": "a", "intent": "choose_new", "risk": "high",
                    "confidence": "exact_key", "supporting_entry_ids": ["e"],
                    "mandatory_human": []}],
                  [{"prediction_id": "1", "agreed_with_prediction": True}])
    assert set(c["groups"]) >= {"intent", "risk", "confidence", "retrieval", "mandatory"}


# --- the hooks: measure, never interfere --------------------------------------------------------

def test_no_phase_four_hook_can_interfere():
    """The whole exit criterion in one assertion (P4-22)."""
    for script in (ASK, CAPTURE, STOP):
        src = open(script).read()
        for token in ("permissionDecision", "updatedInput", "additionalContext", '"deny"'):
            assert token not in src, f"{os.path.basename(script)} contains {token}"


def run(script, payload, env_extra=None, home=None):
    env = dict(os.environ)
    for k in ("LCG_SHADOW_ASK", "LCG_STOP_DETECT", "LCG_RESOLVER"):
        env.pop(k, None)
    env["AGENT_DISCIPLINE_CONFIG"] = "/nonexistent/x.env"
    if home:
        env["HOME"] = str(home)
        env["AGENT_DISCIPLINE_MEMORY_DIR"] = str(home / "mem")
    env.update(env_extra or {})
    return subprocess.run([sys.executable, script], input=json.dumps(payload),
                          capture_output=True, text=True, timeout=90, env=env)


def ask_event(q="Should we use a worktree or just branch?", sid="s1"):
    return {"tool_name": "AskUserQuestion", "session_id": sid, "tool_use_id": "tu1",
            "tool_input": {"questions": [{"question": q, "header": "Worktree", "options": [
                {"label": "worktree", "description": "one per task"},
                {"label": "branch", "description": "in the main checkout"}]}]}}


def test_the_shadow_hook_is_silent_by_default(tmp_path):
    p = run(ASK, ask_event(), home=tmp_path)
    assert p.returncode == 0 and p.stdout.strip() == ""


def test_the_shadow_hook_stays_silent_even_when_enabled(tmp_path):
    p = run(ASK, ask_event(), {"LCG_SHADOW_ASK": "1"}, home=tmp_path)
    assert p.returncode == 0
    assert p.stdout.strip() == "", "P4-22: no question is suppressed, and none is modified"


def test_a_prediction_is_written_when_enabled(tmp_path):
    run(ASK, ask_event(), {"LCG_SHADOW_ASK": "1"}, home=tmp_path)
    rows = list(JsonlStore(str(tmp_path / "mem" / "lcg_predictions.jsonl")).read_all())
    assert len(rows) == 1
    assert rows[0]["mode"] in ("observe", "shadow") and rows[0]["decision_key"].startswith("dk_")


def test_no_prediction_is_ventured_on_a_mandatory_category(tmp_path):
    run(ASK, ask_event("Should I DROP the settlement table?"), {"LCG_SHADOW_ASK": "1"},
        home=tmp_path)
    row = list(JsonlStore(str(tmp_path / "mem" / "lcg_predictions.jsonl")).read_all())[0]
    assert row["predicted_answer"] == "" and row["mandatory_human"] == ["destructive"]
    assert row["confidence"] == "mandatory_human"


def test_an_answer_becomes_a_task_local_resolved_need(tmp_path):
    run(ASK, ask_event(), {"LCG_SHADOW_ASK": "1"}, home=tmp_path)
    ev = dict(ask_event(), tool_response={"answers": {"Worktree": "worktree"}})
    run(CAPTURE, ev, {"LCG_SHADOW_ASK": "1"}, home=tmp_path)
    outs = list(JsonlStore(str(tmp_path / "mem" / "lcg_outcomes.jsonl")).read_all())
    assert len(outs) == 1
    assert outs[0]["actual_answer"] == "worktree"
    assert outs[0]["answer_source"] == "human"
    assert outs[0]["answer_class"] == "task_choice"


def test_the_capture_hook_is_silent(tmp_path):
    run(ASK, ask_event(), {"LCG_SHADOW_ASK": "1"}, home=tmp_path)
    p = run(CAPTURE, dict(ask_event(), tool_response={"answer": "worktree"}),
            {"LCG_SHADOW_ASK": "1"}, home=tmp_path)
    assert p.returncode == 0 and p.stdout.strip() == ""


def test_an_unreadable_response_records_an_outcome_without_inventing_one(tmp_path):
    run(ASK, ask_event(), {"LCG_SHADOW_ASK": "1"}, home=tmp_path)
    run(CAPTURE, dict(ask_event(), tool_response={"weird": object.__name__}),
        {"LCG_SHADOW_ASK": "1"}, home=tmp_path)
    outs = list(JsonlStore(str(tmp_path / "mem" / "lcg_outcomes.jsonl")).read_all())
    assert outs and outs[0]["actual_answer"] == ""
    assert outs[0]["answer_class"] == "insufficient_to_classify"


def test_the_hooks_never_crash_a_tool_call(tmp_path):
    for script in (ASK, CAPTURE, STOP):
        assert run(script, {"garbage": True}, {"LCG_SHADOW_ASK": "1", "LCG_STOP_DETECT": "1"},
                   home=tmp_path).returncode == 0
        p = subprocess.run([sys.executable, script], input="not json",
                           capture_output=True, text=True, timeout=60)
        assert p.returncode == 0


# --- Stop detection ------------------------------------------------------------------------------

@pytest.mark.parametrize("text,expected", [
    ("Should I use a worktree or just branch? Let me know which you prefer.", True),
    ("Would you like option A: keep the deny, or option B: inform only?", True),
    ("I fixed the bug. Why does it happen? Because the guard was inverted.", False),
    ("Done. Tests pass.", False),
    ("Let me check whether the column exists first.", False),
    ("The question is whether the cache is stale, or the query is wrong?", False),
    ("What does this function return?", False),
    # Has a question mark, offers a choice, is not narration — but asks about the CODE, not the
    # human. Without this case, removing the addresses-the-human check went undetected.
    ("Is the settlement column a timestamp or a date?", False),
    ("Does the loader read from prod_settlement or from the staging copy?", False),
])
def test_stop_detection_is_conservative(text, expected):
    assert load_stop().looks_like_a_question_for_the_human(text)[0] is expected


def test_every_stop_is_logged_not_only_the_hits(tmp_path):
    """A hit rate with no denominator is not a measurement (P4-25)."""
    run(STOP, {"session_id": "s", "last_assistant_message": "Done. Tests pass."},
        {"LCG_STOP_DETECT": "1"}, home=tmp_path)
    run(STOP, {"session_id": "s",
               "last_assistant_message": "Worktree or branch? Let me know which you prefer."},
        {"LCG_STOP_DETECT": "1"}, home=tmp_path)
    rows = list(JsonlStore(str(tmp_path / "mem" / "lcg_stop_candidates.jsonl")).read_all())
    assert len(rows) == 2
    assert [r["candidate"] for r in rows] == [False, True]
    assert rows[0]["reason"], "a rejection records WHY, or the threshold cannot be tuned"


def test_a_stop_candidate_produces_a_shadow_prediction(tmp_path):
    run(STOP, {"session_id": "s",
               "last_assistant_message": "Worktree or branch? Let me know which you prefer."},
        {"LCG_STOP_DETECT": "1"}, home=tmp_path)
    preds = list(JsonlStore(str(tmp_path / "mem" / "lcg_predictions.jsonl")).read_all())
    assert preds and preds[0]["confidence"] == "stop_recovery_candidate"
    assert preds[0]["predicted_answer"] == "", "a stop candidate is measured, never answered"


def test_the_stop_hook_is_silent_and_does_not_continue(tmp_path):
    p = run(STOP, {"session_id": "s", "last_assistant_message": "Worktree or branch? Your call."},
            {"LCG_STOP_DETECT": "1"}, home=tmp_path)
    assert p.returncode == 0 and p.stdout.strip() == ""


def test_stop_detection_is_off_by_default(tmp_path):
    run(STOP, {"session_id": "s", "last_assistant_message": "Worktree or branch? Your call."},
        home=tmp_path)
    assert not (tmp_path / "mem" / "lcg_stop_candidates.jsonl").exists()
