#!/usr/bin/env bash
# E2E for hooks/worktree-delegate-nudge.py. The bug it covers: the hook took a matching
# command STRING as proof, so a `bd create` whose issue description mentioned
# `git worktree add` told the orchestrator to hand work to a worker that did not exist, and
# listed tmux panes from an unrelated repo. Evidence now means a worktree that appeared.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
HOOK="$ROOT/hooks/worktree-delegate-nudge.py"
T="$(mktemp -d)"; trap 'rm -rf "$T" "$HOME/.claude/tmp/worktree-nudge/t-"*.json' EXIT
fail=0
ok()  { echo "ok   $1"; }
bad() { echo "FAIL $1"; [ $# -gt 1 ] && echo "     got:  ${2:-<empty>}"; fail=1; }

REPO="$T/repo"
git init -q "$REPO" && git -C "$REPO" -c user.name=t -c user.email=t@t commit -q --allow-empty -m init

fire() {   # sid, command, cwd -> the nudge text (empty when silent)
  jq -nc --arg s "$1" --arg c "$2" --arg w "$3" \
    '{session_id:$s,tool_name:"Bash",cwd:$w,tool_input:{command:$c}}' \
  | python3 "$HOOK" | jq -r '.hookSpecificOutput.additionalContext // ""' 2>/dev/null
}

# ── the false positives ───────────────────────────────────────────────────────────
out="$(fire t-a 'bd create --description "How: require a git worktree add that exited 0"' "$REPO")"
[ -z "$out" ] && ok "an issue description mentioning git worktree add is silent" || bad "mention fired" "$out"

out="$(fire t-b 'grep -rn "wt switch --create" scripts/' "$REPO")"
[ -z "$out" ] && ok "a grep for the command is silent" || bad "grep fired" "$out"

out="$(fire t-c 'git worktree add /nowhere/this-fails' "$REPO")"
[ -z "$out" ] && ok "a FAILED creation is silent (no worktree appeared)" || bad "failed cmd fired" "$out"

# ── the true positive ─────────────────────────────────────────────────────────────
fire t-d 'echo baseline' "$REPO" >/dev/null            # seed the snapshot
git -C "$REPO" worktree add -q -b feat/y "$REPO/.worktrees/feat-y" 2>/dev/null
out="$(fire t-d 'git worktree add .worktrees/feat-y' "$REPO")"
[[ "$out" == *"A worktree was just created"* ]] && ok "a real creation fires" || bad "real creation" "$out"
[[ "$out" == *"$REPO/.worktrees/feat-y"* ]] && ok "the nudge names the new worktree path" \
                                            || bad "path not named" "$out"
[[ "$out" == *"Read .claude/TASK.md and begin."* ]] && ok "it says what to send the worker" \
                                                    || bad "no instruction" "$out"

# ── it does not repeat itself ─────────────────────────────────────────────────────
out="$(fire t-d 'git worktree add .worktrees/feat-y' "$REPO")"
[ -z "$out" ] && ok "the same worktree does not fire twice" || bad "repeat nudge" "$out"

# ── a second, genuinely new worktree fires again ──────────────────────────────────
git -C "$REPO" worktree add -q -b feat/z "$REPO/.worktrees/feat-z" 2>/dev/null
out="$(fire t-d 'git worktree add .worktrees/feat-z' "$REPO")"
[[ "$out" == *"feat-z"* ]] && ok "a NEW worktree fires, naming that one" || bad "second creation" "$out"
[[ "$out" != *"feat-y"* ]] && ok "it does not re-list the old worktree" || bad "named the old one too" "$out"

# ── outside a git repo ────────────────────────────────────────────────────────────
out="$(fire t-e 'git worktree add ../x' "$T")"
[ -z "$out" ] && ok "outside a repo it is silent" || bad "fired outside a repo" "$out"

echo; [ $fail -eq 0 ] && echo "delegate nudge: PASS" || echo "delegate nudge: FAIL"
exit $fail
