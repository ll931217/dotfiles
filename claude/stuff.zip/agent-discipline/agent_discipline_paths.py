"""Resolve this machine's Claude Code global-memory directory at runtime.

Claude Code keys the global memory dir off $HOME with `/`, `.` and `_` replaced by `-`
(the same derivation memory-kit's own recall hook uses:
    GLOBAL_ENC = re.sub(r"[/._]", "-", HOME)
). Hardcoding the resolved name pins the whole plugin to one user, so every hook and
script imports from here instead.

Override with AGENT_DISCIPLINE_MEMORY_DIR when memory lives somewhere non-standard.
"""
import os
import re

__all__ = ["memory_dir", "topics_dir", "mem_file"]


def memory_dir() -> str:
    override = os.environ.get("AGENT_DISCIPLINE_MEMORY_DIR")
    if override:
        return os.path.expanduser(override)
    home = os.path.expanduser("~")
    enc = re.sub(r"[/._]", "-", home)
    return os.path.join(home, ".claude", "projects", enc, "memory")


def topics_dir() -> str:
    return os.path.join(memory_dir(), "topics")


def mem_file(name: str) -> str:
    """Path to a file directly under the memory dir, e.g. mem_file('blocker_log.tsv')."""
    return os.path.join(memory_dir(), name)
