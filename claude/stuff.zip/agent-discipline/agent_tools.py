"""Optional-tool adapters: worktrunk, beads and glab are conveniences, not requirements.

Each of the three has a fallback that needs nothing beyond git, python and a token:

    worktrunk (`wt`)  ->  git worktree add / remove, plus git branch -D
    beads (`bd`)      ->  jira.py search / edit
    glab              ->  GitLab REST v4 over urllib

The rule every adapter obeys: report WHICH path it took, and never report a fallback's narrower
result as the full one. A missing dependency must read as "this check did not run", never as
"this check passed" — the failure being prevented is silence.

    python3 agent_tools.py            # which tools are present, and what runs instead
    python3 agent_tools.py --json
"""
import json
import os
import shutil
import subprocess
import sys
import urllib.error
import urllib.parse
import urllib.request

__all__ = ["have", "backend", "sh", "gl_api", "gitlab_project", "gitlab_token",
           "worktree_add", "worktree_remove", "tasks_ready", "task_set_description",
           "JIRA", "ToolError"]

JIRA_CANDIDATES = (
    os.environ.get("JIRA_PY", ""),
    "~/Projects/llm_library/plugins/data-skills/skills/jira/scripts/jira.py",
    "~/GitLab/llm_library/plugins/data-skills/skills/jira/scripts/jira.py",
)


class ToolError(RuntimeError):
    """A backend failed, with a message naming the tool and the next action."""


def sh(cmd, cwd=None, timeout=120):
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
    return r.returncode, r.stdout.strip(), r.stderr.strip()


def have(tool):
    return shutil.which(tool) is not None


def JIRA():
    """First jira.py that exists, or None. Overridable with JIRA_PY so this is not pinned to
    one person's checkout layout.

    An explicit JIRA_PY that does not exist RAISES: falling through to the default location
    would silently use a different Jira config than the one the caller named."""
    env = os.environ.get("JIRA_PY")
    if env:
        p = os.path.expanduser(env)
        if not os.path.isfile(p):
            raise ToolError(f"JIRA_PY points at a file that does not exist: {p}")
        return p
    for c in JIRA_CANDIDATES[1:]:
        p = os.path.expanduser(c)
        if os.path.isfile(p):
            return p
    return None


# ── worktrees ────────────────────────────────────────────────────────────────────
def worktree_path(repo, branch):
    """Where a worktree for `branch` goes when nobody says: the layout wt itself uses."""
    return os.path.join(repo, ".worktrees", branch.replace("/", "-"))


def worktree_add(repo, branch, path=None, base=None, timeout=300):
    """(backend, path, error_or_None). wt when present -- it runs the user's post-start hook,
    which is what starts the worker session. git worktree cannot do that; the caller is told
    which backend ran so it can say so instead of implying a worker is coming."""
    path = path or worktree_path(repo, branch)
    if have("wt"):
        cmd = ["wt", "switch", "--create", branch, "--yes"] + (["--base", base] if base else [])
        rc, out, err = sh(cmd, cwd=repo, timeout=timeout)
        return "wt", path, None if rc == 0 else (err or out)
    # git needs a start point and a real directory; `base` is a branch name, local or remote.
    start = base or "HEAD"
    if base:
        rc, _, _ = sh(["git", "rev-parse", "--verify", "-q", base], cwd=repo)
        if rc != 0:
            rc2, _, _ = sh(["git", "rev-parse", "--verify", "-q", f"origin/{base}"], cwd=repo)
            start = f"origin/{base}" if rc2 == 0 else "HEAD"
    os.makedirs(os.path.dirname(path), exist_ok=True)
    rc, out, err = sh(["git", "worktree", "add", "-b", branch, path, start], cwd=repo,
                      timeout=timeout)
    return "git-worktree", path, None if rc == 0 else (err or out)


def worktree_remove(repo, path, branch=None, force=True):
    """(backend, error_or_None). The git fallback deletes the branch separately: `git worktree
    remove` leaves it behind, and a squash-merged branch needs -D."""
    if have("wt"):
        rc, out, err = sh(["wt", "remove", "-y", "--foreground", "-D", path], cwd=repo)
        return "wt", None if rc == 0 else (err or out)
    cmd = ["git", "worktree", "remove"] + (["--force"] if force else []) + [path]
    rc, out, err = sh(cmd, cwd=repo)
    if rc != 0:
        return "git-worktree", (err or out)
    if branch:
        rc2, out2, err2 = sh(["git", "branch", "-D", branch], cwd=repo)
        if rc2 != 0:
            return "git-worktree", f"worktree removed, branch {branch} kept: {err2 or out2}"
    return "git-worktree", None


# ── GitLab ───────────────────────────────────────────────────────────────────────
def gitlab_project(cwd="."):
    """URL-encoded project path from the origin remote, e.g. group%2Frepo. glab derives this
    itself via :id; the REST fallback has to be told."""
    rc, out, _ = sh(["git", "remote", "get-url", "origin"], cwd=cwd)
    if rc != 0 or not out:
        return None
    return urllib.parse.quote(_remote_path(out), safe="")


def _remote_path(url):
    """group/repo from any remote form. ANY scheme goes through urlparse -- testing only for
    "http" sent ssh://git@host:8022/group/repo down the scp-like branch and produced
    "git@host:8022/group/repo" as the project, which the API rejects."""
    if "://" in url:
        path = urllib.parse.urlparse(url).path
    elif "@" in url and ":" in url:                  # scp-like: git@host:group/repo.git
        path = url.split(":", 1)[1]
    else:
        path = url
    return path.strip("/").removesuffix(".git")


def gitlab_host(cwd="."):
    env = os.environ.get("GITLAB_HOST")
    if env:
        # glab's own GITLAB_HOST is conventionally bare ("gitlab.example.com"). Passing that
        # to urllib produces "unknown url type", so normalise instead of trusting the shape.
        env = env.rstrip("/")
        return env if "://" in env else f"https://{env}"
    rc, out, _ = sh(["git", "remote", "get-url", "origin"], cwd=cwd)
    if rc != 0 or not out:
        return None
    if out.startswith(("http://", "https://")):
        u = urllib.parse.urlparse(out)
        return f"{u.scheme}://{u.netloc}"
    # ssh://, git://, or scp-like. The API is HTTPS whatever git speaks, and the SSH port
    # (:8022 here) must not travel with the host.
    rest = out.split("://", 1)[-1]
    hostpart = rest.split("@", 1)[-1].split("/", 1)[0].split(":", 1)[0]
    return f"https://{hostpart}" if hostpart else None


def gitlab_token():
    """Env first, then gopass. Returns (token, source) or (None, why-not) -- the caller prints
    the why-not, so a missing token never looks like an empty API result."""
    for var in ("GITLAB_TOKEN", "GLAB_TOKEN", "CI_JOB_TOKEN"):
        if os.environ.get(var):
            return os.environ[var], f"${var}"
    slot = os.environ.get("GITLAB_TOKEN_GOPASS", "vici/gitlab/api_token")
    if have("gopass"):
        rc, out, _ = sh(["gopass", "show", "-o", slot], timeout=20)
        if rc == 0 and out:
            return out, f"gopass {slot}"
    return None, ("no token: set GITLAB_TOKEN, or store one at "
                  f"`gopass insert {slot}` (override the slot with GITLAB_TOKEN_GOPASS)")


def gl_api(path, method="GET", fields=None, cwd=".", timeout=30):
    """One GitLab call. `glab api <path>` when glab is present, else REST v4 directly.

    `path` is glab's own form, with or without a leading `projects/:id`; `:id` is substituted
    with the project resolved from the remote. Returns parsed JSON (dict/list), or raises
    ToolError naming what to fix.
    """
    if have("glab"):
        cmd = ["glab", "api", path]
        if method != "GET":
            cmd += ["-X", method]
        for k, v in (fields or {}).items():
            cmd += ["-f", f"{k}={v}"]
        rc, out, err = sh(cmd, cwd=cwd, timeout=timeout)
        if rc != 0:
            raise ToolError(f"glab api {path} failed: {err or out}")
        return json.loads(out) if out else None

    proj = gitlab_project(cwd)
    if not proj:
        raise ToolError("no origin remote, so the project cannot be resolved for the REST API")
    host = gitlab_host(cwd)
    if not host:
        raise ToolError("cannot derive the GitLab host from origin; set GITLAB_HOST")
    token, src = gitlab_token()
    if not token:
        raise ToolError(f"glab is not installed and {src}")

    url = f"{host}/api/v4/{path.lstrip('/').replace('projects/:id', f'projects/{proj}', 1)}"
    data = urllib.parse.urlencode(fields).encode() if fields else None
    req = urllib.request.Request(url, data=data, method=method,
                                 headers={"PRIVATE-TOKEN": token})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body = r.read().decode()
    except urllib.error.HTTPError as e:
        raise ToolError(f"GitLab API {method} {url} -> {e.code} {e.reason} "
                        f"(token from {src})") from None
    except urllib.error.URLError as e:
        raise ToolError(f"GitLab API unreachable at {host}: {e.reason}") from None
    return json.loads(body) if body else None


# ── tasks ────────────────────────────────────────────────────────────────────────
def tasks_ready(repo):
    """(backend, issues, note). issues: [{id, title, priority}]. The jira fallback CANNOT see
    a dependency graph, so `note` says which check did not run -- reporting a narrower answer
    as the same answer is the failure this exists to avoid."""
    if have("bd") and os.path.isdir(os.path.join(repo, ".beads")):
        rc, out, err = sh(["bd", "ready", "--json"], cwd=repo)
        if rc != 0:
            raise ToolError(f"bd ready failed: {err or out}")
        rows = json.loads(out or "[]")
        return "bd", [{"id": r.get("id"), "title": r.get("title"),
                       "priority": r.get("priority")} for r in rows], None
    jira = JIRA()
    if not jira:
        raise ToolError("no bd and no jira.py — install beads, or set JIRA_PY to jira.py")
    jql = os.environ.get(
        "AGENT_TASKS_JQL",
        'assignee = currentUser() AND statusCategory != Done ORDER BY priority DESC')
    # jira.py search takes the JQL positionally and always prints JSON
    # ({"count": n, "issues": [...]}) -- there is no --json flag, and passing one makes it
    # exit on argparse rather than search.
    rc, out, err = sh([sys.executable, jira, "search", jql,
                       "--limit", os.environ.get("AGENT_TASKS_LIMIT", "50")], timeout=180)
    if rc != 0:
        raise ToolError(f"jira.py search failed: {err or out}")
    try:
        rows = json.loads(out or "[]")
    except json.JSONDecodeError:
        raise ToolError("jira.py search returned non-JSON") from None
    rows = rows.get("issues", rows) if isinstance(rows, dict) else rows
    return "jira", [{"id": r.get("key"), "title": (r.get("summary") or "")[:120],
                     "priority": r.get("priority")} for r in rows], (
        "jira has no dependency graph: 'ready' here means assigned and not done. "
        "Blocked-by relationships were NOT checked.")


def task_set_description(task_id, text, repo="."):
    if have("bd") and os.path.isdir(os.path.join(repo, ".beads")):
        rc, out, err = sh(["bd", "update", task_id, "--description", text], cwd=repo)
        return "bd", None if rc == 0 else (err or out)
    jira = JIRA()
    if not jira:
        return None, "no bd and no jira.py — nothing can be updated"
    rc, out, err = sh([sys.executable, jira, "edit", task_id, "--description", text])
    return "jira", None if rc == 0 else (err or out)


# ── report ───────────────────────────────────────────────────────────────────────
def _jira_quiet():
    """JIRA() without the raise — the status report must render even when JIRA_PY is wrong."""
    try:
        return JIRA()
    except ToolError:
        return None


def backend():
    """What would run right now, per capability."""
    tok, tok_src = gitlab_token()
    return {
        "worktree": {"tool": "wt" if have("wt") else "git worktree",
                     "preferred_present": have("wt"),
                     "note": None if have("wt") else
                     "git worktree cannot run worktrunk's post-start hook, so no worker "
                     "session starts automatically; dispatch prints the command instead"},
        "tasks": {"tool": "bd" if have("bd") else ("jira.py" if _jira_quiet() else None),
                  "preferred_present": have("bd"),
                  "note": None if have("bd") else
                  "jira has no dependency graph: blocked-by is not checked"},
        "gitlab": {"tool": "glab" if have("glab") else ("REST v4" if tok else None),
                   "preferred_present": have("glab"),
                   "note": None if have("glab") else
                   (f"token from {tok_src}" if tok else tok_src)},
    }


def main(argv):
    b = backend()
    if "--json" in argv:
        print(json.dumps(b, indent=2))
        return 0
    print("\nagent-discipline optional tools\n")
    for cap, d in b.items():
        mark = "✓" if d["preferred_present"] else ("→" if d["tool"] else "✗")
        print(f"  {mark} {cap:9} {d['tool'] or 'UNAVAILABLE'}")
        if d["note"]:
            print(f"      {d['note']}")
    print("\n  ✓ preferred tool present   → fallback in use   ✗ neither available")
    return 0 if all(d["tool"] for d in b.values()) else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
